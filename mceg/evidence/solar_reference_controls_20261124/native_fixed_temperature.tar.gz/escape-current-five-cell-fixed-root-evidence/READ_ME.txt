Prescribed-temperature native five-cell root (2026-11-24)

Scope
This is a numerically converged fixed-temperature SolarAtmosphereModel state,
not a thermal-equilibrium result. The original full infinity-norm criterion
1e-9 was satisfied (1.1367218277769098e-10). The independently evaluated
physical/domain/wind flags and a coarse finite observer are recorded in
receipt.json and diagnosis.json. Spatial convergence, a resolved observed
spectrum, Cloudy/Yapeng equivalence, and NUTS are not established here.

Contents
root.npz and profile.npz record the result; spectrum.npz is only the 101-point,
2x2-disk finite-output check. Five accepted_step/step pairs and history.json
retain the actual fixed-temperature trajectory. Inverse secant matrices and
Krylov bases are excluded; they were numerical preconditioners, not a changed
residual or acceptance tolerance. preconditioner_handoff.json documents that
mapping. Initial states and element/atom identity mapping are retained.
The original diagnostic script failed while tracing because it accessed a
Solar dict as a NamedTuple. The failed script/log are preserved separately;
corrected diagnosis succeeded and did not alter the running main solver.

The fixed and initial wind checks compare the same T/mu profile on several
wind grids. non_equilibrium_thermal_trial_flow_resolution.json additionally
records only the flow-resolution check of one later candidate, whose full
F infinity was .3672583743094293. It is explicitly NOT a thermal root. No
subsequent complete-thermal result is included in this fixed-T archive.
Fe redistribution heat is a direct signed channel; its small magnitude does
not bound indirect Fe/Ca or radiation feedback. Signed channel ledgers and
explicit H gross heating/cooling are distinguished; do not relabel their
combination as the Cloudy total Gamma/Lambda grouping.

Reproduction
Restore escape at 4473ed7f2344e8edba012477e05c34b6c7da56a2 and ExoJAX at
38cb2e44f153ad6d729e3253e235702de52920cf. SOURCE_MANIFEST.json and
exojax_source_hashes.json pin every used package source/data file. All 284
ExoJAX package files were verified byte-identical against the latter Git
revision (EXOJAX_TREE_MATCH.json); this does not infer the export's history.
The source and packaged atomic data are deliberately not duplicated here.
Install the recorded dependencies (environment.json), and prepend the two
checkout src directories to PYTHONPATH.

Fetch the external PHOENIX FITS inputs using fetch_stellar_data.py, then run
convert_stellar_data.py; see stellar_metadata.json for URLs, hashes, units,
and the declared LTE stellar proxy. Original FITS, sampled stellar flux,
radiation-boundary arrays and compiler IR/cache are NOT distributed here.
With the resulting exact input, run:

  python replay_fixed_root.py --stellar-data /path/phoenix10000_surface_flux.npz --output /tmp/current5-replay --verify-only
  python replay_fixed_root.py --stellar-data /path/phoenix10000_surface_flux.npz --output /tmp/current5-replay

The first command's hash verification was executed successfully. The second
is the same physical diagnostic as executed_diagnostic.py: its evaluate
function is AST-identical, while paths/input verification were made portable.
The already executed diagnostic is documented by diagnostic_jobs.json and
diagnosis.log. A second expensive physics replay was not performed merely to
rename paths. The recorded offline NIST row prevents a live database query.
The original executed_solver.py contains scratch paths and is retained as
provenance, not presented as a portable cold-start inference application.

All NPZ contents are listed in NPZ_CONTENTS.json. The archive includes no
source/data duplication, raw stellar arrays, compiled binaries or Krylov cache.
