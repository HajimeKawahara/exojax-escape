"""Inspect a recorded native root without exporting the stellar radiation arrays."""
from pathlib import Path
from hashlib import sha256
from unittest.mock import patch
import argparse,json,time
import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd
from escape.solar import SolarAtmosphereModel
from escape.hydrogen_rates import LIGHT_SPEED_CGS
jax.config.update('jax_enable_x64',True)
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--state',type=Path,default=ROOT/'root.npz');parser.add_argument('--configuration',type=Path,default=ROOT/'configuration.json');parser.add_argument('--stellar-data',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--blend',type=float,default=0.);parser.add_argument('--verify-only',action='store_true');args=parser.parse_args();start=time.time();args.output.mkdir(exist_ok=True)
import escape,exojax
for package,manifest in [(Path(escape.__file__).resolve().parent.parent,json.loads((ROOT/'SOURCE_MANIFEST.json').read_text())['files']),(Path(exojax.__file__).resolve().parent.parent.parent,json.loads((ROOT/'exojax_source_hashes.json').read_text()))]:
 for name,expected in manifest.items():
  if sha256((package/name).read_bytes()).hexdigest()!=expected:raise ValueError('Source differs: '+name)
config=json.loads(args.configuration.read_text());sedpath=args.stellar_data;sed=np.load(sedpath)
assert sha256(sedpath.read_bytes()).hexdigest()==config['raw_sed_sha256']
if args.verify_only:
 print('Verified source/data trees and exact stellar input.',flush=True)
 raise SystemExit(0)
nist=json.loads((ROOT/'nist_row.json').read_text())['row']
with patch('exojax.database.nist.api.fetch_nist_lines',lambda *a,**kw:(pd.DataFrame(nist),[])):
 model=SolarAtmosphereModel(config['edges_rp'],nmax=config['nmax'],iron_levels=config['iron_levels'],sulfur_levels=config['sulfur_levels'],iron_lyalpha=True,shielding_model='continuous_core',core_escape_model='continuous',quadrature_order=2,angle_order=2,dense_lower_cells=2,lower_temperature_k=4500.,line_sampling='average',line_quadrature_order=4,wind_ngrid=config['wind_ngrid'],tidal_coefficient_s2=3*(2*np.pi/(1.48*86400))**2,extra_frequency_edges=sed['frequency_hz'][[0,-1]],observer_options=dict(nlon=2,nlat=2,nnu=101))
boundary=model.stellar_boundary(sed['frequency_hz'],sed['surface_flux_nu'],incident_flux_ratio=.1,outside_zero=True)
reference=jnp.asarray(config['temperature_reference_k']);state=np.load(args.state)['state'].ravel()
print('constructed diagnostic',time.time()-start,flush=True)
def evaluate(value):
 f,p=model.evaluate_atmosphere(value,reference,config['mass_loss_g_s'],boundary['incident_mean_intensity'],hydrogen_line_intensity=boundary['hydrogen_line_intensity'],metal_line_intensity=boundary['metal_line_intensity'],overlap_intensity=boundary['overlap_intensity'],thermal_blend=args.blend)
 e=p['iron_lyalpha_exchange']
 selected=['temperature_k','n_h_cm3','mean_molecular_weight','radial_velocity_kms','pressure_dyn_cm2','bound_cm3','electron_cm3','proton_cm3','molecule_cm3','helium_cm3','metal_ion_cm3']
 return dict(residual_norm=jnp.max(jnp.abs(f)),valid=p['valid'],reference_domain_valid=p['reference_domain_valid'],wind=p['wind_info'],profile={k:p[k] for k in selected},thermal_ledger=p['thermal_ledger'],thermal_net=p['thermal_net'],thermal_scale=p['thermal_scale'],advection=p['thermal_advection'],expansion=p['thermal_expansion'],hydrogen_heating=p['radiation']['thermal_heating_erg_cm3_s'],hydrogen_cooling=p['radiation']['thermal_cooling_erg_cm3_s'],metal_energy=p['metal']['energy_erg_cm3_s'],metal_line_heat_by_atom=p['metal']['collision_heat_by_atom_erg_cm3_s'],helium_heating=p['helium']['thermal_heating'],helium_cooling=p['helium']['thermal_cooling'],iron=dict(net_photons_sum_cm3_s=e['net_photons_cm3_s'].sum(1),absolute_photons_sum_cm3_s=jnp.abs(e['net_photons_cm3_s']).sum(1),hydrogen_upward_s=e['hydrogen_upward_s'],hydrogen_downward_s=e['hydrogen_downward_s'],redistribution_heat_erg_cm3_s=e['redistribution_heat_erg_cm3_s'],width_cm_s=e['width_cm_s'],maximum_width_residual=e['maximum_width_residual'],active=e['active'],selection_distance=e['selection_distance'],valid=e['valid']))
r=jax.jit(evaluate)(state)
profile={k:np.asarray(v) for k,v in r.pop('profile').items()};np.savez_compressed(args.output/'profile.npz',radius_cm=np.asarray(model.radius_cm),**profile)
result=jax.tree.map(lambda a:np.asarray(a).tolist(),r)
if float(r['residual_norm'])<1e-9 and bool(r['valid']):
    physical=model.unpack(jnp.asarray(state.reshape(model.cells,-1)[:,1:]),jnp.asarray(profile['n_h_cm3']))
    physical['atomic_lte_mask']=model.atomic_lte_mask
    frequency=jnp.asarray(model.observer.wavenumber_cm)*LIGHT_SPEED_CGS
    chi,eta=model.continuum_coefficients_at(jnp.asarray(profile['temperature_k']),physical,frequency)
    contrast=np.asarray(model.observer.spectrum_from_profiles(jnp.asarray(profile['bound_cm3'][::-1]),jnp.asarray(profile['temperature_k'][::-1]),jnp.asarray(profile['radial_velocity_kms'][::-1]),continuum_extinction=chi[::-1],continuum_emission=eta[::-1]*LIGHT_SPEED_CGS))
    np.savez_compressed(args.output/'spectrum.npz',wavenumber_cm=np.asarray(model.observer.wavenumber_cm),contrast=contrast)
    result['coarse_observer']=dict(finite=bool(np.isfinite(contrast).all()),minimum_contrast=float(np.min(contrast)),maximum_contrast=float(np.max(contrast)),scope='101 frequencies and 2x2 disk points; finite-output guard only. Thermal equilibrium, observer resolution, phase processing and data fit are not established.')
decay=profile['bound_cm3'][:,2]*float(model.hydrogen.atom.einstein_a_s[model.hydrogen_lyalpha_index])
result['iron']['net_exchange_per_hydrogen_spontaneous_decay']=np.divide(np.asarray(r['iron']['net_photons_sum_cm3_s']),decay,out=np.zeros_like(decay),where=decay>0).tolist()
result['iron']['width_scope']='Cell-averaged width; maximum_width_residual is the maximum over all cell nodes. The signed net-exchange/spontaneous-decay ratio is a derived photon ledger, not the continuum-destruction probability.'
heat=np.asarray(r['iron']['redistribution_heat_erg_cm3_s'])
result['iron_heat_ratios']={k:np.divide(heat,np.asarray(r[k]),out=np.full_like(heat,np.nan),where=np.asarray(r[k])!=0).tolist() for k in ['hydrogen_heating','hydrogen_cooling','thermal_scale']}
result.update(metal_atom_specs=model.metal.atom_specs,blend=args.blend,state_sha256=sha256(args.state.read_bytes()).hexdigest(),configuration_sha256=sha256(args.configuration.read_bytes()).hexdigest(),source_revision='4473ed7f2344e8edba012477e05c34b6c7da56a2',raw_stellar_data_included=False,ratio_scope='Explicit hydrogen heating/cooling and model residual scale. The signed multi-species net ledger is not relabeled as gross total Gamma/Lambda.',elapsed_s=time.time()-start)
(args.output/'diagnosis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
