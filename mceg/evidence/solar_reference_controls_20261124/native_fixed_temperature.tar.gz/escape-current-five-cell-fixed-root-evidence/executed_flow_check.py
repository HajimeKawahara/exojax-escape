"""Audit current checkpoint flow derivatives without recomputing radiation.

Use the actual Solar and metal unpack methods projected onto conserved
particle counts. Excitation fractions cannot affect mu within a given ion.
The checkpoint need not be an equilibrium: its convergence scope is retained
by the calling continuation receipt, not inferred by this resolution check.
"""
from pathlib import Path
from hashlib import sha256
from types import SimpleNamespace,MethodType
import argparse,json,time
import jax
import jax.numpy as jnp
import numpy as np
from escape.solar import SolarCompositionModel,SOLAR_ABUNDANCE,HELIUM_ABUNDANCE,ATOMIC_MASS_G
from escape.metal_network import ELEMENTS,MetalNetwork
from escape.helium import GroundHelium
from escape.hydrogen_forward import PLANET_RADIUS_CM,PLANET_MASS_MJ
from escape.atmosphere_wind import wind_from_profiles,thermal_flow_terms
jax.config.update('jax_enable_x64',True)
parser=argparse.ArgumentParser();parser.add_argument('--state',type=Path,required=True);parser.add_argument('--configuration',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--grids',type=int,nargs='+',default=[129,257,513]);args=parser.parse_args();start=time.time()
configuration=json.loads(args.configuration.read_text());state=np.load(args.state)['state'];cells=state.shape[0]
model=object.__new__(SolarCompositionModel);model.hydrogen_size=int(configuration['nmax'])+3;model.cells=cells
model.helium_slice=slice(model.hydrogen_size+4,model.hydrogen_size+6);model.metal_slice=slice(model.hydrogen_size+6,None)
model.abundance=jnp.array([SOLAR_ABUNDANCE[z] for z,_ in ELEMENTS]);model.mass_per_h=ATOMIC_MASS_G*(1.00794+4.002602*HELIUM_ABUNDANCE+sum(m*SOLAR_ABUNDANCE[z] for z,m in ELEMENTS))
model.molecule_nuclei=jnp.array([1.,2.,2.,2.]);model.helium=SimpleNamespace(unpack=GroundHelium.unpack)
model.metal=SimpleNamespace(atom_specs=(),excitation_slices=());model.metal.unpack=MethodType(MetalNetwork.unpack,model.metal)
mu=model.unpack(jnp.asarray(state[:,1:]),jnp.ones(cells))['mean_molecular_weight']
temperature=np.asarray(configuration['temperature_reference_k'])*np.exp(state[:,0]);edges=np.asarray(configuration['edges_rp']);radius=.5*(edges[1:]+edges[:-1])*PLANET_RADIUS_CM
knots=np.r_[PLANET_RADIUS_CM,radius];knot_t=np.r_[configuration['lower_temperature_k'],temperature];knot_mu=jnp.r_[mu[0],mu]
rows=[]
for ngrid in args.grids:
    w,info=wind_from_profiles(knots,knot_t,knot_mu,configuration['mass_loss_g_s'],PLANET_MASS_MJ,base_radius_cm=PLANET_RADIUS_CM,outer_radius_cm=32*PLANET_RADIUS_CM,tidal_coefficient_s2=3*(2*np.pi/(1.48*86400))**2,ngrid=ngrid,return_info=True)
    flow=thermal_flow_terms(knots,w.density_g_cm3,knot_t,knot_mu,w.velocity_kms*1e5,log_velocity_gradient_cm1=info['log_velocity_gradient_cm1'],sound_squared_gradient_cm_s2=info['sound_squared_gradient_cm_s2'])
    rows.append(dict(ngrid=ngrid,wind_valid=bool(info['valid']),wind_converged=bool(info['converged']),wind_residual=float(info['residual_norm']),advection=np.asarray(flow.advection)[1:].tolist(),expansion=np.asarray(flow.expansion)[1:].tolist(),velocity_kms=np.asarray(w.velocity_kms)[1:].tolist()))
for row in rows:
    for key in ['advection','expansion','velocity_kms']:
        a,b=np.asarray(row[key]),np.asarray(rows[-1][key]);mask=abs(b)>max(abs(b))*1e-12
        row[key+'_relative_to_finest']=float(np.max(abs((a[mask]-b[mask])/b[mask])))
result=dict(state=str(args.state),state_sha256=sha256(args.state.read_bytes()).hexdigest(),configuration_sha256=sha256(args.configuration.read_bytes()).hexdigest(),temperature_k=temperature.tolist(),mean_molecular_weight=np.asarray(mu).tolist(),grids=rows,source_revision='4473ed7f2344e8edba012477e05c34b6c7da56a2',checkpoint_equilibrium_not_assessed=True,elapsed_s=time.time()-start)
args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
