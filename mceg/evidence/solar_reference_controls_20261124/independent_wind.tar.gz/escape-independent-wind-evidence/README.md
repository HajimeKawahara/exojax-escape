# Independent wind and energy-gradient reference

This bundle verifies a numerical component. It does not contain an accepted solar atmosphere, a completed Cloudy thermal/wind fixed point, or the unpublished Yapeng/Zhang model inputs. The two prescribed temperature/composition profiles are kept distinct.

| Profile | Evidence | Conclusion |
|---|---|---|
| Original five-cell initial profile, plus fixed base knot | Native 129-node wind versus independent adaptive ODE: velocity 0.0523%, expansion cooling 0.6553% maximum error; native 65 expansion error 1.1439% | Supports the 129-node choice for this initial profile only |
| 1000-node temperature/composition from an explicitly unconverged solar warm start | Native129/257/513/1025 expansion errors21.14/10.62/12.50/17.17% against independent ODE, inside actual Cloudy zone coverage | A small spectral collocation residual and converged velocities do not establish resolved energy gradients for this sharply varying forcing |
| Independent external solver, 1000-node input | Refined sonic start, integration tolerance and step: velocity 0.000553%, expansion 0.00620% | Supports the independent wind reference on this prescribed input; it does not support thermal equilibrium |

The maximum errors are relative to the finer/independent target. No arbitrary population or rate floor is used. The five-cell outer knot has exactly zero prescribed pressure derivative, hence zero advection; that quantity has a separately reported absolute roundoff error rather than an undefined relative error. The original 1000-point report's `max_pressure_gradient_difference` divided by a vanishing derivative and is not a valid relative accuracy metric; `coverage_comparison.json` corrects it with the natural scale a²/r (agreement 4.10e−15).

## Equations and numerical construction

Let z=ln(r/Rp), w=ln(v), and a²=kBT/(μmH). The prescribed ln(T/μ) is a cubic Hermite function of ln(r): centered secant slopes at internal knots, zero endpoint slopes, and constant continuation beyond the profile. With a prime denoting d/dz,

```math
\frac{dw}{dz}=\frac{H(z)}{v^2-a^2},\qquad
H=2a^2-(a^2)'-\frac{GM_p}{r}+\kappa r^2.
```

At the sonic point H=0 and v²=a². The regular slope p=dw/dz is the accelerating root of

```math
2a_c^2p^2-(a_c^2)'p-H'_c=0.
```

The external verifier locates the unique bracket, initializes just inside/outside the sonic point, and integrates each branch with SciPy DOP853. Refinement changes the sonic offset, ODE tolerance and maximum log-radius step. The mass density and flow energy terms are

```math
\rho=\frac{\dot M}{4\pi r^2v},\quad
q_{adv}=-\frac32\rho v\frac{da^2}{dr},\quad
q_{exp}=-\rho a^2v\left(\frac2r+\frac{d\ln v}{dr}\right).
```

An external thermal inner loop keeps density and velocity fixed while recomputing da²/dr from the current temperature and composition. Logarithmic wind relaxation must blend dln(v)/dr with the same weight as ln(v). The outer update requires both the old velocity/density criterion and an explicit change in flow energy, normalized by Γ+Λ+|qadv|+|qexp|, below 1%. The prospective reference accuracy is separately 1%; the CLI's public-sunbather thermal proposal/default factor 1.1 is not an accuracy certificate. Acceptance still requires explicit thermal-factor and physical-profile refinement.

## Files and replay

`tools/` and the dedicated tests are the exact external-driver source from `bfd620c`; `src/escape/` is the isolated native wind source from `4473ed7`. Inputs contain only radius,T,μ and scalar wind parameters. Outputs are derived wind/flow diagnostics. There are no stellar arrays, SED/FITS files, Cloudy binaries, build caches or StableHLO dumps. Original scripts with their historical absolute paths are retained in `original_scripts/`; use `replay.py` for portable checks.

Use Python 3.12, NumPy, SciPy, pytest and ExoJAX commit `38cb2e44f153ad6d729e3253e235702de52920cf`. Running the native comparison also requires JAX with 64-bit enabled (the script does so). The verified environment used CPU. From this directory:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python replay.py --profile five --output /tmp/fresh-five-point-wind
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 JAX_PLATFORMS=cpu python replay.py --profile five --native-grid 129 --output /tmp/fresh-five-point-native
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python replay.py --profile thousand --output /tmp/fresh-thousand-point-wind
python -m pytest -q tests/test_cloudy_atmosphere_tool.py
```

Replace the example output paths with unused directories; existing results are deliberately refused. Supply `PYTHONPATH` for the pinned ExoJAX checkout if it is not installed. The external production driver retains its existing kB=1.380649e−16, while native ExoJAX uses 1.38064852e−16. Portable solver comparison explicitly matches the latter; original production-refinement receipts retain the former. The difference is recorded, not hidden in solver error.

`MANIFEST.json` hashes every included file except itself. The receipts preserve original input/source hashes, exact solver tolerances, test results and the restricted scientific scope. The original unfiltered atmosphere files remain private; only their hashes and the selected temperature/composition input are published.
