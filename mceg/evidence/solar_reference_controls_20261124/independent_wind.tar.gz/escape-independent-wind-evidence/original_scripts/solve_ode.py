"""Independent adaptive integration of the identical prescribed T/mu wind."""
from pathlib import Path
from hashlib import sha256
import json
import time

import numpy as np
from scipy.interpolate import CubicHermiteSpline
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
from exojax.utils.constants import G, MJ, kB

root = Path(__file__).parent
source_path = Path('/tmp/escape-continuation-solar-Fe716-thermal/iteration_000/profiles.npz')
source = dict(np.load(source_path))
r = source['radius_cm']
rp = r[0]
x = np.log(r)
y = np.log(source['temperature_k']/source['mean_molecular_weight'])
slope = np.r_[0., (y[2:]-y[:-2])/(x[2:]-x[:-2]), 0.]
curve = CubicHermiteSpline(x, y, slope)
mass = 2.17*MJ
kappa = 7.243193304369553e-9
mh = 1.67262192369e-24
upper = np.log(32.)

def coefficients(z):
    query = np.log(rp)+np.asarray(z)
    inside = (query>=x[0]) & (query<=x[-1])
    clipped = np.clip(query,x[0],x[-1])
    value = curve(clipped)
    first = np.where(inside,curve(clipped,1),0.)
    second = np.where(inside,curve(clipped,2),0.)
    a2 = kB/mh*np.exp(value)
    return a2, a2*first, a2*(second+first**2)

def numerator(z):
    a2, first, _ = coefficients(z)
    radius = rp*np.exp(z)
    return 2*a2-first-G*mass/radius+kappa*radius**2

scan = np.linspace(0.,upper,100001)
value = numerator(scan)
brackets = np.flatnonzero(value[:-1]*value[1:]<0)
if len(brackets)!=1:
    raise RuntimeError(f'The prescribed profile has {len(brackets)} scanned critical points.')
i = brackets[0]
critical = brentq(numerator,scan[i],scan[i+1],xtol=1e-14)
a2c, a2zc, a2zzc = coefficients(critical)
rc = rp*np.exp(critical)
hz = 2*a2zc-a2zzc+G*mass/rc+2*kappa*rc**2
p = (a2zc+np.sqrt(a2zc**2+8*a2c*hz))/(4*a2c)
if not p-.5*a2zc/a2c>0:
    raise RuntimeError('The selected critical point has no accelerating transonic branch.')

# With w=ln(v), dw/dz=H/(v^2-a^2). L'Hopital gives
# 2*a_c^2*p^2-(a_c^2)'*p-H'_c=0 for p=(ln v)'_c.
def equation(z,w):
    a2, _, _ = coefficients(z)
    return [float(numerator(z)/(np.exp(2*w[0])-a2))]

report = {'scope': 'Independent SciPy adaptive ODE integration with exactly the same1000-node log-Hermite T/mu, endpoint slopes0, constant exterior continuation, gravity and tide. Thermal equilibrium and authors inputs are not claimed.', 'variables': 'z=ln(r/Rp), w=ln(v[cm/s])', 'regularity_equation': '2 a_c^2 p^2 - (d a^2/dz)_c p - (dH/dz)_c = 0; choose p - .5 dln(a^2)/dz > 0', 'critical_radius_rp': float(rc/rp), 'critical_log_velocity_slope': float(p), 'critical_normalized_numerator':float(numerator(critical)/a2c), 'source_sha256':sha256(source_path.read_bytes()).hexdigest(), 'code_sha256':sha256(Path(__file__).read_bytes()).hexdigest(), 'constants':{'G':G,'MJ':MJ,'kB':kB,'proton_mass_g':mh}, 'cases':{}}
query = np.log(r/rp)
a2, az, _ = coefficients(query)
for epsilon in [1e-5,1e-6]:
    start=time.monotonic()
    lower=solve_ivp(equation,(critical-epsilon,0.),[.5*np.log(a2c)-p*epsilon],method='DOP853',rtol=1e-11,atol=1e-12,dense_output=True,max_step=.002)
    higher=solve_ivp(equation,(critical+epsilon,upper),[.5*np.log(a2c)+p*epsilon],method='DOP853',rtol=1e-11,atol=1e-12,dense_output=True,max_step=.002)
    if not lower.success or not higher.success:raise RuntimeError((lower.message,higher.message))
    w=np.empty_like(query)
    left=query<critical-epsilon;right=query>critical+epsilon;center=~(left|right)
    w[left]=lower.sol(query[left])[0];w[right]=higher.sol(query[right])[0];w[center]=.5*np.log(a2c)+p*(query[center]-critical)
    velocity=np.exp(w);rho=1e13/(4*np.pi*r**2*velocity)
    lgrad=numerator(query)/(velocity**2-a2)/r
    lgrad[center]=p/r[center]
    advection=-1.5*rho*velocity*az/r
    expansion=-rho*a2*velocity*(2/r+lgrad)
    name=f'ode_{epsilon:.0e}'
    np.savez(root/(name+'.npz'),radius_cm=r,velocity_cm_s=velocity,density_g_cm3=rho,log_velocity_gradient_cm1=lgrad,advection=advection,expansion=expansion)
    report['cases'][name]={'epsilon_log_radius':epsilon,'seconds':time.monotonic()-start,'lower_steps':len(lower.t),'upper_steps':len(higher.t),'lower_evaluations':lower.nfev,'upper_evaluations':higher.nfev,'maximum_mach_inner':float(np.max(velocity[query<critical]/np.sqrt(a2[query<critical]))),'minimum_mach_outer':float(np.min(velocity[query>critical]/np.sqrt(a2[query>critical])))}
    print(name,report['cases'][name],flush=True)
    (root/'ode_receipt.json').write_text(json.dumps(report,indent=2)+'\n')
a,b=[dict(np.load(root/f'ode_{epsilon:.0e}.npz')) for epsilon in [1e-5,1e-6]]
report['sonic_initialization_refinement']={key:float(np.max(abs(a[key]/b[key]-1))) for key in ['velocity_cm_s','expansion']}
(root/'ode_receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['sonic_initialization_refinement'],flush=True)
