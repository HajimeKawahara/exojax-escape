"""Refine the production offline ODE on the retained1000-node solar profile."""
from pathlib import Path
from hashlib import sha256
import json
import sys
import time
import numpy as np
sys.path.insert(0, '/tmp/escape-coupled-atmosphere/tools')
import cloudy_atmosphere as reference

root = Path(__file__).parent
path = Path('/tmp/escape-continuation-solar-Fe716-thermal/iteration_000/profiles.npz')
profile = dict(np.load(path))
r = profile['radius_cm']
results = []
report = {'scope': 'An independent wind/flow numerical control at a prescribed, explicitly unconverged solar temperature/composition profile. No new Cloudy atmosphere or thermal equilibrium is claimed.', 'source_sha256':sha256(path.read_bytes()).hexdigest(), 'driver_sha256':sha256(Path(reference.__file__).read_bytes()).hexdigest(), 'cases':{}}
for label,offset,tolerance,step in [('default',1e-6,1e-10,.002),('refined',1e-7,1e-11,.001)]:
    start=time.monotonic()
    wind, info = reference.adaptive_wind(r,profile['temperature_k'],profile['mean_molecular_weight'],1e13,2.17,32*r[0],7.243193304369553e-9,sonic_offset=offset,relative_tolerance=tolerance,max_log_step=step)
    flow = dict(profile, density_g_cm3=wind['density_g_cm3'], wind_density_g_cm3=wind['density_g_cm3'], wind_temperature_k=profile['temperature_k'], log_velocity_gradient_cm1=wind['log_velocity_gradient_cm1'])
    adv,exp,_ = reference.thermal_balance(flow,wind['velocity_cm_s'])
    wind.update(advection_erg_cm3_s=adv,expansion_erg_cm3_s=exp)
    np.savez(root/f'production_ode_{label}.npz',radius_cm=r,**wind)
    report['cases'][label]=dict(info,seconds=time.monotonic()-start)
    results.append(wind)
    (root/'production_ode_receipt.json').write_text(json.dumps(report,indent=2)+'\n')
    print(label,report['cases'][label],flush=True)
a,b=results
report['refinement']={key:float(np.max(abs(a[key]/b[key]-1))) for key in ['velocity_cm_s','density_g_cm3','expansion_erg_cm3_s']}
report['refinement']['all_within_one_percent']=all(x<.01 for x in report['refinement'].values())
(root/'production_ode_receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['refinement'],flush=True)
