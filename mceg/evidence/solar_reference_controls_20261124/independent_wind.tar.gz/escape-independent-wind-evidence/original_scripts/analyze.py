"""Use finite force/energy scales and the actual Cloudy coverage for diagnostics."""
from pathlib import Path
from hashlib import sha256
import json

import jax
jax.config.update('jax_enable_x64', True)
import jax.numpy as jnp
import numpy as np

from escape.atmosphere_wind import _effective_temperature
from escape.parker import PROTON_MASS_CGS
from exojax.utils.constants import kB

root = Path(__file__).parent
source = dict(np.load('/tmp/escape-continuation-solar-Fe716-thermal/iteration_000/profiles.npz'))
raw = dict(np.load('/tmp/escape-continuation-solar-Fe716-thermal/iteration_000/cloudy_profiles.npz'))
r = source['radius_cm']
mask = source['cloudy_mask'] & (r >= raw['radius_cm'].min()) & (r <= raw['radius_cm'].max())
params = (jnp.log(jnp.asarray(r)), jnp.log(jnp.asarray(source['temperature_k']/source['mean_molecular_weight'])))
derivative = np.asarray(jax.jit(jax.vmap(jax.grad(lambda radius: kB/PROTON_MASS_CGS*_effective_temperature(radius,params))))(r))
cases = {n:dict(np.load(root/f'wind_{n}.npz')) for n in [129,257,513,1025]}
force_scale = kB*source['temperature_k']/(PROTON_MASS_CGS*source['mean_molecular_weight']*r)
report = {'scope': 'Prescribed1000-node T/mu and a newly solved wind; no atmosphere equilibrium claim. Source default warmstart is not relabeled. Discretization comparisons use actual saved-zone coverage, excluding extrapolated endpoint states. No division by a vanishing pressure gradient: independent Hermite gradient error is normalized by the positive a^2/r force scale.', 'endpoint_metric_correction': 'The previous raw per-gradient relative error is ill-conditioned where the true gradient vanishes. This report supplies its finite physical normalization; original artifacts remain unchanged.', 'independent_pressure_gradient_error_over_a2_div_r': float(np.max(abs(derivative-cases[129]['pressure_gradient'])/force_scale)), 'coverage_radius_rp': [float(r[mask].min()/r[0]),float(r[mask].max()/r[0])], 'finite_difference_controls':{}, 'wind_refinement':{}}
for n,x in cases.items():
    error=(abs(x['finite_difference_advection']-x['advection'])+abs(x['finite_difference_expansion']-x['expansion']))/x['error_scale'];i=np.flatnonzero(mask)[np.argmax(error[mask])]
    report['finite_difference_controls'][str(n)]={'max_flow_error_over_total_budget':float(error[i]),'worst_radius_rp':float(r[i]/r[0]),'max_expansion_relative':float(np.max(abs(x['finite_difference_expansion'][mask]/x['expansion'][mask]-1)))}
for a,b in [(129,257),(257,513),(513,1025),(129,1025)]:
    lo,hi=cases[a],cases[b];error=(abs(lo['advection']-hi['advection'])+abs(lo['expansion']-hi['expansion']))/hi['error_scale'];i=np.flatnonzero(mask)[np.argmax(error[mask])]
    report['wind_refinement'][f'{a}_to_{b}']={'max_flow_error_over_total_budget':float(error[i]),'worst_radius_rp':float(r[i]/r[0]),'max_expansion_relative':float(np.max(abs(lo['expansion'][mask]/hi['expansion'][mask]-1))),'max_velocity_relative':float(np.max(abs(lo['velocity_cm_s'][mask]/hi['velocity_cm_s'][mask]-1)))}
report['code_sha256']=sha256(Path(__file__).read_bytes()).hexdigest()
(root/'coverage_comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
