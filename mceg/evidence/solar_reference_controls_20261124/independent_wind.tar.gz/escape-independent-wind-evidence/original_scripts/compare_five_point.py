"""Compare the recorded five-cell spectral wind to an independent adaptive ODE."""
from pathlib import Path
from hashlib import sha256
import json
import sys
import time
import numpy as np
from scipy.interpolate import CubicHermiteSpline

sys.path.insert(0, '/tmp/escape-coupled-atmosphere/tools')
import cloudy_atmosphere as reference
root = Path(__file__).parent
original = Path('/tmp/escape-five-cell-root-evidence/profile.npz')
p = dict(np.load(original))
names = ['wind_knot_radius_cm', 'wind_knot_temperature_k',
         'wind_knot_mean_molecular_weight', 'mass_loss_g_s', 'planet_mass_mj',
         'base_radius_cm', 'outer_radius_cm', 'tidal_coefficient_s2']
np.savez(root/'five_point_input.npz', **{key:p[key] for key in names})
r,t,mu = [p[key] for key in names[:3]]
x,y = np.log(r),np.log(t/mu)
slopes = np.r_[0.,(y[2:]-y[:-2])/(x[2:]-x[:-2]),0.]
curve = CubicHermiteSpline(x,y,slopes)
spectral_path = Path('/tmp/escape-flow-gradient-audit/resolution_1025.json')
spectral = json.loads(spectral_path.read_text())
report = {
 'scope':'Numerical wind comparison only at the original prescribed five-cell initial T/mu profile, including its fixed base knot. No solved thermal atmosphere or solar adequacy claim.',
 'comparison':'The five atmospheric knots; the fixed bottom knot is excluded exactly as in the saved spectral comparison. No interpolated/extrapolated comparison points.',
 'source_profile_sha256':sha256(original.read_bytes()).hexdigest(),
 'spectral_receipt_sha256':sha256(spectral_path.read_bytes()).hexdigest(),
 'driver_sha256':sha256(Path(reference.__file__).read_bytes()).hexdigest(),
 'spectral_source_revision':'4473ed7',
 'external_driver_revision':'bfd620c',
 'cases':{},
}
results={}
for label,kb,offset,tol,step in [
 ('production_default',1.380649e-16,1e-6,1e-10,.002),
 ('matched_constants',1.38064852e-16,1e-6,1e-10,.002),
 ('matched_constants_refined',1.38064852e-16,1e-7,1e-11,.001),
]:
 reference.KB=kb
 start=time.monotonic()
 wind,info=reference.adaptive_wind(r,t,mu,float(p['mass_loss_g_s']),float(p['planet_mass_mj']),float(p['outer_radius_cm']),float(p['tidal_coefficient_s2']),sonic_offset=offset,relative_tolerance=tol,max_log_step=step)
 a2=kb*t/(reference.MH*mu)
 rho,v=wind['density_g_cm3'],wind['velocity_cm_s']
 adv=-1.5*rho*v*a2*curve(x,1)/r
 exp=-rho*a2*v*(2/r+wind['log_velocity_gradient_cm1'])
 results[label]=dict(velocity_kms=v/1e5,advection=adv,expansion=exp)
 np.savez(root/f'five_point_ode_{label}.npz',radius_cm=r,**wind,advection=adv,expansion=exp)
 report['cases'][label]=dict(info,seconds=time.monotonic()-start)
 print(label,info['sonic_radius_cm'],flush=True)
ref=results['matched_constants_refined']
report['spectral_to_independent_ode']={}
for row in spectral:
 values={}
 for name in ['velocity_kms','advection','expansion']:
  a,b=np.asarray(row[name]),ref[name][1:]
  mask=b!=0
  values[name]=dict(max_relative_error=float(np.max(abs(a[mask]/b[mask]-1))),relative_error=(abs(a[mask]/b[mask]-1)).tolist(),nonzero_target_mask=mask.tolist(),zero_target_max_absolute_error=float(np.max(abs(a[~mask]-b[~mask]))) if np.any(~mask) else 0.)
 report['spectral_to_independent_ode'][str(row['ngrid'])]=values
report['ode_refinement']={name:float(np.max(abs(results['matched_constants'][name][1:][ref[name][1:]!=0]/ref[name][1:][ref[name][1:]!=0]-1))) for name in ref}
report['constant_change_effect']={name:float(np.max(abs(results['production_default'][name][1:][ref[name][1:]!=0]/results['matched_constants'][name][1:][ref[name][1:]!=0]-1))) for name in ref}
report['zero_target_note']='The final knot has exactly zero prescribed sound-speed derivative and therefore zero advection; its absolute error is reported separately, rather than defining a relative error by an arbitrary floor.'
report['constant_note']='The existing external driver uses kB=1.380649e-16; native ExoJAX uses 1.38064852e-16. Matched-constant diagnostic changes only the imported external module scalar during this process, not source or production defaults. Other constants are identical.'
(root/'five_point_independent_ode_receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['spectral_to_independent_ode','ode_refinement','constant_change_effect']},indent=2),flush=True)
