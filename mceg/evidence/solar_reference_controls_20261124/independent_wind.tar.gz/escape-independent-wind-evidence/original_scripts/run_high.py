"""Bound flow derivatives at the reference grid without changing old evidence."""
from pathlib import Path
from hashlib import sha256
import json
import time

import jax
jax.config.update('jax_enable_x64', True)
import numpy as np
from scipy.interpolate import CubicHermiteSpline

from escape.atmosphere_wind import wind_from_profiles
from escape.parker import PROTON_MASS_CGS
from exojax.utils.constants import kB

root = Path(__file__).parent
path = Path('/tmp/escape-continuation-solar-Fe716-thermal/iteration_000/profiles.npz')
source = dict(np.load(path))
r, temp, mu = (source[key] for key in ['radius_cm', 'temperature_k', 'mean_molecular_weight'])
x, y = np.log(r), np.log(temp/mu)
slopes = np.r_[0., (y[2:]-y[:-2])/(x[2:]-x[:-2]), 0.]
curve = CubicHermiteSpline(x, y, slopes)
a2 = kB*temp/(PROTON_MASS_CGS*mu)
a2_gradient = a2*curve(x, 1)/r
mask = source['cloudy_mask'].astype(bool) & np.isfinite(source['heating_erg_cm3_s'])
report = {'scope': 'A new conditional wind uses the frozen1000-node T/mu from an explicitly unconverged warmstart. Original warmstart velocity is not reused or relabeled. Pressure-gradient convention is independently evaluated with SciPy log-Hermite interpolation. Fixed physical radiative fields are used only as a derivative-error scale, not a thermal solution.', 'source_profiles_sha256': sha256(path.read_bytes()).hexdigest(), 'code_sha256': sha256(Path(__file__).read_bytes()).hexdigest(), 'samples': int(len(r)), 'cases': {}}
for ngrid in [513, 1025]:
    start = time.monotonic()
    wind, info = wind_from_profiles(r, temp, mu, 1e13, 2.17, base_radius_cm=float(r[0]), outer_radius_cm=float(32*r[0]), tidal_coefficient_s2=7.243193304369553e-9, ngrid=ngrid, return_info=True)
    rho, v = np.asarray(wind.density_g_cm3), np.asarray(wind.velocity_kms)*1e5
    gradient = np.asarray(info['log_velocity_gradient_cm1'])
    sound_gradient = np.asarray(info['sound_squared_gradient_cm_s2'])
    adv = -1.5*rho*v*a2_gradient
    exp = -rho*a2*v*(2/r+gradient)
    old_adv = -1.5*rho*v*np.gradient(a2, r)
    old_exp = a2*v*np.gradient(rho, r)
    scale = source['heating_erg_cm3_s']+source['cooling_erg_cm3_s']+abs(adv)+abs(exp)
    accepted = mask & np.isfinite(scale) & (scale>0)
    valid = bool(info['valid']) and bool(info['converged'])
    entry = {'valid_wind': valid, 'wind_residual_norm': float(info['residual_norm']), 'seconds': time.monotonic()-start}
    if valid:
        entry.update(max_pressure_gradient_difference=float(np.max(abs(sound_gradient-a2_gradient)/np.maximum(abs(a2_gradient), 1e-30))), max_old_vs_exact_expansion_relative=float(np.max(abs(old_exp[accepted]/exp[accepted]-1))), max_flow_error_over_radiative_and_flow_budget=float(np.max((abs(old_adv-adv)+abs(old_exp-exp))[accepted]/scale[accepted])))
    report['cases'][str(ngrid)] = entry
    np.savez(root/f'wind_{ngrid}.npz', radius_cm=r, density_g_cm3=rho, velocity_cm_s=v, advection=adv, expansion=exp, finite_difference_advection=old_adv, finite_difference_expansion=old_exp, log_velocity_gradient_cm1=gradient, pressure_gradient=a2_gradient, accepted_mask=accepted, error_scale=scale)
    (root/'receipt_high.json').write_text(json.dumps(report, indent=2)+'\n')
    print(ngrid, entry, flush=True)
if all(c['valid_wind'] for c in report['cases'].values()):
    lo, hi = [dict(np.load(root/f'wind_{n}.npz')) for n in [513,1025]]
    mask = lo['accepted_mask'] & hi['accepted_mask']
    report['wind_refinement'] = {'expansion_max_relative': float(np.max(abs(lo['expansion'][mask]/hi['expansion'][mask]-1))), 'velocity_max_relative': float(np.max(abs(lo['velocity_cm_s'][mask]/hi['velocity_cm_s'][mask]-1))), 'flow_error_over_budget_max': float(np.max((abs(lo['expansion']-hi['expansion'])+abs(lo['advection']-hi['advection']))[mask]/hi['error_scale'][mask]))}
    (root/'receipt_high.json').write_text(json.dumps(report, indent=2)+'\n')
    print(report['wind_refinement'], flush=True)
