"""Replay the independent ODE and optionally a frozen native spectral wind."""
from pathlib import Path
import argparse
import json
import sys
import numpy as np
from scipy.interpolate import CubicHermiteSpline

root=Path(__file__).parent
sys.path[:0]=[str(root/'tools'),str(root/'src')]
import cloudy_atmosphere as reference

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--profile',choices=['five','thousand'],default='five')
parser.add_argument('--native-grid',type=int,default=0,
                    help='Run the frozen native solver as well; e.g.129. Requires JAX and pinned ExoJAX.')
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
args.output.mkdir(parents=True,exist_ok=False)
p=dict(np.load(root/'input'/('five_point.npz' if args.profile=='five' else 'thousand_point.npz')))
if args.profile=='five':
 r,t,mu=[p[k] for k in ['wind_knot_radius_cm','wind_knot_temperature_k','wind_knot_mean_molecular_weight']]
else:r,t,mu=[p[k] for k in ['radius_cm','temperature_k','mean_molecular_weight']]
reference.KB=1.38064852e-16  # Match the recorded native ExoJAX constant explicitly.
x,y=np.log(r),np.log(t/mu)
curve=CubicHermiteSpline(x,y,np.r_[0.,(y[2:]-y[:-2])/(x[2:]-x[:-2]),0.])
a2=reference.KB*t/(reference.MH*mu)

def terms(wind):
 rho,v=wind['density_g_cm3'],wind['velocity_cm_s']
 return dict(advection=-1.5*rho*v*a2*curve(x,1)/r,
             expansion=-rho*a2*v*(2/r+wind['log_velocity_gradient_cm1']))

report={'scope':'Prescribed-profile wind numerical check only. No atmosphere equilibrium claim.',
        'profile':args.profile,'constant_convention':'Native-matched kB=1.38064852e-16', 'ode_cases':{}}
results={}
for name,offset,tol,step in [('default',1e-6,1e-10,.002),('refined',1e-7,1e-11,.001)]:
 wind,info=reference.adaptive_wind(r,t,mu,float(p['mass_loss_g_s']),float(p['planet_mass_mj']),float(p['outer_radius_cm']),float(p['tidal_coefficient_s2']),sonic_offset=offset,relative_tolerance=tol,max_log_step=step)
 wind.update(terms(wind));results[name]=wind
 report['ode_cases'][name]=info
 np.savez(args.output/f'ode_{name}.npz',radius_cm=r,**wind)
report['ode_refinement']={key:float(np.max(abs(results['default'][key]/results['refined'][key]-1))) for key in ['velocity_cm_s','density_g_cm3','expansion']}
if args.native_grid:
 import jax
 jax.config.update('jax_enable_x64',True)
 from escape.atmosphere_wind import wind_from_profiles
 w,info=wind_from_profiles(r,t,mu,float(p['mass_loss_g_s']),float(p['planet_mass_mj']),base_radius_cm=float(r[0]),outer_radius_cm=float(p['outer_radius_cm']),tidal_coefficient_s2=float(p['tidal_coefficient_s2']),ngrid=args.native_grid,return_info=True)
 native=dict(velocity_cm_s=np.asarray(w.velocity_kms)*1e5,density_g_cm3=np.asarray(w.density_g_cm3),log_velocity_gradient_cm1=np.asarray(info['log_velocity_gradient_cm1']))
 native.update(terms(native));np.savez(args.output/'native.npz',radius_cm=r,**native)
 mask=np.ones(len(r),dtype=bool)
 if args.profile=='five':mask[0]=False
 report['native']={'ngrid':args.native_grid,'converged':bool(info['converged']),'valid':bool(info['valid']),'residual':float(info['residual_norm']),'scope':'All prescribed query knots except the fixed base for the five-cell case; no original Cloudy-coverage mask is applied here.','relative_errors':{key:float(np.max(abs(native[key][mask]/results['refined'][key][mask]-1))) for key in ['velocity_cm_s','density_g_cm3','expansion']}}
(args.output/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
