// Original C23.01 source excerpts. Unmodified content; original line numbers follow.
// opacity_add1subshell.cpp:105-129
105: 	if( (DepartCoef > 1e-35 && rfield.lgInducProcess) && hydro.lgHInducImp )
106: 	{
107: 		iup = MIN2(ipHiEnergy,rfield.nflux);
108: 		/* >>>chng 99 apr 29, following was present, caused pdr to make opac at impossible energy*/
109: 		/*iup = MAX2(ipLowEnergy,iup);*/
110: 		double DepartCoefInv = 1./DepartCoef;
111: 		if( chStat == 'v' )
112: 		{
113: 			/* volitile opacities, always reevaluate */
114: 			for( i=ipLowEnergy-1; i < iup; i++ )
115: 			{
116: 				opac.opacity_abs[i] += opac.OpacStack[i+k]*abundance*
117: 					MAX2(0. , 1.-  rfield.ContBoltz[i]*DepartCoefInv);
118: 			}
119: 		}
120: 		else
121: 		{
122: 			/* static opacities, save in special array */
123: 			for( i=ipLowEnergy-1; i < iup; i++ )
124: 			{
125: 				opac.OpacStatic[i] += opac.OpacStack[i+k]*abundance*
126: 					MAX2(0. , 1.-  rfield.ContBoltz[i]*DepartCoefInv);
127: 			}
128: 		}
129: 	}
