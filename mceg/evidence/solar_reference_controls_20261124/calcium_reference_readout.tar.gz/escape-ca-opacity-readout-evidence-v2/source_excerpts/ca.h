// Original C23.01 source excerpts. Unmodified content; original line numbers follow.
// ca.h:33-47
33: 	  Cakh;
34: 
35: 	/** parameters dealing with dest of CaII by Lya */
36: 	realnum dstCala, 
37: 	  dCakh, 
38: 	  dCaf12, 
39: 	  Ca3d, 
40: 	  Ca4p;
41: 
42: 	/** summed pop of CaII excited states */
43: 	realnum popca2ex;
44: 
45: 	};
46: extern t_ca ca;
47: 
