// Original C23.01 source excerpts. Unmodified content; original line numbers follow.
// rt_ots.cpp:390-426
390: }
391: 
392: /* =================================================================== */
393: 
394: void RT_OTS_AddLine(double ots, 
395: 	/* pointer on the f scale */
396:   long int ip )
397: {
398: 
399: 	DEBUG_ENTRY( "RT_OTS_AddLine()" );
400: 
401: 	/* add ots due to line destruction to radiation field */
402: 
403: 	/* return if outside bounds of this continuum source, ip > rfield.nflux
404: 	 * first case ip==0 happens when called with dummy line */
405: 	if( ip==0 || ip > rfield.nflux )
406: 	{ 
407: 		return;
408: 	}
409: 
410: 	/*the local ots rate must be non-negative */
411: 	ASSERT( ots >= 0. );
412: 	/* continuum pointer must be positive */
413: 	ASSERT( ip > 0 );
414: 
415: 	/* add locally destroyed flux of photons to line OTS array */
416: 	/* check whether local gas opacity  (units cm-1) is positive, if so
417: 	 * convert line destruction rate into ots rate by dividing by it */
418: 	if( opac.opacity_abs[ip-1] > 0. )
419: 	{
420: 		rfield.otslin[ip-1] += (realnum)(ots/opac.opacity_abs[ip-1]);
421: 	}
422: 	/* first iteration is 1, second is two */
423: 	{
424: 		enum {DEBUG_LOC=false};
425: 		if( DEBUG_LOC && /*iteration == 2 && nzone>294 &&*/ ip== 2363 /*&& ots > 1e16*/)
426: 		{
