// Original C23.01 source excerpts. Unmodified content; original line numbers follow.
// ion_photo.cpp:158-213
158: 
159: 	/* Ly-alpha photoionization of Ca+
160: 	 * valence shell is reevaluated by ion_photo on every call, so this does not double count */
161: 	if( nelem == ipCALCIUM )
162: 	{
163: 
164: 		long id_Ca2;
165: 
166: 		if( (id_Ca2 = atmdat.ipSpecIon[nelem][1]) < 0 )
167: 		{
168: 			return;
169: 		}
170: 
171: 		// H I Lya OTS rates
172: 		double hlgam = rfield.otslin[ iso_sp[ipH_LIKE][ipHYDROGEN].trans(ipH2p,ipH1s).ipCont() -1];
173: 		double PhotoRate5 = 1.7e-18*hlgam,
174: 		PhotoRate4 = 8.4e-19*hlgam,
175: 		PhotoRate3 = 7.0e-18*hlgam,
176: 		PhotoRate2 = 4.8e-18*hlgam;
177: 
178: 		realnum dstCala = (realnum)(dBaseStates[id_Ca2][4].Pop()*PhotoRate5 +
179: 				dBaseStates[id_Ca2][3].Pop()*PhotoRate4);
180: 		realnum dCaf12 = (realnum)((dBaseStates[id_Ca2][2].Pop()*PhotoRate3 +
181: 				dBaseStates[id_Ca2][1].Pop()*PhotoRate2)*2.31e-12);
182: 
183: 		double denseCa2 = 0.;
184: 		for( long i = 0; i < dBaseSpecies[id_Ca2].numLevels_local; ++i)
185: 		{
186: 			denseCa2 += dBaseStates[id_Ca2][i].Pop();
187: 		}
188: 
189: 		/* total rate Lalpha destroys CaII,
190: 		 * this is only used in ioncali to increase ionization rate by
191: 		 * adding it to the ct vector */
192: 		if( denseCa2 > 0. )
193: 		{
194: 			dstCala = (realnum)(
195: 				(dstCala + dCaf12/2.31e-12)/denseCa2);
196: 			{
197: 				/*@-redef@*/
198: 				enum {DEBUG_LOC=false};
199: 				/*@+redef@*/
200: 				if( DEBUG_LOC )
201: 				{
202: 					fprintf(ioQQQ," hlgam is %e\n", hlgam);
203: 				}
204: 			}
205: 		}
206: 		else
207: 		{
208: 			dstCala = 0.;
209: 		}
210: 
211: 		long ns = 6, ion = 1;
212: 		ionbal.PhotoRate_Shell[nelem][ion][ns][0] += dstCala;
213: 	}
