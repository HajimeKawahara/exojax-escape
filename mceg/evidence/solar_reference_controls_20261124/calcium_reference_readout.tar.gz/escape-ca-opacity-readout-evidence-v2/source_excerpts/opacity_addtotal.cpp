// Original C23.01 source excerpts. Unmodified content; original line numbers follow.
// opacity_addtotal.cpp:313-325
313: 	OpacityAdd1Subshell(opac.ipo3exc3[2],opac.ipo3exc3[0],opac.ipo3exc3[1],
314: 	  dense.xIonDense[ipOXYGEN][2]*oxy.poiii3,'v');
315: 
316: 	/* magnesium opacity
317: 	 * excited level of Mg+ */
318: 	OpacityAdd1Subshell(opac.ipOpMgEx,opac.ipmgex,iso_sp[ipH_LIKE][ipHYDROGEN].fb[ipH1s].ipIsoLevNIonCon,
319: 		dense.xIonDense[ipMAGNESIUM][1]* atoms.popMg2,'v');
320: 
321: 	/* calcium opacity
322: 	 * photoionization of excited levels of Ca+ */
323: 	OpacityAdd1Subshell(opac.ica2op,opac.ica2ex[0],opac.ica2ex[1],
324: 	  ca.popca2ex,'v');
325: 
