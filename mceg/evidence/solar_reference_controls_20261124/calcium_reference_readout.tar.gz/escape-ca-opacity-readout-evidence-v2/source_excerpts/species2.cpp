// Original C23.01 source excerpts. Unmodified content; original line numbers follow.
// species2.cpp:1065-1099
1065: 	double hlgam,
1066: 	PhotoRate2,
1067: 	PhotoRate3,
1068: 	PhotoRate4,
1069: 	PhotoRate5;
1070: 
1071: 	/* photoionization of evcited levels by Ly-alpha */
1072: 	hlgam = rfield.otslin[ iso_sp[ipH_LIKE][ipHYDROGEN].trans(ipH2p,ipH1s).ipCont() -1];
1073: 	PhotoRate5 = 1.7e-18*hlgam;
1074: 	PhotoRate4 = 8.4e-19*hlgam;
1075: 	PhotoRate3 = 7.0e-18*hlgam;
1076: 	PhotoRate2 = 4.8e-18*hlgam;
1077: 
1078: 	if( tr.ipHi() + 1 == 2)
1079: 	{
1080: 		xtraDxRate += PhotoRate2;
1081: 	}
1082: 	else if( tr.ipHi() + 1 == 3 )
1083: 	{
1084: 		xtraDxRate += PhotoRate3;
1085: 	}
1086: 	else if( tr.ipHi() + 1 == 4 )
1087: 	{
1088: 		xtraDxRate += PhotoRate4;
1089: 	}
1090: 	else if( tr.ipHi() + 1 == 5 )
1091: 	{
1092: 		xtraDxRate += PhotoRate5;
1093: 	}
1094: 	else
1095: 	{
1096: 		xtraDxRate += 0.;
1097: 	}
1098: 	return;
1099: }
