// Original C23.01 source excerpts. Unmodified content; original line numbers follow.
// ca.cpp:1-20
1: /* This file is part of Cloudy and is copyright (C)1978-2023 by Gary J. Ferland and
2:  * others.  For conditions of distribution and use see copyright notice in license.txt */
3: #include "cddefines.h"
4: #include "ca.h"
5: t_ca ca;
6: 
7: void t_ca::zero()
8: {
9: 	Ca2RmLya = 0.;
10: 	popca2ex = 0.;
11: 	Ca3d = 0.;
12: 	Ca4p = 0.;
13: 	dstCala = 0.;
14: }
