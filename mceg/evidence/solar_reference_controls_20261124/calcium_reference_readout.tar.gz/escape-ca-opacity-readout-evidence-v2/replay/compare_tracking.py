"""Compare all saved numerical outputs of the readout-only binary."""
from pathlib import Path
import argparse,hashlib,json
p=argparse.ArgumentParser();p.add_argument('original',type=Path);p.add_argument('tracking',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
exclude={'model.in','model.out','console.txt','fe_ots_ledger.tsv','input_receipt.json','execution_receipt.json','scope.json'}
files=[p for p in a.original.iterdir() if p.is_file() and (p.name.startswith('model.') or p.name.startswith('history.')) and p.name not in exclude]
comparison={}
for f in files:
 other=a.tracking/f.name
 comparison[f.name]={'original_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'tracking_sha256':hashlib.sha256(other.read_bytes()).hexdigest() if other.exists() else None,'byte_identical':other.exists() and f.read_bytes()==other.read_bytes()}
report={'original':str(a.original),'tracking':str(a.tracking),'input_byte_identical':(a.original/'model.in').read_bytes()==(a.tracking/'model.in').read_bytes(),'saved_outputs':comparison,'all_saved_outputs_identical':bool(files) and all(r['byte_identical'] for r in comparison.values()),'scope':'Instrumentation validation only. Does not validate the reference model or establish numerical convergence.'}
a.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='saved_outputs'}))
if not(report['all_saved_outputs_identical'] and report['input_byte_identical']):raise SystemExit(1)
