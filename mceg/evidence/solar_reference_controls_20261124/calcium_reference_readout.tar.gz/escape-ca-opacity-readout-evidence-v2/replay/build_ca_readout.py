"""Read-only one-zone check of the legacy Ca excited-population opacity hook."""
from pathlib import Path
import subprocess,json,hashlib,difflib
root=Path(__file__).parent/'ca_readout';root.mkdir(exist_ok=True)
src=Path('/tmp/cloudy-reference-run/c23.01/source');original=(src/'rt_ots.cpp').read_text()
s=original.replace('#include "cosmology.h"','#include "cosmology.h"\n#include "ca.h"\n#include "atmdat.h"\n#include "radius.h"\n#include "phycon.h"')
anchor='''		(*diatom)->H2_RT_OTS();

	return;'''
assert s.count(anchor)==1
s=s.replace(anchor,'''        (*diatom)->H2_RT_OTS();

    const long calcium = atmdat.ipSpecIon[ipCALCIUM][1];
    if(calcium>=0 && dBaseSpecies[calcium].numLevels_local>=5){
        static FILE* f=open_data("ca_opacity_readout.tsv","w");
        static bool first=true;
        if(first){fprintf(f,"# iteration zone depth_cm T_K ne_cm3 legacy_excited_cm3 actual_first4excited_cm3 candidate_lya_absorption_cm1 total_absorption_cm1 ots_lya_photons_cm2_s candidate_Ca_OTS_events_cm3_s Ca0_cm3 Ca1_cm3 Ca2_cm3 CaII_net_cooling_erg_cm3_s\\n"); first=false;}
        const double cross[]={4.8e-18,7.0e-18,8.4e-19,1.7e-18};
        double excited=0.,candidate=0.;
        for(long i=1;i<5;++i){excited+=dBaseStates[calcium][i].Pop();candidate+=dBaseStates[calcium][i].Pop()*cross[i-1];}
        const long frequency=iso_sp[ipH_LIKE][ipHYDROGEN].trans(ipH2p,ipH1s).ipCont()-1;
        const double flux=rfield.otslin[frequency];
        fprintf(f,"%ld %ld %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g\\n",iteration,nzone,radius.depth,phycon.te,dense.eden,double(ca.popca2ex),excited,candidate,double(opac.opacity_abs[frequency]),flux,candidate*flux,dense.xIonDense[ipCALCIUM][0],dense.xIonDense[ipCALCIUM][1],dense.xIonDense[ipCALCIUM][2],dBaseSpecies[calcium].CoolTotal);
    }
    return;''')
path=root/'rt_ots_ca_readout.cpp';path.write_text(s)
(root/'readout.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='C23.01/rt_ots.cpp',tofile='diagnostic/rt_ots.cpp')))
commands=[['g++','-std=c++11','-O2','-fno-pie','-I'+str(src),'-DSYS_CONFIG="'+str(src/'cloudyconfig.h')+'"','-c',str(path),'-o',str(root/'rt_ots_ca_readout.o')],['g++','-no-pie','-o',str(root/'cloudy_ca_readout.exe'),str(src/'maincl.o'),str(root/'rt_ots_ca_readout.o'),str(src/'libcloudy.a')]]
for command in commands:subprocess.run(command,check=True)
(root/'model.in').write_text('''title Read-only Ca excited-opacity hook; not an atmosphere
blackbody 10000 K dilution 0.025
illumination forward 0
hden 11.358
constant temperature 6707 K linear
abundances "default.abn"
set dr 8
stop zone 1
iterate 3
save hydrogen conditions "model.conditions" last
save cooling "model.cooling" last
set eden convergence 0.0001
set ionization tolerance 0.0001
''')
inputs=[src/'rt_ots.cpp',src/'ca.cpp',src/'ca.h',src/'opacity_addtotal.cpp',src/'ion_photo.cpp',src/'libcloudy.a',src/'maincl.o',path,root/'model.in',root/'cloudy_ca_readout.exe']
(root/'build_receipt.json').write_text(json.dumps({'scope':'A readout-only one-zone blackbody state checks legacy-variable behavior. It does not establish an atmospheric sensitivity or correct the opacity.','commands':commands,'sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}},indent=2)+'\n')
print(root)
