# C23.01 excited-Ca opacity readout

This is a completed, readout-only one-zone counterexample to a specific reference photon-allocation assumption. It is not a planetary-atmosphere sensitivity or a claim that the final Fe-OTS cooling difference has been explained.

The input is a 10,000 K blackbody diluted by 0.025, hydrogen density 10^11.358 cm^-3, fixed temperature 6,707 K, C23.01 default solar abundances, one zone, and three iterations. No original stellar SED is included or needed. The default H and Fe atoms are used; this is not the separate Fe716 full-column experiment.

## What is measured

`ca_opacity_readout.tsv` records values at the end of RT_OTS. In every readout `ca.popca2ex` is zero. The final sum of the first four excited Ca II populations is 45,314.4 cm^-3. C23's opacity_addtotal uses the zero legacy variable for the excited-Ca opacity, while ion_photo/species2 use the actual database populations for Ly-alpha photoionization.

Using exactly those four receiver cross sections, define chi_Ca = sum(n_i sigma_i), where sigma_i = [4.8e-18, 7.0e-18, 8.4e-19, 1.7e-18] cm^2. The final candidate forward absorption is 2.76412e-13 cm^-1, while the recorded total continuum absorption used to allocate the common OTS field is 2.13785e-14 cm^-1: a ratio of 12.9294. Multiplying the same OTS photon flux by the two opacities gives 13.7652 and 1.06464 cm^-3 s^-1, respectively.

The candidate is forward absorption, while continuum opacity can include induced-recombination corrections. `induced_recombination_bound.json` independently bounds the inverse of these same four channels using Maxwellian Milne balance. Even with ionic statistical weight set to its minimum 1 and the exponential bounded by 1, the inverse contribution is at most 2.693e-9 of the candidate. This distinction cannot account for the ratio in this state. This does not audit every diffuse source or prove a global all-frequency energy budget.

The readout is not simultaneous with every adjacent rate call; it measures a stable final one-zone state. The last `CaII_net_cooling` readout column is zero at this call position and is not used as final cooling evidence. No opacity/rate is corrected by this diagnostic.

## Instrumentation control

Both binaries use the same original maincl.o and libcloudy.a. The diagnostic replaces only rt_ots.o with the attached readout-only source; `readout.patch` makes the alteration explicit. The same input was run with an unmodified companion. Both requested saved physical tables, `model.conditions` and `model.cooling`, are byte-identical. `tracking_identity.json` and execution/build receipts contain exact hashes and exit codes. This supports saved-table parity, not an unmeasured claim of all internal bitwise identity.

## Replay

1. Obtain and build C23.01. Check the original source/object hashes in `diagnostic/build_receipt.json` and `source_receipt.json`; binaries are not redistributed here.
2. Compile `diagnostic/rt_ots_ca_readout.cpp` using the recorded include/config/compiler flags; link it with the original maincl.o and libcloudy.a. Link a second unmodified companion from maincl.o and libcloudy.a alone. The historical builder is under `replay/`; its local paths must be adjusted to your installation.
3. Copy `diagnostic/model.in` into two separate working directories. Run each binary with `-r model`. Use the same C23 data directory in both runs.
4. Compare the two saved tables byte-for-byte and recompute the last readout's opacity/receiver products. The equations and complete readout are sufficient to reproduce `diagnostic/summary.json`. The induced upper bound uses the first five Ca II statistical weights in the pinned original level table; it is a conservative derivation, not an altered Cloudy execution.

## Scope and exclusions

This evidence contradicts completeness of the legacy excited-Ca opacity/receiver allocation in the specified one-zone C23 state. It does not establish the size or sign of the planetary spectrum or thermal response, the cause of any separate full-column cooling difference, numerical convergence of a solar atmosphere, or adequacy of native escape physics. Those need separate controlled runs.

No executable, object/library, cache, original stellar SED/FITS, or full stellar-flux array is included. All data files here are scalar/plasma readouts or small saved physical tables; there are no NPZ files. Cloudy source excerpts and altered readout source are redistributed under the unmodified accompanying Cloudy license; original software credit belongs to Gary J. Ferland and contributors.
