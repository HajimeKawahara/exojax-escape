# OU2 continuum-quadrature follow-up

This additional complete-population-root experiment follows the immutable
`matched_ou2_reference.tar.gz` (SHA256
`73b800204d3f85bd5141219dc7b281ca3656b4cdf0c255671b6fae579aa29065`).
It does not alter that archive or its historical frozen-state frequency check.

The same 267-cell H15, T=8000 K, nH=1e12 cm^-3, NH=1e21 cm^-2,
BB10000 K/W=.025 normal-beam OU2 problem is independently re-solved with
continuum quadrature order 8 instead of 4. All opacities, continuum recycling,
line pumping, and populations are recomputed at each root evaluation. The
native default bidirectional continuum and solar atmosphere are not assessed.

The new maximum log-population residual is 2.29683e-12 (external stopping
1e-10; acceptance 1e-9). The maximum local n2/n3/ne changes are
0.0340704%/0.198665%/0.00182068%, each below the unchanged 1% refinement
criterion. This replaces no fixed-state measurement: it supplies the previously
missing actual root-refinement result as a new experiment.

The native source snapshot at revision
71aceae2ca0c8c7c30ae9d6d27feddb7db27fa32 and ExoJAX revision
38cb2e44f153ad6d729e3253e235702de52920cf are the same as the prior archive.
The additional CLI only passes `quadrature_order=8` into the native constructor;
its exact executed hash and the external OU2 operator hash are in the saved
configuration. The new operator's rates were already verified to preserve the
old order-4 strict root after its diagnostic-only heat outputs were added.

Replay from the extracted prior archive, with its native source_snapshot and
ExoJAX source on PYTHONPATH:

    python solve_ou2_frequency_comparison.py PRIOR/continuum_controls/ou2_standard_maxdr5e6 NEW_OUTPUT --cells 267 --continuum-order 8 --reference-grid --solver krylov

NEW_OUTPUT must not already exist. The saved arrays are derived H populations;
there are no stellar input spectra, binaries, caches, or compiled IR.
