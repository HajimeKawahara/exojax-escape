"""Check only the actually executed C23 boundary-option control."""
from pathlib import Path
from hashlib import sha256
import json, re, subprocess
import numpy as np

root = Path(__file__).parent
source = Path('/tmp/cloudy-reference-run/c23.01/source')
files = ['levels','electrons','protons','conditions','line_tau']
result = {'scope':'C23.01 unmodified binary, one BB10000K normal beam, H15, constant T8000K/nH1e12, NH1e21, six columns, doubled line tau, OU2. This compares the parsed forward versus reverse option only; it is not a universal statement about all illumination modes or future versions.', 'table_identity':{}, 'inputs':{}, 'physical_summary':{}}
for name in files:
 a,b=[(root/m/('model.'+name)).read_bytes() for m in ['forward','reverse']]
 result['table_identity'][name]={'byte_identical':a==b,'sha256':sha256(a).hexdigest(),'reverse_sha256':sha256(b).hexdigest()}
for mode in ['forward','reverse']:
 d=root/mode;text=(d/'model.out').read_text()
 result['inputs'][mode]={'sha256':sha256((d/'model.in').read_bytes()).hexdigest(),'input_echo_contains_selected_option':('illumination '+mode+' 0') in text,'output_sha256':sha256((d/'model.out').read_bytes()).hexdigest(),'ending':next(s.strip() for s in reversed(text.splitlines()) if 'Cloudy ends:' in s),'returncode':json.load(open(d/'heartbeat.json'))['returncode']}
 x=np.loadtxt(d/'model.conditions',comments='#')
 result['physical_summary'][mode]={'zones':len(x),'first_row':x[0].tolist(),'last_row':x[-1].tolist()}
refs=subprocess.check_output(['rg','-n','--glob','*.cpp','--glob','*.h',r'Illumination\b|OpticalDepthScaleFactor',str(source)],text=True)
(root/'source_symbol_references.txt').write_text(refs)
result['source_tracking']={'searched_tree':str(source),'patterns':r'Illumination\b|OpticalDepthScaleFactor','reference_listing_sha256':sha256(refs.encode()).hexdigest(),'observation':'Stored fields are assigned in initializers/parsers, read for optimization command reconstruction, and printed by the trace. This source search finds no radiation-transport read of those stored per-shape fields. Actual attenuation uses geometry.DirectionalCosin, whose value is the same for both zero-angle commands.'}
result['conclusion']='In this executed, identical slab with spatially varying populations, changing forward to reverse leaves every one of the five saved physical tables byte-identical. The accepted keyword therefore does not demonstrate the reverse lower boundary needed by the proposed native-state comparison. Keep that boundary requirement unresolved.'
assert all(x['byte_identical'] for x in result['table_identity'].values())
assert all(x['input_echo_contains_selected_option'] and x['returncode']==0 for x in result['inputs'].values())
(root/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['table_identity','conclusion']},indent=2))
