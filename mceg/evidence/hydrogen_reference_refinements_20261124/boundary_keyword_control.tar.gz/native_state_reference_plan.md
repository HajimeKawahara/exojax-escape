# Native-state reference alignment

The ongoing prescribed-profile Cloudy campaign uses the old 48-node input
(SHA256 1358d51eecad0835bf8bbb2974b95163caefe5086ba01faec6a6e6fa226bd3bc),
not the final five- or eight-cell native thermal root. It certifies neither that
root nor its energy equation. Its unresolved convergence tests stay separate.

For the next native root, retain the exact edges, center T/nH/mu, all atomic and
molecular populations, electron density, lower-cell mask, source manifest, and
incident continuum/line input hashes. Native RT/SE uses piecewise-constant
center states; the four-point within-cell average samples only optical depth
and continuum radiation. The wind alone uses the log-Hermite T/mu interpolant.
Interpolating the center density/temperature into a continuous Cloudy DLAW/TLAW
changes the discrete problem and cannot be called an identical-state comparison.

A causal sequence is:

1. Compare conditional process operators at the exact native T, ne, population,
   and radiation state. Keep direct continuum, local OTS, transported diffuse
   continuum, and effective-RR elimination distinct. Match kinetic energy
   bookkeeping before comparing separate Gamma/Lambda. Record which supplied
   quantities are actually frozen and which Cloudy recomputes. This check can
   expose an omitted process without requiring a second thermal equilibrium.
2. Re-solve SE at prescribed T and nH only after declaring a common spatial and
   radiation closure. Keep the native two-sided model and the optional C23 OU2
   comparison as different subjects; the pure-H OU2 result does not silently
   validate solar elimination. Refine each actual solved reference profile to
   the existing 1% criterion before the 5% native/reference comparison.
3. Then compare the native thermal residual to the independent qualified
   process ledger at those conditions. An independently converged Cloudy
   temperature/wind loop is a further control, not a prerequisite for finding
   a same-state kernel or conservation defect.

The two prescribed LTE cells at the bottom of the native atmosphere emit into
the upper gas. The zero inner boundary applies at 1 Rp, below those cells.
Omitting them and setting the new Cloudy lower boundary to zero is a different
radiative problem. A reference of only the upper region must preserve the
frequency- and angle-dependent upward intensity at the internal interface, or
explicitly assess the lost-boundary approximation. A scalar dilution is not
a general replacement for this field.

C23.01 parses `illumination reverse`, but an exhaustive source-symbol search
currently finds the stored `rfield.Illumination[]` only in initialization,
parsing, optimization-command reconstruction, and trace printing. Likewise,
`OpticalDepthScaleFactor[]` is only assigned or printed; normal-beam attenuation
uses the global `geometry.DirectionalCosin`. This source audit motivates the
separate executed forward/reverse boundary test. No general feature-support
claim is made before that test is complete.

The unchanged criteria are maximum complete native log-residual below 1e-9,
1% independently tested numerical refinement, and 5% on the declared positive
profiles and separate heating/cooling. A fixed-state or sampled conditional
control is not a waiver of the full-use requirements.
