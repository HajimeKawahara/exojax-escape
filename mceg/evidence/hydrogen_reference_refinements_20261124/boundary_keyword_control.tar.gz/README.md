# Executed lower-boundary option control

The source search and controlled execution test are specific to Cloudy C23.01
and the unchanged binary SHA in source_audit.json. The input echo confirms the
selected forward or reverse keyword. Both completed calculations give identical
five physical tables; this keyword alone has not demonstrated the internal
upward boundary required by the native LTE lower cells. Do not infer a general
claim about other configurations or releases.

Both inputs are a small pure-H constant-T slab, independent of any stellar data
license. The comparison script recomputes file identity and tracks every source
reference to both stored illumination fields. Full original output, inputs,
process metadata and saved tables are retained. See native_state_reference_plan.md
for the subsequent matched-state comparison plan and its separate numerical and
closure requirements.

Replay each case in its own new directory using the unchanged C23.01 binary:

    /path/to/cloudy_unmodified.exe -r model

Original source archive: https://data.nublado.org/cloudy_releases/c23/c23.01.tar.gz
SHA256 a9ad2dc037e88f552389de0e483d68f54310976dee32154ed13830882aedae0b.
Exact source-file hashes are in source_audit.json. No binary, object, stellar
input, cache or compiled IR is included.
