"""Wrap unchanged C23 function bodies with explicit supplied-state accessors."""
from pathlib import Path
import hashlib,json,subprocess
root=Path('/tmp/escape-iron-lyalpha-validation');source=Path('/tmp/cloudy-causal-rates/source')
a=(source/'rt_escprob.cpp').read_text();width=a[a.index('double RT_LineWidth('):a.index('/*RT_DestHummer evaluate')]
a=(source/'species2.cpp').read_text();i=a.index('STATIC void setXtraRatesFe2(const TransitionProxy& tr, double &xtraExRate, double &xtraDxRate)\n{');pump=a[i:]
# This is the final function in the distributed source.
assert pump.rstrip().endswith('}')
preamble=r'''
/* Altered source from Cloudy (C) 1978-2023 Gary J. Ferland and others.
 * See the Cloudy license. Original function bodies use supplied-state accessors. */
#include <cmath>
#include <cfloat>
#include <cstdio>
#include <cassert>
#include <algorithm>
extern double esc_PRD_1side(double,double);
namespace supplied {
using realnum=float;
#define DEBUG_ENTRY(x)
#define ASSERT(x) assert(x)
#define STATIC
#define MAX2(a,b) ((a)>(b)?(a):(b))
#define MIN2(a,b) ((a)<(b)?(a):(b))
constexpr double PI=3.1415926535897932384626433832795;
constexpr double SMALLFLOAT=1.1754943508222875e-38;
struct {double eden;} dense;
struct {bool lgBallistic() const{return false;} double windv0;} wind;
struct {bool lgPradDen;} pressure;
struct {double taumin=-1e-20;} opac;
int iteration=2;
inline double tau_from_here(double a,double b){return a-b;}
struct Emission {
 mutable realnum ti=0,tt=0,dampv=0,dam=0,pe=0,pd=0,ps=0,aa=0;
 realnum& TauIn()const{return ti;} realnum& TauTot()const{return tt;}
 realnum& dampXvel()const{return dampv;} realnum& damp()const{return dam;}
 realnum& Pelec_esc()const{return pe;} realnum& Pdest()const{return pd;}
 realnum Pesc_total()const{return ps+pe;} realnum Aul()const{return aa;}
};
struct State {double population=0;realnum weight=1;double Pop()const{return population;}realnum g()const{return weight;}};
struct TransitionProxy {
 mutable Emission e; State lower,upper;realnum wn=0;
 Emission& Emis()const{return e;} const State* Hi()const{return &upper;}
 const State* Lo()const{return &lower;}realnum EnergyWN()const{return wn;}
};
struct {bool lgLyaFeIIPumpOn=true;realnum HLineWidth=0;} hydro;
constexpr int ipH_LIKE=0,ipHYDROGEN=0,ipH2p=2,ipH1s=0;
struct Ion {State st[3];TransitionProxy h;const TransitionProxy& trans(int,int)const{return h;}};
Ion iso_sp[1][1];
'''
main=r'''
}
int main(){
 using namespace supplied;
 double ti,tt,a,vd,ne,pe,pd;
 for(double t: {1e-4,1e-3,.1,19.,21.,1e4,1e8})
 for(double density: {1e3,1e12,1e17,1e20,1e22})
 for(double damping: {1e-4,.1})
 for(double destruction: {0.,.001,.2}) {
  TransitionProxy line;line.e.ti=t;line.e.tt=3*t;
  realnum doppler=1.234567e6;line.e.dampv=damping*doppler;
  line.e.dam=line.e.dampv/doppler;line.e.pe=1e-6;line.e.pd=destruction;
  dense.eden=density;
  double value=RT_LineWidth(line,doppler);
  printf("W %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g\n",double(line.e.ti),double(line.e.tt),double(line.e.dam),double(doppler),density,double(line.e.pe),double(line.e.pd),value);
 }
 for(double width: {0.,1e5,1e6,1e7})
 for(double offset: {-30.,-10.,-1.,1.,10.,30.})
 for(double optical: {.5,1.,2.,1e3}) {
  hydro.HLineWidth=width;iso_sp[0][0].st[0].population=1e12;iso_sp[0][0].st[2].population=1e5;
  iso_sp[0][0].h.e.ps=.01;iso_sp[0][0].h.e.pe=.001;
  TransitionProxy line;line.wn=82259+offset;line.e.tt=optical;line.e.ti=optical/2;
  line.e.aa=2e8;line.lower.weight=3;line.upper.weight=5;
  double up=0,down=0;setXtraRatesFe2(line,up,down);
  printf("P %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g\n",double(hydro.HLineWidth),double(line.wn),double(line.e.tt),double(line.e.aa),double(line.lower.weight),double(line.upper.weight),double(iso_sp[0][0].h.e.Pesc_total()),up,down);
 }
}
'''
(root/'source_kernels.cpp').write_text(preamble+width+pump+main)
command=['g++','-O2','-std=c++17','-no-pie',str(root/'source_kernels.cpp'),str(source/'libcloudy.a'),'-lpthread','-o',str(root/'source_kernels.exe')]
r=subprocess.run(command,capture_output=True,text=True);(root/'build.log').write_text(r.stdout+r.stderr);r.check_returncode()
r=subprocess.run([str(root/'source_kernels.exe')],capture_output=True,text=True);(root/'source_values.txt').write_text(r.stdout);r.check_returncode()
(root/'source_receipt.json').write_text(json.dumps(dict(command=command,scope='Unchanged original C23 function bodies with supplied-state accessor stubs; original esc_PRD_1side linked from the unmodified library. This is primitive parity, not a full atmosphere comparison.',sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [source/'rt_escprob.cpp',source/'species2.cpp',source/'libcloudy.a',root/'source_kernels.cpp']}),indent=2)+'\n')
