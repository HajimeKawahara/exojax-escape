from pathlib import Path
import json,hashlib
import numpy as np
import jax
import jax.numpy as jnp
from escape.iron_lyalpha import static_lyalpha_width,_extra_rates
jax.config.update('jax_enable_x64',True)
root=Path('/tmp/escape-iron-lyalpha-validation')
width=[];pump=[]
for line in (root/'source_values.txt').read_text().splitlines():
 key,*values=line.split();(width if key=='W' else pump).append(list(map(float,values)))
w,p=map(np.array,(width,pump))
actual=np.asarray(static_lyalpha_width(*map(jnp.asarray,w[:,:7].T)))
error=np.max(abs(actual-w[:,7])/np.maximum(abs(w[:,7]),1e-100))
occupation=(1-p[:,6])/(3e12/1e5-1)
up,down,_=jax.vmap(lambda width,occ,wn,col,a,gl,gu:_extra_rates(jnp.array([width]),jnp.array([occ]),jnp.array([a]),jnp.array([gu/gl]),jnp.array([wn]),jnp.array([[col]])))(*map(jnp.asarray,[p[:,0],occupation,p[:,1],p[:,2],p[:,3],p[:,4],p[:,5]]))
up=np.asarray(up).ravel();down=np.asarray(down).ravel()
pump_error=np.max(abs(np.stack((up,down),axis=1)-p[:,-2:])/np.maximum(abs(p[:,-2:]),1e-100))
de=1.37194e-6*p[:,0]*2/3
safe=np.where(de>0,de,1)
x=p[:,1];center=82259.
profile=np.where(x<center-de,(x-(center-2*de))/safe,np.where(x<center+de,1,(center+2*de-x)/safe))
profile=np.where((de>0)&(x>=center-2*de)&(x<=center+2*de)&(p[:,2]>1),profile,0)
source_order=p[:,3]*occupation*profile
np.testing.assert_allclose(source_order,p[:,8],rtol=3e-15,atol=1e-100)
report=dict(pump_roundoff_attribution='Re-evaluating the original center-plus/minus-width subtraction order reproduces C++ to 3e-15. Native evaluates the offset first to avoid cancellation; its 4.4e-12 discrepancy is floating-point order, not a physical approximation.',width_cases=len(w),pump_cases=len(p),width_max_relative=float(error),pump_max_relative=float(pump_error),scope='Independent original C23 source-function values; no whole-atmosphere, threshold-smoothness, or LTE claim.')
(root/'comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
np.testing.assert_allclose(actual,w[:,7],rtol=2e-6,atol=1e-100)
np.testing.assert_allclose(up,p[:,7],rtol=1e-10,atol=1e-100)
np.testing.assert_allclose(down,p[:,8],rtol=1e-10,atol=1e-100)
receipt=json.loads((root/'source_receipt.json').read_text())
data=dict(source_files_sha256={Path(k).name:v for k,v in receipt['sha256'].items() if Path(k).suffix=='.cpp'},roundoff_note=report['pump_roundoff_attribution'],width=w.tolist(),pump=p.tolist(),source_receipt_sha256=hashlib.sha256((root/'source_receipt.json').read_bytes()).hexdigest(),scope=report['scope'])
Path('/tmp/escape-coupled-atmosphere/tests/data/cloudy_iron_lyalpha.json').write_text(json.dumps(data,indent=2)+'\n')
