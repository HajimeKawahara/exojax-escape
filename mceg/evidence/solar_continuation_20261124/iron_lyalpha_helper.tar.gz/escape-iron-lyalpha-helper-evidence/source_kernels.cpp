
#include <cmath>
#include <cfloat>
#include <cstdio>
#include <cassert>
#include <algorithm>
extern double esc_PRD_1side(double,double);
namespace supplied {
using realnum=float;
#define DEBUG_ENTRY(x)
#define ASSERT(x) assert(x)
#define STATIC
#define MAX2(a,b) ((a)>(b)?(a):(b))
#define MIN2(a,b) ((a)<(b)?(a):(b))
constexpr double PI=3.1415926535897932384626433832795;
constexpr double SMALLFLOAT=1.1754943508222875e-38;
struct {double eden;} dense;
struct {bool lgBallistic() const{return false;} double windv0;} wind;
struct {bool lgPradDen;} pressure;
struct {double taumin=-1e-20;} opac;
int iteration=2;
inline double tau_from_here(double a,double b){return a-b;}
struct Emission {
 mutable realnum ti=0,tt=0,dampv=0,dam=0,pe=0,pd=0,ps=0,aa=0;
 realnum& TauIn()const{return ti;} realnum& TauTot()const{return tt;}
 realnum& dampXvel()const{return dampv;} realnum& damp()const{return dam;}
 realnum& Pelec_esc()const{return pe;} realnum& Pdest()const{return pd;}
 realnum Pesc_total()const{return ps+pe;} realnum Aul()const{return aa;}
};
struct State {double population=0;realnum weight=1;double Pop()const{return population;}realnum g()const{return weight;}};
struct TransitionProxy {
 mutable Emission e; State lower,upper;realnum wn=0;
 Emission& Emis()const{return e;} const State* Hi()const{return &upper;}
 const State* Lo()const{return &lower;}realnum EnergyWN()const{return wn;}
};
struct {bool lgLyaFeIIPumpOn=true;realnum HLineWidth=0;} hydro;
constexpr int ipH_LIKE=0,ipHYDROGEN=0,ipH2p=2,ipH1s=0;
struct Ion {State st[3];TransitionProxy h;const TransitionProxy& trans(int,int)const{return h;}};
Ion iso_sp[1][1];
double RT_LineWidth(const TransitionProxy& t, realnum DopplerWidth)
{
	double RT_LineWidth_v, 
	  aa, 
	  atau, 
	  b, 
	  r, 
	  vth;
	realnum tau; 

	DEBUG_ENTRY( "RT_LineWidth()" );

	/* uses line width from 
	 * >>refer	esc	prob	Bonilha et al. Ap.J. (1979) 233 649
	 * >>refer	esc	prob	Elitzur Ferland 1986ApJ...305...35E.pdf
	 * return value is half velocity width*(1-ESC PROB) [cm s-1]
	 * this assumes incomplete redistribution, damp.tau^1/3 width */

	/* thermal width */
	vth = DopplerWidth;

	/* optical depth in outer direction is defined
	 * on second and later iterations. 
	 * smaller of inner and outer optical depths is chosen for esc prob */
	if( iteration > 1 )
	{
		/* optical depth to shielded face */
		realnum tauout = tau_from_here(t.Emis().TauTot(), t.Emis().TauIn());

		/* >>chng 99 apr 22 use smaller optical depth */
		tau = MIN2( t.Emis().TauIn() , tauout );
	}
	else
	{
		tau = t.Emis().TauIn();
	}
	/* do not evaluate line width if quite optically thin - will be dominated
	 * by noise in this case */
	if( tau <1e-3 )
		return 0;

	t.Emis().damp() = t.Emis().dampXvel() / DopplerWidth;
	ASSERT( t.Emis().damp() > 0. );

	double Pesc =  esc_PRD_1side( tau , t.Emis().damp());

	/* max optical depth is thermalization length */
	realnum therm = (realnum)(5.3e16/MAX2(1e-15,dense.eden));
	if( tau > therm )
	{
		/* \todo 2 this seems to create an inconsistency as it changes tau
		 * for the purposes of this routine (to return the line-width),
		 * but this leaves the actual optical depth unchanged. */
		pressure.lgPradDen = true;
		tau = therm;
	}

	/* >>chng 01 jun 23, use wind vel instead of rt since rt deleted */
	/* >>chng 04 may 13, use thermal for subsonic cases */
	if( ! wind.lgBallistic() )
	{
		/* static geometry */
		/* esc prob has noise if smaller than FLT_EPSILON, or is masing */
		if( (tau-opac.taumin)/100. < FLT_EPSILON )
		{
			RT_LineWidth_v = 0.;
		}
		else
		{
			if( tau <= 20. )
			{
				atau = -6.907755;
				if( tau > 1e-3 )
					atau = log(tau);
				aa = 4.8 + 5.2*tau + (4.*tau - 1.)*atau;
				b = 6.5*tau - atau;
			}
			else
			{
				ASSERT( t.Emis().damp()*tau >= 0.);
				atau = log(MAX2(0.0001,tau));
				aa = 1. + 2.*atau/pow(1. + 0.3*t.Emis().damp()*tau,0.6667) + 
					pow(6.5*t.Emis().damp()*tau,0.333);
				b = 1.6 + 1.5/(1. + 0.20*t.Emis().damp()*tau);
			}

			double escProb = Pesc + t.Emis().Pelec_esc() + t.Emis().Pdest();
			RT_LineWidth_v = vth*0.8862*aa/b*(1. - MIN2( 1. , escProb) );

			/* small number roundoff can dominate this process */
			if( escProb >= 1. - 100. * FLT_EPSILON )
				RT_LineWidth_v = 0.;
		}

		/* we want full width, not half width */
		RT_LineWidth_v *= 2.;

	}
	else
	{
		/* ballistic wind */
		r = t.Emis().damp()*tau/PI;
		if( r <= 1. )
		{
			RT_LineWidth_v = vth*sqrt(log(MAX2(1.,tau))*.2821);
		}
		else
		{
			RT_LineWidth_v = 2.*fabs(wind.windv0);
			if( r*vth <= RT_LineWidth_v )
			{
				RT_LineWidth_v = vth*r*log(RT_LineWidth_v/(r*vth));
			}
		}
	}

	ASSERT( RT_LineWidth_v >= 0. );
	return RT_LineWidth_v;
}

STATIC void setXtraRatesFe2(const TransitionProxy& tr, double &xtraExRate, double &xtraDxRate)
{
	DEBUG_ENTRY( "setXtraRatesFe2()" );

	if( ! hydro.lgLyaFeIIPumpOn )
		return;

	/* get rates FeII atom is pumped */

	/* elsewhere in this file the dest prob hydro.dstfe2lya is defined from
	 * quantites derived here, and the resulting populations */
	
	/*************trapeze form La profile:de,EnerLyaProf1,EnerLyaProf2,EnerLyaProf3,EnerLyaProf4*************************
	 * */
	/* width of Lya in cm^-1 */
	/* HLineWidth has units of cm/s, as was evaluated in PresTotCurrent */
	/* the factor is 1/2 of E(Lya, cm^-1_/c */
	double de = 1.37194e-06*hydro.HLineWidth*2.0/3.0;
	/* 82259 is energy of Lya in wavenumbers, so these are the form of the trapezoid */
	double EnerLyaProf1 = 82259.0 - de*2.0;
	double EnerLyaProf2 = 82259.0 - de;
	double EnerLyaProf3 = 82259.0 + de;
	double EnerLyaProf4 = 82259.0 + de*2.0;

	double PhotOccNumLyaCenter = 0.;

	/* find Lya photon occupation number */
	if( iso_sp[ipH_LIKE][ipHYDROGEN].st[ipH2p].Pop() > SMALLFLOAT )
	{
		/* This is the photon occupation number at the Lya line center */
		PhotOccNumLyaCenter =
			MAX2(0.,1.0-
			iso_sp[ipH_LIKE][ipHYDROGEN].trans(ipH2p,ipH1s).Emis().Pesc_total())/
			(iso_sp[ipH_LIKE][ipHYDROGEN].st[ipH1s].Pop()/iso_sp[ipH_LIKE][ipHYDROGEN].st[ipH2p].Pop()*3. - 1.0);
	}


	/* on first iteration optical depth in line is inward only, on later
	 * iterations is total optical depth */
	double taux = 0.;
	if( iteration == 1 )
	{
		taux = tr.Emis().TauIn();
	}
	else
	{
		taux = tr.Emis().TauTot();
	}

	/* the energy of the FeII line */
	double EnergyWN = tr.EnergyWN();

	if( EnergyWN >= EnerLyaProf1 && EnergyWN <= EnerLyaProf4  &&  taux > 1 )
	{
		/* this branch, line is within the Lya profile */

		/*
		 * Lya source function, at peak is PhotOccNumLyaCenter,
		 *
		 *     Prof2    Prof3
		 *       ----------
		 *      /          \
		 *     /            \
		 *    /              \
		 *  ======================
		 * Prof1              Prof4
		 *
		 */

		double PhotOccNum_at_nu = 0.,
			PumpRate = 0.;
		if( EnergyWN < EnerLyaProf2 )
		{
			/* linear interpolation on edge of trapazoid */
			PhotOccNum_at_nu = PhotOccNumLyaCenter*(EnergyWN - EnerLyaProf1)/ de;
		}
		else if( EnergyWN < EnerLyaProf3 )
		{
			/* this is the central plateau */
			PhotOccNum_at_nu = PhotOccNumLyaCenter;
		}
		else
		{
			/* linear interpolation on edge of trapazoid */
			PhotOccNum_at_nu = PhotOccNumLyaCenter*(EnerLyaProf4 - EnergyWN)/de;
		}

		/* at this point Lya source function at FeII line energy is defined, but
		 * we need to multiply by line width in Hz,
		 * >>refer	Fe2	pump	Netzer, H., Elitzur, M., & Ferland, G. J. 1985, ApJ, 299, 752-762*/

#if 0
		/** \todo 2 change this number to speed of light. */
		/* width of FeII line in Hz  */
		double FeIILineWidthHz = 1.e8/(EnergyWN*299792.5)*sqrt(log(taux))*GetDopplerWidth(dense.AtomicWeight[ipIRON]);

		/* final Lya pumping rate, s^-1*/
		PumpRate = FeIILineWidthHz * PhotOccNum_at_nu * tr.Emis().Aul()*
		  powi(82259.0f/EnergyWN,3);
#endif
		/* above must be bogus, use just occ num times A */
		PumpRate = tr.Emis().Aul()* PhotOccNum_at_nu;

		/* Lya pumping rate from ipHi to lower n */
		xtraDxRate += PumpRate;

		/* Lya pumping rate from n to upper ipHi */
		xtraExRate += PumpRate * (*tr.Hi()).g()/(*tr.Lo()).g();
	}

	return;
}

}
int main(){
 using namespace supplied;
 double ti,tt,a,vd,ne,pe,pd;
 for(double t: {1e-4,1e-3,.1,19.,21.,1e4,1e8})
 for(double density: {1e3,1e12,1e17,1e20,1e22})
 for(double damping: {1e-4,.1})
 for(double destruction: {0.,.001,.2}) {
  TransitionProxy line;line.e.ti=t;line.e.tt=3*t;
  realnum doppler=1.234567e6;line.e.dampv=damping*doppler;
  line.e.dam=line.e.dampv/doppler;line.e.pe=1e-6;line.e.pd=destruction;
  dense.eden=density;
  double value=RT_LineWidth(line,doppler);
  printf("W %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g\n",double(line.e.ti),double(line.e.tt),double(line.e.dam),double(doppler),density,double(line.e.pe),double(line.e.pd),value);
 }
 for(double width: {0.,1e5,1e6,1e7})
 for(double offset: {-30.,-10.,-1.,1.,10.,30.})
 for(double optical: {.5,1.,2.,1e3}) {
  hydro.HLineWidth=width;iso_sp[0][0].st[0].population=1e12;iso_sp[0][0].st[2].population=1e5;
  iso_sp[0][0].h.e.ps=.01;iso_sp[0][0].h.e.pe=.001;
  TransitionProxy line;line.wn=82259+offset;line.e.tt=optical;line.e.ti=optical/2;
  line.e.aa=2e8;line.lower.weight=3;line.upper.weight=5;
  double up=0,down=0;setXtraRatesFe2(line,up,down);
  printf("P %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g\n",double(hydro.HLineWidth),double(line.wn),double(line.e.tt),double(line.e.aa),double(line.lower.weight),double(line.upper.weight),double(iso_sp[0][0].h.e.Pesc_total()),up,down);
 }
}
