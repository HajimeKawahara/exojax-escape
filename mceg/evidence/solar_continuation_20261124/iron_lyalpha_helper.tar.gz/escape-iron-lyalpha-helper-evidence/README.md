# Local Fe II / Ly-alpha helper verification

This evidence supports only the local helper committed at
`ce8f649408fb134e04c127e219c9c6709fa673b4`. Provider source, tests and the small
reference fixture already live in that commit; their exact hashes are recorded
in `implementation_receipt.json`.

The independent C23 source-function harness covers 210 line-width cases and 96
pumping cases, with maximum relative errors 1.24e-8 and 4.40e-12. The pump
roundoff difference comes from the original large-center-plus-width subtraction
order; reproducing that order agrees to 3e-15. Six meaningful tests also verify
signed stimulated reverse exchange, equal/opposite H/Fe photon transfer, the
internal-energy difference ledger, the implicit width derivative, zero/optically
thin selections and invalid-domain rejection.

The selected model retains the explicit Fe optical-depth >1 gate and empirical
trapezoid. It is not an exact LTE closure or a globally smooth inference model.
The local photon bookkeeping must be integrated so the Fe-absorbed H photons do
not also enter the generic continuum OTS pool. Full Solar integration, reference
allocation controls, thermal feedback, physical adequacy and inference readiness
are separate assessments and are not established by these tests.

Replay `source_kernels.cpp` using the exact compilation recipe and original C23
library/source hashes in `source_receipt.json`, then run `compare.py` with the
provider source at the recorded commit. Local paths in scripts require adjustment.
The executable and static library are intentionally excluded. `build_reference.py`
can regenerate the harness from the original functions; a copyright comment was
added to that generator after the tested harness was produced, so regenerating
changes the wrapper text hash without changing its function bodies. The archived
`source_kernels.cpp` is the exact tested source.

`equations.tex` is a short human explanation; it compiled without overfull boxes
and its one-page rendered output was inspected. The repository's final model
document may integrate or relabel these equations separately.

No stellar flux, SED, data cache or compiled binary is included.
