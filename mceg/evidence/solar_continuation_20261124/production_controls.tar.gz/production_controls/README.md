# Production Newton and Fe exchange controls

The positive-iteration JAX Newton/GMRES run uses source 95ce166, the ten-metal
fixed-temperature two-cell blackbody case, and the correction merit. It starts
from the old discontinuous-K2 stalled state, which is not a root of the selected
continuous operator. It takes two updates to F_inf=8.50875e-13 (criterion 1e-9)
and differs from the independent host root by 9.31e-13 in state coordinates.
This is not a cold-start atmosphere, thermal/wind solve, or full-path derivative.
The exact driver keeps its executed scratch paths; remap that root and remove
the create-only output directory before replay, using the source manifest.

The separate iron_integration receipts pin the final source and actual
composition integration tests: shared quadrature, equal-and-opposite H/Fe
photons and atomic energy, unchanged continuum OTS at fixed state, and regular
dense-LTE inactivity. They do not establish atmospheric/reference adequacy.
No stellar data, compiler output, executable or observation reference arrays
are included. The original source versions are already published in Git.
