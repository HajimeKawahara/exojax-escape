"""Exercise positive Newton iterations in the actual JAX population solver."""
from pathlib import Path
import hashlib
import json
import threading
import time

import jax
import jax.numpy as jnp
import numpy as np

from escape.solar import SolarCompositionModel
from escape.nonlinear import newton_krylov

jax.config.update('jax_enable_x64', True)
jax.config.update('jax_compilation_cache_dir', '/tmp/escape-jax-cache')
root = Path('/tmp/escape-solar-molecular-continuation')
out = root/'column_sulfur_production_root'
out.mkdir(exist_ok=False)
start = time.time()
phase = 'construct'
def heartbeat():
    while True:
        time.sleep(25)
        print(dict(phase=phase, elapsed=time.time()-start), flush=True)
threading.Thread(target=heartbeat, daemon=True).start()
model = SolarCompositionModel(
    [0., 5e5, 1e6], nmax=15, iron_levels=716, sulfur_levels=72,
    quadrature_order=2, angle_order=2, line_optical_depth_scale=1.,
    line_sampling='average', line_quadrature_order=4,
    shielding_model='cloudy', core_escape_model='continuous')
temperature = jnp.array([8000., 8200.])
density = jnp.array([1e12, 9e11])
incoming = model.hydrogen.boundary_blackbody(10000., .025)
seed = root/'column_sulfur_average/checkpoint.npz'
initial = jnp.asarray(np.load(seed)['state']).ravel()
shape = (model.cells, model.state_size)
def residual(flat):
    target, physical = model.evaluate(flat.reshape(shape), density, temperature, incoming)
    return jnp.where(physical['valid'], (flat.reshape(shape)-target).ravel(), jnp.nan)

phase = 'lower'
lowered = jax.jit(lambda x: newton_krylov(
    residual, x, iterations=6, tolerance=1e-9, merit='correction',
    restart=30, krylov_iterations=5, linear_rtol=1e-5)).lower(initial)
print(dict(lowered=True, elapsed=time.time()-start), flush=True)
phase = 'compile'
executable = lowered.compile()
compiled_at = time.time()
print(dict(compiled=True, elapsed=compiled_at-start), flush=True)
phase = 'execute'
result = executable(initial)
state = np.asarray(result.value)
expected = np.load(root/'column_sulfur_average_continuous_k2/checkpoint.npz')['state'].ravel()
norm, converged = float(result.residual_norm), bool(result.converged)
manifest = root/'source_correction_merit/manifest.json'
receipt = dict(
    residual_norm=norm, converged=converged, iterations=int(result.iterations),
    max_difference_from_host_root=float(np.max(np.abs(state-expected))),
    elapsed=time.time()-start, execution_seconds=time.time()-compiled_at,
    driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    seed_sha256=hashlib.sha256(seed.read_bytes()).hexdigest(),
    source_manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),
    source_revision=json.loads(manifest.read_text())['revision'],
    scope='Positive-iteration JAX Newton/GMRES population root at fixed two-cell T/density, ten metals, analytic BB. The starting state is the stalled original-K2 checkpoint, not a root of the selected continuous operator. No cold atmospheric or thermal/wind inference claim.')
np.savez_compressed(out/'solution.npz', state=state.reshape(shape))
(out/'summary.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(receipt, flush=True)
assert converged and np.isfinite(state).all() and norm <= 1e-9
