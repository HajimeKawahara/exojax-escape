"""Replay the stored fixed-temperature root; never fetch a stellar spectrum."""
from __future__ import annotations

import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import sys
import time
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
os.environ.setdefault("JAX_PLATFORMS", "cpu")
sys.path.insert(0, str(ROOT / "source"))

import exojax
import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd
from escape.solar import SolarAtmosphereModel

jax.config.update("jax_enable_x64", True)


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stellar-data", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--spectrum", type=Path,
                        help="Optionally check the same prescribed-temperature root's observer.")
    args = parser.parse_args()
    start = time.time()
    config = json.loads((ROOT / "configuration.json").read_text())
    if digest(args.stellar_data) != config["raw_sed_sha256"]:
        raise ValueError("The supplied stellar input does not match the recorded source.")
    package = Path(exojax.__file__).resolve().parent
    mismatches = [name for name, expected in json.loads(
        (ROOT / "exojax_source_hashes.json").read_text()).items()
        if not (package / Path(name).relative_to("src/exojax")).is_file()
        or digest(package / Path(name).relative_to("src/exojax")) != expected]
    if mismatches:
        raise ValueError(f"ExoJAX source differs from this experiment: {mismatches[:3]}")
    data = np.load(args.stellar_data)
    profile = np.load(ROOT / "profile.npz")
    nist = json.loads((ROOT / "nist_row.json").read_text())["row"]
    with patch("exojax.database.nist.api.fetch_nist_lines",
               lambda *a, **kw: (pd.DataFrame(nist), [])):
        model = SolarAtmosphereModel(
            config["edges_rp"], nmax=15, iron_levels=716,
            quadrature_order=2, angle_order=2, dense_lower_cells=2,
            lower_temperature_k=4500., line_sampling="average",
            line_quadrature_order=4, wind_ngrid=int(profile["wind_ngrid"]),
            planet_mass_mj=float(profile["planet_mass_mj"]),
            tidal_coefficient_s2=float(profile["tidal_coefficient_s2"]),
            extra_frequency_edges=data["frequency_hz"][[0, -1]],
            observer_options=dict(nlon=2, nlat=2, nnu=101),
        )
    boundary = model.stellar_boundary(
        data["frequency_hz"], data["surface_flux_nu"],
        incident_flux_ratio=.1, outside_zero=True)
    state = np.load(ROOT / "root.npz")["state"].ravel()
    temperature = jnp.asarray(config["temperature_reference_k"])

    def evaluate(value):
        residual, physical = model.evaluate_atmosphere(
            value, temperature, config["mass_loss_g_s"],
            boundary["incident_mean_intensity"],
            hydrogen_line_intensity=boundary["hydrogen_line_intensity"],
            metal_line_intensity=boundary["metal_line_intensity"],
            overlap_intensity=boundary["overlap_intensity"], thermal_blend=0.)
        return (residual, physical["valid"], physical["reference_domain_valid"],
                physical["wind_info"]["converged"])

    residual, valid, domain, wind_converged = jax.jit(evaluate)(state)
    norm = float(jnp.max(jnp.abs(residual)))
    passed = bool(np.isfinite(norm) and norm < 1e-9 and valid and domain and wind_converged)
    result = dict(residual_infinity=norm, required_residual=1e-9,
                  physical_valid=bool(valid), reference_domain_valid=bool(domain),
                  wind_converged=bool(wind_converged), passed=passed,
                  thermal_equilibrium_tested=False, spectrum_tested=False,
                  raw_stellar_input_sha256=digest(args.stellar_data),
                  root_sha256=digest(ROOT / "root.npz"), elapsed_s=time.time()-start)
    if passed and args.spectrum is not None:
        from escape.hydrogen_rates import LIGHT_SPEED_CGS

        composition = jnp.asarray(state.reshape(model.cells, -1)[:, 1:])
        actual_temperature = temperature*jnp.exp(
            jnp.asarray(state.reshape(model.cells, -1)[:, 0]))
        wind, _ = model._wind(composition, actual_temperature,
                              config["mass_loss_g_s"])
        physical = model.unpack(composition, wind.density_g_cm3/model.mass_per_h)
        physical["atomic_lte_mask"] = model.atomic_lte_mask
        frequency = jnp.asarray(model.observer.wavenumber_cm)*LIGHT_SPEED_CGS
        chi, eta = model.continuum_coefficients_at(actual_temperature, physical, frequency)
        # Use the identical observation path without labeling this a thermal root.
        contrast = model.observer.spectrum_from_profiles(
            physical["bound_cm3"][::-1], actual_temperature[::-1],
            wind.velocity_kms[::-1], continuum_extinction=chi[::-1],
            continuum_emission=eta[::-1]*LIGHT_SPEED_CGS)
        contrast = np.asarray(contrast)
        result["spectrum_tested"] = True
        result["spectrum_finite"] = bool(np.all(np.isfinite(contrast)))
        result["spectrum_min_contrast"] = float(np.min(contrast))
        result["spectrum_max_contrast"] = float(np.max(contrast))
        result["spectrum_scope"] = "Finite output at 2x2 disk points and 101 frequencies; no observation processing, spatial or spectral convergence, thermal balance or fit is established."
        result["passed"] = passed = bool(passed and result["spectrum_finite"])
        np.savez_compressed(args.spectrum,
                            wavenumber_cm=np.asarray(model.observer.wavenumber_cm),
                            contrast=contrast)
        result["spectrum_sha256"] = digest(args.spectrum)
        result["elapsed_s"] = time.time()-start
    args.output.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2), flush=True)
    if not passed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
