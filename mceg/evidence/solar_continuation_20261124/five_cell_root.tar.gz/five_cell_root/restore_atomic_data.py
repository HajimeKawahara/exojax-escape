"""Restore previously published atomic data from an existing local Git clone."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--repo", type=Path, required=True)
args = parser.parse_args()
record = json.loads((root / "atomic_data.json").read_text())
for name, expected in record["files"].items():
    content = subprocess.check_output([
        "git", "show", record["revision"] + ":" + expected["repository_path"]
    ], cwd=args.repo)
    if hashlib.sha256(content).hexdigest() != expected["sha256"]:
        raise ValueError("Source hash mismatch: " + name)
    target = root / name
    if target.exists() and target.read_bytes() != content:
        raise ValueError("Refusing to replace different data: " + name)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
    print("Verified", name)
