"""Exact-JVP numerical candidate for the current coupled Solar atmosphere.

Host Newton is a checkpointed diagnostic. It does not replace the production
implicit derivative and never accepts a failed or out-of-domain atmosphere.
"""
from pathlib import Path
import json
import hashlib
import time
import jax
import jax.numpy as jnp
import numpy as np
from scipy.sparse.linalg import LinearOperator, gmres
from escape.solar import SolarAtmosphereModel

jax.config.update('jax_enable_x64', True)
jax.config.update('jax_compilation_cache_dir', '/tmp/escape-jax-cache')
start=time.time()
output=Path('refined5_k2_exact_affine');output.mkdir(exist_ok=True)
sedpath=Path('/tmp/escape-stellar-sed-data/phoenix10000_surface_flux.npz')
sed=np.load(sedpath)
edges=np.array([1.,1.05,1.05+.25/3,1.05+2*.25/3,1.3,3.])
centers=.5*(edges[1:]+edges[:-1])
model=SolarAtmosphereModel(edges, nmax=15, iron_levels=716,
    quadrature_order=2, angle_order=2, dense_lower_cells=2, lower_temperature_k=4500.,
    line_sampling="average",line_quadrature_order=4,wind_ngrid=65, tidal_coefficient_s2=3*(2*np.pi/(1.48*86400))**2,
    extra_frequency_edges=sed['frequency_hz'][[0,-1]],
    observer_options=dict(nlon=2,nlat=2,nnu=101))
boundary=model.stellar_boundary(sed['frequency_hz'],sed['surface_flux_nu'],
    incident_flux_ratio=.1, outside_zero=True)
temperature=jnp.asarray(np.interp(centers,[1.,1.175,2.15],[4500.,6000.,8000.]));mass_loss=1e13
old_centers=np.array([1.025,1.175,2.15])
initial=model.initialize(jnp.asarray(np.exp(np.interp(centers,old_centers,np.log([3e16,3e13,5e8])))),temperature)
shape=(model.cells,model.state_size+1)
value=np.asarray(jnp.column_stack((jnp.zeros(model.cells),initial))).ravel()
start_blend=0.
old=np.load('dense_boundary_full_thermal/stalled_baseline.npz')['state']
seed=np.stack([np.interp(centers,old_centers,column) for column in old[:,1:].T],axis=1)
value=np.load('refined5_average_connected_k2_affine/blend_0.0000_step_00/trial_00.npz')['state'].ravel().copy()
np.savez_compressed(output/'input_seed.npz',state=value.reshape(shape))
if (output/'checkpoint.npz').exists():
    checkpoint=np.load(output/'checkpoint.npz');value=checkpoint['state'].ravel();start_blend=float(checkpoint['blend'])

configuration=dict(edges_rp=edges.tolist(),temperature_reference_k=np.asarray(temperature).tolist(),
 mass_loss_g_s=mass_loss,nmax=15,iron_levels=716,dense_lower_cells=2,lower_temperature_k=4500.,
 inner_radiation='dark, matching selected one-sided Cloudy reference',
 source_snapshot='source_average_connected_k2 (single-function control)',
 source_manifest_sha256=hashlib.sha256(Path('source_average_connected_k2/manifest.json').read_bytes()).hexdigest(),
 driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 raw_sed_sha256=hashlib.sha256(sedpath.read_bytes()).hexdigest(),raw_sed_included=False,line_sampling="average",line_quadrature_order=4,shielding_model="continuous_core",core_escape_model="continuous",
 numerical_scope='Five coarse cells, splitting the inverted middle cell into three, exact JVP Newton with exact frozen-J inverse line-search metric (inverse secants are preconditioners only); no physical/grid adequacy or NUTS claim.')
(output/'configuration.json').write_text(json.dumps(configuration,indent=2)+'\n')
print('constructed',shape,len(model.grid.frequency_hz),len(model.metal.line_frequency_hz),time.time()-start,flush=True)

def evaluate(flat,blend):
    return model.evaluate_atmosphere(flat,temperature,mass_loss,
        boundary['incident_mean_intensity'],hydrogen_line_intensity=boundary['hydrogen_line_intensity'],
        metal_line_intensity=boundary['metal_line_intensity'],overlap_intensity=boundary['overlap_intensity'],
        thermal_blend=blend)
function=jax.jit(lambda x,b:evaluate(x,b)[0])
product=jax.jit(lambda x,b,v:jax.jvp(lambda y:evaluate(y,b)[0],(x,),(v,))[1])


import threading
import signal
import resource


def heartbeat():
    while True:
        time.sleep(30)
        print('heartbeat', time.time()-start, 'maxrss_kib',
              resource.getrusage(resource.RUSAGE_SELF).ru_maxrss, flush=True)


def terminated(signum, frame):
    print('received_signal', signum, time.time()-start, flush=True)
    raise SystemExit(128+signum)


signal.signal(signal.SIGTERM, terminated)
signal.signal(signal.SIGINT, terminated)
threading.Thread(target=heartbeat, daemon=True).start()


def inverse_secant(s, y):
    norm=np.linalg.norm(s, axis=0)
    keep=(norm>0) & np.isfinite(norm)
    s, y=s[:, keep]/norm[keep], y[:, keep]/norm[keep]
    u, singular, vt=np.linalg.svd(y, full_matrices=False)
    selected=singular>singular[0]*1e-10
    left=((s-y)@vt[selected].T)/singular[selected]
    right=u[:, selected].T
    def apply(v):
        return v+left@(right@v)
    return apply, dict(rank=int(selected.sum()),singular_values=singular.tolist(),
        relative_cutoff=1e-10,secant_relative_error=float(np.linalg.norm(apply(y)-s)/np.linalg.norm(s))), left, right


previous=np.load('refined5_average_connected_k2_affine/blend_0.0000_step_00/linear_solve.npz')
probe=np.load('refined5_k2_exact_merit/result.npz')
precondition, _, _, _=inverse_secant(
    np.concatenate((previous['vectors'],probe['vectors']),axis=1),
    np.concatenate((previous['products'],probe['products']),axis=1))
receipt=json.loads(Path('refined5_k2_exact_merit/summary.json').read_text())
assert receipt['linear_valid'] and receipt['exact_inverse_merit']<.5*receipt['original_correction_norm']
(output/'certified_initial_handoff.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('initial_residual',float(abs(function(value,start_blend)).max()),time.time()-start,flush=True)

for blend in np.linspace(0.,1.,17):
    blend=float(blend)
    if blend<start_blend-1e-12:
        continue
    for iteration in range(25):
        residual=np.asarray(function(value,blend))
        norm=float(abs(residual).max())
        if not np.isfinite(norm) or norm<1e-9:
            break
        vectors=[]
        products=[]
        def matvec(v):
            result=np.array(product(value,blend,v),copy=True)
            vectors.append(np.array(v,copy=True));products.append(result.copy())
            return result
        operator=LinearOperator((value.size,value.size),dtype=float,matvec=matvec)
        inverse=LinearOperator(operator.shape,dtype=float,matvec=precondition)
        def linear_solve(rhs,label):
            trace=[]
            def callback(error):
                trace.append(float(error))
                if len(trace)%5==0:
                    print('krylov',blend,iteration,label,len(trace),error,time.time()-start,flush=True)
            solution,info=gmres(operator,rhs,M=inverse,restart=80,maxiter=3,
                rtol=1e-5,atol=0.,callback=callback,callback_type='pr_norm')
            error=float(np.linalg.norm(operator@solution-rhs)/np.linalg.norm(rhs))
            return solution,dict(label=label,true_relative_error=error,valid=bool(np.isfinite(error) and error<5e-5),iterations=len(trace),info=int(info))
        correction,linear=linear_solve(-residual,'newton')
        old_merit=float(np.linalg.norm(correction))
        step_dir=output/f'blend_{blend:.4f}_step_{iteration:02d}'
        step_dir.mkdir(exist_ok=True)
        np.savez_compressed(step_dir/'newton.npz',state=value.reshape(shape),residual=residual,correction=correction)
        trials=[];accepted=False
        if linear['valid']:
            for backtrack in range(16):
                fraction=2.**(-backtrack)
                trial=value+fraction*correction
                trial_f=np.asarray(function(trial,blend))
                finite=bool(np.isfinite(trial_f).all())
                trial_norm=float(np.max(abs(trial_f)))
                trial_row=dict(backtrack=backtrack,fraction=fraction,finite=finite,
                    original_infinity_norm=trial_norm,original_l2_norm=float(np.linalg.norm(trial_f)),
                    largest_residual_index=int(np.argmax(abs(trial_f))))
                if finite:
                    # Keep J at the original Newton point throughout this line search.
                    # B accelerates this solve; it is never used as an error norm.
                    if trial_norm==0.:
                        simplified=np.zeros_like(value)
                        check=dict(valid=True,true_relative_error=0.,iterations=0,info=0)
                    else:
                        simplified,check=linear_solve(trial_f,f'trial_{backtrack}')
                    merit=float(np.linalg.norm(simplified))
                    trial_row.update(exact_inverse_merit=merit,linear_check=check)
                    accepted=check['valid'] and merit<(1-.5*fraction)*old_merit
                trial_row['accepted']=bool(accepted)
                trials.append(trial_row)
                print('trial',blend,iteration,trial_row,flush=True)
                np.savez_compressed(step_dir/f'trial_{backtrack:02d}.npz',state=trial.reshape(shape),residual=trial_f)
                if accepted:
                    value=trial.copy()
                    break
        precondition,audit,left,right=inverse_secant(np.stack(vectors,axis=1),np.stack(products,axis=1))
        np.savez_compressed(step_dir/'krylov.npz',vectors=np.stack(vectors,axis=1),products=np.stack(products,axis=1),inverse_left=left,inverse_right=right)
        (step_dir/'preconditioner.json').write_text(json.dumps(audit,indent=2)+'\n')
        row=dict(stage='exact_affine_newton',blend=blend,step=iteration,accepted=bool(accepted),
            old_original_infinity_norm=norm,original_infinity_norm=float(abs(function(value,blend)).max()),
            old_exact_inverse_merit=old_merit,max_step=float(abs(correction).max()),
            newton_linear_check=linear,trials=trials,elapsed_s=time.time()-start)
        print(row,flush=True)
        (step_dir/'receipt.json').write_text(json.dumps(row,indent=2)+'\n')
        with (output/'history.jsonl').open('a') as stream:
            stream.write(json.dumps(row)+'\n')
        np.savez_compressed(output/'checkpoint.npz',state=value.reshape(shape),blend=blend)
        if not accepted:
            break
    norm=float(abs(function(value,blend)).max())
    print('stage',blend,norm,time.time()-start,flush=True)
    np.savez_compressed(output/f'stage_{blend:.4f}.npz',state=value.reshape(shape),blend=blend,residual=norm)
    if not np.isfinite(norm) or norm>=1e-9:
        break

residual,physical=jax.jit(evaluate)(value,blend)
full_norm=float(abs(function(value,1.)).max())
converged=bool(np.isfinite(full_norm) and full_norm<1e-9)
applicable=converged and bool(physical['reference_domain_valid'])
names=['bound_cm3','electron_cm3','proton_cm3','molecule_cm3','helium_cm3','metal_ion_cm3',
       'mean_molecular_weight','thermal_net','temperature_k','n_h_cm3','radial_velocity_kms',
       'pressure_dyn_cm2','reference_domain_valid','thermal_balance_required']
np.savez_compressed(output/'solution.npz',state=value.reshape(shape),residual_norm=float(abs(residual).max()),
    full_thermal_residual_norm=full_norm,blend=blend,converged=converged,applicable=applicable,
    **{key:np.asarray(physical[key]) for key in names})
summary=dict(residual_norm=float(abs(residual).max()),full_thermal_residual_norm=full_norm,blend=blend,
    converged=converged,applicable=bool(applicable),temperature_k=np.asarray(physical['temperature_k']).tolist(),
    n_h_cm3=np.asarray(physical['n_h_cm3']).tolist(),pressure_bar=(np.asarray(physical['pressure_dyn_cm2'])/1e6).tolist(),elapsed_s=time.time()-start)
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(summary,flush=True)
