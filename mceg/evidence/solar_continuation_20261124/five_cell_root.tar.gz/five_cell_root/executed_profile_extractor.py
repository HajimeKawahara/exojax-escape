"""Exact-JVP numerical candidate for the current coupled Solar atmosphere.

Host Newton is a checkpointed diagnostic. It does not replace the production
implicit derivative and never accepts a failed or out-of-domain atmosphere.
"""
from pathlib import Path
import json
import hashlib
import time
import jax
import jax.numpy as jnp
import numpy as np
from scipy.sparse.linalg import LinearOperator, gmres
from escape.solar import SolarAtmosphereModel

jax.config.update('jax_enable_x64', True)
jax.config.update('jax_compilation_cache_dir', '/tmp/escape-jax-cache')
start=time.time()
output=Path('refined5_fixed_temperature_root_profile');output.mkdir(exist_ok=True)
sedpath=Path('/tmp/escape-stellar-sed-data/phoenix10000_surface_flux.npz')
sed=np.load(sedpath)
edges=np.array([1.,1.05,1.05+.25/3,1.05+2*.25/3,1.3,3.])
centers=.5*(edges[1:]+edges[:-1])
model=SolarAtmosphereModel(edges, nmax=15, iron_levels=716,
    quadrature_order=2, angle_order=2, dense_lower_cells=2, lower_temperature_k=4500.,
    line_sampling="average",line_quadrature_order=4,wind_ngrid=65, tidal_coefficient_s2=3*(2*np.pi/(1.48*86400))**2,
    extra_frequency_edges=sed['frequency_hz'][[0,-1]],
    observer_options=dict(nlon=2,nlat=2,nnu=101))
boundary=model.stellar_boundary(sed['frequency_hz'],sed['surface_flux_nu'],
    incident_flux_ratio=.1, outside_zero=True)
temperature=jnp.asarray(np.interp(centers,[1.,1.175,2.15],[4500.,6000.,8000.]));mass_loss=1e13
old_centers=np.array([1.025,1.175,2.15])
initial=model.initialize(jnp.asarray(np.exp(np.interp(centers,old_centers,np.log([3e16,3e13,5e8])))),temperature)
shape=(model.cells,model.state_size+1)
value=np.asarray(jnp.column_stack((jnp.zeros(model.cells),initial))).ravel()
start_blend=0.
old=np.load('dense_boundary_full_thermal/stalled_baseline.npz')['state']
seed=np.stack([np.interp(centers,old_centers,column) for column in old[:,1:].T],axis=1)
value=np.load('refined5_k2_exact_affine/stage_0.0000.npz')['state'].ravel().copy()
np.savez_compressed(output/'input_seed.npz',state=value.reshape(shape))
if (output/'checkpoint.npz').exists():
    checkpoint=np.load(output/'checkpoint.npz');value=checkpoint['state'].ravel();start_blend=float(checkpoint['blend'])


from escape.hydrogen_forward import PLANET_RADIUS_CM
from escape.parker import PROTON_MASS_CGS
from escape.hydrogen_rates import BOLTZMANN_CGS
physical_temperature=np.asarray(temperature)*np.exp(value.reshape(shape)[:,0])
composition=value.reshape(shape)[:,1:]
mu=np.asarray(model.unpack(jnp.asarray(composition),jnp.ones(model.cells))['mean_molecular_weight'])
wind,info=model._wind(jnp.asarray(composition),jnp.asarray(physical_temperature),mass_loss)
density=np.asarray(wind.density_g_cm3)
pressure=density*BOLTZMANN_CGS*physical_temperature/(mu*PROTON_MASS_CGS)
physical=model.unpack(jnp.asarray(composition),jnp.asarray(density/model.mass_per_h))
np.savez_compressed(output/'profile.npz',radius_cm=np.asarray(model.radius_cm),
 temperature_k=physical_temperature,mean_molecular_weight=mu,
 velocity_cm_s=np.asarray(wind.velocity_kms)*1e5,density_g_cm3=density,
 pressure_dyn_cm2=pressure,n_h_cm3=density/model.mass_per_h,
 wind_knot_radius_cm=np.r_[PLANET_RADIUS_CM,np.asarray(model.radius_cm)],
 wind_knot_temperature_k=np.r_[model.lower_temperature_k,physical_temperature],
 wind_knot_mean_molecular_weight=np.r_[mu[0],mu],
 base_radius_cm=PLANET_RADIUS_CM,outer_radius_cm=32*PLANET_RADIUS_CM,
 planet_mass_mj=model.planet_mass_mj,tidal_coefficient_s2=model.tidal_coefficient_s2,
 mass_loss_g_s=mass_loss,wind_ngrid=model.wind_ngrid,
 bound_cm3=np.asarray(physical['bound_cm3']),electron_cm3=np.asarray(physical['electron_cm3']),proton_cm3=np.asarray(physical['proton_cm3']),molecule_cm3=np.asarray(physical['molecule_cm3']),helium_cm3=np.asarray(physical['helium_cm3']),metal_ion_cm3=np.asarray(physical['metal_ion_cm3']),principal_n=np.asarray(model.hydrogen.atom.principal_n))
report=dict(source_snapshot='source_average_connected_k2',
 source_manifest_sha256=hashlib.sha256(Path('source_average_connected_k2/manifest.json').read_bytes()).hexdigest(),
 driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 state_origin='refined5_k2_exact_affine/stage_0.0000.npz',
 state_sha256=hashlib.sha256(Path('refined5_k2_exact_affine/stage_0.0000.npz').read_bytes()).hexdigest(),
 state_scope='Converged fixed-temperature population/composition/wind root, original infinity residual 2.1742607714259066e-12. Nine retained elements; C0 Federman and continuous Doppler escape. Energy balance is NOT solved.',
 thermal_blend=0.,dense_lower_cells=2,wind_valid=bool(info['valid']),
 reference_domain_valid=bool(np.all((density[2:]/model.mass_per_h<=1e15)&(pressure[2:]<=1e3))),
 n3_over_n2=(np.asarray(physical['bound_cm3'])[:,3:6].sum(1)/np.asarray(physical['bound_cm3'])[:,1:3].sum(1)).tolist(),
 wind_info={k:np.asarray(v).tolist() for k,v in info.items()},
 raw_sed_included=False,elapsed_s=time.time()-start)
(output/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(report,flush=True)
