"""Locate original K2 fit joins crossed by a recorded Newton direction."""
from pathlib import Path
import hashlib
import json

import jax
import numpy as np
from scipy.special import softmax
from scipy.optimize import brentq
from escape.solar import SolarCompositionModel
from escape.hydrogen_forward import PLANET_RADIUS_CM
from escape.metal_network import C, KB

jax.config.update('jax_enable_x64', True)
base = Path('/tmp/escape-solar-molecular-continuation')
out = base/'matched_fe716_column12_continuous_newton05'
source = base/'source_dense_boundary_continuous_core'
manifest = json.loads((source/'manifest.json').read_text())
for rel, digest in manifest['files'].items():
    assert hashlib.sha256((source/rel).read_bytes()).hexdigest() == digest
sed = np.load('/tmp/escape-stellar-sed-data/phoenix10000_surface_flux.npz')
r = np.load('/tmp/escape-continuation-Fe716-union6k/iteration_000/cloudy_profiles.npz')
edges = np.array([1,1.04,1.1,1.2,1.35,1.6,1.9,2.3,2.7,2.95,2.999,2.99999,3])*PLANET_RADIUS_CM
radius = (edges[1:]+edges[:-1])/2
T = np.exp(np.interp(radius,r['radius_cm'],np.log(r['temperature_k'])))
density = np.exp(np.interp(radius,r['radius_cm'],np.log(r['n_h_cm3'])))
m = SolarCompositionModel(edges,nmax=15,iron_levels=716,quadrature_order=4,angle_order=4,line_optical_depth_scale=2,extra_frequency_edges=sed['frequency_hz'][[0,-1]])
trial = np.load(out/'direction_000.npz'); state = trial['state']; direction = trial['correction']
atom_index = [x[0] for x in m.metal.atom_specs].index('Fe II')
atom = m.metal.atoms[atom_index]
upper,lower,nu,A,lifetime,kind = map(np.asarray,m.metal.lines[atom_index])
g = np.asarray(atom.weight)
start = m.metal_slice.start
excitation = m.metal.excitation_slices[atom_index]
charge = start+2*list(m.metal.atomic_number).index(26)
width = nu[None,:]*np.sqrt(2*KB*T[:,None]/(55.845*1.66053906660e-24))/C
factor = C*C*A[None,:]/(8*np.pi*nu[None,:]**2*np.sqrt(np.pi)*width)
# The abundance cancels in ratios, but absolute column depths require it.
element_density = np.asarray(m.unpack(state,density)['element_density_cm3'])[:,list(m.metal.atomic_number).index(26)]
def levels(alpha):
    x=state+alpha*direction
    ions=element_density*softmax(np.column_stack((x[:,charge],np.zeros(len(x)),x[:,charge+1])),axis=1)[:,1]
    return ions[:,None]*softmax(np.column_stack((np.zeros(len(x)),x[:,start+excitation.start:start+excitation.stop])),axis=1)
def columns(alpha):
    p=levels(alpha)
    delta=factor*(p[:,lower]*g[upper]/g[lower]-p[:,upper])*np.diff(edges)[:,None]
    front=np.concatenate((np.cumsum(delta[::-1],axis=0)[:-1][::-1],np.zeros_like(delta[:1])),axis=0)
    return front,2*delta.sum(axis=0)[None,:]-front
left,right=columns(0),columns(1/16)
records=[]
for side in range(2):
    for join in (.01,11):
        a,b=left[side]*np.sqrt(np.pi),right[side]*np.sqrt(np.pi)
        for cell,line in zip(*np.where((a-join)*(b-join)<0)):
            def at(alpha):
                p=levels(alpha)
                delta=factor[:,line]*(p[:,lower[line]]*g[upper[line]]/g[lower[line]]-p[:,upper[line]])*np.diff(edges)
                front=delta[cell+1:].sum()
                return np.sqrt(np.pi)*(front if side==0 else 2*delta.sum()-front)-join
            alpha=brentq(at,0,1/16,xtol=1e-14)
            pop=levels(alpha)[cell,upper[line]]
            records.append(dict(cell=int(cell),side=('front','back')[side],join_t=join,alpha=float(alpha),upper=int(upper[line]),lower=int(lower[line]),frequency_hz=float(nu[line]),wavelength_angstrom=float(C/nu[line]*1e8),einstein_a_s=float(A[line]),before_t=float(a[cell,line]),after_t=float(b[cell,line]),upper_population_cm3=float(pop),excitation_state_row=int(start+excitation.start+upper[line]-1)))
records.sort(key=lambda x:(x['cell'],x['upper'],x['alpha']))
report=dict(scope='Read-only fit-join crossing diagnostic; column crossing is not by itself a full-residual attribution.',source_manifest_sha256=hashlib.sha256((source/'manifest.json').read_bytes()).hexdigest(),state_and_direction_sha256=hashlib.sha256((out/'direction_000.npz').read_bytes()).hexdigest(),crossings=len(records),FeII_first_excitation_state_row=start+excitation.start,cases=records)
(out/'k2_crossings.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
