"""Update a numerical inverse model from exact current-state JVP pairs.

Old inverse information is approximate at a new nonlinear state. Only the new
pairs are enforced as exact secants; no atmospheric equation is modified.
"""
from pathlib import Path
import argparse
import hashlib
import json

import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument('--pairs', type=Path, required=True)
parser.add_argument('--previous', type=Path)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
with np.load(args.pairs) as data:
    state = data['state']
    vectors, products = data['vectors'], data['products']
norm = np.linalg.norm(vectors, axis=0)
usable = (norm > 0) & np.isfinite(norm)
s = vectors[:, usable] / norm[usable]
y = products[:, usable] / norm[usable]
assert np.isfinite(s).all() and np.isfinite(y).all()
if args.previous is None:
    old_left = np.empty((s.shape[0], 0))
    old_right = np.empty((0, s.shape[0]))
else:
    with np.load(args.previous) as data:
        old_left, old_right = data['left'], data['right']
assert old_left.shape[0] == old_right.shape[1] == s.shape[0]
base_y = y + old_left @ (old_right @ y)
u, singular, vt = np.linalg.svd(y, full_matrices=False)
keep = singular > 1e-10 * singular[0]
left = np.concatenate((old_left, (s - base_y) @ vt[keep].T / singular[keep]), axis=1)
right = np.concatenate((old_right, u[:, keep].T), axis=0)
error = np.linalg.norm(y + left @ (right @ y) - s) / np.linalg.norm(s)
assert np.isfinite(error) and error < 1e-7
# The small QR core measures the actual update norm, without a dense n-by-n B.
_, l = np.linalg.qr(left, mode='reduced')
_, r = np.linalg.qr(right.T, mode='reduced')
update_norm = np.linalg.norm(l @ r.T, 2)
np.savez_compressed(args.output, state=state, left=left, right=right)
report = dict(
    formula='B_new = B_old + (S - B_old Y) Y^+',
    source_pairs_sha256=hashlib.sha256(args.pairs.read_bytes()).hexdigest(),
    previous_sha256=(None if args.previous is None else hashlib.sha256(args.previous.read_bytes()).hexdigest()),
    cutoff_relative=1e-10,
    singular_values=singular.tolist(),
    current_secant_rank=int(keep.sum()),
    retained_factor_columns=int(left.shape[1]),
    current_secant_relative_error=float(error),
    inverse_update_spectral_norm=float(update_norm),
    scope='Numerical right preconditioner only. Old B is approximate at a new state; current JVP pairs alone are exact constraints. The physical residual and final convergence criterion are unchanged.',
)
args.output.with_suffix('.json').write_text(json.dumps(report, indent=2) + '\n')
print(report)
