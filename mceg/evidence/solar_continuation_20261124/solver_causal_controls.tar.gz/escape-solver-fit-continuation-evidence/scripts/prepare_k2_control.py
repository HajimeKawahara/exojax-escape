"""Create an immutable one-function K2 control from the recorded 12-cell source."""
from pathlib import Path
import ast
import hashlib
import json
import shutil

base=Path('/tmp/escape-solar-molecular-continuation')
old=base/'source_dense_boundary_continuous_core'
new=base/'source_dense_boundary_continuous_core_k2'
donor=base/'source_average_connected_k2/escape/line_escape_probability.py'
assert not new.exists()
shutil.copytree(old,new,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
path=Path('escape/line_escape_probability.py')
def function(text):
    return next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='doppler_core_escape')
source=(old/path).read_text();replacement=donor.read_text();a=function(source);b=function(replacement)
lines=source.splitlines(keepends=True);new_text=''.join(lines[:a.lineno-1]+replacement.splitlines(keepends=True)[b.lineno-1:b.end_lineno]+lines[a.end_lineno:])
(new/path).write_text(new_text)
def other_nodes(text):
    return [ast.dump(n,include_attributes=False) for n in ast.parse(text).body if not(isinstance(n,ast.FunctionDef) and n.name=='doppler_core_escape')]
assert other_nodes(source)==other_nodes(new_text)
old_manifest=json.loads((old/'manifest.json').read_text())
files={str(p.relative_to(new)):hashlib.sha256(p.read_bytes()).hexdigest() for p in new.rglob('*') if p.is_file() and p.name!='manifest.json'}
assert set(files)==set(old_manifest['files'])
changed=[name for name,digest in files.items() if digest!=old_manifest['files'][name]]
assert changed==[str(path)]
manifest=dict(old_manifest)
manifest.update(revision=old_manifest['revision']+' plus continuous Doppler K2 one-function control from d97b51f',files=files,parent_manifest_sha256=hashlib.sha256((old/'manifest.json').read_bytes()).hexdigest(),donor_module_sha256=hashlib.sha256(donor.read_bytes()).hexdigest(),control=dict(changed_function='doppler_core_escape',changed_file=str(path),selection='The donor function defaults to continuous for the old caller API; every other AST node and packaged file is unchanged.',scope='Numerical fit comparison, not proof of atmospheric equivalence, spatial convergence, or inference derivative adequacy.'))
(new/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest['control'],indent=2))
