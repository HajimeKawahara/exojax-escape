"""Inspect the coupled root with separately compiled residual/JVP kernels.

The Python/SciPy loop is a development diagnostic, not the inference solver.
No finite-difference Jacobian or substitute physical state is accepted.
"""
from pathlib import Path
import argparse
import json
import time

import jax
import jax.numpy as jnp
import numpy as np
from scipy.sparse.linalg import LinearOperator, gmres

from escape.solar import SolarCompositionModel
from escape.hydrogen_forward import PLANET_RADIUS_CM

jax.config.update('jax_enable_x64', True)
jax.config.update('jax_compilation_cache_dir', '/tmp/escape-jax-cache')
parser = argparse.ArgumentParser()
parser.add_argument('--iron-levels', type=int, default=716)
parser.add_argument('--nmax', type=int, default=15)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--log-field', type=float, default=0.)
parser.add_argument('--seed', type=Path)
parser.add_argument('--warmup', action='store_true')
parser.add_argument('--linear-seed', type=Path)
parser.add_argument('--preconditioner-history', type=Path)
parser.add_argument('--krylov-history', type=Path)
args = parser.parse_args()
args.output.mkdir(exist_ok=True)
start = time.time()
sed_path = Path('/tmp/escape-stellar-sed-data/phoenix10000_surface_flux.npz')
sed = np.load(sed_path)
reference_path = Path('/tmp/escape-continuation-Fe716-union6k/iteration_000/cloudy_profiles.npz')
reference = np.load(reference_path)
edges = np.array([1.,1.04,1.1,1.2,1.35,1.6,1.9,2.3,2.7,2.95,2.999,2.99999,3.])*PLANET_RADIUS_CM
radius = (edges[:-1]+edges[1:])/2
model = SolarCompositionModel(edges, nmax=args.nmax, iron_levels=args.iron_levels,
    quadrature_order=4, angle_order=4, line_optical_depth_scale=2.,
    extra_frequency_edges=sed['frequency_hz'][[0,-1]])
boundary = model.stellar_boundary(sed['frequency_hz'], sed['surface_flux_nu'], outside_zero=True)
def sample(name):
    values = reference[name]
    if values.ndim == 1:
        return np.exp(np.interp(radius, reference['radius_cm'], np.log(np.maximum(values, 1e-300))))
    return np.column_stack([np.exp(np.interp(radius, reference['radius_cm'], np.log(np.maximum(v, 1e-300)))) for v in values.T])
temperature, density = jnp.asarray(sample('temperature_k')), jnp.asarray(sample('n_h_cm3'))
state = model.initialize(density, temperature)
proton = density*sample('ionized_fraction')
bound = sample('bound_cm3')[:, :model.hydrogen_size]
state = state.at[:, :model.hydrogen_size].set(jnp.log(bound/proton[:,None]))
state = state.at[:, model.hydrogen_size].set(jnp.log(density*sample('hminus_fraction')/proton))
he0,he1,he2 = (sample('helium_'+label+'_fraction') for label in ['neutral','singly_ionized','doubly_ionized'])
state = state.at[:, model.helium_slice].set(jnp.asarray(np.column_stack((np.log(he1/he0),np.log(he2/he0)))))
if args.seed is not None:
    state = jnp.asarray(np.load(args.seed)['state'])
import hashlib
receipt = dict(source_snapshot='source_dense_boundary_continuous_core_k2/manifest.json',
    stellar_source_sha256=hashlib.sha256(sed_path.read_bytes()).hexdigest(),
    reference_sha256=hashlib.sha256(reference_path.read_bytes()).hexdigest(),
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    purpose='Prescribed-temperature/density comparison, not a thermal atmosphere or spatial-convergence proof.',
    radius_edges_cm=edges.tolist())
(args.output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
shape = state.shape
print('constructed', shape, len(model.metal.line_frequency_hz), time.time()-start, flush=True)

def residual(flat, log_field):
    target, physical = model.evaluate(flat.reshape(shape), density,
        temperature, **{key: value*jnp.exp(log_field) for key,value in boundary.items()})
    return jnp.where(physical['valid'], (flat.reshape(shape)-target).ravel(), jnp.nan)

function = jax.jit(residual)
product = jax.jit(lambda flat, field, tangent: jax.jvp(
    lambda x: residual(x, field), (flat,), (tangent,))[1])
value = np.asarray(state).ravel()
history = []
manifest_path=Path('/tmp/escape-solar-molecular-continuation/source_dense_boundary_continuous_core_k2/manifest.json')
manifest=json.loads(manifest_path.read_text())
for name,digest in manifest['files'].items():
    assert hashlib.sha256((manifest_path.parent/name).read_bytes()).hexdigest()==digest
receipt.update(source_manifest_sha256=hashlib.sha256(manifest_path.read_bytes()).hexdigest(),source_revision=manifest['revision'])
receipt['linear_solver']='Restarted GMRES20 on J B with exact JVP, one block per incomplete solve. The residual correction starts at the best saved direction. Right preconditioning minimizes the original linear residual; the explicitly recorded forcing criterion controls trial-step accuracy and the strict physical-root criterion is unchanged.'
(args.output/'driver.py').write_text(Path(__file__).read_text())
(args.output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
current=np.asarray(function(value,args.log_field));assert np.isfinite(current).all()
print(dict(stage='initial',residual=float(np.max(abs(current))),elapsed=time.time()-start),flush=True)
np.savez_compressed(args.output/'checkpoint.npz',state=value.reshape(shape),residual=float(np.max(abs(current))))
if args.warmup:
    print('Compiling exact JVP',flush=True)
    tangent=np.random.default_rng(0).normal(size=value.size)
    derivative=np.asarray(product(value,args.log_field,tangent))
    report=dict(finite=bool(np.isfinite(derivative).all()),maximum=float(np.max(abs(derivative))),elapsed=time.time()-start,scope='State-Jacobian warmup only, not parameter/inference proof.')
    (args.output/'warmup.json').write_text(json.dumps(report,indent=2)+'\n');print(report,flush=True)
    raise SystemExit(0 if report['finite'] else 1)

import os
if os.environ.get('ESCAPE_K2_TWO_SIDED')=='1':
    trial=np.load(args.linear_seed)
    np.testing.assert_array_equal(trial['state'],value.reshape(shape))
    center=.043470281092442296
    direction=trial['correction'].ravel()
    cases=[];arrays={}
    for epsilon in (1e-5,1e-6,1e-7):
        pair=[]
        for sign in (-1,1):
            at=center+sign*epsilon
            f=np.asarray(function(value+at*direction,args.log_field))
            assert np.isfinite(f).all()
            arrays['epsilon_'+str(epsilon)+'_sign_'+str(sign)]=f.reshape(shape)
            pair.append(f)
        jump=pair[1]-pair[0]
        cases.append(dict(epsilon=epsilon,maximum_jump=float(abs(jump).max()),maximum_row=list(map(int,np.unravel_index(np.argmax(abs(jump)),shape))),FeII_190_jump=float(jump.reshape(shape)[7,436])))
        print(cases[-1],flush=True)
    report=dict(scope='Same full physical residual on two sides of a single identified original K2 fit join; no equation or target change.',alpha=center,transition='Fe II 190 -> 11 (zero-based), cell 7, 1649.576793 Angstrom, front t=sqrt(pi)*tau=.01',cases=cases,elapsed=time.time()-start)
    (args.output/'two_sided.json').write_text(json.dumps(report,indent=2)+'\n')
    np.savez_compressed(args.output/'two_sided_residuals.npz',**arrays)
    raise SystemExit(0)

def checkpoint(row):
    row['elapsed'] = time.time()-start
    history.append(row)
    print(row, flush=True)
    np.savez_compressed(args.output/'checkpoint.npz', state=value.reshape(shape))
    (args.output/'history.json').write_text(json.dumps(history, indent=2)+'\n')

def inverse_secant(s, y, *, beta=1., relative_cutoff=1e-10):
    """SVD update B=beta I+(S-beta Y)Y^+, with no normal equations."""
    magnitude=np.linalg.norm(s, axis=0)
    usable=(magnitude>0) & np.isfinite(magnitude)
    s=s[:, usable]/magnitude[usable]
    y=y[:, usable]/magnitude[usable]
    u, singular, vt=np.linalg.svd(y, full_matrices=False)
    keep=singular>relative_cutoff*singular[0]
    left=(s-beta*y)@vt[keep].T/singular[keep]
    right=u[:, keep].T
    def apply(v):
        return beta*v+left@(right@v)
    audit=dict(beta=beta, relative_cutoff=relative_cutoff,
               singular_values=singular.tolist(), rank=int(keep.sum()),
               secant_relative_error=float(np.linalg.norm(apply(y)-s)/np.linalg.norm(s)),
               inverse_update_norm=float(np.linalg.norm(left, 2)))
    return apply, audit, (s, y, left, right)

def apply_inverse(v):
    return v
preconditioner_report=dict(kind='Identity until exact current-J pairs are available', scope='No old nonlinear secant preconditioner is reused.')
(args.output/'preconditioner.json').write_text(json.dumps(preconditioner_report,indent=2)+'\n');print(preconditioner_report,flush=True)
recycled_vectors=[];recycled_products=[]
if args.krylov_history is not None:
    old_pairs=np.load(args.krylov_history)
    old_b,audit,_=inverse_secant(old_pairs['vectors'],old_pairs['products'])
    apply_inverse=old_b
    old_receipt=json.loads((args.krylov_history.parent/'receipt.json').read_text())
    same_source=old_receipt['source_manifest_sha256']==receipt['source_manifest_sha256']
    identical=np.array_equal(old_pairs['state'],value.reshape(shape)) and same_source
    audit['identical_source']=bool(same_source)
    audit.update(identical_linearization_state=bool(identical),scope='Approximate preconditioner only; old exact JVP pairs are accumulated only at an identical state.')
    if identical:
        recycled_vectors=list(old_pairs['vectors'].T);recycled_products=list(old_pairs['products'].T)
    (args.output/'recycled_preconditioner.json').write_text(json.dumps(audit,indent=2)+'\n');print(audit,flush=True)
import os
inverse_model_path=os.environ.get('ESCAPE_NEWTON_INVERSE_MODEL')
if inverse_model_path is not None:
    inverse_model_path=Path(inverse_model_path)
    inverse_data=np.load(inverse_model_path)
    inverse_left,inverse_right=inverse_data['left'],inverse_data['right']
    assert inverse_left.shape[0]==inverse_right.shape[1]==value.size
    def apply_inverse(v):
        return v+inverse_left@(inverse_right@v)
    receipt['inverse_model']=dict(sha256=hashlib.sha256(inverse_model_path.read_bytes()).hexdigest(),same_state=bool(np.array_equal(inverse_data['state'],value.reshape(shape))),scope='Approximate numerical inverse; old-state pairs are not accumulated as current exact JVP constraints.')
trial_only=os.environ.get('ESCAPE_NEWTON_TRIAL_ONLY','0')=='1'
forcing_cap=float(os.environ.get('ESCAPE_NEWTON_FORCING_CAP','0.00005'))
assert 0<forcing_cap<=.2
receipt['nonlinear_forcing']=dict(cap=forcing_cap,reference_residual=0.0018826275046635033,formula='max(1e-5, min(cap, cap * (F_inf / 0.0018826275046635033)**0.75))',scope='Trial-step linear accuracy only. Final physical root remains F_inf < 1e-9; no inference derivative claim.')
receipt['trial_only']=trial_only
(args.output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
for i in range(1):
    current = np.asarray(function(value, args.log_field))
    norm = float(np.max(np.abs(current)))
    if not np.isfinite(norm) or norm < 1e-10:
        break
    vectors=list(recycled_vectors);products=list(recycled_products)
    def matvec(tangent):
        result=np.array(product(value,args.log_field,tangent),copy=True)
        assert np.isfinite(result).all()
        vectors.append(np.array(tangent,copy=True));products.append(result.copy())
        temporary=args.output/'krylov_pairs.inprogress.npz'
        np.savez_compressed(temporary,state=value.reshape(shape),vectors=np.stack(vectors,axis=1),products=np.stack(products,axis=1))
        temporary.replace(args.output/'krylov_pairs.npz')
        return result
    operator = LinearOperator((value.size, value.size),dtype=float,matvec=matvec)
    trace = []
    def callback(error):
        trace.append(float(error))
        if len(trace) % 5 == 0:
            print(dict(stage='right_preconditioned_true_residual_krylov', step=i, iteration=len(trace), relative=float(error), elapsed=time.time()-start), flush=True)
    initial_direction=None
    if i==0 and args.linear_seed is not None:
        previous=np.load(args.linear_seed)
        np.testing.assert_array_equal(previous['state'],value.reshape(shape))
        initial_direction=previous['correction'].ravel()
    forcing=max(1e-5,min(forcing_cap,forcing_cap*(norm/0.0018826275046635033)**.75))
    if initial_direction is None:
        initial_direction=np.zeros_like(current)
        initial_product=np.zeros_like(current)
    else:
        initial_product=operator@initial_direction
    right_hand_side=-current-initial_product
    right_operator=LinearOperator((value.size,value.size),dtype=float,
        matvec=lambda tangent: operator@apply_inverse(tangent))
    if trial_only:
        assert initial_direction is not None
        correction=initial_direction
        info=0
    else:
        increment, info = gmres(right_operator, right_hand_side, restart=20, maxiter=1,
            rtol=min(.99,.95*forcing*np.linalg.norm(current)/np.linalg.norm(right_hand_side)), atol=0., callback=callback, callback_type='pr_norm')
        correction=initial_direction+apply_inverse(increment)
    j_correction=operator@correction
    error = float(np.linalg.norm(j_correction+current)/np.linalg.norm(current))
    metric,audit,_=inverse_secant(np.stack(vectors,axis=1),np.stack(products,axis=1))
    old_merit=float(np.linalg.norm(metric(current)))
    (args.output/'metric.json').write_text(json.dumps(audit,indent=2)+'\n')
    np.savez_compressed(args.output/('direction_%03d.npz'%i), state=value.reshape(shape), correction=correction.reshape(shape), residual=current.reshape(shape))
    print(dict(stage='direction', step=i, maximum=float(np.max(np.abs(correction))), relative_error=error), flush=True)
    accepted, backtracks = False, 0
    forcing=max(1e-5,min(forcing_cap,forcing_cap*(norm/0.0018826275046635033)**.75))
    if np.isfinite(error) and error < forcing:
        for backtracks in range(24):
            candidate = value+2.**(-backtracks)*correction
            after = np.asarray(function(candidate, args.log_field))
            print(dict(stage='trial',step=i,backtrack=backtracks,finite=bool(np.isfinite(after).all()),residual=float(np.max(abs(after))),maximum_row=list(map(int,np.unravel_index(np.argmax(abs(after)),shape))),inverse_metric=float(np.linalg.norm(metric(after))),old_inverse_metric=old_merit,physical_l2=float(np.linalg.norm(after)),old_physical_l2=float(np.linalg.norm(current)),linearization_error=float(np.max(abs(after-current-2.**(-backtracks)*j_correction))),linearization_maximum_row=list(map(int,np.unravel_index(np.argmax(abs(after-current-2.**(-backtracks)*j_correction)),shape)))),flush=True)
            if np.all(np.isfinite(after)) and np.linalg.norm(after) < np.linalg.norm(current):
                value, accepted = candidate, True
                break
    checkpoint(dict(stage='newton', step=i, residual=float(np.max(np.abs(function(value, args.log_field)))),
        accepted=accepted, linear_relative_error=error, krylov_iterations=len(trace),
        gmres_info=int(info), backtracks=backtracks, forcing=forcing, merit='Euclidean norm of the unmodified physical residual'))
    if not accepted:
        break

norm = float(np.max(np.abs(function(value, args.log_field))))
summary = dict(converged=bool(np.isfinite(norm) and norm < 1e-9),
    residual=norm, elapsed=time.time()-start, iron_levels=args.iron_levels,
    nmax=args.nmax, log_field=args.log_field,
    purpose='Fixed-profile numerical integration proof; not atmospheric adequacy.')
(args.output/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(summary, flush=True)
if summary['converged']:
    _, physical = jax.jit(model.evaluate)(value.reshape(shape), density, temperature,
        **{key: value*jnp.exp(args.log_field) for key,value in boundary.items()})
    names = ['bound_cm3', 'electron_cm3', 'proton_cm3', 'molecule_cm3', 'helium_cm3',
             'metal_ion_cm3', 'mean_molecular_weight', 'thermal_net', 'temperature_k', 'n_h_cm3']
    np.savez_compressed(args.output/'solution.npz', state=value.reshape(shape),
        radius_cm=radius, radius_edges_cm=edges,
        **{key: np.asarray(physical[key]) for key in names},
        **{'metal_levels_'+str(i):np.asarray(level) for i,level in enumerate(physical['metal_levels_cm3'])})
