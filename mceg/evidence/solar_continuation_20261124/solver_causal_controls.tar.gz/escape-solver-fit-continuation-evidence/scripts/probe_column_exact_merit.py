"""Accuracy-controlled frozen-J inverse norm, never an approximate B norm."""
from pathlib import Path
import argparse,json,sys,hashlib,time
import numpy as np
from scipy.sparse.linalg import LinearOperator,gmres

p=argparse.ArgumentParser()
p.add_argument('--seed',type=Path,required=True)
p.add_argument('--direction',type=Path,required=True)
p.add_argument('--alpha',type=float,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--krylov-history',type=Path)
p.add_argument('--previous-correction',type=Path)
probe=p.parse_args()
base=Path('/tmp/escape-solar-molecular-continuation')
setup=base/'solve_reference_column_continuous_k2.py'
probe.output.mkdir(exist_ok=False)
(probe.output/'setup.py').write_bytes(setup.read_bytes())
sys.argv=[str(setup),'--seed',str(probe.seed),'--output',str(probe.output)]
if probe.krylov_history:sys.argv+=['--krylov-history',str(probe.krylov_history)]
namespace={'__file__':str(probe.output/'setup.py'),'__name__':'__setup__'}
exec(compile(setup.read_text().split('for i in range(1):',1)[0],str(probe.output/'setup.py'),'exec'),namespace)
globals().update({k:v for k,v in namespace.items() if not k.startswith('__')})
source_direction=np.load(probe.direction)
np.testing.assert_array_equal(source_direction['state'],value.reshape(shape))
target=value+probe.alpha*source_direction['correction'].ravel()
rhs=-np.asarray(function(target,0.));assert np.isfinite(rhs).all()
vectors=list(recycled_vectors);products=list(recycled_products)
def operator(tangent):
 result=np.array(product(value,0.,tangent),copy=True)
 assert np.isfinite(result).all()
 vectors.append(np.array(tangent,copy=True));products.append(result.copy())
 tmp=probe.output/'krylov_pairs.inprogress.npz'
 np.savez_compressed(tmp,state=value.reshape(shape),vectors=np.stack(vectors,axis=1),products=np.stack(products,axis=1))
 tmp.replace(probe.output/'krylov_pairs.npz')
 return result
initial=np.zeros_like(value)
if probe.previous_correction:
 data=np.load(probe.previous_correction)
 np.testing.assert_array_equal(data['base_state'],value.reshape(shape))
 np.testing.assert_array_equal(data['target_state'],target.reshape(shape))
 initial=data['inverse_correction'].ravel()
elif probe.alpha==0:
 initial=source_direction['correction'].ravel()
initial_product=operator(initial) if np.any(initial) else np.zeros_like(rhs)
remaining=rhs-initial_product
trace=[]
def callback(error):
 trace.append(float(error))
 if len(trace)%4==0:print(dict(stage='frozen_J',iteration=len(trace),relative=float(error),elapsed=time.time()-start),flush=True)
right=LinearOperator((value.size,value.size),dtype=float,matvec=lambda v:operator(apply_inverse(v)))
z,info=gmres(right,remaining,restart=20,maxiter=1,rtol=min(.99,1e-5*np.linalg.norm(rhs)/np.linalg.norm(remaining)),atol=0,callback=callback,callback_type='pr_norm')
correction=initial+apply_inverse(z)
relative=float(np.linalg.norm(operator(correction)-rhs)/np.linalg.norm(rhs))
np.savez_compressed(probe.output/'inverse_correction.npz',base_state=value.reshape(shape),target_state=target.reshape(shape),inverse_correction=correction.reshape(shape),target_residual=-rhs.reshape(shape))
report=dict(alpha=probe.alpha,true_linear_relative_error=relative,linear_accurate=relative<5e-5,inverse_correction_norm=float(np.linalg.norm(correction)),inverse_correction_max=float(abs(correction).max()),target_residual_infinity=float(abs(rhs).max()),target_residual_l2=float(np.linalg.norm(rhs)),iterations=len(trace),gmres_info=int(info),elapsed=time.time()-start,scope='Frozen-J exact inverse norm with a measured true linear residual. No nonlinear step or strict physical root is accepted by this probe.',source_manifest_sha256=receipt['source_manifest_sha256'],probe_driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(probe.output/'probe_driver.py').write_bytes(Path(__file__).read_bytes())
(probe.output/'probe.json').write_text(json.dumps(report,indent=2)+'\n');print(report,flush=True)
