"""Read-only exact column diagnostic for the archived Anderson trials."""
from pathlib import Path
import hashlib,json,sys
import numpy as np
import jax
import jax.numpy as jnp
from exojax.special.faddeeva import rewofz
from escape.solar import SolarCompositionModel
from escape.hydrogen_forward import PLANET_RADIUS_CM
from escape.hydrogen_escape_probability import vvoigt,BOLTZMANN_CGS,LIGHT_SPEED_CGS,PROTON_MASS_CGS
from escape.metal_network import C,KB
jax.config.update('jax_enable_x64',True)
base=Path('/tmp/escape-solar-molecular-continuation')
out=base/'matched_fe716_column12_anderson_federman_chunk03'
source=base/'source_dense_boundary_federman'
manifest=json.loads((source/'manifest.json').read_text())
for rel,wanted in manifest['files'].items():assert hashlib.sha256((source/rel).read_bytes()).hexdigest()==wanted
sed=np.load('/tmp/escape-stellar-sed-data/phoenix10000_surface_flux.npz')
r=np.load('/tmp/escape-continuation-Fe716-union6k/iteration_000/cloudy_profiles.npz')
edges=np.array([1.,1.04,1.1,1.2,1.35,1.6,1.9,2.3,2.7,2.95,2.999,2.99999,3.])*PLANET_RADIUS_CM
radius=(edges[1:]+edges[:-1])/2
T=np.exp(np.interp(radius,r['radius_cm'],np.log(r['temperature_k'])))
density=np.exp(np.interp(radius,r['radius_cm'],np.log(r['n_h_cm3'])))
m=SolarCompositionModel(edges,nmax=15,iron_levels=716,quadrature_order=4,angle_order=4,line_optical_depth_scale=2.,extra_frequency_edges=sed['frequency_hz'][[0,-1]])

trial=np.load(out/'trials/step_0045.npz');a=trial['base_state'];b=a+trial['anderson_direction']
index=[x[0] for x in m.metal.atom_specs].index('N I');atom=m.metal.atoms[index];line=m.metal.lines[index]
upper,lower,nu,A,lifetime,kind=map(np.asarray,line);g=np.asarray(atom.weight)
def columns(state):
 physical=m.unpack(jnp.asarray(state),jnp.asarray(density));levels=np.asarray(physical['metal_levels_cm3'][index]);mass=14.007*1.66053906660e-24
 width=nu[None,:]*np.sqrt(2*KB*T[:,None]/mass)/C
 factor=C*C*A[None,:]/(8*np.pi*nu[None,:]**2*np.sqrt(np.pi)*width)
 delta=(factor*levels[:,lower]*g[upper]/g[lower]-factor*levels[:,upper])*np.diff(edges)[:,None]
 front=np.concatenate((np.cumsum(delta[::-1],axis=0)[:-1][::-1],np.zeros_like(delta[:1])),axis=0)
 return front,2*delta.sum(0)[None,:]-front,delta
old=columns(a);new=columns(b);report=[]
for which,(v,w) in enumerate(zip(old,new)):
 for boundary in (0.,.01/np.sqrt(np.pi),2.,10.,11/np.sqrt(np.pi),100.):
  for cell,j in zip(*np.where((v-boundary)*(w-boundary)<0)):
   row=dict(column=('front','back','zone')[which],boundary=boundary,cell=int(cell),upper=int(upper[j]),lower=int(lower[j]),frequency_hz=float(nu[j]),before=float(v[cell,j]),after=float(w[cell,j]),einstein_a_s=float(A[j]));report.append(row);print(row,flush=True)
(out/'nitrogen_branch_crossings.json').write_text(json.dumps(dict(scope='Exact archived finite-state line-column diagnostic; no model change or physical clipping.',cases=report),indent=2)+'\n')
