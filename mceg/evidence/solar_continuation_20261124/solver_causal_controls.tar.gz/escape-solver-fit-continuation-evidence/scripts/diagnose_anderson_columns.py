"""Read-only exact column diagnostic for the archived Anderson trials."""
from pathlib import Path
import hashlib,json,sys
import numpy as np
import jax
import jax.numpy as jnp
from exojax.special.faddeeva import rewofz
from escape.solar import SolarCompositionModel
from escape.hydrogen_forward import PLANET_RADIUS_CM
from escape.hydrogen_escape_probability import vvoigt,BOLTZMANN_CGS,LIGHT_SPEED_CGS,PROTON_MASS_CGS
from escape.metal_network import C,KB
jax.config.update('jax_enable_x64',True)
base=Path('/tmp/escape-solar-molecular-continuation')
out=base/'matched_fe716_column12_anderson'
source=base/'source_dense_boundary'
manifest=json.loads((source/'manifest.json').read_text())
for rel,wanted in manifest['files'].items():assert hashlib.sha256((source/rel).read_bytes()).hexdigest()==wanted
sed=np.load('/tmp/escape-stellar-sed-data/phoenix10000_surface_flux.npz')
r=np.load('/tmp/escape-continuation-Fe716-union6k/iteration_000/cloudy_profiles.npz')
edges=np.array([1.,1.04,1.1,1.2,1.35,1.6,1.9,2.3,2.7,2.95,2.999,2.99999,3.])*PLANET_RADIUS_CM
radius=(edges[1:]+edges[:-1])/2
T=np.exp(np.interp(radius,r['radius_cm'],np.log(r['temperature_k'])))
density=np.exp(np.interp(radius,r['radius_cm'],np.log(r['n_h_cm3'])))
m=SolarCompositionModel(edges,nmax=15,iron_levels=716,quadrature_order=4,angle_order=4,line_optical_depth_scale=2.,extra_frequency_edges=sed['frequency_hz'][[0,-1]])
trials=np.load(out/'trials/step_0000.npz')
states={'seed':np.load(out/'seed.npz')['state'],'first_invalid_picard':trials['base_state']+trials['picard_direction'],'first_accepted':trials['base_state']+trials['picard_direction']/16,'current_best':np.load(out/'checkpoint.npz')['state']}

def columns(delta):
 front=np.concatenate((np.cumsum(delta[::-1],axis=0)[:-1][::-1],np.zeros_like(delta[:1])),axis=0)
 total=2*delta.sum(0)
 return front,total,total[None,:]-front

def describe(front,total,back,upper,lower,nu):
 def one(values):
  arg=np.unravel_index(np.argmin(values),values.shape)
  line=arg[-1]
  return {'minimum':float(values[arg]),'index':list(map(int,arg)),'upper':int(upper[line]),'lower':int(lower[line]),'wavelength_angstrom':float(C/nu[line]*1e8)}
 return {'tau_in':one(front),'tau_total':one(total),'tau_out':one(back),'below_minus30_count':int(np.sum(front<=-30)+np.sum(back<=-30))}
result={}
for label,state in states.items():
 physical=m.unpack(jnp.asarray(state),jnp.asarray(density));bound=np.asarray(physical['bound_cm3'])
 h=m.hydrogen; a=h.atom
 nu=np.asarray(a.line_frequency_hz);upper=np.asarray(a.line_upper);lower=np.asarray(a.line_lower);g=np.asarray(a.statistical_weights)
 width=nu[None,:]/LIGHT_SPEED_CGS*np.sqrt(2*BOLTZMANN_CGS*T[:,None]/PROTON_MASS_CGS)
 factor=LIGHT_SPEED_CGS**2*np.asarray(a.einstein_a_s)/(8*np.pi*nu**2)/(np.sqrt(np.pi)*width)
 kappa=factor*(bound[:,lower]*g[upper]/g[lower]-bound[:,upper])
 fine_matrix=np.asarray(jax.vmap(lambda w:vvoigt(a.line_frequency_hz[None,:]-a.line_frequency_hz[:,None],w/jnp.sqrt(2),h._gamma_hz)*jnp.sqrt(jnp.pi)*w[:,None])(jnp.asarray(width)))
 fine=np.einsum('cl,clk->ck',kappa,fine_matrix)
 if h.line_overlap_model=='coincident':fine=kappa@np.asarray(h._multiplets)
 front,total,back=columns(fine*np.diff(edges)[:,None])
 row={'hydrogen':describe(front,total,back,upper,lower,nu),'metals':{}}
 for atom,spec,levels,line in zip(m.metal.atoms,m.metal.atom_specs,physical['metal_levels_cm3'],m.metal.lines):
  upper,lower,nu,A,lifetime,kind=map(np.asarray,line)
  levels=np.asarray(levels);g=np.asarray(atom.weight)
  mass=dict(m.metal.elements)[spec[1]]*1.66053906660e-24
  width=nu[None,:]*np.sqrt(2*KB*T[:,None]/mass)/C
  factor=C*C*A[None,:]/(8*np.pi*nu[None,:]**2*np.sqrt(np.pi)*width)
  kappa=factor*levels[:,lower]*g[upper]/g[lower]-factor*levels[:,upper]
  front,total,back=columns(kappa*np.diff(edges)[:,None])
  row['metals'][spec[0]]=describe(front,total,back,upper,lower,nu)
 result[label]=row
 print(label,'Hmin',row['hydrogen']['tau_in']['minimum'],'badmetals',{k:v for k,v in row['metals'].items() if v['below_minus30_count']},flush=True)
receipt={'source_revision':manifest['revision'],'source_manifest_sha256':hashlib.sha256((source/'manifest.json').read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Exact line column formulas, NumPy accumulation; not a second full F evaluation. Physics is unchanged.','states':result}
(out/'line_column_diagnostics.json').write_text(json.dumps(receipt,indent=2)+'\n')
