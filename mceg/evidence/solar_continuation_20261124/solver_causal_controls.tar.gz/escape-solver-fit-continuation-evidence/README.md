# Causal line-fit and nonlinear-solver controls

This archive documents a **conditional numerical investigation**, not a solved
solar atmosphere. The fixed-temperature/density, twelve-cell model retained nine
metal elements, Fe II 716 levels and H n<=15. It predates sulfur and the new
conservative Fe II/Ly-alpha exchange. Despite the source directory name, this
driver does not enable the dense atomic-LTE mask.

## What was established

1. An incorrectly selected negative-optical-depth Federman branch produced a
   non-finite trial at a Fe II optical depth near -1. The isolated correction
   makes that same full-model trial finite. Original C++ negative-tau parity and
   the explicitly chosen continuous value at tau=-1 are distinguished in
   `negative_branch/`.
2. The original positive-tau Federman fit has a jump at tau=2. A full-model
   nitrogen transition crosses it; connecting the fitted branches removes that
   declared numerical discontinuity. This is an alternative fit, not source
   identity with the original C23 fit.
3. Independently, Fe II 190->11 (1649.576793 Angstrom) crosses the original K2
   join sqrt(pi)*tau=0.01. The full Fe-level residual jumps by 0.001069994216 as
   the two-sided displacement tends to zero. Replacing **only**
   `doppler_core_escape` with the independently checked continuous variant makes
   the same row difference scale to 6.16e-13 at displacement 1e-7. The full
   residual difference also decreases in proportion to the displacement.
4. Current-J SVD inverse-secant right preconditioning eventually gives a
   frozen-J inverse with a separately measured true linear relative residual
   5.55e-6. It does not solve the nonlinear model. The best accepted nonlinear
   residual is 0.0014493, above the unchanged 1e-9 criterion. No approximate B
   norm is accepted as an accurate nonlinear affine merit.

The investigation ended after the last bounded batch because the newer ten-
element plus Fe/Ly-alpha target superseded this numerical experiment. Failed
trials, inaccurate linear solves and the unresolved nonlinear root are retained.

## Replay and provenance

- `source/` contains the changed primitive module and full per-file manifests for
  the four frozen sources. Reconstruct other package files/data from the pinned
  provider revision in each manifest; the original dense-boundary snapshot is
  revision `12dbf5aa6d6af7e9b93f9bac83bceadbc52bbcec`.
- `states/` contains only state vectors, correction vectors and residuals. The
  keys, shapes and dtypes are explicitly audited in `npz_keys.json`.
- `scripts/` preserves the exact diagnostic/solver recipes. Update local paths
  after reconstruction; use CPU float64 JAX and the ExoJAX version recorded by
  the provider's reference environment. Source and input hashes in `reports.json`
  must match before interpreting a replay. The original stellar spectrum and
  prescribed reference profile must be retrieved separately using their recorded
  hashes. No stellar spectrum/flux array is redistributed here.
- `reports.json` consolidates original receipts, rejected/accepted trial histories,
  source identities and measured linear errors. Its entries retain original file
  paths and hashes. Large transient Krylov caches are omitted; reconstructing a
  preconditioner may change iteration cost but must not change the physical
  residual or acceptance criterion.
- Re-evaluate `best_accepted_state.npz` with the continuous-core-plus-K2 source.
  Re-evaluate `accurate_frozen_J_inverse.npz` at its own `base_state` (which is
  intentionally different from the later best accepted state) and verify
  J*inverse_correction = -target_residual to the recorded relative tolerance.
- For the K2 causal check, use `k2_crossing_base_and_direction.npz`,
  alpha=0.043470281092442296 and displacements 1e-5, 1e-6, 1e-7. Compare the
  continuous-core source with the single-function K2 variant. The JSON reports
  include the affected line and all audited join crossings.

Nothing here establishes temperature/wind balance, grid convergence, Cloudy
agreement, agreement with the paper, or an inference-ready derivative of the
complete atmosphere.
