"""Compare coarse raw-density differences with the same Parker momentum ODE.

The ODE diagnostic is used only away from the sonic point. A production
implementation should differentiate the already regular wind interpolant.
"""
from pathlib import Path
from hashlib import sha256
import json
import numpy as np

source = Path('/tmp/escape-five-cell-root-evidence/profile.npz')
p = np.load(source)
r, rho, v = (p[k] for k in ('radius_cm', 'density_g_cm3', 'velocity_cm_s'))
t, mu = p['temperature_k'], p['mean_molecular_weight']
# Same ExoJAX constants as the actual frozen momentum calculation.
k, m, grav, mj = 1.38064852e-16, 1.67262192369e-24, 6.67408e-8, 1.8986e30
a2 = k*t/(mu*m)
knots = np.log(p['wind_knot_radius_cm'])
values = np.log(p['wind_knot_temperature_k']/p['wind_knot_mean_molecular_weight'])
beta = np.r_[0., (values[2:]-values[:-2])/(knots[2:]-knots[:-2]), 0.][1:]
da2 = a2*beta/r
vp = (2*a2/r-da2-grav*mj*float(p['planet_mass_mj'])/r**2
      +float(p['tidal_coefficient_s2'])*r)/(v-a2/v)
qadv = -1.5*rho*v*da2
qexp = -rho*a2*v*(2/r+vp/v)
legacyadv = -1.5*rho*v*np.gradient(a2,r)
legacyexp = a2*v*np.gradient(rho,r)
result=dict(profile_sha256=sha256(source.read_bytes()).hexdigest(),
    scope='Frozen prescribed-temperature five-cell root. ODE diagnostic, not a new solved atmosphere or a sonic-point implementation.',
    mach=v/np.sqrt(a2), sound_squared_log_radius_gradient=beta,
    legacy_advection=legacyadv,legacy_expansion=legacyexp,
    ode_consistent_advection=qadv,ode_consistent_expansion=qexp,
    expansion_legacy_over_ode=legacyexp/qexp,
    physical_units='Energy terms erg cm^-3 s^-1, radius cm, velocity cm s^-1')
for key,value in result.items():
    if isinstance(value,np.ndarray):result[key]=value.tolist()
Path(__file__).with_name('diagnosis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
