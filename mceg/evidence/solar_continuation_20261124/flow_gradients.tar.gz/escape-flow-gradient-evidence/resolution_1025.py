"""Wind-energy derivative resolution at a fixed five-cell physical profile."""
from pathlib import Path
import json,time
import jax
import jax.numpy as jnp
import numpy as np
from escape.atmosphere_wind import wind_from_profiles,thermal_flow_terms
jax.config.update('jax_enable_x64',True)
p=np.load('/tmp/escape-five-cell-root-evidence/profile.npz');start=time.time();rows=json.loads(Path(__file__).with_name('resolution.json').read_text())
for ngrid in (1025,):
    w,info=wind_from_profiles(p['wind_knot_radius_cm'],p['wind_knot_temperature_k'],p['wind_knot_mean_molecular_weight'],float(p['mass_loss_g_s']),float(p['planet_mass_mj']),base_radius_cm=float(p['base_radius_cm']),outer_radius_cm=float(p['outer_radius_cm']),tidal_coefficient_s2=float(p['tidal_coefficient_s2']),ngrid=ngrid,return_info=True)
    terms=thermal_flow_terms(p['wind_knot_radius_cm'],w.density_g_cm3,p['wind_knot_temperature_k'],p['wind_knot_mean_molecular_weight'],w.velocity_kms*1e5,log_velocity_gradient_cm1=info['log_velocity_gradient_cm1'],sound_squared_gradient_cm_s2=info['sound_squared_gradient_cm_s2'])
    row=dict(ngrid=ngrid,wind_converged=bool(info['converged']),wind_valid=bool(info['valid']),wind_residual=float(info['residual_norm']),advection=np.asarray(terms.advection)[1:].tolist(),expansion=np.asarray(terms.expansion)[1:].tolist(),velocity_kms=np.asarray(w.velocity_kms)[1:].tolist(),elapsed_s=time.time()-start)
    rows.append(row);Path(__file__).with_name('resolution_1025.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
for row in rows:
    for name in ['advection','expansion','velocity_kms']:
        a,b=np.asarray(row[name]),np.asarray(rows[-1][name]);nonzero=abs(b)>np.max(abs(b))*1e-12
        row[name+'_maximum_relative_to_1025']=float(np.max(abs((a[nonzero]-b[nonzero])/b[nonzero])))
Path(__file__).with_name('resolution_1025.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2),flush=True)
