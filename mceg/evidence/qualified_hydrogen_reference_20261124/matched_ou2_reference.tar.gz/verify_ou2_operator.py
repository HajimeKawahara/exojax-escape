"""Independent E2 and finite-difference checks of the external comparison path."""
from pathlib import Path
from hashlib import sha256
import json
import numpy as np
from scipy.special import expn
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as jnp
from escape.hydrogen_escape_probability import HydrogenEscapeProbabilityModel
from escape.hydrogen_nlte import _bound_ratios
from ou2_model import OU2Comparison
r=Path(__file__).parent;state=np.load(r/'ou2_reference_grid_strict/solution.npz');m=HydrogenEscapeProbabilityModel(state['edges_cm'],nmax=15,line_optical_depth_scale=2.,shell_collision_model='anderson_lebedev',line_overlap_model='coincident');model=OU2Comparison(m);T=jnp.full(m.cells,8000.);incident=m.boundary_blackbody(10000.,.025)
@jax.jit
def residual(x):
 ratio=x.reshape(m.cells,18);f=jax.nn.softmax(jnp.column_stack((ratio,jnp.zeros(m.cells))),axis=1);b=1e12*f[:,:-1];e=1e12*f[:,-1];rates,_=model.rates(T,b,e,e,incident);return (ratio-jnp.log(jax.vmap(_bound_ratios)(e,rates))).ravel()
x=jnp.asarray(state['state'].ravel());direction=jnp.asarray(np.random.default_rng(721).normal(size=x.size));direction=direction/jnp.max(abs(direction));F=np.asarray(residual(x));jvp=np.asarray(jax.jit(lambda z,v:jax.jvp(residual,(z,),(v,))[1])(x,direction));differences={}
for epsilon in [1e-4,1e-5,1e-6]:
 fd=np.asarray((residual(x+epsilon*direction)-residual(x-epsilon*direction))/(2*epsilon));differences[str(epsilon)]=float(np.linalg.norm(fd-jvp)/np.linalg.norm(jvp))
tau=np.geomspace(1e-10,100.,400);nodes,weights=np.polynomial.legendre.leggauss(64);quad=np.exp(-tau[:,None]/((nodes+1)/2))@(weights/2);e2_error=float(np.max(abs(quad/expn(2,tau)-1)))
assert abs(F).max()<1e-9
assert max(differences.values())<1e-4
assert e2_error<6e-5
report={'scope':'External OU2 residual at the converged127cell state. This checks AD of this explicitly discretized comparison model, not an implicit solar/NUTS gradient or exact E2 derivative at tau=0. The thermal-ledger extension leaves the saved strict root satisfied.','root_residual_max':float(abs(F).max()),'JVP_relative_L2_error_vs_central_FD':differences,'E2_64point_max_relative_error_vs_scipy':e2_error,'criteria':{'root':1e-9,'JVP':1e-4,'E2_function_value':6e-5},'source_sha256':{p.name:sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),r/'ou2_model.py']}}
(r/'ou2_verification.json').write_text(json.dumps(report,indent=2)+'\n');print(report,flush=True)
