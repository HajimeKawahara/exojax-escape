"""External pure-H OU2 comparison operator; native defaults are unchanged.

This finite-atom diagnostic uses native atomic coefficients and line escape.
It replaces continuum recycling and the nonlocal pumping field together. It
is not a solar atmosphere or an assertion of exact C23 mesh/cache parity.
"""
from __future__ import annotations
import jax
import jax.numpy as jnp
import numpy as np
from escape.hydrogen_atom import atom_cross_sections
from escape.hydrogen_escape_probability import _column_above
from escape.hydrogen_rates import PLANCK_CGS,LIGHT_SPEED_CGS
from escape.radiation import _cell_weights

class OU2Comparison:
    def __init__(self, model, *, exact_source=False, escape_order=64):
        self.model=model
        self.exact_source=bool(exact_source)
        atom=model.atom
        n=np.asarray(atom.principal_n)
        edge=np.asarray(atom.ionization_energy_erg)/PLANCK_CGS
        self.edge_frequency=jnp.asarray([edge[n==q].max()*(1+1e-12) for q in n])
        self.edge_sigma=atom_cross_sections(atom,self.edge_frequency)
        self.eligible=jnp.asarray(n[:,None]>n[None,:])
        x,w=np.polynomial.legendre.leggauss(escape_order)
        self.mu=jnp.asarray((x+1)/2);self.weight=jnp.asarray(w/2)

    def rates(self, temperature, bound, proton, electron, incident):
        m=self.model;atom=m.atom;nu=m.grid.frequency_hz
        old=m.population_state(temperature,bound,proton,electron,incident)
        chi,eta,inverse=m._continuum(temperature,bound,proton,electron,nu,m._sigma)
        edge_chi,_,edge_inverse=m._continuum(temperature,bound,proton,electron,self.edge_frequency,self.edge_sigma)
        edge_tau=_column_above(edge_chi*m.widths_cm[:,None])
        Pc=jnp.sum(jnp.exp(-edge_tau[...,None]/self.mu)*self.weight,axis=-1)
        ix=jnp.arange(len(atom.principal_n))
        level_opacity=jnp.diag(self.edge_sigma)[None,:]*(bound-(electron*proton)[:,None]*edge_inverse[:,ix,ix])
        other=jnp.maximum(1-level_opacity/jnp.where(edge_chi>0,edge_chi,1),0)
        beta=jnp.minimum(1.,Pc+(1-Pc)*other)
        alpha=jnp.einsum('lf,clf->cl',m._photo_kernel,inverse)
        pref=2*PLANCK_CGS/LIGHT_SPEED_CGS**2*nu**3
        rr=(electron*proton)[:,None,None]*inverse*m._sigma[None,:,:]*pref[None,None,:]
        # Subtract unweighted RR from the existing continuum to retain FF.
        escaped_eta=eta-rr.sum(axis=1)+(rr*Pc[:,:,None]).sum(axis=1)
        exp_face=jnp.exp(-_column_above(chi*m.widths_cm[:,None]))
        two=old['two_photon_emission']
        escaped_eta+=two*exp_face
        depth=old['transport_extinction_cm1']*m.widths_cm[:,None]
        def step(incoming,values):
            tau,source=values
            emitted=source*(_cell_weights(tau)[0] if self.exact_source else jnp.exp(-tau))
            return incoming*jnp.exp(-tau)+emitted,incoming
        outward=jax.lax.scan(step,jnp.zeros_like(nu),(depth,.5*escaped_eta*m.widths_cm[:,None]),reverse=True)[1]
        previous_chi=jnp.concatenate([chi[1:],chi[-1:]],axis=0)
        predictor=1.35*previous_chi*m.widths_cm[:,None]
        tmn=jnp.where(predictor<1e-4,1.,jnp.where(predictor<5,_cell_weights(predictor)[0],1/jnp.maximum(predictor,1e-300)))
        direct=incident*jnp.exp(-_column_above(depth))*tmn
        nonlocal_field=direct+outward
        local_two=two*(1-exp_face)/jnp.where(chi>0,chi,1)
        occupation=(nonlocal_field+local_two)/pref
        flux=(electron*proton)[:,None]*alpha*(1-Pc)/jnp.where(edge_chi>0,edge_chi,1)
        cross=self.edge_sigma*self.eligible
        photo=occupation@m._photo_kernel.T+old['photoionization_ots_s']+flux@cross.T
        induced=jnp.einsum('cf,lf,clf->cl',occupation,m._photo_kernel,inverse)
        induced+=old['recombination_ots_cm3_s']+jnp.einsum('cf,lf,clf->cl',flux,cross,edge_inverse)
        recombination=alpha*beta+induced
        # Escape/destruction at fixed populations do not depend on the incident
        # pump. Replace both stimulated directions; destruction photons stay.
        new_mean=jax.vmap(lambda row:jnp.interp(atom.line_frequency_hz,nu,row))(nonlocal_field)
        pump=old['line_operators'].pump_up_s*new_mean/jnp.where(old['line_pump_mean_intensity']>0,old['line_pump_mean_intensity'],1)
        old_pump=old['line_operators'].pump_up_s
        delta=pump-old_pump
        u,l=atom.line_upper,atom.line_lower;g=atom.statistical_weights
        radiative=old['rates'].radiative_bound_bound_s.at[:,l,u].add(delta)
        radiative=radiative.at[:,u,l].add(delta*g[l]/g[u])
        rates=old['rates']._replace(radiative_bound_bound_s=radiative,photoionization_s=photo,radiative_recombination_cm3_s=recombination)
        return rates,dict(Pc=Pc,beta=beta,alpha_thin=alpha,nonlocal_intensity=nonlocal_field,photoionization=photo,direct_intensity=direct,outward_intensity=outward)
