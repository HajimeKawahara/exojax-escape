"""Retain raw relevant readouts verbatim, omitting repetitive intermediate logs."""
from pathlib import Path
from hashlib import sha256
import gzip,json,shutil,tarfile
source=Path('/tmp/escape-ou2-matched-root-evidence');out=Path('/tmp/escape-ou2-matched-root-thin');out.mkdir(exist_ok=False)
for p in source.rglob('*'):
 if p.is_file() and p.name not in ['SHA256SUMS.json','origin_manifest.json'] and p.name!='model.out.gz':
  q=out/p.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
receipts={}
for p in source.rglob('model.out.gz'):
 lines=gzip.open(p,'rt').readlines();ep={};cont={};mat={};heat={};block=None;kind=None
 for line in lines:
  fields=line.split()
  if not fields:continue
  tag=fields[0]
  if tag=='EPSTATE':ep[int(fields[2])]=line
  elif tag=='CONTSTATE':cont[int(fields[2]),int(fields[3])]=line
  elif tag in ['MCEG_BEGIN','HHEAT_BEGIN']:block=[line];kind=tag;zone=int(fields[2])
  elif block is not None:
   block.append(line)
   if tag==('MCEG_END' if kind=='MCEG_BEGIN' else 'HHEAT_END'):
    (mat if kind=='MCEG_BEGIN' else heat)[zone]=block;block=None
 selected=lines[:120]+[x for x in lines[120:-80] if 'PROBLEM' in x]+[ep[k] for k in sorted(ep)]+[cont[k] for k in sorted(cont)]
 for blocks in [mat,heat]:
  for zone in sorted(blocks):selected+=blocks[zone]
 selected+=lines[-80:]
 q=out/p.parent.relative_to(source)/'model.selected_readouts.txt';q.write_text(''.join(selected))
 receipts[str(q.relative_to(out))]={'scope':'Verbatim selection, explicitly not the original full Cloudy output. First120/last80 lines, every PROBLEM, final EPSTATE/CONTSTATE and final complete MCEG/HHEAT blocks per selected zone.','full_uncompressed_sha256':sha256(''.join(lines).encode()).hexdigest(),'selected_sha256':sha256(q.read_bytes()).hexdigest(),'full_log_gzip_sha256':sha256(p.read_bytes()).hexdigest(),'full_log_retained_in_archive':'escape-ou2-matched-root-evidence.tar.gz'}
(out/'selected_readouts_provenance.json').write_text(json.dumps(receipts,indent=2)+'\n')
copy=out/'build_thin_followup.py';shutil.copyfile(__file__,copy)
readme=(out/'README.md').read_text();readme=readme.replace('plus all new control logs compressed','plus verbatim final readouts and each complete raw physical table from the new controls').replace('Unpack each model.out.gz only into a fresh replay copy if extraction is needed.','The model.selected_readouts.txt files are explicitly selected records, never relabeled full logs. The selection algorithm and full-log hashes are retained. Complete original logs remain in the separate full archive escape-ou2-matched-root-evidence.tar.gz (SHA256 09d96310b92444df31582b7bd2452bb0df97fb6e28b695a63d63c6183ca41917); repetitive intermediate readouts are omitted here.');(out/'README.md').write_text(readme)
files={str(p.relative_to(out)):sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*')) if p.is_file()};(out/'SHA256SUMS.json').write_text(json.dumps(files,indent=2)+'\n')
archive=out.with_suffix('.tar.gz')
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as z,tarfile.open(fileobj=z,mode='w') as tar:
 for p in sorted(out.rglob('*')):
  if p.is_file():
   info=tar.gettarinfo(str(p),str(p.relative_to(out)));info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';tar.addfile(info,p.open('rb'))
receipt={'path':str(archive),'sha256':sha256(archive.read_bytes()).hexdigest(),'size_bytes':archive.stat().st_size,'file_count':len(files)+1,'full_archive_sha256':'09d96310b92444df31582b7bd2452bb0df97fb6e28b695a63d63c6183ca41917'};out.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt)
