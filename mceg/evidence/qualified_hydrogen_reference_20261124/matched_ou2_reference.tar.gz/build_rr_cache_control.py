"""Isolate RR cooling's temperature-only early return, preserving its formula."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,difflib
r=Path(__file__).parent;s=Path('/tmp/cloudy-reference-run/c23.01/source');source=r/'iso_cool_heat_readout.cpp';original=source.read_text()
old='\tif( fp_equal( phycon.te, iso_ctrl.RRC_TeUsed[ipISO][nelem] ) && conv.nTotalIoniz )\n\t\treturn;'
assert original.count(old)==1
text=original.replace(old,'\t// Controlled numerical reference: recompute the existing beta-dependent\n\t// RR cooling expression even when temperature has not changed.')
target=r/'iso_cool_rr_cache_control.cpp';target.write_text(text)
(r/'iso_cool_rr_cache_control.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile=source.name,tofile=target.name)))
flags=json.loads((r/'matching_flags_provenance.json').read_text())['compiler_flags'];obj=r/'iso_cool_rr_cache_control.o';subprocess.run(flags+['-c',str(target),'-o',str(obj)],check=True)
binary=r/'cloudy_rr_cache_control.exe';command=['g++','-no-pie','-o',str(binary),str(s/'maincl.o'),str(r/'iso_original_flags.o'),str(r/'rt_original_flags.o'),str(obj),str(s/'libcloudy.a')];subprocess.run(command,check=True)
(r/'rr_cache_control_provenance.json').write_text(json.dumps({'scope':'Numerical cache refresh control: remove temperature-only early return from existing beta-dependent discrete RR cooling formula. No escape factor, cross section, cooling expression, or convergence criterion is altered. Not unmodified C23.','compiler_flags':flags,'link_command':command,'sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in [source,target,obj,binary]}},indent=2)+'\n')
base=r/'continuum_controls/ou2_heat_readout';dest=r/'continuum_controls/ou2_rr_cache_control';dest.mkdir(exist_ok=False);(dest/'model.in').write_bytes((base/'model.in').read_bytes());d=json.loads((base/'control.json').read_text());d.update(variant='RR_cooling_cache_refresh_control',executable=str(binary),executable_sha256=sha256(binary.read_bytes()).hexdigest());(dest/'control.json').write_text(json.dumps(d,indent=2)+'\n');print(dest)
