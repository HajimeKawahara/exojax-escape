"""Add a selected-zone H thermal ledger without changing physical expressions."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,difflib
r=Path(__file__).parent;s=Path('/tmp/cloudy-reference-run/c23.01/source');original=(s/'iso_cool.cpp').read_text()
marker='\n\treturn;\n}\n\nSTATIC double iso_rad_rec_cooling_approx'
assert original.count(marker)==1
readout='''
    // Diagnostic only: capture the already-computed kinetic ledger.
    if(ipISO==ipH_LIKE && nelem==ipHYDROGEN && iteration>=3 &&
       (nzone==1 || nzone==3 || nzone==64 || nzone==127)) {
        fprintf(ioQQQ,"HHEAT_BEGIN %ld %ld %.17e %.17e %.17e %.17e %.17e %.17e %.17e %.17e %.17e\\n",
            iteration,nzone,phycon.te,dense.eden,dense.xIonDense[0][1],
            CollisIonizatCoolingTotal,CollisIonizatHeatingTotal,sp->xLineTotCool,
            sp->RadRecCool,HeatExcited,sp->RecomInducCool_Rate);
        for(long n=0;n<sp->numLevels_local;++n)
            fprintf(ioQQQ,"HHEAT_LEVEL %ld %.17e %.17e %.17e %.17e %.17e %.17e\\n",
                n,sp->st[n].Pop(),sp->fb[n].PhotoHeat,sp->fb[n].RadRecCoolCoef,
                sp->fb[n].RecomInducCool_Coef,sp->fb[n].PopLTE,sp->fb[n].RadRecomb[ipRecNetEsc]);
        fprintf(ioQQQ,"HHEAT_END\\n");
    }
'''
text=original.replace(marker,'\n'+readout+marker);target=r/'iso_cool_heat_readout.cpp';target.write_text(text)
(r/'iso_cool_heat_readout.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='c23.01/source/iso_cool.cpp',tofile='iso_cool_heat_readout.cpp')))
flags=json.loads((r/'matching_flags_provenance.json').read_text())['compiler_flags'];obj=r/'iso_cool_heat_readout.o';subprocess.run(flags+['-c',str(target),'-o',str(obj)],check=True)
binary=r/'cloudy_heat_readout.exe';command=['g++','-no-pie','-o',str(binary),str(s/'maincl.o'),str(r/'iso_original_flags.o'),str(r/'rt_original_flags.o'),str(obj),str(s/'libcloudy.a')];subprocess.run(command,check=True)
(r/'heat_readout_provenance.json').write_text(json.dumps({'scope':'Original C23 expressions and line-cache policy, selected iso_cool return ledger only. Same compiler flags. Saved-output parity must be demonstrated before using this diagnostic.','compiler_flags':flags,'link_command':command,'sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in [s/'iso_cool.cpp',target,obj,binary]}},indent=2)+'\n')
base=r/'continuum_controls/ou2_matching_flags';dest=r/'continuum_controls/ou2_heat_readout';dest.mkdir(exist_ok=False);(dest/'model.in').write_bytes((base/'model.in').read_bytes());d=json.loads((base/'control.json').read_text());d.update(variant='readout_only_H_thermal_ledger',executable=str(binary),executable_sha256=sha256(binary.read_bytes()).hexdigest());(dest/'control.json').write_text(json.dumps(d,indent=2)+'\n');print(dest)
