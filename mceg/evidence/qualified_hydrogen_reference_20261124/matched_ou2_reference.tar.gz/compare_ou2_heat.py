"""Compare physical H kinetic powers after explicitly matching the OU2 closure."""
from pathlib import Path
from hashlib import sha256
import argparse,json,sys
import numpy as np
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as jnp
from escape.hydrogen_escape_probability import HydrogenEscapeProbabilityModel
from ou2_model import OU2Comparison
sys.path.insert(0,str(Path(__file__).parent/'tools'))
from cloudy_thermal_bookkeeping import hydrogen_heat_groups
p=argparse.ArgumentParser(description=__doc__);p.add_argument('case',type=Path);a=p.parse_args();r=a.case/'derived';profile=dict(np.load(r/'profile.npz'));width=np.load(r/'zone_geometry.npz')['width_cm'];ledger=json.loads((a.case/'thermal_ledger.json').read_text());C=len(width)
# Retain full-precision actual thermal-evaluation populations at selected zones.
for zone,values in ledger['zones'].items():
 k=int(zone)-1;header=values['header'];profile['bound_cm3'][k]=np.asarray(values['levels'])[:,1];profile['electron_cm3'][k]=header[3];profile['proton_cm3'][k]=header[4]
m=HydrogenEscapeProbabilityModel(np.r_[0.,np.cumsum(width[::-1])],nmax=15,line_optical_depth_scale=2.,shell_collision_model='anderson_lebedev',line_overlap_model='coincident');model=OU2Comparison(m)
T=jnp.asarray(profile['temperature_k'][::-1]);b=jnp.asarray(profile['bound_cm3'][::-1]);e=jnp.asarray(profile['electron_cm3'][::-1]);proton=jnp.asarray(profile['proton_cm3'][::-1]);rates,info=jax.jit(model.rates)(T,b,proton,e,m.boundary_blackbody(10000.,.025));powers={k:np.asarray(v) for k,v in info['kinetic_powers'].items()}
report={'scope':'Same prescribed standard-C23 state and actual thermal-evaluation populations at selected zones; external native OU2 operator and common H kinetic grouping. Excludes H free-free, other species, total atmosphere and wind. Corrected-cache control remains separate from unmodified C23.','source_sha256':{p.name:sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),Path(__file__).with_name('ou2_model.py')]},'zones':{}}
for zone,values in ledger['zones'].items():
 h=values['header'];levels=np.asarray(values['levels']);k=C-int(zone);native={name:float(v[k]) for name,v in powers.items()};reference=dict(ground_photo=float(levels[0,1]*levels[0,2]),excited_photo=h[9],spontaneous_recombination=h[8],induced_recombination=h[10],collisional_ionization=h[5],three_body_recombination=h[6],line_net=-h[7]);ng=hydrogen_heat_groups(**native);cg=hydrogen_heat_groups(**reference)
 scale=max(float(cg['heating']),float(cg['cooling']));report['zones'][zone]={'C23':reference,'native':native,'native_minus_C23_over_C23_heat_scale':{key:(native[key]-reference[key])/scale for key in native},'grouped_C23':{key:float(cg[key]) for key in ['heating','cooling','net']},'grouped_native':{key:float(ng[key]) for key in ['heating','cooling','net']},'native_net_minus_C23_over_heat_scale':float((ng['net']-cg['net'])/scale)}
(a.case/'native_ou2_heat_comparison.json').write_text(json.dumps(report,indent=2)+'\n');np.savez_compressed(a.case/'native_ou2_powers.npz',**powers)
print({z:{'C23':v['grouped_C23'],'native':v['grouped_native'],'deltaQ_scale':v['native_net_minus_C23_over_heat_scale']} for z,v in report['zones'].items()},flush=True)
