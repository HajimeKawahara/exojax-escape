"""Extract final finite-atom operators and geometry from one readout-only slab."""
from pathlib import Path
from hashlib import sha256
import argparse,json
import numpy as np

p=argparse.ArgumentParser(description=__doc__);p.add_argument('case',type=Path);a=p.parse_args();case=a.case
out=case/'derived'
if out.exists():raise FileExistsError(out)
profile={};tables={name:np.loadtxt(case/('model.'+name),ndmin=2) for name in ['levels','conditions','electrons','protons']}
levels=tables['levels'];depth=levels[:,0];bound=levels[:,1:19]
assert bound.shape[1]==18 and np.all(levels[:,19:]==0) and np.all(np.diff(depth)>0)
assert all(np.array_equal(v[:,0],depth) for v in tables.values())
profile=dict(depth_cm=depth,bound_cm3=bound,temperature_k=tables['conditions'][:,1],n_h_cm3=tables['conditions'][:,2],electron_cm3=tables['electrons'][:,1],proton_cm3=tables['protons'][:,1],n2_cm3=bound[:,1:3].sum(1),n3_cm3=bound[:,3:6].sum(1))
rows={};blocks={};parts={};block=None;finished=False;echo=False
required=json.loads((case/'control.json').read_text())['required_output_echo'];digest=sha256()
with (case/'model.out').open('rb') as stream:
 for raw in stream:
  digest.update(raw);line=raw.decode(errors='replace').strip();bits=line.split()
  if 'Cloudy exited OK' in line:finished=True
  if required in line:echo=True
  if line.startswith('EPSTATE '):
   v=np.array(list(map(float,bits[1:])));rows[int(v[1])]=v
  elif line.startswith('CONTSTATE '):
   v=np.array(list(map(float,bits[1:])));parts[int(v[1]),int(v[2])]=v
  elif line.startswith('MCEG_BEGIN '):
   block=dict(header=list(map(float,bits[1:])),fb=[],bb=[],matrix=[],two_photon=[])
  elif block is not None:
   tag=bits[0] if bits else ''
   if tag in ['MCEG_FB','MCEG_BB','MCEG_2PH']:
    block[{'MCEG_FB':'fb','MCEG_BB':'bb','MCEG_2PH':'two_photon'}[tag]].append(list(map(float,bits[1:])))
   elif tag=='MCEG_MATRIX':block['matrix'].append(list(map(float,bits[2:])))
   elif tag=='MCEG_SOLUTION':block['solution']=list(map(float,bits[1:]))
   elif tag=='MCEG_END':blocks[int(block['header'][1])]=block;block=None
if not finished or not echo:raise ValueError('Missing successful completion or required input echo.')
width=np.array([rows[i+1][20] for i in range(len(depth))]);assert np.all(width>0)
out.mkdir();np.savez_compressed(out/'profile.npz',**profile);np.savez_compressed(out/'zone_geometry.npz',width_cm=width)
for zone,block in blocks.items():np.savez_compressed(out/f'zone{zone:03d}_operators.npz',**{k:np.asarray(v) for k,v in block.items()})
np.savez_compressed(out/'continuum_parts.npz',rows=np.array([parts[k] for k in sorted(parts)]))
receipt={'scope':'Final selected operator rows and zone geometry; no assumption of atmospheric convergence. All retained zones belong to their own adaptive run.','control':json.loads((case/'control.json').read_text()),'model_out_sha256':digest.hexdigest(),'extractor_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'zones':len(depth),'n2_column_cm2':float(width@profile['n2_cm3']),'n3_column_cm2':float(width@profile['n3_cm3']),'artifact_sha256':{q.name:sha256(q.read_bytes()).hexdigest() for q in out.iterdir()}}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(out)
