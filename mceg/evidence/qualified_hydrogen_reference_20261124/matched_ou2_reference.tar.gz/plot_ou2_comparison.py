"""Plot the scoped pure-H operator comparison and the independent cache control."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
r=Path(__file__).parent;out=r/'figures';out.mkdir(exist_ok=True)
p=np.load(r/'ou2_reference267_strict/solution.npz');c=np.load(r/'continuum_controls/ou2_standard_maxdr5e6/derived/profile.npz');depth=c['depth_cm'];b=p['bound_cm3'][::-1]
fig,axs=plt.subplots(2,2,figsize=(9,6),sharex=True,gridspec_kw={'height_ratios':[2,1]},constrained_layout=True)
for col,(name,values) in enumerate([('n2',b[:,1:3].sum(1)),('n3',b[:,3:6].sum(1))]):
 target=c[name+'_cm3'];axs[0,col].loglog(depth,target,color='black',label='Standard C23 OU2');axs[0,col].loglog(depth,values,'--',color='#0072B2',label='Native coefficients, matched OU2');axs[0,col].set_ylabel(name+' [cm$^{-3}$]');axs[0,col].legend(fontsize=8)
 axs[1,col].semilogx(depth,100*(values/target-1),color='#0072B2');axs[1,col].axhline(0,color='gray',lw=.7);axs[1,col].set_ylabel('Difference [%]');axs[1,col].set_xlabel('Depth from illuminated face [cm]');axs[1,col].set_ylim(-1.2,1.2)
 for ax in axs[:,col]:ax.grid(alpha=.2)
fig.suptitle('Pure-H fixed-temperature closure test — not a planetary fit\n267 common cells; complete population/continuum root residual = 2.5×10$^{-12}$',fontsize=11)
fig.savefig(out/'ou2_matched_profiles.png',dpi=170);plt.close(fig)
legacy=json.loads((r/'continuum_controls/ou2_heat_readout/thermal_ledger.json').read_text());fresh=json.loads((r/'continuum_controls/ou2_rr_cache_control/native_ou2_heat_comparison.json').read_text());zones=['1','3','64','127'];x=np.arange(4);fig,axs=plt.subplots(1,2,figsize=(10,4),constrained_layout=True)
for name,offset,color in [('Unmodified C23',-.25,'#999999'),('C23 cache refreshed',0,'#D55E00'),('Matched native OU2',.25,'#0072B2')]:
 if name=='Unmodified C23':values=[legacy['zones'][z]['header'][8] for z in zones]
 else:values=[fresh['zones'][z]['C23' if name=='C23 cache refreshed' else 'native']['spontaneous_recombination'] for z in zones]
 axs[0].bar(x+offset,values,.24,label=name,color=color)
axs[0].set_ylabel('Spontaneous RR cooling [erg cm$^{-3}$ s$^{-1}$]');axs[0].set_xticks(x,zones);axs[0].set_xlabel('Selected zone (surface → depth)');axs[0].legend(fontsize=8)
for quantity,marker in [('heating','o'),('cooling','s')]:
 delta=[100*(fresh['zones'][z]['grouped_native'][quantity]/fresh['zones'][z]['grouped_C23'][quantity]-1) for z in zones];axs[1].plot(x,delta,marker+'-',label=quantity.capitalize())
axs[1].axhline(0,color='gray',lw=.7);axs[1].set_xticks(x,zones);axs[1].set_xlabel('Selected zone');axs[1].set_ylabel('Native − refreshed C23 [%]');axs[1].legend();axs[1].grid(alpha=.2)
fig.suptitle('Separate thermal-ledger control: fixed 8000 K, six full columns\nRefreshing the existing RR formula changes cooling while all five population tables stay byte-identical',fontsize=10)
fig.savefig(out/'rr_cache_and_matched_heat.png',dpi=170);plt.close(fig)
print(out)
