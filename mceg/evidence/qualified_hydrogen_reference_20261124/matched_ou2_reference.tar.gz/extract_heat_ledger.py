"""Extract final selected iso_cool ledgers without assigning convergence status."""
from pathlib import Path
from hashlib import sha256
import argparse,json
p=argparse.ArgumentParser(description=__doc__);p.add_argument('case',type=Path);a=p.parse_args();blocks={};block=None
for line in (a.case/'model.out').read_text().splitlines():
 f=line.split()
 if f and f[0]=='HHEAT_BEGIN':block={'header':list(map(float,f[1:])),'levels':[]}
 elif f and f[0]=='HHEAT_LEVEL':block['levels'].append(list(map(float,f[1:])))
 elif f and f[0]=='HHEAT_END':blocks[int(block['header'][1])]=block;block=None
report={'scope':'Actual iso_cool return values. A paired output/source check is required before interpreting a readout or numerical-control variant. Not asserted equivalent to an earlier SE timestamp.','source_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'model_output_sha256':sha256((a.case/'model.out').read_bytes()).hexdigest(),'columns':['level','population_cm3','photo_heat_per_atom_erg_s','effective_RR_cool_cm3_erg_s','induced_cool_coefficient','PopLTE_cm3','beta'],'header':['iteration','zone','T','ne','np','CI_cool','three_body_heat','line_net_cool','RR_cool','excited_PI_heat','induced_RR_cool'],'zones':blocks}
(a.case/'thermal_ledger.json').write_text(json.dumps(report,indent=2)+'\n');print(a.case/'thermal_ledger.json')
