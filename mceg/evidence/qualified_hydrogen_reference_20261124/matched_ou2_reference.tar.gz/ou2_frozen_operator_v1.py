"""Resolve the OU2 continuum operator at frozen, standard-C23 slab populations.

External diagnostic only. It never changes the native scientific model. The
continuous-frequency counterpart uses native kernels; exact C23 threshold-cell
rounding and its stored opacity predictor remain separate comparison errors.
"""
from pathlib import Path
from hashlib import sha256
import argparse,json,time
import numpy as np
from scipy.special import expn
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as jnp
from escape.hydrogen_escape_probability import HydrogenEscapeProbabilityModel
from escape.hydrogen_atom import atom_cross_sections,atom_milne_population
from escape.hydrogen_continuum import hydrogen_free_free_coefficients
from escape.hydrogen_rates import PLANCK_CGS,LIGHT_SPEED_CGS
from escape.hydrogen_two_photon import two_photon_emissivity

p=argparse.ArgumentParser(description=__doc__);p.add_argument('case',type=Path);p.add_argument('--order',type=int,default=4);p.add_argument('--output',type=Path);a=p.parse_args();start=time.monotonic()
r=a.case/'derived';data=dict(np.load(r/'profile.npz'));width=np.load(r/'zone_geometry.npz')['width_cm'];nzone=len(width)
m=HydrogenEscapeProbabilityModel(np.r_[0.,np.cumsum(width[::-1])],nmax=15,quadrature_order=a.order,line_optical_depth_scale=2.,shell_collision_model='anderson_lebedev')
# Diagnostic arrays run from the illuminated surface into the slab.
T=jnp.asarray(data['temperature_k']);bound=jnp.asarray(data['bound_cm3']);ne=jnp.asarray(data['electron_cm3']);np_=jnp.asarray(data['proton_cm3']);nu=np.asarray(m.grid.frequency_hz);weights=np.asarray(m.grid.weight_hz);sigma=np.asarray(m._sigma);pref=2*PLANCK_CGS/LIGHT_SPEED_CGS**2*nu**3
threshold=np.asarray(m.atom.ionization_energy_erg)/PLANCK_CGS
edge_frequency=jnp.asarray(np.nextafter(threshold,np.inf));edge_sigma=atom_cross_sections(m.atom,edge_frequency)
@jax.jit
def coefficients():
 chi,eta,inverse=m._continuum(T,bound,np_,ne,jnp.asarray(nu),m._sigma)
 scatter=m.scattering_coefficients_at(bound,ne,jnp.asarray(nu))
 edge_chi,_,edge_inverse=m._continuum(T,bound,np_,ne,edge_frequency,edge_sigma)
 rr=(ne*np_)[:,None,None]*inverse*m._sigma[None,:,:]*jnp.asarray(pref)[None,None,:]
 ff=jax.vmap(lambda t,e,p:hydrogen_free_free_coefficients(t,e,p,jnp.asarray(nu))[1])(T,ne,np_)
 two=two_photon_emissivity(jnp.asarray(nu),m.grid.weight_hz,m.atom.excitation_energy_erg[1]/PLANCK_CGS,bound[:,1])
 return chi,scatter,inverse,edge_chi,edge_inverse,rr,ff,two
chi,scatter,inverse,edge_chi,edge_inverse,rr,ff,two=[np.asarray(v) for v in coefficients()]
def above(dt):return np.concatenate([np.zeros_like(dt[:1]),np.cumsum(dt,axis=0)[:-1]],axis=0)
def phi(t):return np.divide(-np.expm1(-t),t,out=np.ones_like(t),where=t!=0)
edge_depth=above(edge_chi*width[:,None]);Pc=expn(2,edge_depth)
level_opacity=np.asarray(edge_sigma).diagonal()[None,:]*(np.asarray(bound)-(np.asarray(ne*np_)[:,None]*edge_inverse[:,np.arange(18),np.arange(18)]))
fother=np.maximum(1-np.divide(level_opacity,edge_chi,out=np.zeros_like(level_opacity),where=edge_chi>0),0.)
beta=np.minimum(1.,Pc+(1-Pc)*fother)
alpha=np.einsum('lf,clf->cl',np.asarray(m._photo_kernel),inverse)
# All same-n thresholds share a cell in the C23 control. Exclude all such
# local RR photons from that threshold cell, as GammaBn does, not just self.
ots_photons=np.asarray(ne*np_)[:,None]*alpha*(1-Pc)
edge_flux=np.divide(ots_photons,edge_chi,out=np.zeros_like(ots_photons),where=edge_chi>0)
cross=np.asarray(edge_sigma).copy();principal=np.asarray(m.atom.principal_n)
cross*=principal[:,None]>principal[None,:]
rr_ots=edge_flux@cross.T
rr_escape=(rr*Pc[:,:,None]).sum(axis=1)
tau_abs=chi*width[:,None];tau= tau_abs+np.log1p(scatter*width[:,None]);face_tau=above(tau)
exp_face=np.exp(-above(tau_abs))
two_escape=two*exp_face
source=rr_escape+ff+two_escape
# Source-then-attenuation versus exact uniform-cell source, both at cell entry.
def outward(exact):
 field=np.zeros_like(source);current=np.zeros_like(nu)
 for k in range(nzone):
  field[k]=current
  emitted=.5*source[k]*width[k]
  current=current*np.exp(-tau[k])+emitted*(phi(tau[k]) if exact else np.exp(-tau[k]))
 return field
previous_chi=np.vstack([chi[0],chi[:-1]])
raw=1.35*previous_chi*width[:,None]
tmn=np.where(raw<1e-4,1.,np.where(raw<5.,phi(raw),1/np.maximum(raw,1e-300)))
beam=np.asarray(m.boundary_blackbody(10000.,.025))[None,:]*np.exp(-face_tau)
photo_kernel=np.asarray(m._photo_kernel)/pref
pi_direct=(beam*tmn)@photo_kernel.T
pi_direct_entry=beam@photo_kernel.T
pi_direct_average=(beam*phi(tau))@photo_kernel.T
pi_outward=outward(False)@photo_kernel.T
pi_outward_exact=outward(True)@photo_kernel.T
# GammaBn excludes the first threshold frequency bin also for 2-photon OTS;
# continuous native quadrature is the explicitly different zero-bin-width limit.
local_two=np.divide(two*(1-exp_face),chi,out=np.zeros_like(two),where=chi>0)
pi_two=local_two@photo_kernel.T
parts=np.load(r/'continuum_parts.npz')['rows'];report={'scope':'Same frozen standard-C23 populations and geometry, native frequency kernels, OU2 continuum closure only. No SE/thermal/wind solve. Native default is unchanged. Incident tmn uses the previous final-zone opacity as a declared predictor approximation; exact C23 cached entry opacity and threshold-adjacent grid are not supplied. Line OTS and outward line flux remain the saved C23 operator in conditional swaps.','source_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'source_snapshot':json.loads((Path(__file__).parent/'source_snapshot.json').read_text()),'profile_sha256':sha256((r/'profile.npz').read_bytes()).hexdigest(),'quadrature_order':a.order,'zones':{}}
for zone in [1,3,64,127]:
 k=zone-1;op=dict(np.load(r/f'zone{zone:03d}_operators.npz'));c=parts[parts[:,1]==zone];fb=op['fb'];pred_beta=np.minimum(1,c[:,9]+(1-c[:,9])*c[:,10]);np.testing.assert_allclose(pred_beta,fb[:6,9],rtol=2e-13,atol=1e-20)
 observed=c[:,3:9]
 native=np.column_stack([pi_direct[k,:6],observed[:,1],pi_outward[k,:6],rr_ots[k,:6],observed[:,4],pi_two[k,:6]])
 exact=native.copy();exact[:,2]=pi_outward_exact[k,:6]
 def solve_swap(photo,rr_factor):
  A=op['matrix'].copy();b=fb[:,-1].copy();A[np.arange(6),np.arange(6)]+=photo-fb[:6,5]
  b[:6]+=op['header'][4]*op['header'][7]*fb[:6,8]*(rr_factor-fb[:6,9])
  pop=np.linalg.solve(A,b)
  return {'n2_cm3':float(pop[1:3].sum()),'n3_cm3':float(pop[3:6].sum()),'n2_over_saved':float(pop[1:3].sum()/op['solution'][1:3].sum()),'n3_over_saved':float(pop[3:6].sum()/op['solution'][3:6].sum()),'minimum_population':float(pop.min()),'normalized_linear_residual':float(np.max(abs(A@pop-b)/(abs(A)@abs(pop)+abs(b))))}
 report['zones'][str(zone)]={'depth_cm':float(data['depth_cm'][k]),'C23_Pc':c[:,9].tolist(),'native_Pc':Pc[k,:6].tolist(),'C23_fother':c[:,10].tolist(),'native_fother':fother[k,:6].tolist(),'C23_beta':fb[:6,9].tolist(),'native_beta':beta[k,:6].tolist(),'native_thin_alpha_over_C23':(alpha[k,:6]/fb[:6,8]).tolist(),'C23_PI_parts':observed.tolist(),'native_PI_parts':native.tolist(),'part_names':['direct','line_OTS_retained_C23','outward_continuum','RR_OTS','outward_line_retained_C23','two_photon_OTS'],'native_direct_entry':pi_direct_entry[k,:6].tolist(),'native_direct_exact_cell_average':pi_direct_average[k,:6].tolist(),'native_outward_exact':pi_outward_exact[k,:6].tolist(),'relative_total_PI_native_minus_C23':(native.sum(1)/fb[:6,5]-1).tolist(),'conditional_linear_solves':{'unchanged_saved_operator':solve_swap(fb[:6,5],fb[:6,9]),'OU2_native_continuum_PI_only':solve_swap(native.sum(1),fb[:6,9]),'OU2_native_PI_and_beta':solve_swap(native.sum(1),beta[k,:6]),'OU2_native_exact_outward_and_beta':solve_swap(exact.sum(1),beta[k,:6]),'full_RR_with_original_PI_inconsistent_control':solve_swap(fb[:6,5],np.ones(6))}}
report['seconds']=time.monotonic()-start;out=a.output or (r/f'ou2_frozen_operator_order{a.order}.json');out.write_text(json.dumps(report,indent=2)+'\n');print({z:{'total_PI_relative':v['relative_total_PI_native_minus_C23'],'n3_swaps':{k:w['n3_over_saved'] for k,w in v['conditional_linear_solves'].items()}} for z,v in report['zones'].items()},flush=True)
