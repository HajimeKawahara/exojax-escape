"""Checkpoint a small coupled OU2 H slab; external diagnostic, not core default."""
from pathlib import Path
from hashlib import sha256
import argparse,json,time
import numpy as np
from scipy.optimize import root
from scipy.sparse.linalg import LinearOperator,gmres
from types import SimpleNamespace
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as jnp
from escape.hydrogen_escape_probability import HydrogenEscapeProbabilityModel
from escape.hydrogen_nlte import _bound_ratios
from ou2_model import OU2Comparison
p=argparse.ArgumentParser(description=__doc__);p.add_argument('reference',type=Path);p.add_argument('output',type=Path);p.add_argument('--cells',type=int,default=12);p.add_argument('--exact-source',action='store_true');p.add_argument('--reference-grid',action='store_true');p.add_argument('--solver',choices=['dense','krylov'],default='dense');p.add_argument('--max-evaluations',type=int,default=100);a=p.parse_args();a.output.mkdir(exist_ok=False)
r=a.reference/'derived';ref=dict(np.load(r/'profile.npz'));width=np.load(r/'zone_geometry.npz')['width_cm'];total=width.sum()
# Resolve the strongly varying illuminated face with the reference's depth
# distribution, resampled uniformly in log depth; no state clipping.
front_edges=np.r_[0.,np.cumsum(width)] if a.reference_grid else np.r_[0.,np.geomspace(width[0],total,a.cells)]
a.cells=len(front_edges)-1
centers=(front_edges[1:]+front_edges[:-1])/2
bound=np.column_stack([np.interp(centers,ref['depth_cm'],v) for v in ref['bound_cm3'].T])[::-1];electron=np.interp(centers,ref['depth_cm'],ref['electron_cm3'])[::-1]
edges=np.r_[0.,np.cumsum(np.diff(front_edges)[::-1])];m=HydrogenEscapeProbabilityModel(edges,nmax=15,line_optical_depth_scale=2.,shell_collision_model='anderson_lebedev',line_overlap_model='coincident')
model=OU2Comparison(m,exact_source=a.exact_source);T=jnp.full(a.cells,8000.);incident=m.boundary_blackbody(10000.,.025);initial=np.log(bound/electron[:,None]).ravel();shape=(a.cells,18)
@jax.jit
def residual(x):
 logratio=x.reshape(shape);f=jax.nn.softmax(jnp.column_stack((logratio,jnp.zeros(a.cells))),axis=1);b=1e12*f[:,:-1];e=1e12*f[:,-1];rates,_=model.rates(T,b,e,e,incident)
 return (logratio-jnp.log(jax.vmap(_bound_ratios)(e,rates))).ravel()
jacobian=jax.jit(jax.jacfwd(residual));count=0;start=time.monotonic()
def fun(x):
 global count
 y=np.asarray(residual(jnp.asarray(x)));count+=1
 norm=float(np.max(abs(y)));np.savez_compressed(a.output/'latest.npz',state=x,residual=y,edges_cm=edges,iteration=count)
 record={'evaluation':count,'residual_max':norm,'seconds':time.monotonic()-start}
 with (a.output/'trace.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
 print(record,flush=True);return y
(a.output/'configuration.json').write_text(json.dumps({'arguments':{k:str(v) if isinstance(v,Path) else v for k,v in vars(a).items()},'source_sha256':{p.name:sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),Path(__file__).with_name('ou2_model.py')]},'scope':'External small pure-H fully population/continuum-coupled OU2 comparison. Native atomic/line closures and remaining known approximation differences apply. Not thermal/wind or solar validation.'},indent=2)+'\n')
if a.solver=='dense':
 solution=root(fun,initial,jac=lambda x:np.asarray(jacobian(jnp.asarray(x))),method='hybr',options={'maxfev':a.max_evaluations,'xtol':1e-10,'factor':.1})
else:
 jvp=jax.jit(lambda x,v:jax.jvp(residual,(x,),(v,))[1]);x=initial.copy();y=fun(x)
 for step in range(20):
  if np.max(abs(y))<1e-8:break
  operator=LinearOperator((len(x),len(x)),matvec=lambda v:np.asarray(jvp(jnp.asarray(x),jnp.asarray(v))),dtype=float)
  direction,info=gmres(operator,-y,rtol=1e-9,atol=0.,restart=100,maxiter=10)
  linear_error=float(np.linalg.norm(operator@direction+y)/np.linalg.norm(y))
  accepted=False
  for power in range(16):
   trial=x+direction*2.**(-power);value=fun(trial)
   if np.all(np.isfinite(value)) and np.linalg.norm(value)<np.linalg.norm(y):
    x,y=trial,value;accepted=True;break
  record={'step':step,'gmres_info':int(info),'linear_relative_residual':linear_error,'accepted':accepted,'line_search_power':power,'residual_max':float(np.max(abs(y)))}
  (a.output/f'step_{step:03d}.json').write_text(json.dumps(record,indent=2)+'\n');np.savez_compressed(a.output/f'step_{step:03d}.npz',state=x,residual=y)
  print(record,flush=True)
  if not accepted:break
 solution=SimpleNamespace(x=x,success=bool(np.max(abs(y))<1e-8),message='Checkpointed exact-JVP Newton/GMRES')
y=fun(solution.x);f=np.asarray(jax.nn.softmax(jnp.column_stack((jnp.asarray(solution.x.reshape(shape)),jnp.zeros(a.cells))),axis=1));b=1e12*f[:,:-1];e=1e12*f[:,-1]
report={'scipy_success':bool(solution.success),'message':str(solution.message),'residual_max':float(abs(y).max()),'converged':bool(abs(y).max()<1e-8),'seconds':time.monotonic()-start,'n2_column_cm2':float(np.diff(edges)@b[:,1:3].sum(1)),'n3_column_cm2':float(np.diff(edges)@b[:,3:6].sum(1))}
np.savez_compressed(a.output/'solution.npz',state=solution.x.reshape(shape),bound_cm3=b,electron_cm3=e,edges_cm=edges,residual=y)
(a.output/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(report,flush=True)
