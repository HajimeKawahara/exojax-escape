# Matched-source OU2 frequency-root refinement

This additional experiment independently solves the full 267-cell population,
charge, and continuum residual at quadrature orders 4 and 8 with identical
executed source. Both roots meet 1e-9 (actual solver stop 1e-10); maximum local
n2/n3/ne changes are 0.0340704%/0.198665%/0.00182068%, below the unchanged 1%.
The order-4 replay arrays are exactly equal to the prior strict 267-cell root.

This archive supplements, rather than changes, the immutable matched reference
archive SHA256 73b800204d3f85bd5141219dc7b281ca3656b4cdf0c255671b6fae579aa29065.
The earlier follow-up db8be118b2c3624561a8f8f672577dc57750aff4c99dd2612986179001bb17c7
retains the historical-source order-4 root; this paired supplement additionally
executes order 4 with the very same CLI as order 8 to remove that incidental
source-version difference. Neither earlier archive is overwritten.

The source snapshot at native revision 71aceae2ca0c8c7c30ae9d6d27feddb7db27fa32
and ExoJAX revision 38cb2e44f153ad6d729e3253e235702de52920cf remain unchanged.
The full source snapshot/reference geometry is in the prior matched archive.
Replay each order using that source snapshot and ExoJAX on PYTHONPATH:

    python solve_ou2_frequency_comparison.py PRIOR/continuum_controls/ou2_standard_maxdr5e6 NEW_OUTPUT --cells 267 --continuum-order ORDER --reference-grid --solver krylov

ORDER is 4 or 8; NEW_OUTPUT must be a new directory. This fixed-T H15 OU2
comparison is not the native bidirectional default, a solar atmosphere,
thermal/wind equilibrium, atomic convergence, or an observational fit.
No stellar input, binary, object, cache, or compiled IR is included.
