"""Freeze the matched-source order4/order8 complete roots."""
from pathlib import Path
from hashlib import sha256
import json,shutil,tarfile
import numpy as np
b=Path(__file__).parent;out=Path('/tmp/escape-ou2-frequency-paired-followup');out.mkdir(exist_ok=False)
names=['ou2_reference267_frequency4','ou2_reference267_frequency8']
a,c=[dict(np.load(b/name/'solution.npz')) for name in names]
old=dict(np.load(b/'ou2_reference267_strict/solution.npz'))
configurations=[json.loads((b/name/'configuration.json').read_text()) for name in names]
assert np.array_equal(a['edges_cm'],c['edges_cm'])
report={'scope':'External H15 OU2 fixed-temperature population/charge/continuum model,267cells,matched executed source,continuum quadrature4 to8. No native-default bidirectional,solar,thermal/wind,atomic-completeness or observer certificate.',
        'criteria':{'root':1e-9,'external_solver_stop':1e-10,'profile_refinement_relative':.01},
        'same_executed_source_hashes':configurations[0]['source_sha256']==configurations[1]['source_sha256'],
        'order4_replay_vs_historical_strict_arrays_exact':{key:np.array_equal(a[key],old[key]) for key in a},
        'max_relative_profile_change':{},
        'root_residuals':[float(abs(d['residual']).max()) for d in [a,c]]}
for label,low,high in [('n2',a['bound_cm3'][:,1:3].sum(1),c['bound_cm3'][:,1:3].sum(1)),('n3',a['bound_cm3'][:,3:6].sum(1),c['bound_cm3'][:,3:6].sum(1)),('electron',a['electron_cm3'],c['electron_cm3'])]:
 report['max_relative_profile_change'][label]=float(abs(high/low-1).max())
assert report['same_executed_source_hashes'] and all(report['order4_replay_vs_historical_strict_arrays_exact'].values())
(out/'ou2_paired_frequency_refinement.json').write_text(json.dumps(report,indent=2)+'\n')
files=['solve_ou2_frequency_comparison.py','ou2_model.py','package_paired_frequency.py']
for name in names:
 files += [name+'/'+s for s in ['solution.npz','configuration.json','receipt.json','trace.jsonl']]
 files += [str(p.relative_to(b)) for p in sorted((b/name).glob('step_*.json'))]
for name in files:
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(b/name,p)
(out/'README.md').write_text('''# Matched-source OU2 frequency-root refinement

This additional experiment independently solves the full 267-cell population,
charge, and continuum residual at quadrature orders 4 and 8 with identical
executed source. Both roots meet 1e-9 (actual solver stop 1e-10); maximum local
n2/n3/ne changes are 0.0340704%/0.198665%/0.00182068%, below the unchanged 1%.
The order-4 replay arrays are exactly equal to the prior strict 267-cell root.

This archive supplements, rather than changes, the immutable matched reference
archive SHA256 73b800204d3f85bd5141219dc7b281ca3656b4cdf0c255671b6fae579aa29065.
The earlier follow-up db8be118b2c3624561a8f8f672577dc57750aff4c99dd2612986179001bb17c7
retains the historical-source order-4 root; this paired supplement additionally
executes order 4 with the very same CLI as order 8 to remove that incidental
source-version difference. Neither earlier archive is overwritten.

The source snapshot at native revision 71aceae2ca0c8c7c30ae9d6d27feddb7db27fa32
and ExoJAX revision 38cb2e44f153ad6d729e3253e235702de52920cf remain unchanged.
The full source snapshot/reference geometry is in the prior matched archive.
Replay each order using that source snapshot and ExoJAX on PYTHONPATH:

    python solve_ou2_frequency_comparison.py PRIOR/continuum_controls/ou2_standard_maxdr5e6 NEW_OUTPUT --cells 267 --continuum-order ORDER --reference-grid --solver krylov

ORDER is 4 or 8; NEW_OUTPUT must be a new directory. This fixed-T H15 OU2
comparison is not the native bidirectional default, a solar atmosphere,
thermal/wind equilibrium, atomic convergence, or an observational fit.
No stellar input, binary, object, cache, or compiled IR is included.
''')
manifest={str(p.relative_to(out)):sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*')) if p.is_file()}
(out/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(out.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(out)))
print(json.dumps({'archive':str(archive),'sha256':sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'files':len(manifest)+1,'result':report},indent=2))
