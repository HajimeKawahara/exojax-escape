"""Observe an archived native root with its own continuum and explicit processing.

This driver does not re-solve the atmosphere or improve its radial resolution.
It verifies the archived root/source hashes before using its recorded state.
"""
from pathlib import Path
from unittest.mock import patch
import argparse
import hashlib
import importlib.util
import json
import time

import jax
import jax.numpy as jnp
import matplotlib
import numpy as np
import pandas as pd

matplotlib.use('Agg')
import matplotlib.pyplot as plt

from escape.solar import SolarCompositionModel
from escape.hydrogen_forward import PLANET_RADIUS_CM, SYNCHRONOUS_ROTATION_KMS
from escape.nlte_forward import HydrogenNLTEForwardModel
from cloudy_halpha import NIST_ROW, apply_observation, stellar_reference
from generate_spectra import load_observations


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case', type=Path, required=True)
    parser.add_argument('--cadence', type=Path, required=True)
    parser.add_argument('--stellar-surface', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--nlon', type=int, default=24)
    parser.add_argument('--nlat', type=int, default=12)
    parser.add_argument('--nnu', type=int, default=601)
    parser.add_argument('--nphase', type=int, default=5)
    args = parser.parse_args()
    args.output.mkdir(exist_ok=False)
    jax.config.update('jax_enable_x64', True)
    jax.config.update('jax_compilation_cache_dir', '/tmp/escape-jax-cache')
    start = time.time()
    read = lambda name: json.loads((args.case/name).read_text())
    manifest, source = read('MANIFEST.json'), read('SOURCE_MANIFEST.json')
    for name in ('configuration.json', 'diagnosis.json', 'root.npz', 'profile.npz',
                 'SOURCE_MANIFEST.json', 'exojax_source_hashes.json'):
        assert digest(args.case/name) == manifest[name], name
    for package, hashes in (
        ('escape', source['files']), ('exojax', read('exojax_source_hashes.json'))):
        installed = Path(next(iter(importlib.util.find_spec(package).submodule_search_locations)))
        for name, expected in hashes.items():
            relative = name.split(package+'/', 1)[1]
            assert digest(installed/relative) == expected, name
    config, diagnosis = read('configuration.json'), read('diagnosis.json')
    assert diagnosis['residual_norm'] < 1e-9
    assert diagnosis['valid'] and diagnosis['reference_domain_valid'] and diagnosis['wind']['converged']
    assert digest(args.case/'root.npz') == diagnosis['state_sha256']
    assert digest(args.case/'configuration.json') == diagnosis['configuration_sha256']
    assert digest(args.stellar_surface) == config['raw_sed_sha256']
    state = np.load(args.case/'root.npz')['state']
    profile = dict(np.load(args.case/'profile.npz'))
    surface = dict(np.load(args.stellar_surface))
    cadence = dict(np.load(args.cadence))
    temperature = np.array(config['temperature_reference_k'])*np.exp(state[:, 0])
    np.testing.assert_allclose(temperature, profile['temperature_k'], rtol=1e-12)
    edges = np.array(config['edges_rp'])
    model = SolarCompositionModel(
        edges*PLANET_RADIUS_CM, nmax=config['nmax'], iron_levels=config['iron_levels'],
        sulfur_levels=config['sulfur_levels'], iron_lyalpha=config['iron_lyalpha'],
        quadrature_order=2, angle_order=2, line_sampling=config['line_sampling'],
        line_quadrature_order=config['line_quadrature_order'],
        shielding_model=config['shielding_model'], core_escape_model=config['core_escape_model'],
        extra_frequency_edges=surface['frequency_hz'][[0,-1]])
    physical = model.unpack(jnp.asarray(state[:, 1:]), jnp.asarray(profile['n_h_cm3']))
    physical['atomic_lte_mask'] = jnp.arange(model.cells) < config['dense_lower_cells']
    for name in ('bound_cm3', 'electron_cm3', 'mean_molecular_weight', 'molecule_cm3'):
        np.testing.assert_allclose(physical[name], profile[name], rtol=1e-12)
    phases = np.linspace(.30, .50, args.nphase)
    assert phases[0] <= cadence['phase'].min() <= cadence['phase'].max() <= phases[-1]
    spectra, chi, eta = [], None, None
    for phase in phases:
        with patch('exojax.database.nist.api.fetch_nist_lines',
                   lambda *a, **kw: (pd.DataFrame(NIST_ROW), [])):
            observer = HydrogenNLTEForwardModel(
                radius_edges_rp=edges, nlayer=len(edges)-1, nmax=config['nmax'],
                nlon=args.nlon, nlat=args.nlat, nnu=args.nnu, phase=float(phase))
        if chi is None:
            frequency = jnp.asarray(observer.wavenumber_cm)*2.99792458e10
            chi, eta = jax.jit(model.continuum_coefficients_at)(
                jnp.asarray(temperature), physical, frequency)
        contrast = observer.spectrum_from_profiles(
            physical['bound_cm3'][::-1], temperature[::-1], profile['radial_velocity_kms'][::-1],
            rotation_kms=SYNCHRONOUS_ROTATION_KMS, zonal_kms=11.6,
            continuum_extinction=chi[::-1], continuum_emission=eta[::-1]*2.99792458e10)
        spectra.append(np.asarray(contrast)[::-1])
        print(dict(phase=float(phase), elapsed_s=time.time()-start), flush=True)
    spectra = np.asarray(spectra)
    assert np.isfinite(spectra).all()
    velocity = np.asarray(observer.velocity_kms)[::-1]
    stellar_velocity = np.linspace(-600, 600, 2401)
    reference = stellar_reference(stellar_velocity, surface, 110.)
    processed = apply_observation(phases, velocity, spectra, cadence, reference, stellar_velocity)
    assert np.all(processed.valid)
    sampled = np.array([np.interp(cadence['phase'], phases, column) for column in spectra.T]).T
    sampled = np.array([np.interp(cadence['velocity'], velocity, row) for row in sampled])
    weights = cadence['coadd_weight']
    raw = (sampled*weights).sum(0)/weights.sum(0)
    observed_v, observed, error = load_observations(observer.line_center_cm)
    prediction = np.interp(observed_v, cadence['velocity'], np.asarray(processed.contrast))
    arrays = dict(phase=phases, model_velocity_kms=velocity, phase_spectra=spectra,
                  output_velocity_kms=cadence['velocity'], processed=np.asarray(processed.contrast),
                  unprocessed=raw, observed_velocity_kms=observed_v, observed=observed,
                  supplied_error=error)
    np.savez_compressed(args.output/'derived_spectrum.npz', **arrays)
    thermal = diagnosis['blend'] == 1.
    label = 'Thermal root' if thermal else 'Prescribed-temperature root'
    fig, axes = plt.subplots(2,3,figsize=(11,6.5),constrained_layout=True)
    radius = profile['radius_cm']/PLANET_RADIUS_CM
    n2, n3 = profile['bound_cm3'][:,1:3].sum(1), profile['bound_cm3'][:,3:6].sum(1)
    energy = (np.asarray(diagnosis['thermal_net'])+diagnosis['advection']+diagnosis['expansion'])
    scale = (np.asarray(diagnosis['thermal_scale'])+np.abs(diagnosis['advection'])+np.abs(diagnosis['expansion']))
    balance = energy/scale
    balance[:config['dense_lower_cells']] = np.nan
    axes[0,0].plot(radius,temperature,'o-')
    axes[0,1].plot(radius,profile['mean_molecular_weight'],'o-')
    axes[0,2].plot(radius,profile['radial_velocity_kms'],'o-')
    axes[1,0].semilogy(radius,n2,'o-',label='n=2')
    axes[1,0].semilogy(radius,n3,'s--',label='n=3'); axes[1,0].legend(fontsize=8)
    axes[1,1].semilogy(radius,n3/n2,'o-')
    plotted_balance = np.maximum(np.abs(balance), 1e-15)
    axes[1,2].semilogy(radius,plotted_balance,'o-')
    if np.any(balance == 0.):
        axes[1,2].plot(radius[balance == 0.],plotted_balance[balance == 0.],
                       'v',label='Rounded zero (shown at floor)')
    axes[1,2].axhline(1e-9,color='.5',ls=':',label='Thermal residual limit')
    axes[1,2].set(ylim=(3e-16,1.),yticks=[1e-15,1e-12,1e-9,1e-6,1e-3,1.])
    axes[1,2].legend(fontsize=7)
    for axis,title,ylabel in zip(axes.flat,
        ('Temperature','Mean molecular weight','Radial Parker wind','Hydrogen populations','Excitation ratio','Thermal residual: upper cells'),
        ('T [K]',r'$\mu$ [proton masses]','v [km/s]',r'$n_i$ [cm$^{-3}$]',r'$n_3/n_2$','|Net heat| / numerical scale')):
        axis.set(xlabel=r'Radius / $R_p$',ylabel=ylabel,title=title,xlim=(1,3)); axis.grid(alpha=.15)
        axis.axvspan(1,edges[config['dense_lower_cells']],color='.6',alpha=.12)
    fig.suptitle(label+'; five-cell numerical control')
    fig.supxlabel('Markers are the solved cells; joining lines guide the eye. Shading: prescribed lower boundary.\n'
                  'The numerical heat scale is not Cloudy gross heating/cooling. Radial convergence remains unverified.',fontsize=8)
    fig.savefig(args.output/'profiles.png',dpi=180); plt.close(fig)
    fig, axis = plt.subplots(figsize=(9,4.6), constrained_layout=True)
    axis.errorbar(observed_v, observed*1e6, yerr=error*1e6, fmt='.', color='.4',
                  alpha=.55, ms=3, elinewidth=.6, label='Keck/KPF observation')
    axis.plot(cadence['velocity'], raw*1e6, '--', label=label+': before processing')
    axis.plot(cadence['velocity'], np.asarray(processed.contrast)*1e6,
              label=label+': observation proxy')
    axis.axhline(0, color='.5', lw=.6)
    axis.set(xlim=(-105,105), xlabel='Velocity from NIST H-alpha [km/s]',
             ylabel='Residual contrast [ppm]', title=label+'; coarse native atmosphere, no fit')
    axis.legend(fontsize=8); axis.grid(alpha=.15)
    fig.supxlabel('Approximate cadence/master weights and stellar mask; atmosphere resolution is unverified.\n'
                  'Data: Yapeng Zhang (2026), doi:10.5281/zenodo.20707255, CC BY 4.0.', fontsize=8)
    fig.savefig(args.output/'spectrum.png', dpi=180); plt.close(fig)
    report = dict(source_revision=source['revision'], root_sha256=digest(args.case/'root.npz'),
        driver_sha256=digest(__file__), cadence_sha256=digest(args.cadence),
        helper_sha256={name:digest(importlib.util.find_spec(name).origin)
                       for name in ('cloudy_halpha','generate_spectra')},
        velocities_kms=dict(rotation=SYNCHRONOUS_ROTATION_KMS,zonal=11.6,stellar_rotation=110.),
        stellar_input_sha256=digest(args.stellar_surface), thermal_blend=diagnosis['blend'],
        root_residual=diagnosis['residual_norm'],
        grids=dict(nlayer=model.cells,nlon=args.nlon,nlat=args.nlat,nnu=args.nnu,nphase=args.nphase),
        continuum='Actual solved H/He/metals/molecules/free-free; prescribed dense metal Kirchhoff mask retained',
        processing='Same approximate cadence, equal master weights, stellar mask and endpoint extension as examples/cloudy_halpha.py',
        rms_over_supplied_error=float(np.sqrt(np.mean(((prediction-observed)/error)**2))),
        elapsed_s=time.time()-start,
        scope='Fixed archived root, no new atmosphere solve or radial-resolution claim. Phase/angle/frequency convergence and exact observational reduction remain separate checks.',
        raw_stellar_arrays_included=False)
    (args.output/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
    print(report, flush=True)


if __name__ == '__main__':
    main()
