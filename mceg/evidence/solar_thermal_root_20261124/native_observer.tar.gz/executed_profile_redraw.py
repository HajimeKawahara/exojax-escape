"""Redraw profile diagnostics on a common absolute-residual scale."""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import matplotlib
import numpy as np

matplotlib.use('Agg')
import matplotlib.pyplot as plt

driver = Path('/tmp/observe_native_solar_root.py')
plot_source = driver.read_text().split('    fig, axes = plt.subplots')[1]
plot_source = 'fig, axes = plt.subplots'+plot_source.split('    fig, axis = plt.subplots')[0]
plot_source = '\n'.join(line[4:] if line.startswith('    ') else line
                        for line in plot_source.splitlines())
for case, output in (
    ('/tmp/escape-current-five-cell-fixed-root-evidence','/tmp/escape-native-current5-observer-refined'),
    ('/tmp/escape-current-five-cell-thermal-root-evidence','/tmp/escape-native-current5-thermal-observer')):
    case, output = Path(case), Path(output)
    read = lambda name: json.loads((case/name).read_text())
    profile = dict(np.load(case/'profile.npz'))
    config, diagnosis = read('configuration.json'), read('diagnosis.json')
    temperature = profile['temperature_k']
    edges = np.asarray(config['edges_rp'])
    label = 'Thermal root' if diagnosis['blend'] == 1. else 'Prescribed-temperature root'
    args = SimpleNamespace(output=output)
    PLANET_RADIUS_CM = profile['radius_cm'][0]/((edges[0]+edges[1])/2)
    old_hash = hashlib.sha256((output/'profiles.png').read_bytes()).hexdigest()
    exec(compile(plot_source,str(driver),'exec'),globals())
    receipt_path = output/'receipt.json'
    receipt = json.loads(receipt_path.read_text())
    receipt.setdefault('profile_plot_history', []).append(receipt['profile_plot_update'])
    receipt['profile_plot_update'] = dict(
        driver_sha256=hashlib.sha256(driver.read_bytes()).hexdigest(),
        redraw_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        original_image_sha256=old_hash,
        updated_image_sha256=hashlib.sha256((output/'profiles.png').read_bytes()).hexdigest(),
        reason='Display the rounded-zero residual at an explicitly labeled floor. Numerical arrays are unchanged.')
    receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
