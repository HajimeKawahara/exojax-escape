# Native five-cell observer controls

The thermal case uses the independently verified full thermal/radiation/
composition/wind root, F-infinity = 8.4278006796e-10. Only the upper three cells
solve energy balance. The two dense lower cells use the declared prescribed
temperature/LTE extension. The fixed-temperature controls use a different root
whose temperature remains prescribed. These curves are not fitted.

The actual native H/He/metal/molecular/free-free continuum and H populations
enter the observer. No Cloudy population is substituted. The root, atomic
model, source manifests and independent wind checks are in the accompanying
native thermal and previous fixed-temperature archives. Restore escape
4473ed7f2344e8edba012477e05c34b6c7da56a2 and ExoJAX
38cb2e44f153ad6d729e3253e235702de52920cf. The two observer helpers are pinned
in each refined receipt and can be restored from escape 3164ba3. Put that
checkout's examples directory on PYTHONPATH alongside the pinned src paths.

Run observe_native_solar_root.py with --case pointing at the unpacked native
root archive, --cadence cadence_weights.npz, --stellar-surface pointing at
the independently fetched PHOENIX input, and a new --output directory.
Use --nlon 48 --nlat 24 --nnu 1201 --nphase 9 for the refined cases, or
24/12/601/5 for the coarse prescribed-temperature case. Source, root and
stellar-input hashes are verified before numerical work. The original
executed drivers are retained; subsequent plotting-only changes explicitly
show the rounded-zero energy residual at a labeled floor. They do not change
any numerical spectrum/profile. Original/intermediate/final image hashes are
in each receipt. The executed redraw script retains original scratch paths.

Joint angular/frequency/phase refinement at the prescribed-temperature root
changes the processed spectrum by at most 6.84972 ppm (0.012794 supplied
uncertainties). This is not a radial convergence test or a thermal-profile
resolution test. The thermal model visibly fails to describe the observed
central trough and peak amplitudes; this is recorded, not fitted away.
RMS divided by supplied errors is 2.4684. This descriptive statistic is not
a likelihood or reduced chi-square with validated covariance.

Processing uses the explicitly approximate cadence, nightly master weights,
stellar mask and endpoint continuation of examples/cloudy_halpha.py. The
actual publication reduction has not been reconstructed. Cadence weights
were derived from the archived HDF5 errors and validity and the stated mask;
see cadence_summary.json. The immutable Zenodo record declares CC BY 4.0:
Zhang, Yapeng (2026), Keck/KPF high-resolution emission spectroscopic
observations of KELT-9 b, doi:10.5281/zenodo.20707255.
https://creativecommons.org/licenses/by/4.0/
The derived arrays convert wavelengths to velocity at the native NIST H-alpha
center and add the model and approximate weights. Error bars retain the
supplied uncertainties without asserting an independently verified confidence
level. No endorsement is implied. The original notice is retained as source
provenance; its old single-phase/blackbody description applies to that earlier
plot, not these explicitly processed PHOENIX-reference controls.

No original PHOENIX/FITS/SED, sampled stellar boundary/reference, executable,
compiler IR/cache or duplicate atomic data is included. NPZ files contain
derived planet spectra, observed data/errors, and observation weights only.
