"""Convert externally retrieved PHOENIX FITS inputs without redistributing them."""
from __future__ import annotations

import argparse
from hashlib import sha256
import json
from pathlib import Path

from astropy.io import fits
import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    metadata = json.loads((Path(__file__).parent / "stellar_metadata.json").read_text())
    for name in ("wavelength.fits", "phoenix10000.fits"):
        if sha256((args.input / name).read_bytes()).hexdigest() != metadata["sha256"][name]:
            raise ValueError(f"Unexpected input content: {name}")
    wavelength = np.asarray(fits.getdata(args.input / "wavelength.fits"), dtype=float)
    flux = np.asarray(fits.getdata(args.input / "phoenix10000.fits"), dtype=float)
    if wavelength.shape != flux.shape or not np.all(np.diff(wavelength) > 0):
        raise ValueError("Incompatible wavelength/flux arrays.")
    if not np.all(np.isfinite(flux) & (flux >= 0)):
        raise ValueError("Invalid surface flux.")
    wavelength_cm = wavelength*1e-8
    light_speed = 2.99792458e10
    frequency = light_speed/wavelength_cm
    flux_nu = flux*wavelength_cm**2/light_speed
    np.savez_compressed(args.output, frequency_hz=frequency[::-1],
                        surface_flux_nu=flux_nu[::-1])
    actual = sha256(args.output.read_bytes()).hexdigest()
    expected = metadata["sha256"]["phoenix10000_surface_flux.npz"]
    if actual != expected:
        raise ValueError(f"Converted file hash differs: {actual}; expected {expected}")
    print(f"Verified converted stellar input: {actual}")


if __name__ == "__main__":
    main()
