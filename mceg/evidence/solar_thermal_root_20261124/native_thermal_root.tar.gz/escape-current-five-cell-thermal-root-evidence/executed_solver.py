"""Exact-JVP numerical candidate for the current coupled Solar atmosphere.

Host Newton is a checkpointed diagnostic. It does not replace the production
implicit derivative and never accepts a failed or out-of-domain atmosphere.
"""
from pathlib import Path
import argparse
from unittest.mock import patch
import pandas as pd
import json
import hashlib
import time
import jax
import jax.numpy as jnp
import numpy as np
from scipy.sparse.linalg import LinearOperator, gmres
from escape.solar import SolarAtmosphereModel

jax.config.update('jax_enable_x64', True)
jax.config.update('jax_compilation_cache_dir', '/tmp/escape-jax-cache')
start=time.time()
parser=argparse.ArgumentParser()
parser.add_argument('--seed',type=Path,required=True)
parser.add_argument('--seed-configuration',type=Path,required=True)
parser.add_argument('--seed-preconditioner',type=Path)
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--blends',type=float,nargs='+',default=[0.,1.])
parser.add_argument('--maximum-newton-steps',type=int,default=25)
args=parser.parse_args()
output=args.output;output.mkdir(exist_ok=True)
source=Path('source_current_flow_gradient')
seed_configuration=json.loads(args.seed_configuration.read_text())
old_state=np.load(args.seed)['state']
old_temperature=np.asarray(seed_configuration['temperature_reference_k'])*np.exp(old_state[:,0])
sedpath=Path('/tmp/escape-stellar-sed-data/phoenix10000_surface_flux.npz')
sed=np.load(sedpath)
edges=np.array([1.,1.05,1.05+.25/3,1.05+2*.25/3,1.3,3.])
centers=.5*(edges[1:]+edges[:-1])
nist=json.loads(Path('/tmp/escape-five-cell-root-evidence/nist_row.json').read_text())['row']
with patch('exojax.database.nist.api.fetch_nist_lines',lambda *a,**kw:(pd.DataFrame(nist),[])):
    model=SolarAtmosphereModel(edges, nmax=15, iron_levels=716, sulfur_levels=72,
    iron_lyalpha=True,shielding_model='continuous_core',core_escape_model='continuous',newton_merit='correction',
    quadrature_order=2, angle_order=2, dense_lower_cells=2, lower_temperature_k=4500.,
    line_sampling="average",line_quadrature_order=4,wind_ngrid=129, tidal_coefficient_s2=3*(2*np.pi/(1.48*86400))**2,
    extra_frequency_edges=sed['frequency_hz'][[0,-1]],
    observer_options=dict(nlon=2,nlat=2,nnu=101))
boundary=model.stellar_boundary(sed['frequency_hz'],sed['surface_flux_nu'],
    incident_flux_ratio=.1, outside_zero=True)
temperature=jnp.asarray(old_temperature);mass_loss=1e13
shape=(model.cells,model.state_size+1)
# Initialization supplies only new sulfur coordinates; existing species retain
# the earlier root's identity-matched values, never interpolated by array index.
initial=np.asarray(model.initialize(jnp.ones(model.cells)*1e10,temperature))
prior=old_state[:,1:]
seeded=initial.copy()
prefix=model.metal_slice.start
seeded[:,:prefix]=prior[:,:prefix]
old_z=[z for z in model.metal.atomic_number if z!=16]
old_offset=2*len(old_z)
column_map=list(range(prefix))
for old_index,z in enumerate(old_z):
    new_index=model.metal.atomic_number.index(z)
    a,b=prefix+2*old_index,prefix+2*new_index
    seeded[:,b:b+2]=prior[:,a:a+2]
    column_map.extend([b,b+1])
for (_,z,_),block in zip(model.metal.atom_specs,model.metal.excitation_slices):
    if z==16:continue
    count=block.stop-block.start
    a,b=prefix+old_offset,prefix+block.start
    seeded[:,b:b+count]=prior[:,a:a+count]
    column_map.extend(range(b,b+count))
    old_offset+=count
assert prefix+old_offset==prior.shape[1]
column_map=np.r_[0,np.asarray(column_map)+1]
flat_map=np.concatenate([column_map+i*shape[1] for i in range(model.cells)])
seed_wind,seed_wind_info=model._wind(jnp.asarray(seeded),temperature,mass_loss)
if not bool(seed_wind_info['converged']):raise ValueError('Mapped seed wind failed its strict solve.')
sulfur_seed=np.asarray(model.initialize(seed_wind.density_g_cm3/model.mass_per_h,temperature))
new_columns=np.setdiff1d(np.arange(model.state_size),column_map[1:]-1)
seeded[:,new_columns]=sulfur_seed[:,new_columns]
value=np.column_stack((np.zeros(model.cells),seeded)).ravel()
start_blend=float(args.blends[0])
np.savez_compressed(output/'input_seed.npz',state=value.reshape(shape),old_to_new_column=column_map)
(output/'seed_mapping.json').write_text(json.dumps(dict(seed=str(args.seed),
    seed_sha256=hashlib.sha256(args.seed.read_bytes()).hexdigest(),
    old_state_shape=list(old_state.shape),new_state_shape=list(shape),
    method='Existing elements and atoms map by identity. New sulfur uses the declared Saha numerical initialization at the mapped composition wind density. New reference temperature is the old state physical temperature; the final blend=1 energy equations are unchanged.'),indent=2)+'\n')
if (output/'checkpoint.npz').exists():
    checkpoint=np.load(output/'checkpoint.npz');value=checkpoint['state'].ravel();start_blend=float(checkpoint['blend'])

configuration=dict(edges_rp=edges.tolist(),temperature_reference_k=np.asarray(temperature).tolist(),
 mass_loss_g_s=mass_loss,wind_ngrid=129,nmax=15,iron_levels=716,sulfur_levels=72,iron_lyalpha=True,dense_lower_cells=2,lower_temperature_k=4500.,
 inner_radiation='dark, matching selected one-sided Cloudy reference',
 source_snapshot='source_current_flow_gradient at 4473ed7f2344e8edba012477e05c34b6c7da56a2',
 source_manifest_sha256=hashlib.sha256((source/'manifest.json').read_bytes()).hexdigest(),
 driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 raw_sed_sha256=hashlib.sha256(sedpath.read_bytes()).hexdigest(),raw_sed_included=False,line_sampling="average",line_quadrature_order=4,shielding_model="continuous_core",core_escape_model="continuous",
 numerical_scope='Five coarse cells, splitting the inverted middle cell into three, exact JVP Newton with exact frozen-J inverse line-search metric (inverse secants are preconditioners only); no physical/grid adequacy or NUTS claim.')
(output/'configuration.json').write_text(json.dumps(configuration,indent=2)+'\n')
print('constructed',shape,len(model.grid.frequency_hz),len(model.metal.line_frequency_hz),time.time()-start,flush=True)

def evaluate(flat,blend):
    return model.evaluate_atmosphere(flat,temperature,mass_loss,
        boundary['incident_mean_intensity'],hydrogen_line_intensity=boundary['hydrogen_line_intensity'],
        metal_line_intensity=boundary['metal_line_intensity'],overlap_intensity=boundary['overlap_intensity'],
        thermal_blend=blend)
function=jax.jit(lambda x,b:evaluate(x,b)[0])
product=jax.jit(lambda x,b,v:jax.jvp(lambda y:evaluate(y,b)[0],(x,),(v,))[1])


import threading
import signal
import resource


def heartbeat():
    while True:
        time.sleep(30)
        print('heartbeat', time.time()-start, 'maxrss_kib',
              resource.getrusage(resource.RUSAGE_SELF).ru_maxrss, flush=True)


def terminated(signum, frame):
    print('received_signal', signum, time.time()-start, flush=True)
    raise SystemExit(128+signum)


signal.signal(signal.SIGTERM, terminated)
signal.signal(signal.SIGINT, terminated)
threading.Thread(target=heartbeat, daemon=True).start()


def inverse_secant(s, y):
    norm=np.linalg.norm(s, axis=0)
    keep=(norm>0) & np.isfinite(norm)
    s, y=s[:, keep]/norm[keep], y[:, keep]/norm[keep]
    u, singular, vt=np.linalg.svd(y, full_matrices=False)
    selected=singular>singular[0]*1e-10
    left=((s-y)@vt[selected].T)/singular[selected]
    right=u[:, selected].T
    def apply(v):
        return v+left@(right@v)
    return apply, dict(rank=int(selected.sum()),singular_values=singular.tolist(),
        relative_cutoff=1e-10,secant_relative_error=float(np.linalg.norm(apply(y)-s)/np.linalg.norm(s))), left, right


if args.seed_preconditioner is not None:
    prior_inverse=np.load(args.seed_preconditioner)
    left=np.zeros((value.size,prior_inverse['inverse_left'].shape[1]))
    right=np.zeros((prior_inverse['inverse_right'].shape[0],value.size))
    left[flat_map]=prior_inverse['inverse_left']
    right[:,flat_map]=prior_inverse['inverse_right']
    def precondition(v):return v+left@(right@v)
    (output/'preconditioner_handoff.json').write_text(json.dumps(dict(
        origin=str(args.seed_preconditioner),sha256=hashlib.sha256(args.seed_preconditioner.read_bytes()).hexdigest(),
        method='Identity-map the previous approximate inverse onto existing coordinates; leave new sulfur as identity. This is only a linear preconditioner, not a current Jacobian or nonlinear merit.'),indent=2)+'\n')
else:
    def precondition(v):return v
print('initial_residual',float(abs(function(value,start_blend)).max()),time.time()-start,flush=True)

for blend in args.blends:
    blend=float(blend)
    if blend<start_blend-1e-12:
        continue
    for iteration in range(args.maximum_newton_steps):
        residual=np.asarray(function(value,blend))
        norm=float(abs(residual).max())
        if not np.isfinite(norm) or norm<1e-9:
            break
        vectors=[]
        products=[]
        def matvec(v):
            result=np.array(product(value,blend,v),copy=True)
            vectors.append(np.array(v,copy=True));products.append(result.copy())
            return result
        operator=LinearOperator((value.size,value.size),dtype=float,matvec=matvec)
        inverse=LinearOperator(operator.shape,dtype=float,matvec=precondition)
        def linear_solve(rhs,label):
            trace=[]
            def callback(error):
                trace.append(float(error))
                if len(trace)%5==0:
                    print('krylov',blend,iteration,label,len(trace),error,time.time()-start,flush=True)
            solution,info=gmres(operator,rhs,M=inverse,restart=80,maxiter=3,
                rtol=1e-5,atol=0.,callback=callback,callback_type='pr_norm')
            error=float(np.linalg.norm(operator@solution-rhs)/np.linalg.norm(rhs))
            return solution,dict(label=label,true_relative_error=error,valid=bool(np.isfinite(error) and error<5e-5),iterations=len(trace),info=int(info))
        correction,linear=linear_solve(-residual,'newton')
        # Reuse current-J products only to accelerate the same frozen-J trial
        # solves. Their unpreconditioned linear errors remain the acceptance gate.
        precondition,trial_inverse_audit,_,_=inverse_secant(
            np.stack(vectors,axis=1),np.stack(products,axis=1))
        inverse=LinearOperator(operator.shape,dtype=float,matvec=precondition)
        old_merit=float(np.linalg.norm(correction))
        step_dir=output/f'blend_{blend:.4f}_step_{iteration:02d}'
        step_dir.mkdir(exist_ok=True)
        np.savez_compressed(step_dir/'newton.npz',state=value.reshape(shape),residual=residual,correction=correction)
        trials=[];accepted=False
        if linear['valid']:
            for backtrack in range(16):
                fraction=2.**(-backtrack)
                trial=value+fraction*correction
                trial_f=np.asarray(function(trial,blend))
                finite=bool(np.isfinite(trial_f).all())
                trial_norm=float(np.max(abs(trial_f)))
                trial_row=dict(backtrack=backtrack,fraction=fraction,finite=finite,
                    original_infinity_norm=trial_norm,original_l2_norm=float(np.linalg.norm(trial_f)),
                    largest_residual_index=int(np.argmax(abs(trial_f))))
                if finite:
                    # Keep J at the original Newton point throughout this line search.
                    # B accelerates this solve; it is never used as an error norm.
                    if trial_norm==0.:
                        simplified=np.zeros_like(value)
                        check=dict(valid=True,true_relative_error=0.,iterations=0,info=0)
                    else:
                        simplified,check=linear_solve(trial_f,f'trial_{backtrack}')
                    merit=float(np.linalg.norm(simplified))
                    trial_row.update(exact_inverse_merit=merit,linear_check=check)
                    accepted=check['valid'] and merit<(1-.5*fraction)*old_merit
                trial_row['accepted']=bool(accepted)
                trials.append(trial_row)
                print('trial',blend,iteration,trial_row,flush=True)
                np.savez_compressed(step_dir/f'trial_{backtrack:02d}.npz',state=trial.reshape(shape),residual=trial_f)
                if accepted:
                    value=trial.copy()
                    break
        precondition,audit,left,right=inverse_secant(np.stack(vectors,axis=1),np.stack(products,axis=1))
        np.savez_compressed(step_dir/'krylov.npz',vectors=np.stack(vectors,axis=1),products=np.stack(products,axis=1),inverse_left=left,inverse_right=right)
        (step_dir/'preconditioner.json').write_text(json.dumps(audit,indent=2)+'\n')
        row=dict(stage='exact_affine_newton',blend=blend,step=iteration,accepted=bool(accepted),
            old_original_infinity_norm=norm,original_infinity_norm=float(abs(function(value,blend)).max()),
            old_exact_inverse_merit=old_merit,max_step=float(abs(correction).max()),
            newton_linear_check=linear,trial_inverse_audit=trial_inverse_audit,trials=trials,elapsed_s=time.time()-start)
        print(row,flush=True)
        (step_dir/'receipt.json').write_text(json.dumps(row,indent=2)+'\n')
        with (output/'history.jsonl').open('a') as stream:
            stream.write(json.dumps(row)+'\n')
        np.savez_compressed(output/'checkpoint.npz',state=value.reshape(shape),blend=blend)
        if not accepted:
            break
    norm=float(abs(function(value,blend)).max())
    print('stage',blend,norm,time.time()-start,flush=True)
    np.savez_compressed(output/f'stage_{blend:.4f}.npz',state=value.reshape(shape),blend=blend,residual=norm)
    if not np.isfinite(norm) or norm>=1e-9:
        break

residual,physical=jax.jit(evaluate)(value,blend)
full_norm=float(abs(function(value,1.)).max())
converged=bool(np.isfinite(full_norm) and full_norm<1e-9)
applicable=converged and bool(physical['reference_domain_valid'])
names=['bound_cm3','electron_cm3','proton_cm3','molecule_cm3','helium_cm3','metal_ion_cm3',
       'mean_molecular_weight','thermal_net','temperature_k','n_h_cm3','radial_velocity_kms',
       'pressure_dyn_cm2','reference_domain_valid','thermal_balance_required']
np.savez_compressed(output/'solution.npz',state=value.reshape(shape),residual_norm=float(abs(residual).max()),
    full_thermal_residual_norm=full_norm,blend=blend,converged=converged,applicable=applicable,
    **{key:np.asarray(physical[key]) for key in names})
summary=dict(residual_norm=float(abs(residual).max()),full_thermal_residual_norm=full_norm,blend=blend,
    converged=converged,applicable=bool(applicable),temperature_k=np.asarray(physical['temperature_k']).tolist(),
    n_h_cm3=np.asarray(physical['n_h_cm3']).tolist(),pressure_bar=(np.asarray(physical['pressure_dyn_cm2'])/1e6).tolist(),elapsed_s=time.time()-start)
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(summary,flush=True)
