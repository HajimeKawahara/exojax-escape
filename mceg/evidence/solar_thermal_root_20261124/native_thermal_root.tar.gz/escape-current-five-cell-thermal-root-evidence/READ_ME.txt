Native five-cell coupled thermal root (2026-11-24)

The selected coarse model meets the original full F-infinity <1e-9 criterion:
8.42780067955573e-10. The upper three cells solve energy balance jointly with
radiation, populations, electrons/composition/mu and the Parker wind. The two
dense lower cells retain the declared imposed LTE/temperature boundary; they
are not claimed to satisfy the non-LTE thermal equations. Independent physical,
reference-domain and wind flags passed. The 101-frequency/2x2-disk observer
is finite. Spatial resolution, atomic completeness, transfer closure agreement,
observed-spectrum processing, physical adequacy and NUTS are separate gates.

Root/state and derived profiles are in root.npz, solution.npz, profile.npz.
The six accepted thermal steps and their original residual/true-linear-error
receipts are included. Exact frozen-J inverse correction norms govern the
line search; inverse secants are preconditioners only. Temporary increases of
the unscaled residual are retained honestly. The final residual is unmodified.
The fixed-temperature seed is pinned to the separate immutable archive SHA
in receipt.json. No large preconditioner/Krylov matrices are redistributed.

wind_grid_and_domain.json retains all 129/257/513/1025 and 16/32/64 Rp results
at the final T/mu, including the failed 64 Rp/1025 solve (residual 2.35e-8 >1e-8,
returned NaNs). No tolerance was relaxed. The adopted 129 grid agrees with
32 Rp/1025 to 0.237% in expansion cooling; the independent DOP853 check is
also included (about 0.240%). A wind convergence check is not an atmosphere
spatial-convergence check. Constant outer T/mu remains an explicit assumption.

The final diagnostic stores upper retained-metal charge photoionization
leakage events/rates, three-body binding energy, signed thermal channels and
Fe exchange/width/selection diagnostics. Direct Fe redistribution heat does
not bound indirect radiation/Ca/Fe effects. Native signed channels and explicit
hydrogen gross heating/cooling are not relabeled as Cloudy gross Gamma/Lambda.
The raw observer scope text is inherited from a finite-output-only diagnostic;
receipt.json distinguishes that narrow check from the full thermal residual.

Restore escape Git 4473ed7f2344e8edba012477e05c34b6c7da56a2 and ExoJAX Git
38cb2e44f153ad6d729e3253e235702de52920cf, then set PYTHONPATH to their src
paths. Hash manifests cover the exact package code/data; it is not duplicated.
Follow environment.json and fetch_stellar_data.py/convert_stellar_data.py for
the externally supplied PHOENIX input. No original stellar FITS/flux/boundary
arrays, continuum radiation arrays or compiler IR/cache are distributed here.

  python replay_thermal_root.py --stellar-data /path/phoenix10000_surface_flux.npz --output /tmp/thermal-replay --verify-only
  python replay_thermal_root.py --stellar-data /path/phoenix10000_surface_flux.npz --output /tmp/thermal-replay

The portable replay's physical evaluate function is AST-identical to the
successfully executed diagnostic. Only paths and input/hash checks differ.
The executed solver/diagnostic scripts and logs retain original commands and
scratch paths as provenance; they are not a portable cold-start NUTS program.
