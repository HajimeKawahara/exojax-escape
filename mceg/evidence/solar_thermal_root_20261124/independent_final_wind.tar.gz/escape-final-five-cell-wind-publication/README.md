# Independent wind check at a strict five-cell thermal root

This archive verifies only the wind and energy-gradient calculation at one fixed native state. It does not establish Solar physical adequacy, spatial convergence, or agreement with Cloudy or observations. The root state is identified by SHA256 and the recorded residual in `state_provenance.json`; no stellar input arrays are included.

The source T/mu and radius knots are in `input_profile.npz`, including the fixed 4500 K lower knot. `spectral.json` contains the native flow values at 129, 257 and 513 nodes. The independent DOP853 solver uses the same log-Hermite forcing, a regular sonic launch, and matched physical constants. `five_point_independent_ode_receipt.json` reports the comparison and independent ODE refinement; theoretical zero advection is checked absolutely.

Install NumPy and SciPy, copy this directory to a fresh scratch directory, and run `python replay.py`. The replay writes new timing/hash metadata in that copy, so preserve this immutable archive. `compare.py` is the original executed script; `replay.py` changes only the source-import path. The two copied external tools are verification sources, not an escape runtime dependency.
