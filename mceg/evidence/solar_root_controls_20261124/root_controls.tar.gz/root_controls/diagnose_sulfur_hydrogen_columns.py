"""Inspect the coupled root with separately compiled residual/JVP kernels.

The Python/SciPy loop is a development diagnostic, not the inference solver.
No finite-difference Jacobian or substitute physical state is accepted.
"""
from pathlib import Path
import argparse
import json
import time
import threading, signal, sys

import jax
import jax.numpy as jnp
import numpy as np
from scipy.sparse.linalg import LinearOperator, gmres

from escape.solar import SolarCompositionModel

jax.config.update('jax_enable_x64', True)
jax.config.update('jax_compilation_cache_dir', '/tmp/escape-jax-cache')
parser = argparse.ArgumentParser()
parser.add_argument('--iron-levels', type=int, default=716)
parser.add_argument('--nmax', type=int, default=15)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--log-field', type=float, default=0.)
parser.add_argument('--seed', type=Path)
parser.add_argument('--prepare-only',action='store_true')
parser.add_argument('--skip-relax',action='store_true')
args = parser.parse_args()
args.output.mkdir(exist_ok=True)
start = time.time()
phase='construct'
def heartbeat():
    while True:
        time.sleep(25)
        print(dict(heartbeat=True,phase=phase,elapsed=time.time()-start),flush=True)
threading.Thread(target=heartbeat,daemon=True).start()
def terminated(sig,frame):
    (args.output/'interruption.json').write_text(json.dumps(dict(signal=sig,phase=phase,elapsed=time.time()-start))+'\n')
    raise SystemExit(128+sig)
signal.signal(signal.SIGTERM,terminated)
model = SolarCompositionModel([0., 5e5, 1e6], nmax=args.nmax,
    iron_levels=args.iron_levels, quadrature_order=2, angle_order=2,
    line_optical_depth_scale=1., line_sampling='average',line_quadrature_order=4)
temperature = jnp.array([8000., 8200.])
density = jnp.array([1e12, 9e11])
incoming = model.hydrogen.boundary_blackbody(10000., .025)
state = model.initialize(density, temperature)
if args.seed is not None:
    prior = np.load(args.seed)['state']
    if prior.shape[1] == model.state_size:
        state = jnp.asarray(prior)
    else:
        # Match old nine-element coordinates by element and atom identity.
        seeded = np.array(state)
        prefix = model.metal_slice.start
        seeded[:, :prefix] = prior[:, :prefix]
        old_z = [z for z in model.metal.atomic_number if z != 16]
        old_offset = 2*len(old_z)
        for old_index,z in enumerate(old_z):
            new_index = model.metal.atomic_number.index(z)
            seeded[:,prefix+2*new_index:prefix+2*new_index+2] = prior[:,prefix+2*old_index:prefix+2*old_index+2]
        for (_,z,_),block in zip(model.metal.atom_specs,model.metal.excitation_slices):
            if z==16:continue
            count=block.stop-block.start
            seeded[:,prefix+block.start:prefix+block.stop] = prior[:,prefix+old_offset:prefix+old_offset+count]
            old_offset += count
        assert prefix+old_offset == prior.shape[1]
        state = jnp.asarray(seeded)
        np.savez_compressed(args.output/'mapped_seed.npz',state=seeded)
        (args.output/'seed_mapping.json').write_text(json.dumps(dict(source=str(args.seed),sha256=__import__('hashlib').sha256(args.seed.read_bytes()).hexdigest(),old_state_size=int(prior.shape[1]),new_state_size=model.state_size,method='Copy H/He and matching metal element/excitation coordinates; sulfur uses declared initialization.',source_revision='5242cc40d971f5313c256a1a0eabe694ea0f7de9'),indent=2)+'\n')
shape = state.shape
print('constructed', shape, len(model.metal.line_frequency_hz), time.time()-start, flush=True)

def residual(flat, log_field):
    target, physical = model.evaluate(flat.reshape(shape), density,
        temperature, incoming*jnp.exp(log_field))
    return jnp.where(physical['valid'], (flat.reshape(shape)-target).ravel(), jnp.nan)

function = jax.jit(residual)
product = jax.jit(lambda flat, field, tangent: jax.jvp(
    lambda x: residual(x, field), (flat,), (tangent,))[1])
value = np.asarray(state).ravel()
history = []

def checkpoint(row):
    row['elapsed'] = time.time()-start
    history.append(row)
    print(row, flush=True)
    np.savez_compressed(args.output/'checkpoint.npz', state=value.reshape(shape))
    (args.output/'history.json').write_text(json.dumps(history, indent=2)+'\n')

from escape.hydrogen_escape_probability import vvoigt
from escape.hydrogen_rates import LIGHT_SPEED_CGS,BOLTZMANN_CGS
from escape.hydrogen_escape_probability import PROTON_MASS_CGS
h=model.hydrogen;atom=h.atom
upper,lower,g=atom.line_upper,atom.line_lower,atom.statistical_weights
width=atom.line_frequency_hz[None,:]/LIGHT_SPEED_CGS*jnp.sqrt(2*BOLTZMANN_CGS*temperature[:,None]/PROTON_MASS_CGS)
factor=LIGHT_SPEED_CGS**2*atom.einstein_a_s/(8*jnp.pi*atom.line_frequency_hz**2)/(jnp.sqrt(jnp.pi)*width)
fine_matrix=jax.vmap(lambda w:vvoigt(atom.line_frequency_hz[None,:]-atom.line_frequency_hz[:,None],w/jnp.sqrt(2),h._gamma_hz)*jnp.sqrt(jnp.pi)*w[:,None])(width)
nodes=(np.polynomial.legendre.leggauss(4)[0]+1)/2
saved=np.load('/tmp/escape-solar-molecular-continuation/column_sulfur_average_step_diagnosis/direction.npz')
def columns(state):
    physical=model.unpack(jnp.asarray(state).reshape(shape),density);bound=physical['bound_cm3']
    kappa=factor*(bound[:,lower]*g[upper]/g[lower]-bound[:,upper])
    depth=np.asarray(jnp.einsum('cl,clk->ck',kappa,fine_matrix))*np.asarray(model.widths_cm)[:,None]
    front=np.cumsum(depth[::-1],axis=0)[::-1]-depth;total=depth.sum(0)
    sampled=front[None,:,:]+nodes[:,None,None]*depth[None,:,:]
    return dict(front=sampled,back=abs(total[None,None,:]-sampled),depth=depth)
before=columns(saved['state']);after=columns(saved['state']+saved['direction']);rows=[]
for side in ('front','back'):
    for label,boundary in [('zero',0.),('K2thin',.01/np.sqrt(np.pi)),('K2large',11/np.sqrt(np.pi)),('Federman2',2.),('Federman10',10.),('Federman100',100.)]:
        for q,cell,line in np.argwhere((before[side]<boundary)!=(after[side]<boundary)):
            rows.append(dict(side=side,boundary=label,node=int(q),cell=int(cell),line=int(line),before=float(before[side][q,cell,line]),after=float(after[side][q,cell,line]),n_upper=int(atom.principal_n[upper[line]]),n_lower=int(atom.principal_n[lower[line]]),upper=int(upper[line]),lower=int(lower[line]),wavelength_angstrom=float(LIGHT_SPEED_CGS/atom.line_frequency_hz[line]*1e8)))
(args.output/'hydrogen_crossings.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2),flush=True)
