"""Inspect the coupled root with separately compiled residual/JVP kernels.

The Python/SciPy loop is a development diagnostic, not the inference solver.
No finite-difference Jacobian or substitute physical state is accepted.
"""
from pathlib import Path
import argparse
import json
import time
import threading, signal, sys

import jax
import jax.numpy as jnp
import numpy as np
from scipy.sparse.linalg import LinearOperator, gmres

from escape.solar import SolarCompositionModel

jax.config.update('jax_enable_x64', True)
jax.config.update('jax_compilation_cache_dir', '/tmp/escape-jax-cache')
parser = argparse.ArgumentParser()
parser.add_argument('--iron-levels', type=int, default=716)
parser.add_argument('--nmax', type=int, default=15)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--log-field', type=float, default=0.)
parser.add_argument('--seed', type=Path)
parser.add_argument('--prepare-only',action='store_true')
parser.add_argument('--skip-relax',action='store_true')
args = parser.parse_args()
args.output.mkdir(exist_ok=True)
start = time.time()
phase='construct'
def heartbeat():
    while True:
        time.sleep(25)
        print(dict(heartbeat=True,phase=phase,elapsed=time.time()-start),flush=True)
threading.Thread(target=heartbeat,daemon=True).start()
def terminated(sig,frame):
    (args.output/'interruption.json').write_text(json.dumps(dict(signal=sig,phase=phase,elapsed=time.time()-start))+'\n')
    raise SystemExit(128+sig)
signal.signal(signal.SIGTERM,terminated)
model = SolarCompositionModel([0., 5e5, 1e6], nmax=args.nmax,
    iron_levels=args.iron_levels, quadrature_order=2, angle_order=2,
    line_optical_depth_scale=1., line_sampling='average',line_quadrature_order=4)
temperature = jnp.array([8000., 8200.])
density = jnp.array([1e12, 9e11])
incoming = model.hydrogen.boundary_blackbody(10000., .025)
state = model.initialize(density, temperature)
if args.seed is not None:
    prior = np.load(args.seed)['state']
    if prior.shape[1] == model.state_size:
        state = jnp.asarray(prior)
    else:
        # Match old nine-element coordinates by element and atom identity.
        seeded = np.array(state)
        prefix = model.metal_slice.start
        seeded[:, :prefix] = prior[:, :prefix]
        old_z = [z for z in model.metal.atomic_number if z != 16]
        old_offset = 2*len(old_z)
        for old_index,z in enumerate(old_z):
            new_index = model.metal.atomic_number.index(z)
            seeded[:,prefix+2*new_index:prefix+2*new_index+2] = prior[:,prefix+2*old_index:prefix+2*old_index+2]
        for (_,z,_),block in zip(model.metal.atom_specs,model.metal.excitation_slices):
            if z==16:continue
            count=block.stop-block.start
            seeded[:,prefix+block.start:prefix+block.stop] = prior[:,prefix+old_offset:prefix+old_offset+count]
            old_offset += count
        assert prefix+old_offset == prior.shape[1]
        state = jnp.asarray(seeded)
        np.savez_compressed(args.output/'mapped_seed.npz',state=seeded)
        (args.output/'seed_mapping.json').write_text(json.dumps(dict(source=str(args.seed),sha256=__import__('hashlib').sha256(args.seed.read_bytes()).hexdigest(),old_state_size=int(prior.shape[1]),new_state_size=model.state_size,method='Copy H/He and matching metal element/excitation coordinates; sulfur uses declared initialization.',source_revision='5242cc40d971f5313c256a1a0eabe694ea0f7de9'),indent=2)+'\n')
shape = state.shape
print('constructed', shape, len(model.metal.line_frequency_hz), time.time()-start, flush=True)

def residual(flat, log_field):
    target, physical = model.evaluate(flat.reshape(shape), density,
        temperature, incoming*jnp.exp(log_field))
    return jnp.where(physical['valid'], (flat.reshape(shape)-target).ravel(), jnp.nan)

function = jax.jit(residual)
product = jax.jit(lambda flat, field, tangent: jax.jvp(
    lambda x: residual(x, field), (flat,), (tangent,))[1])
value = np.asarray(state).ravel()
history = []

def checkpoint(row):
    row['elapsed'] = time.time()-start
    history.append(row)
    print(row, flush=True)
    np.savez_compressed(args.output/'checkpoint.npz', state=value.reshape(shape))
    (args.output/'history.json').write_text(json.dumps(history, indent=2)+'\n')

phase='residual and relaxation'
for i in range(0 if args.skip_relax else 16):
    current = np.asarray(function(value, args.log_field))
    norm = float(np.max(np.abs(current)))
    candidate = value-.5*current
    after = np.asarray(function(candidate, args.log_field))
    accepted = np.all(np.isfinite(after)) and np.max(np.abs(after)) < norm
    if accepted:
        value = candidate
    checkpoint(dict(stage='relax', step=i, residual=norm, accepted=bool(accepted)))
    if not accepted or norm < 1e-10:
        break

if args.prepare_only:
    np.savez_compressed(args.output/'checkpoint.npz',state=value.reshape(shape))
    print('Prepared checkpoint',flush=True)
    raise SystemExit(0)
phase='Newton and exact JVP'
for i in range(60):
    current = np.asarray(function(value, args.log_field))
    norm = float(np.max(np.abs(current)))
    if not np.isfinite(norm) or norm < 1e-10:
        break
    operator = LinearOperator((value.size, value.size), dtype=float,
        matvec=lambda tangent: np.array(product(value, args.log_field, tangent), copy=True))
    trace = []
    def callback(error):
        trace.append(float(error))
        print(dict(krylov=len(trace),relative=float(error),elapsed=time.time()-start),flush=True)
    correction, info = gmres(operator, -current, restart=80, maxiter=30,
        rtol=1e-5, atol=0., callback=callback,
        callback_type='pr_norm')
    error = float(np.linalg.norm(operator@correction+current)/np.linalg.norm(current))
    accepted, backtracks = False, 0
    if np.isfinite(error) and error < 5e-5:
        for backtracks in range(24):
            candidate = value+2.**(-backtracks)*correction
            after = np.asarray(function(candidate, args.log_field))
            if np.all(np.isfinite(after)) and np.max(np.abs(after)) < norm:
                value, accepted = candidate, True
                break
    checkpoint(dict(stage='newton', step=i, residual=float(np.max(np.abs(function(value, args.log_field)))),
        accepted=accepted, linear_relative_error=error, krylov_iterations=len(trace),
        gmres_info=int(info), backtracks=backtracks))
    if not accepted:
        break

norm = float(np.max(np.abs(function(value, args.log_field))))
summary = dict(converged=bool(np.isfinite(norm) and norm < 1e-9),
    residual=norm, elapsed=time.time()-start, iron_levels=args.iron_levels,
    nmax=args.nmax, log_field=args.log_field, source_snapshot='source_sulfur_average/manifest.json', line_sampling='average',line_quadrature_order=4,
    purpose='Fixed-profile numerical integration proof; not atmospheric adequacy.')
(args.output/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(summary, flush=True)
if summary['converged']:
    _, physical = jax.jit(model.evaluate)(value.reshape(shape), density, temperature,
        incoming*jnp.exp(args.log_field))
    names = ['bound_cm3', 'electron_cm3', 'proton_cm3', 'molecule_cm3', 'helium_cm3',
             'metal_ion_cm3', 'mean_molecular_weight', 'thermal_net', 'temperature_k', 'n_h_cm3']
    np.savez_compressed(args.output/'solution.npz', state=value.reshape(shape),
        **{key: np.asarray(physical[key]) for key in names})
