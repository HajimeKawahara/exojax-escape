"""Plot the measured numerical obstruction and its paired repair."""
from pathlib import Path
import json

import jax
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
from scipy.integrate import quad
from scipy.special import expn

from escape.line_escape_probability import doppler_core_escape

jax.config.update('jax_enable_x64', True)
root = Path('/tmp/escape-solar-molecular-continuation')
out = Path('/tmp/escape-solar-root-publication')
out.mkdir(exist_ok=True)
t = np.linspace(.009, .011, 600)
old = np.asarray(doppler_core_escape(t/np.sqrt(np.pi), core_escape_model='cloudy'))
new = np.asarray(doppler_core_escape(t/np.sqrt(np.pi), core_escape_model='continuous'))
history = json.loads((root/'column_sulfur_average/history.json').read_text())
old_norm = [row['residual'] for row in history if row['stage'] == 'newton']
new_history = json.loads((root/'column_sulfur_average_continuous_k2/history.json').read_text())
new_norm = [row['residual'] for row in new_history if row['stage'] == 'newton']

fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.1), layout='constrained')
ax = axes[0]
ax.plot(t, old, color='#b84a3a', label='Original C23 approximation')
ax.plot(t, new, color='#276eaa', label='Continuous positive-depth option')
check_t = np.array([.0092, .0096, .0104, .0108])
exact = np.array([2/np.sqrt(np.pi)*quad(
    lambda x: np.exp(-x*x)*expn(2, q/np.sqrt(np.pi)*np.exp(-x*x)),
    0., 12., epsabs=1e-12, epsrel=1e-12)[0] for q in check_t])
ax.plot(check_t, exact, 'kx', ms=6, label='Independent Doppler integral')
ax.axvline(.01, color='.5', lw=.8, ls=':')
ax.set(xlabel=r'$t=\sqrt{\pi}\,\tau$', ylabel='Doppler core escape probability',
       title='A numerical jump in the line operator')
ax.ticklabel_format(axis='x', style='plain', useOffset=False)
ax.xaxis.set_major_locator(MaxNLocator(5))
ax.legend(fontsize=8, loc='lower left')

ax = axes[1]
ax.semilogy(np.arange(len(old_norm)), old_norm, 'o-', color='#b84a3a', ms=4,
            label='Original option: stalled')
offset = len(old_norm)
# The changed operator must be evaluated afresh at the old checkpoint.
new_initial = .0021255539087832176
ax.semilogy(np.arange(offset, offset+len(new_norm)+1), [new_initial]+new_norm,
            'o-', color='#276eaa', ms=5, label='Re-evaluate with continuous option')
ax.axhline(1e-9, color='.25', ls='--', lw=1, label='Unchanged acceptance criterion')
ax.set(xlabel='Accepted Newton updates (then operator change)',
       ylabel=r'$\max |F|$', title='Ten-metal two-cell population control')
ax.legend(fontsize=8, loc='lower left')
ax.text(.03, .97, 'Prescribed T and density; not a thermal atmosphere',
        transform=ax.transAxes, va='top', fontsize=8)
fig.savefig(out/'root_control.png', dpi=180)
np.savez_compressed(out/'root_control_plot_data.npz', t=t, original=old,
                    continuous=new, original_residual=np.array(old_norm),
                    continuous_residual=np.array([new_initial]+new_norm),
                    integral_t=check_t, integral=exact)
