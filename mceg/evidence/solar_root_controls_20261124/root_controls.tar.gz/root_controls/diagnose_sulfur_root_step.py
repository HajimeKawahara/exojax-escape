"""Inspect the coupled root with separately compiled residual/JVP kernels.

The Python/SciPy loop is a development diagnostic, not the inference solver.
No finite-difference Jacobian or substitute physical state is accepted.
"""
from pathlib import Path
import argparse
import json
import time
import threading, signal, sys

import jax
import jax.numpy as jnp
import numpy as np
from scipy.sparse.linalg import LinearOperator, gmres

from escape.solar import SolarCompositionModel

jax.config.update('jax_enable_x64', True)
jax.config.update('jax_compilation_cache_dir', '/tmp/escape-jax-cache')
parser = argparse.ArgumentParser()
parser.add_argument('--iron-levels', type=int, default=716)
parser.add_argument('--nmax', type=int, default=15)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--log-field', type=float, default=0.)
parser.add_argument('--seed', type=Path)
parser.add_argument('--prepare-only',action='store_true')
parser.add_argument('--skip-relax',action='store_true')
args = parser.parse_args()
args.output.mkdir(exist_ok=True)
start = time.time()
phase='construct'
def heartbeat():
    while True:
        time.sleep(25)
        print(dict(heartbeat=True,phase=phase,elapsed=time.time()-start),flush=True)
threading.Thread(target=heartbeat,daemon=True).start()
def terminated(sig,frame):
    (args.output/'interruption.json').write_text(json.dumps(dict(signal=sig,phase=phase,elapsed=time.time()-start))+'\n')
    raise SystemExit(128+sig)
signal.signal(signal.SIGTERM,terminated)
model = SolarCompositionModel([0., 5e5, 1e6], nmax=args.nmax,
    iron_levels=args.iron_levels, quadrature_order=2, angle_order=2,
    line_optical_depth_scale=1., line_sampling='average',line_quadrature_order=4)
temperature = jnp.array([8000., 8200.])
density = jnp.array([1e12, 9e11])
incoming = model.hydrogen.boundary_blackbody(10000., .025)
state = model.initialize(density, temperature)
if args.seed is not None:
    prior = np.load(args.seed)['state']
    if prior.shape[1] == model.state_size:
        state = jnp.asarray(prior)
    else:
        # Match old nine-element coordinates by element and atom identity.
        seeded = np.array(state)
        prefix = model.metal_slice.start
        seeded[:, :prefix] = prior[:, :prefix]
        old_z = [z for z in model.metal.atomic_number if z != 16]
        old_offset = 2*len(old_z)
        for old_index,z in enumerate(old_z):
            new_index = model.metal.atomic_number.index(z)
            seeded[:,prefix+2*new_index:prefix+2*new_index+2] = prior[:,prefix+2*old_index:prefix+2*old_index+2]
        for (_,z,_),block in zip(model.metal.atom_specs,model.metal.excitation_slices):
            if z==16:continue
            count=block.stop-block.start
            seeded[:,prefix+block.start:prefix+block.stop] = prior[:,prefix+old_offset:prefix+old_offset+count]
            old_offset += count
        assert prefix+old_offset == prior.shape[1]
        state = jnp.asarray(seeded)
        np.savez_compressed(args.output/'mapped_seed.npz',state=seeded)
        (args.output/'seed_mapping.json').write_text(json.dumps(dict(source=str(args.seed),sha256=__import__('hashlib').sha256(args.seed.read_bytes()).hexdigest(),old_state_size=int(prior.shape[1]),new_state_size=model.state_size,method='Copy H/He and matching metal element/excitation coordinates; sulfur uses declared initialization.',source_revision='5242cc40d971f5313c256a1a0eabe694ea0f7de9'),indent=2)+'\n')
shape = state.shape
print('constructed', shape, len(model.metal.line_frequency_hz), time.time()-start, flush=True)

def residual(flat, log_field):
    target, physical = model.evaluate(flat.reshape(shape), density,
        temperature, incoming*jnp.exp(log_field))
    return jnp.where(physical['valid'], (flat.reshape(shape)-target).ravel(), jnp.nan)

function = jax.jit(residual)
product = jax.jit(lambda flat, field, tangent: jax.jvp(
    lambda x: residual(x, field), (flat,), (tangent,))[1])
value = np.asarray(state).ravel()
history = []

def checkpoint(row):
    row['elapsed'] = time.time()-start
    history.append(row)
    print(row, flush=True)
    np.savez_compressed(args.output/'checkpoint.npz', state=value.reshape(shape))
    (args.output/'history.json').write_text(json.dumps(history, indent=2)+'\n')

phase='diagnostic exact Newton direction'
f=np.asarray(function(value,0.))
operator=LinearOperator((value.size,value.size),dtype=float,matvec=lambda v:np.array(product(value,0.,v),copy=True))
direction,info=gmres(operator,-f,restart=40,maxiter=5,rtol=1e-5,atol=0.)
jd=operator@direction
report=dict(initial_max=float(np.max(abs(f))),linear_relative=float(np.linalg.norm(jd+f)/np.linalg.norm(f)),info=int(info),max_step=float(np.max(abs(direction))),trials=[])
np.savez_compressed(args.output/'direction.npz',state=value,direction=direction,residual=f,jvp=jd)
def coordinate(index):
    cell,coord=divmod(int(index),model.state_size)
    if coord<model.hydrogen_size:
        return dict(cell=cell,coordinate=coord,species='H',principal_n=int(model.hydrogen.atom.principal_n[coord]))
    if coord<model.helium_slice.start:return dict(cell=cell,coordinate=coord,species='H molecule')
    if coord<model.metal_slice.start:return dict(cell=cell,coordinate=coord,species='He')
    offset=coord-model.metal_slice.start
    if offset<2*len(model.metal.elements):return dict(cell=cell,coordinate=coord,species='metal charge',z=model.metal.atomic_number[offset//2],q=offset%2)
    for spec,block in zip(model.metal.atom_specs,model.metal.excitation_slices):
        if block.start<=offset<block.stop:return dict(cell=cell,coordinate=coord,species=spec[0],level_coordinate=offset-block.start)
    return dict(cell=cell,coordinate=coord)
for alpha in (0.,1.,.5,.25,.125,.0625,.01,1e-3,1e-4):
    trial=value+alpha*direction;res=np.asarray(function(trial,0.));prediction=f+alpha*jd
    indices=np.argsort(abs(res))[-6:][::-1]
    item=dict(alpha=alpha,maximum_residual=float(np.max(abs(res))),maximum_linearization_error=float(np.max(abs(res-prediction))),rows=[dict(**coordinate(i),residual=float(res[i]),linearization_error=float(res[i]-prediction[i]),state_change=float(alpha*direction[i])) for i in indices])
    report['trials'].append(item);print(item,flush=True)
np.savez_compressed(args.output/'trial.npz',state=value+direction)
(args.output/'diagnosis.json').write_text(json.dumps(report,indent=2)+'\n')
print(dict(completed=True,elapsed=time.time()-start),flush=True)
