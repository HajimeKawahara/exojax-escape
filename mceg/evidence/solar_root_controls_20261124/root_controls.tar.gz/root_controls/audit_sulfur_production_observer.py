"""Check the ten-metal root through the explicit production options.

This prescribed-profile two-cell control does not establish thermal or
planetary adequacy. The incident spectrum is an analytic blackbody.
"""
from pathlib import Path
import hashlib
import json
import time

import jax
import jax.numpy as jnp
import numpy as np

from escape.solar import SolarCompositionModel
from escape.nlte_forward import HydrogenNLTEForwardModel, halpha_coefficients
from escape.hydrogen_forward import PLANET_RADIUS_CM
from escape.hydrogen_rates import LIGHT_SPEED_CGS

jax.config.update('jax_enable_x64', True)
jax.config.update('jax_compilation_cache_dir', '/tmp/escape-jax-cache')
root = Path('/tmp/escape-solar-molecular-continuation')
out = root/'column_sulfur_production_observer'
out.mkdir(exist_ok=False)
start = time.time()
edges = np.array([0., 5e5, 1e6])
temperature = jnp.array([8000., 8200.])
density = jnp.array([1e12, 9e11])
model = SolarCompositionModel(
    edges, nmax=15, iron_levels=716, sulfur_levels=72,
    quadrature_order=2, angle_order=2, line_optical_depth_scale=1.,
    line_sampling='average', line_quadrature_order=4,
    shielding_model='cloudy', core_escape_model='continuous')
seed = root/'column_sulfur_average_continuous_k2/checkpoint.npz'
state = jnp.asarray(np.load(seed)['state'])
incident = model.hydrogen.boundary_blackbody(10000., .025)

def check(value):
    target, physical = model.evaluate(value, density, temperature, incident)
    return jnp.max(jnp.abs(value-target)), physical['valid']

norm, valid = jax.jit(check)(state)
norm, valid = float(norm), bool(valid)
print(dict(residual=norm, valid=valid, elapsed=time.time()-start), flush=True)
assert valid and norm < 1e-9
physical = model.unpack(state, density)
observer = HydrogenNLTEForwardModel(
    nlayer=2, nlon=4, nlat=4, nnu=61, nmax=15,
    radius_edges_rp=1+edges/PLANET_RADIUS_CM)
frequency = jnp.asarray(observer.wavenumber_cm)*LIGHT_SPEED_CGS
chi, eta = model.continuum_coefficients_at(temperature, physical, frequency)
a, _ = halpha_coefficients(physical['bound_cm3'], observer.line_center_cm,
                          sum_branches=False)
profiles = jax.vmap(observer._line_profiles)(temperature, jnp.zeros(2))
minimum_extinction = np.asarray((chi+jnp.sum(a[:, :, None]*profiles, axis=1)).min(1))
spectrum = np.asarray(jax.jit(lambda: observer.spectrum_from_profiles(
    physical['bound_cm3'][::-1], temperature[::-1], jnp.zeros(2),
    continuum_extinction=chi[::-1],
    continuum_emission=eta[::-1]*LIGHT_SPEED_CGS))())
finite = bool(np.isfinite(spectrum).all())
np.savez_compressed(out/'observer.npz', spectrum=spectrum,
                    wavenumber_cm=np.asarray(observer.wavenumber_cm),
                    minimum_extinction=minimum_extinction,
                    bound_cm3=np.asarray(physical['bound_cm3']))
manifest = root/'source_sulfur_production/manifest.json'
receipt = dict(
    residual=norm, physical_valid=valid, finite_observer=finite,
    minimum_extinction_cm1=minimum_extinction.tolist(),
    source_manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),
    seed_sha256=hashlib.sha256(seed.read_bytes()).hexdigest(),
    driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    source_revision=json.loads(manifest.read_text())['revision'],
    retained_metal_elements=10, iron_levels=716, sulfur_levels=72,
    line_sampling='average', core_escape_model='continuous',
    shielding_model='cloudy', elapsed=time.time()-start,
    scope=__doc__)
(out/'summary.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(receipt, flush=True)
assert finite
