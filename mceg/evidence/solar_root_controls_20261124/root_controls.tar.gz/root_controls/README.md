# Scoped numerical root and implicit-derivative controls

The original C23 Doppler-core approximation jumps at sqrt(pi)*tau=0.01.
The ten-metal two-cell Newton run stalls above its unchanged 1e-9 criterion.
The preserved direction/trials locate a nonvanishing full-equation jump at
the H n=11 to n=10 threshold. Changing only the Doppler-core function in the
isolated comparison gives a residual of 3.5705e-13 in two Newton updates.
The unchanged production API at 927fb77, with core_escape_model='continuous',
independently reproduces this residual and a finite H-alpha observer.

The continuous function removes the inaccurate optically thin shortcut and
connects the moderate/thick approximations. Independent angular/frequency
quadrature and regression tests are retained. This does not improve the
separate wing approximation, establish global zero-depth differentiability,
or bound the final thermal/spectral effect of the operator change.

The actual JAX custom_root/custom_linear_solve reverse derivative at the
earlier nine-metal verified root agrees with the independent implicit JVP
to 6.6367e-10 relative error. Primal iterations are zero: this checks the
implicit primitive, not cold-start convergence. A single-file overlay from
4ea5632 skips unused zero-step Newton tracing and reproduces the same result.
Its elapsed time was 1478 s versus 2521 s; these are individual runs, not a
controlled performance benchmark. Both source manifests and exact drivers
are retained. The independent JVP/finite-difference evidence is in the
unchanged solar-discretization-20261124 archive.

## Replay and exclusions

Source manifests identify Git revisions and every implementation/data hash.
For the isolated K2 experiment, use 5242cc4 plus the explicitly included
single-function source overlay. For the production observer use 927fb77;
for the original warm derivative use cd76343. The zero-step optimization
changes only nonlinear.py to its 4ea5632 version. Recorded drivers retain
their original /tmp paths; remap the scratch root before replay in an empty
directory. All illumination here is an analytic blackbody. No original
PHOENIX spectrum, stellar_reference array, binary or compiler cache is included.
