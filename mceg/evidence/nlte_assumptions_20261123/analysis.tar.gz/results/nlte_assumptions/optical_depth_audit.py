"""Evaluate opacity of already-solved prescribed-field atmospheres.

This measures a consistency diagnostic, not a self-consistent radiation field.
Static line-center depth alone does not supply an escape probability or Case B.
"""
from pathlib import Path
from unittest.mock import patch
import hashlib
import json

import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd

from exojax.opacity.lpf.lpf import vvoigt
from escape.hydrogen_atom import atom_cross_sections, atom_natural_width_hz
from escape.hydrogen_continuum import continuum_coefficients
from escape.hydrogen_rates import BOLTZMANN_CGS, LIGHT_SPEED_CGS, PLANCK_CGS
from escape.nlte_forward import HydrogenNLTEForwardModel
from escape.parker import PROTON_MASS_CGS
from verify_nlte_spectrum import NIST_ROW

jax.config.update('jax_enable_x64', True)
ROOT = Path('/tmp/exojax-escape-nlte-spectrum')
OUT = ROOT/'results/nlte_assumptions'
TIDE = 3*(2*np.pi/(1.48*86400))**2
previous = json.loads((ROOT/'results/nlte_asymmetry/candidate_metrics.json').read_text())
CASES = [('baseline',0.,10000.,1e13),('manual',TIDE,14000.,1e15),
         ('radial_fit',TIDE,6000.,1.888437367355413e14)]
report = {
    'scope':'Optical depths of prescribed-field populations, not a converged radiation-population solution.',
    'convention':'Radial outward column from each layer midpoint to 3 Rp: sum full exterior cells plus half the current cell. Total columns span 1 to 3 Rp.',
    'line_scope':'Static thermal/full-lifetime line centers. H-alpha uses the observer common NIST center and three branches; Ly-alpha uses the resolved 2p->1s atomic transition.',
    'continuum_scope':'Hydrogenic bound-free true absorption and signed net bound-free extinction; optional second total includes H+ free-free with Gaunt factor 1. No H-minus.',
    'diagnostic_development_note':'An initial run exited 1 because this diagnostic passed a one-dimensional detuning array to vvoigt, which requires a line-by-frequency matrix. Corrected to shape (1,1); no scientific source was changed and no model failure was inferred.',
    'fixed':{'nlayer':128,'nmax':15,'temperature_base_k':6000.,'wind_mu':.5,
             'radiation_dilution':.025,'radiation_temperature_k':10000.},
    'source_correspondence':{
        'cross_sections':'src/escape/hydrogen_atom.py:177; cm^2',
        'net_continuum':'src/escape/hydrogen_continuum.py:105; cm^-1',
        'observer_halpha':'src/escape/nlte_forward.py:116; profile cm and integrated extinction cm^-2',
        'populations':'src/escape/nlte_forward.py:139; cm^-3',
    },
    'cases':{},
}
models = {}
for name,tide,top,mass in CASES:
    if tide not in models:
        with patch('exojax.database.nist.api.fetch_nist_lines',lambda *a,**kw:(pd.DataFrame(NIST_ROW),[])):
            models[tide] = HydrogenNLTEForwardModel(nlayer=128,nlon=12,nlat=6,nnu=601,
                                                   tidal_coefficient_s2=tide)
    model = models[tide]
    atom = model.atom
    p = model.population_profiles(temperature_top_k=top,mass_loss_g_s=mass)
    if not np.all(p['converged']):
        raise RuntimeError(f'Invalid prescribed population state: {name}')
    frequency = jnp.asarray([
        1.001*atom.ionization_energy_erg[0]/PLANCK_CGS,
        1.001*jnp.max(atom.ionization_energy_erg[1:3])/PLANCK_CGS,
        model.line_center_cm*LIGHT_SPEED_CGS,
    ])
    labels = ['Lyman_edge_1p001','Balmer_edge_1p001','Halpha_continuum']
    sigma = atom_cross_sections(atom,frequency)
    absorption = np.asarray(p['bound_cm3'] @ sigma)
    net,_ = jax.vmap(lambda t,n,ne:continuum_coefficients(
        atom,t,n,ne,ne,frequency,include_free_free=False,
    ))(p['temperature_k'],p['bound_cm3'],p['electron_density_cm3'])
    total,_ = jax.vmap(lambda t,n,ne:continuum_coefficients(
        atom,t,n,ne,ne,frequency,include_free_free=True,
    ))(p['temperature_k'],p['bound_cm3'],p['electron_density_cm3'])
    # Independent Hz-convention Ly-alpha line-center extinction.
    upper,lower = atom.line_upper[0],atom.line_lower[0]
    nu = atom.line_frequency_hz[0]
    doppler = nu/LIGHT_SPEED_CGS*jnp.sqrt(BOLTZMANN_CGS*p['temperature_k']/PROTON_MASS_CGS)
    gamma = atom_natural_width_hz(atom)[0]
    ly_profile = jax.vmap(lambda sig:vvoigt(jnp.zeros((1,1)),jnp.atleast_1d(sig),jnp.atleast_1d(gamma))[0,0])(doppler)
    ly_weight = LIGHT_SPEED_CGS**2*atom.einstein_a_s[0]/(8*jnp.pi*nu**2)*(
        atom.statistical_weights[upper]/atom.statistical_weights[lower]*p['bound_cm3'][:,lower]
        -p['bound_cm3'][:,upper])
    phi = jax.vmap(model._line_profiles)(p['temperature_k'],jnp.zeros_like(p['temperature_k']))
    halpha = jnp.sum(p['halpha_branch_extinction_integral'][:,:,None]*phi,axis=1)
    center = int(np.argmin(np.abs(np.asarray(model.velocity_kms))))
    coefficients = {label+'_true_absorption':absorption[:,i] for i,label in enumerate(labels)}
    coefficients.update({label+'_net_bound_free':np.asarray(net)[:,i] for i,label in enumerate(labels)})
    coefficients.update({label+'_net_bound_free_plus_free_free':np.asarray(total)[:,i] for i,label in enumerate(labels)})
    coefficients.update(Lyalpha_static_center=np.asarray(ly_weight*ly_profile),
                        Halpha_static_center=np.asarray(halpha[:,center]))
    dr = np.asarray(model.thickness_cm)
    radius = np.asarray(model.radius_rp)
    depths = {key:np.cumsum(value*dr)-.5*value*dr for key,value in coefficients.items()}
    record = {
        'parameters':{'temperature_top_k':top,'mass_loss_g_s':mass,'tidal_coefficient_s2':tide},
        'sample_frequencies_hz':dict(zip(labels,map(float,frequency))),
        'sample_wavelengths_angstrom':dict(zip(labels,map(float,LIGHT_SPEED_CGS/frequency*1e8))),
        'total_tau_1_to_3_rp':{key:float(np.sum(value*dr)) for key,value in coefficients.items()},
        'all_coefficients_finite':bool(all(np.isfinite(x).all() for x in coefficients.values())),
        'minimum_extinction_cm1':{key:float(np.min(value)) for key,value in coefficients.items()},
        'max_scaled_rate_residual':float(np.max(p['rate_residual_norm'])),
        'layers':[],
    }
    targets = [('fixed_1p1',1.1),('fixed_1p3',1.3),('fixed_1p8',1.8),('fixed_2p0',2.),('fixed_2p5',2.5)]
    if name in previous['cases']:
        for kind in ['rest_vertical_tau_one','moving_vertical_tau_one']:
            row = previous['cases'][name][kind][0]
            if row['reaches_tau_one']:
                targets.append((kind+'_Halpha_center',row['radius_rp']))
    for label,target in targets:
        idx = int(np.argmin(np.abs(radius-target)))
        record['layers'].append({
            'label':label,'radius_rp':float(radius[idx]),
            'temperature_k':float(p['temperature_k'][idx]),
            'radial_velocity_kms':float(p['radial_velocity_kms'][idx]),
            'n_h_cm3':float(p['n_h_cm3'][idx]),
            'ionized_fraction':float(p['ionized_fraction'][idx]),
            'tau_to_outer_boundary':{key:float(value[idx]) for key,value in depths.items()},
        })
    report['cases'][name]=record
    (OUT/'optical_depth_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({name:record}),flush=True)
report['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
report['source_sha256']={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                        for p in sorted((ROOT/'src/escape').glob('*.py'))}
(OUT/'optical_depth_audit.json').write_text(json.dumps(report,indent=2)+'\n')
