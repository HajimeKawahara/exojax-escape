"""Prescribed-field sensitivity only; not a fitted or coupled atmosphere."""
from functools import partial
from pathlib import Path
from unittest.mock import patch
import json

import jax
import jax.numpy as jnp
import matplotlib
import numpy as np
import pandas as pd
from scipy.signal import find_peaks

matplotlib.use('Agg')
import matplotlib.pyplot as plt

from escape.hydrogen_atom import solve_atom_populations
from escape.hydrogen_forward import PLANET_RADIUS_CM
from escape.hydrogen_populations import hydrogen_nuclei_density
from escape.hydrogen_rates import planck_occupation
from escape.nlte_forward import HydrogenNLTEForwardModel, halpha_coefficients
from generate_spectra import load_observations
from verify_nlte_spectrum import NIST_ROW

jax.config.update('jax_enable_x64', True)
OUT = Path('/tmp/exojax-escape-nlte-spectrum/results/nlte_assumptions')
OUT.mkdir(parents=True, exist_ok=True)
TIDE = 3*(2*np.pi/(1.48*86400))**2


def temperature_law(radius_cm, parameters):
    top, cooling = parameters
    r = radius_cm/PLANET_RADIUS_CM
    rise = 1-jnp.exp(-(r-1)/.12)
    # A smooth, bounded diagnostic turnover, not a solved energy equation.
    turnover = (1-cooling)+cooling*jax.nn.sigmoid((1.8-r)/.25)
    return 6000+(top-6000)*rise*turnover


class SensitivityModel(HydrogenNLTEForwardModel):
    def __init__(self, *, cooling=False, **kwargs):
        self.cooling = float(cooling)
        super().__init__(**kwargs)

    def temperature_profile(self, temperature_top_k=None):
        top = self.temperature_top_k if temperature_top_k is None else temperature_top_k
        return temperature_law(self.radius_rp*PLANET_RADIUS_CM,(top,self.cooling))

    def _wind_temperature_law(self, temperature_top_k):
        top = self.temperature_top_k if temperature_top_k is None else temperature_top_k
        return temperature_law,(top,self.cooling)


def construct(cooling, **overrides):
    grid = dict(nlayer=128,nlon=12,nlat=6,nnu=601,tidal_coefficient_s2=TIDE)
    grid.update(overrides)
    with patch('exojax.database.nist.api.fetch_nist_lines',
               lambda *a,**kw:(pd.DataFrame(NIST_ROW),[])):
        return SensitivityModel(cooling=cooling,**grid)


@partial(jax.jit,static_argnums=0)
def calculate(model,mass,top,halpha_factor):
    temperature = model.temperature_profile(top)
    velocity = model.radial_velocity(mean_molecular_weight=.5,temperature_top_k=top)
    density = hydrogen_nuclei_density(model.radius_rp*PLANET_RADIUS_CM,velocity,mass)
    atom = model.atom
    eta = planck_occupation(atom.line_frequency_hz,10000.,.025)
    halpha = (atom.principal_n[atom.line_upper]==3)&(atom.principal_n[atom.line_lower]==2)
    eta = eta*jnp.where(halpha,halpha_factor,1.)
    continuum = planck_occupation(model.continuum_frequency_hz,10000.,.025)
    solution = jax.vmap(lambda n,t:solve_atom_populations(
        n,atom,t,eta,continuum,model.continuum_frequency_hz,model.continuum_weight_hz,
    ))(density,temperature)
    alpha,emission = halpha_coefficients(solution.bound_cm3,model.line_center_cm,sum_branches=False)
    spectrum = model._transfer_line_coefficients(alpha,emission,velocity,0.,0.,temperature)
    center_profiles = jax.vmap(model._line_profiles)(temperature,jnp.zeros_like(velocity))[:,:,300]
    source = jnp.sum(emission*center_profiles,axis=1)/jnp.sum(alpha*center_profiles,axis=1)
    return dict(spectrum=spectrum,temperature_k=temperature,radial_velocity_kms=velocity,
                n_h_cm3=density,bound_cm3=solution.bound_cm3,source=source,
                converged=solution.converged,rate_residual_norm=solution.rate_residual_norm)


models = {False:construct(False),True:construct(True)}
velocity = np.asarray(models[False].velocity_kms)
obs_v,observed,error = load_observations(models[False].line_center_cm)
records,arrays = {},{}
settings = [('prescribed BB',False,1.),('H-alpha pumping x0.3',False,.3),
            ('H-alpha pumping x0.1',False,.1),('Prescribed cooling',True,1.),
            ('Cooling + pumping x0.3',True,.3)]
for atmosphere,mass,top in [('manual',1e15,14000.),('moderate',1e14,10000.)]:
    for label,cooling,factor in settings:
        model = models[cooling]
        result = calculate(model,mass,top,factor)
        spectrum = np.asarray(result['spectrum'])
        valid = bool(np.all(result['converged']) and np.isfinite(spectrum).all())
        key = atmosphere+' / '+label
        record = dict(mass_loss_g_s=mass,temperature_parameter_k=top,cooling=cooling,
                      halpha_pumping_factor=factor,valid=valid)
        if valid:
            prediction = np.interp(obs_v,velocity[::-1],spectrum[::-1])
            offset = float(np.average(observed-prediction,weights=error**-2))
            peaks,_ = find_peaks(spectrum[::-1],prominence=np.ptp(spectrum)*.005)
            peaks = peaks[np.abs(velocity[::-1][peaks])<80]
            record.update(baseline=offset,rms=float(np.sqrt(np.mean(((prediction+offset-observed)/error)**2))),
                          peaks=[dict(velocity_kms=float(velocity[::-1][i]),
                                      contrast=float(spectrum[::-1][i])) for i in peaks],
                          center_ppm_after_baseline=float(1e6*(spectrum[300]+offset)),
                          max_rate_residual=float(np.max(result['rate_residual_norm'])),
                          temperature_range_k=[float(result['temperature_k'].min()),float(result['temperature_k'].max())])
            if len(peaks)==2:
                record['red_minus_blue_ppm'] = float(1e6*np.diff(spectrum[::-1][peaks])[0])
            if not cooling and factor==1:
                # Verify the custom diagnostic path reproduces the public path.
                reference = np.asarray(model.spectrum(mass_loss_g_s=mass,temperature_top_k=top))
                np.testing.assert_allclose(spectrum,reference,rtol=1e-12,atol=1e-15)
                record['public_path_max_difference'] = float(np.max(np.abs(spectrum-reference)))
        records[key] = record
        for item,value in result.items():
            arrays[key+' / '+item] = np.asarray(value)
        print(json.dumps({key:record}),flush=True)
        (OUT/'sensitivity.json').write_text(json.dumps(records,indent=2)+'\n')
        np.savez(OUT/'sensitivity.npz',velocity=velocity,radius_rp=np.asarray(model.radius_rp),**arrays)

fig,axes = plt.subplots(2,3,figsize=(14,8),constrained_layout=True)
colors = ['.4','C0','C2','C1','C3']
for row,atmosphere in enumerate(['manual','moderate']):
    axes[row,0].errorbar(obs_v,100*observed,yerr=100*error,fmt='.',color='.7',ms=2,label='Zenodo data')
    for (label,cooling,factor),color in zip(settings,colors):
        key = atmosphere+' / '+label
        if not records[key]['valid']:
            continue
        axes[row,0].plot(velocity,100*(arrays[key+' / spectrum']+records[key]['baseline']),color=color,label=label)
        axes[row,1].plot(model.radius_rp,arrays[key+' / source']/1e6,color=color,label=label)
        if factor==1:
            axes[row,2].plot(model.radius_rp,arrays[key+' / temperature_k'],color=color,label=label)
    mass,top = (1e15,14000) if row==0 else (1e14,10000)
    axes[row,0].set(title=f'Mass loss {mass:.0e} g/s; T scale {top} K',ylabel='Residual [%]',xlim=(-100,100))
    axes[row,1].set(title='Line-center source function',ylabel='Source / 1e6 [cgs per wavenumber]',xlim=(1,3))
    axes[row,2].set(title='Prescribed gas temperature',ylabel='Temperature [K]',xlim=(1,3))
    axes[row,0].legend(fontsize=7)
    axes[row,2].legend(fontsize=7)
for ax in axes[:,0]: ax.set_xlabel('Planet-frame velocity [km/s]')
for ax in axes[:,1:].flat: ax.set_xlabel('Radius / Rp')
fig.suptitle('Temperature and radiation sensitivity: all winds, densities and populations recomputed')
fig.supxlabel('H-alpha depression and cooling are diagnostic assumptions, not measured fields or thermal equilibrium. Constant offsets fitted only.\nData: Y. Zhang (2026), doi:10.5281/zenodo.20707255, CC BY 4.0; observation processing omitted.',fontsize=8)
fig.savefig(OUT/'temperature_radiation.png',dpi=150)
plt.close(fig)
