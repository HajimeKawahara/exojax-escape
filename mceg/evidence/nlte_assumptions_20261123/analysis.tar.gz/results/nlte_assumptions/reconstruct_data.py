"""Audit plausible published-data averaging operators; no exact reproduction claim."""
from pathlib import Path
import json
import h5py
import numpy as np

ROOT = Path('/tmp/escape-observation-processing')
C = 299792.458
CENTER = 1e8/15233.146
observed = np.loadtxt('/tmp/exojax-escape-nlte-spectrum/data/zenodo_20707255/KELT9b_w6565_avg_p0.30-0.45.dat')
wave_obs, flux_obs, sigma_obs = observed.T
exposures=[]
for path in sorted(ROOT.glob('*.h5')):
    with h5py.File(path) as h:
        phase, wave, flux, err, bary = [h[key][:] for key in ['phase','wave','flux','err','baryrv']]
    for i,p in enumerate(phase):
        if .3 <= p <= .45:
            for order in range(2):
                exposures.append((p, wave[order], flux[i,order], err[i,order], bary[i], order, path.name))

def reconstruct(zero=0.,bary_sign=0,ivar=True,mask=True,bin_points=1):
    lo=np.r_[wave_obs[0]-(wave_obs[1]-wave_obs[0])/2,(wave_obs[:-1]+wave_obs[1:])/2]
    hi=np.r_[(wave_obs[:-1]+wave_obs[1:])/2,wave_obs[-1]+(wave_obs[-1]-wave_obs[-2])/2]
    nodes=(np.arange(bin_points)+.5)/bin_points
    wavelengths=lo[:,None]+(hi-lo)[:,None]*nodes
    total=np.zeros_like(wavelengths); weights=np.zeros_like(wavelengths)
    for p,w,f,e,b,o,n in exposures:
        vp=244.8*np.sin(2*np.pi*p)+zero+bary_sign*b
        target=wavelengths*(1+vp/C)
        prediction=np.interp(target,w,f,left=np.nan,right=np.nan)
        noise=np.interp(target,w,e,left=np.nan,right=np.nan)
        valid=np.isfinite(prediction)&np.isfinite(noise)&(noise>0)
        if mask: valid &= np.abs(C*(target/CENTER-1))>=110
        weight=np.where(valid,1/noise**2 if ivar else 1.,0.)
        total+=np.where(valid,weight*prediction,0.)
        weights+=weight
    result=np.mean(total/weights,axis=1)
    return result

report=[]; arrays={}
for mask in [False,True]:
    for ivar in [False,True]:
        for bary in [-1,0,1]:
            for bins in [1,5]:
                f=reconstruct(bary_sign=bary,ivar=ivar,mask=mask,bin_points=bins)
                record=dict(mask=mask,ivar=ivar,bary_sign=bary,bin_points=bins,
                            rms_difference_over_sigma=float(np.sqrt(np.mean(((f-flux_obs)/sigma_obs)**2))),
                            rms_difference_ppm=float(1e6*np.sqrt(np.mean((f-flux_obs)**2))))
                report.append(record)
                arrays[f'm{int(mask)}_w{int(ivar)}_b{bary}_n{bins}']=f
best=min(report,key=lambda x:x['rms_difference_over_sigma'])
(ROOT/'data_reconstruction.json').write_text(json.dumps(dict(note='Plausible operators only; not recovered original reduction code.',trials=report,best=best),indent=2)+'\n')
np.savez(ROOT/'data_reconstruction.npz',wave=wave_obs,observed=flux_obs,error=sigma_obs,**arrays)
print(json.dumps(sorted(report,key=lambda x:x['rms_difference_over_sigma'])[:10],indent=2))
