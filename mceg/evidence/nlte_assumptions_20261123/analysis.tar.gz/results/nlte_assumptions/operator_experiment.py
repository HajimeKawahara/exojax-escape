"""Partial observation operator using the archived cadence, errors and mask.

This intentionally omits nightly-master division and continuum normalization.
Inverse-variance coaddition is an explicit approximation, not a recovered
author pipeline. The HDF5 wavelength frame follows the paper's stellar-frame
description; no additional barycentric correction is applied.
"""
from pathlib import Path
from unittest.mock import patch
import hashlib
import json

import h5py
import jax
import jax.numpy as jnp
import matplotlib
import numpy as np
import pandas as pd
from scipy.signal import find_peaks

matplotlib.use('Agg')
import matplotlib.pyplot as plt

from escape.hydrogen_forward import SYNCHRONOUS_ROTATION_KMS
from escape.nlte_forward import HydrogenNLTEForwardModel
from generate_spectra import load_observations
from verify_nlte_spectrum import NIST_ROW

jax.config.update('jax_enable_x64', True)
ROOT=Path('/tmp/exojax-escape-nlte-spectrum')
OUT=ROOT/'results/nlte_assumptions'
DATA=Path('/tmp/escape-observation-processing')
C=299792.458
MODEL_PHASES=np.array([.30,.375,.45])
TIDE=3*(2*np.pi/(1.48*86400))**2

def construct(phase):
    with patch('exojax.database.nist.api.fetch_nist_lines',
               lambda *a, **kw:(pd.DataFrame(NIST_ROW), [])):
        return HydrogenNLTEForwardModel(phase=phase,nlayer=128,nlon=12,nlat=6,nnu=601,
                                       tidal_coefficient_s2=TIDE)

models=[construct(float(phase)) for phase in MODEL_PHASES]
model=models[1]
velocity=np.asarray(model.velocity_kms)
wave=1e8/model.line_center_cm*(1+velocity/C)
center=1e8/model.line_center_cm
obs_v,observed,error=load_observations(model.line_center_cm)
phases=[]; night_index=[]; weights=[]; masks=[]; file_records=[]
for n,path in enumerate(sorted(DATA.glob('*.h5'))):
    with h5py.File(path) as h:
        phase=h['phase'][:]; wav=h['wave'][:]; err=h['err'][:]; flux=h['flux'][:]
    file_records.append(dict(file=path.name,md5=hashlib.md5(path.read_bytes()).hexdigest(),
                             sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                             exposures=len(phase),phase_range=[float(phase.min()),float(phase.max())]))
    for i,p in enumerate(phase):
        if not .30<=p<=.45:
            continue
        vp=244.8*np.sin(2*np.pi*p)
        # First-order velocity sum, consistent with the stated mask approximation.
        stellar_wave=center*(1+(velocity+vp)/C)
        w=np.zeros_like(velocity)
        for order in range(2):
            sigma=np.interp(stellar_wave,wav[order],err[i,order],left=np.nan,right=np.nan)
            values=np.interp(stellar_wave,wav[order],flux[i,order],left=np.nan,right=np.nan)
            valid=np.isfinite(sigma)&(sigma>0)&np.isfinite(values)
            w+=np.where(valid,1/sigma**2,0.)
        phases.append(p); night_index.append(n); weights.append(w)
        masks.append(np.abs(velocity+vp)>=110)
phases=np.asarray(phases); weights=np.asarray(weights); masks=np.asarray(masks)
masked=weights*masks
basis=np.column_stack([np.interp(phases,MODEL_PHASES,np.eye(3)[i]) for i in range(3)])

def phase_weights(w):
    if np.any(w.sum(axis=0)<=0):
        raise RuntimeError('No retained exposure at one or more plotted pixels.')
    return (basis.T@w)/w.sum(axis=0)

phase_mix={'unmasked':phase_weights(weights),'masked':phase_weights(masked)}
mean_phase={name:phases@w/w.sum(axis=0) for name,w in [('unmasked',weights),('masked',masked)]}
np.testing.assert_allclose(basis.sum(axis=1),1.,atol=1e-14)
for matrix in phase_mix.values():
    np.testing.assert_allclose(matrix.sum(axis=0),1.,atol=1e-14)

def peak_metrics(f):
    v,s=velocity[::-1],f[::-1]
    indices,_=find_peaks(s,prominence=max(np.ptp(s)*.005,1e-12))
    indices=indices[np.abs(v[indices])<80]
    result=dict(count=int(len(indices)),peaks=[dict(velocity_kms=float(v[i]),contrast=float(s[i])) for i in indices])
    if len(indices)==2:
        result['red_minus_blue_ppm']=float(1e6*(s[indices[1]]-s[indices[0]]))
    return result

def scaled_difference(f,g):
    difference=np.interp(obs_v,velocity[::-1],(f-g)[::-1])/error
    return dict(maximum=float(np.max(np.abs(difference))),rms=float(np.sqrt(np.mean(difference**2))))

report=dict(scope=__doc__,phases=MODEL_PHASES.tolist(),files=file_records,
            selected_exposures=len(phases),temperature_base_k=6000.,wind_mu=.5,
            radiation_dilution=.025,tidal_coefficient_s2=TIDE,
            rotation_kms=float(SYNCHRONOUS_ROTATION_KMS),zonal_kms=11.6,
            grid=dict(layers=128,longitude=12,latitude=6,wavelength=601,nmax=15),
            coadd_assumption='Inverse supplied variance, sum over both orders, pixelwise normalization after masking.',
            model_phase_interpolation='Piecewise linear in phase; no additional orbital shift to planet-frame spectral predictions.',
            phase_samples=[],cases={},
            normalization_max_error={k:float(np.max(np.abs(a.sum(axis=0)-1))) for k,a in phase_mix.items()})
for sample in [-30.,0.,30.]:
    j=np.argmin(abs(velocity-sample))
    report['phase_samples'].append(dict(velocity_kms=float(velocity[j]),
        masked_exposure_count=int(np.count_nonzero(masked[:,j])),
        unmasked_exposure_count=int(np.count_nonzero(weights[:,j])),
        masked_mean_phase=float(mean_phase['masked'][j]),
        unmasked_mean_phase=float(mean_phase['unmasked'][j]),
        normalized_anchor_weights={k:a[:,j].tolist() for k,a in phase_mix.items()}))

arrays=dict(velocity=velocity,phase=phases,night=np.asarray(night_index),
            masked_mean_phase=mean_phase['masked'],unmasked_mean_phase=mean_phase['unmasked'],
            masked_exposure_count=np.count_nonzero(masked,axis=0),
            masked_phase_weights=phase_mix['masked'],unmasked_phase_weights=phase_mix['unmasked'])
for name,top,mass in [('manual',14000.,1e15),('previous_fit',6105.231332735623,209185986389574.34)]:
    p=model.population_profiles(temperature_top_k=top,mass_loss_g_s=mass)
    predictions=[]
    for local in models:
        transfer=jax.jit(lambda a,e,v,t:local._transfer_line_coefficients(
            a,e,v,SYNCHRONOUS_ROTATION_KMS,11.6,t))
        predictions.append(np.asarray(transfer(p['halpha_branch_extinction_integral'],
            p['halpha_branch_emissivity_integral'],p['radial_velocity_kms'],p['temperature_k'])))
    predictions=np.asarray(predictions)
    if not np.isfinite(predictions).all() or not np.all(p['converged']):
        raise RuntimeError('Invalid spectrum or local atom solve.')
    curves={'central_phase':predictions[1],**{k:np.sum(a*predictions,axis=0) for k,a in phase_mix.items()}}
    record=dict(temperature_top_k=top,mass_loss_g_s=mass,
                max_scaled_rate_residual=float(np.max(p['rate_residual_norm'])),
                masks_change_over_supplied_error=scaled_difference(curves['masked'],curves['unmasked']),
                cadence_change_over_supplied_error=scaled_difference(curves['unmasked'],curves['central_phase']),
                total_change_over_supplied_error=scaled_difference(curves['masked'],curves['central_phase']),
                spectra={})
    for key,f in curves.items():
        sampled=np.interp(obs_v,velocity[::-1],f[::-1])
        offset=np.average(observed-sampled,weights=error**-2)
        record['spectra'][key]=dict(peaks=peak_metrics(f),overlay_constant=float(offset),
             rms_residual_over_supplied_error=float(np.sqrt(np.mean(((sampled+offset-observed)/error)**2))))
        arrays[name+'_'+key]=f
    arrays[name+'_phase_predictions']=predictions
    report['cases'][name]=record
    print(json.dumps({name:record}),flush=True)
    (OUT/'operator_metrics.json').write_text(json.dumps(report,indent=2)+'\n')

report['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
(OUT/'operator_metrics.json').write_text(json.dumps(report,indent=2)+'\n')
np.savez(OUT/'operator_arrays.npz',**arrays)
fig,axes=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
styles={'central_phase':('Phase 0.375','0.45',':'),
        'unmasked':('Actual cadence, no stellar mask','C0','--'),
        'masked':('Actual cadence + stellar mask','C3','-')}
for ax,(name,title) in zip(axes[0],[('manual','Manual asymmetric atmosphere'),('previous_fit','Previous gradient-fit atmosphere')]):
    ax.errorbar(obs_v,100*observed,yerr=100*error,fmt='.',ms=2.5,color='.65',label='Zenodo data')
    for key,(label,color,style) in styles.items():
        offset=report['cases'][name]['spectra'][key]['overlay_constant']
        ax.plot(velocity,100*(arrays[name+'_'+key]+offset),color=color,ls=style,label=label)
    ax.set(title=title,xlabel='Planet-frame velocity [km/s]',ylabel='Line residual [%]',xlim=(-100,100))
    ax.legend(fontsize=7)
axes[1,0].plot(velocity,mean_phase['unmasked'],'C0--',label='No stellar mask')
axes[1,0].plot(velocity,mean_phase['masked'],'C3-',label='Stellar mask included')
axes[1,0].set(title='Blue and red pixels sample different phases',xlabel='Planet-frame velocity [km/s]',
              ylabel='Weighted mean orbital phase',xlim=(-100,100))
axes[1,0].legend(fontsize=8)
for name,label,color in [('manual','Manual atmosphere','C1'),('previous_fit','Previous fit','C2')]:
    axes[1,1].plot(velocity,1e6*(arrays[name+'_masked']-arrays[name+'_central_phase']),color=color,label=label)
axes[1,1].axhline(0,color='.5',lw=.7)
axes[1,1].set(title='Change before fitting a constant offset',xlabel='Planet-frame velocity [km/s]',
              ylabel='Masked average minus phase 0.375 [ppm]',xlim=(-100,100))
axes[1,1].legend(fontsize=8)
fig.suptitle('Partial observation operator: cadence and stellar mask\nNightly-master division and continuum normalization are still omitted\nTop panels: a separate constant offset is fitted to every curve',fontsize=12)
fig.supxlabel('Data: Y. Zhang (2026), doi:10.5281/zenodo.20707255, CC BY 4.0. Inverse-variance weights are assumed; the original coadd is not reproduced.',fontsize=8)
fig.savefig(OUT/'operator_comparison.png',dpi=160,bbox_inches='tight')
plt.close(fig)
print(json.dumps({k:report[k] for k in ['selected_exposures','phase_samples','normalization_max_error']},indent=2),flush=True)
