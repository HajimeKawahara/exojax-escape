"""Check two new prescribed cooling cases, without fitting their spectra."""
from pathlib import Path
import json
import numpy as np

# Load the explicitly retained research definitions, not its execution section.
source = Path('/tmp/nlte-assumption-sensitivity.py').read_text()
namespace = {}
exec(compile(source.split('\nmodels =')[0],'/tmp/nlte-assumption-sensitivity.py','exec'),namespace)
construct,calculate = namespace['construct'],namespace['calculate']
jax,jnp = namespace['jax'],namespace['jnp']
temperature_law = namespace['temperature_law']
OUT = namespace['OUT']
from escape.hydrogen_forward import PLANET_RADIUS_CM,PLANET_MASS_MJ
from escape.parker import G,MJ,PROTON_MASS_CGS,kB
from verify_nlte_spectrum import uncertainty_scaled_difference
from generate_spectra import load_observations

stored = np.load(OUT/'sensitivity.npz')
fine = construct(True,nlayer=256,nmax=20,wind_ngrid=257)
obs_v,_,sigma = load_observations(fine.line_center_cm)
report = {'scope':'Only joint layer/atom/wind refinement at two new cooling/pumping points; not all axes or a prior-domain guarantee.','cases':{}}
for label,mass,top in [('manual',1e15,14000.),('moderate',1e14,10000.)]:
    key = label+' / Cooling + pumping x0.3'
    result = calculate(fine,mass,top,.3)
    refined = np.asarray(result['spectrum'])
    coarse = stored[key+' / spectrum']
    record = uncertainty_scaled_difference(
        np.interp(obs_v,stored['velocity'][::-1],coarse[::-1]),
        np.interp(obs_v,np.asarray(fine.velocity_kms)[::-1],refined[::-1]),sigma)
    # Check the prescribed wind numerator for one simple zero over 1..32 Rp.
    r = jnp.geomspace(PLANET_RADIUS_CM,32*PLANET_RADIUS_CM,8193)
    sound = lambda rr:kB*temperature_law(rr,(top,1.))/(.5*PROTON_MASS_CGS)
    derivative = jax.vmap(jax.grad(sound))(r)
    numerator = np.asarray(2*sound(r)/r-derivative-G*MJ*PLANET_MASS_MJ/r**2+namespace['TIDE']*r)
    changes = np.where(numerator[:-1]*numerator[1:]<0)[0]
    record.update(sampled_sonic_numerator_crossings=int(len(changes)),
                  temperature_min_to_32rp_k=float(temperature_law(r,(top,1.)).min()),
                  all_local_solves_converged=bool(np.all(result['converged'])),
                  max_rate_residual=float(np.max(result['rate_residual_norm'])))
    report['cases'][label]=record
    print(json.dumps({label:record}),flush=True)
(OUT/'sensitivity_refinement.json').write_text(json.dumps(report,indent=2)+'\n')
if not all(x['passed'] and x['all_local_solves_converged'] and x['sampled_sonic_numerator_crossings']==1 for x in report['cases'].values()):
    raise RuntimeError('A selected cooling refinement or sonic-topology check failed.')
