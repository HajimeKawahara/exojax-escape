"""Check selected exploratory fits, and compare their spectra with the data."""
from pathlib import Path
from unittest.mock import patch
import hashlib
import json

import jax
import jax.numpy as jnp
import matplotlib
import numpy as np
import pandas as pd

matplotlib.use('Agg')
import matplotlib.pyplot as plt

from escape.nlte_forward import HydrogenNLTEForwardModel
from escape.hydrogen_forward import SYNCHRONOUS_ROTATION_KMS
from generate_spectra import load_observations
from verify_nlte_spectrum import NIST_ROW, uncertainty_scaled_difference

jax.config.update('jax_enable_x64', True)
OUT = Path('/tmp/exojax-escape-nlte-spectrum/results/nlte_asymmetry')
TIDE = 3 * (2 * np.pi / (1.48 * 86400)) ** 2
fits = json.loads((OUT/'fits.json').read_text())
if len(fits) != 6:
    raise RuntimeError('Wait for all six fits; do not present an incomplete campaign.')
manual = json.loads((OUT/'candidate_metrics.json').read_text())
saved = np.load(OUT/'candidate_arrays.npz')

def construct(**overrides):
    grid = dict(nlayer=128, nlon=12, nlat=6, nnu=601, tidal_coefficient_s2=TIDE)
    grid.update(overrides)
    with patch('exojax.database.nist.api.fetch_nist_lines',
               lambda *a, **kw: (pd.DataFrame(NIST_ROW), [])):
        return HydrogenNLTEForwardModel(**grid)

model = construct()
obs_v, observed, error = map(jnp.asarray, load_observations(model.line_center_cm))

def inputs(p, horizontal):
    return dict(mass_loss_g_s=1e13*jnp.exp(p[0]), temperature_top_k=1e4*p[1],
                rotation_kms=horizontal*SYNCHRONOUS_ROTATION_KMS,
                zonal_kms=horizontal*11.6)

@jax.jit
def residual(p, horizontal):
    signal = model.spectrum(**inputs(p, horizontal))
    pred = jnp.interp(obs_v, model.velocity_kms[::-1], signal[::-1])
    baseline = jnp.sum((observed-pred)/error**2)/jnp.sum(1/error**2)
    return (pred+baseline-observed)/error

jacobian = jax.jit(jax.jacfwd(residual, argnums=0))
summary = dict(
    scope='Exploratory local least squares; fixed fields, single phase, no observational processing or posterior validation.',
    mass_bounds_g_s=[1e11,1e15], top_temperature_bounds_k=[6000,14000],
    baseline='One constant profiled analytically at every evaluation; no slope, amplitude factor or fitted wavelength shift.',
    parameters=['ln(Mdot/1e13)', 'Ttop/1e4'],
    fixed=dict(tidal_coefficient_s2=TIDE, wind_mu=.5, dilution=.025,
               radiation_temperature_k=10000, temperature_base_k=6000, phase=.375,
               nmax=15, layers=128, nlon=12, nlat=6, nnu=601,
               rotation_if_enabled_kms=float(SYNCHRONOUS_ROTATION_KMS),
               zonal_if_enabled_kms=11.6),
    selections={},
)
spectra, profiles, parameters = {}, {}, {}
for horizontal in [0., 1.]:
    name = 'radial_only' if horizontal == 0 else 'fixed_horizontal'
    successful = [x for x in fits if x['horizontal'] == horizontal and x['success']]
    if not successful:
        raise RuntimeError(f'No successfully terminated fit: {name}')
    best = min(successful, key=lambda x:x['rms'])
    p = np.asarray(best['coordinates'])
    kw = inputs(p,horizontal)
    parameters[name] = kw
    spectra[name] = np.asarray(model.spectrum(**kw))
    if not np.isfinite(spectra[name]).all():
        raise RuntimeError(f'Nonfinite selected spectrum: {name}')
    checked_rms = float(np.sqrt(np.mean(np.asarray(residual(p,horizontal))**2)))
    np.testing.assert_allclose(checked_rms,best['rms'],rtol=1e-10,atol=1e-12)
    profiles[name] = model.population_profiles(mass_loss_g_s=kw['mass_loss_g_s'],
                                             temperature_top_k=kw['temperature_top_k'])
    automatic = np.asarray(jacobian(p,horizontal))
    step = 1e-4
    finite = np.column_stack([(np.asarray(residual(p+step*d,horizontal))
                              -np.asarray(residual(p-step*d,horizontal)))/(2*step)
                             for d in np.eye(2)])
    allowed = 1e-8+3e-3*np.maximum(np.abs(automatic),np.abs(finite))
    record = dict(best=best, gradient={
        'method':'JAX forward-mode AD versus centered finite differences, including the profiled baseline',
        'scope':'Centered differences can cross a search bound but stay within the atomic-data temperature domain; they test the model derivative, not a constrained minimum.',
        'step_in_coordinates':step,'rtol':.003,'atol':1e-8,
        'finite':bool(np.isfinite(automatic).all() and np.isfinite(finite).all()),
        'passed':bool(np.all(np.abs(automatic-finite)<=allowed)),
        'max_error_over_tolerance':float(np.max(np.abs(automatic-finite)/allowed)),
    }, all_populations_converged=bool(np.all(profiles[name]['converged'])),
        max_scaled_rate_residual=float(np.max(profiles[name]['rate_residual_norm'])))
    summary['selections'][name] = record
    (OUT/'fit_checks.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({name:record}),flush=True)

fine = construct(nlayer=256)
for name, kw in parameters.items():
    finer = np.asarray(fine.spectrum(**kw))
    coarse_obs = np.interp(obs_v, np.asarray(model.velocity_kms)[::-1], spectra[name][::-1])
    fine_obs = np.interp(obs_v, np.asarray(fine.velocity_kms)[::-1], finer[::-1])
    check = uncertainty_scaled_difference(coarse_obs, fine_obs, error)
    summary['selections'][name]['layer_refinement'] = check
    print(json.dumps({name:check}),flush=True)

velocity = np.asarray(model.velocity_kms)
for name in spectra:
    # Detect local maxima rather than selecting extrema in arbitrary half-windows.
    from scipy.signal import find_peaks
    f = spectra[name][::-1]
    v = velocity[::-1]
    peaks, _ = find_peaks(f, prominence=max(np.ptp(f)*.005,1e-12))
    peaks = peaks[np.abs(v[peaks])<80]
    record = summary['selections'][name]
    record['peaks'] = [dict(velocity_kms=float(v[i]), contrast=float(f[i])) for i in peaks]
    if len(peaks)==2:
        record['red_minus_blue_ppm'] = float(1e6*(f[peaks[1]]-f[peaks[0]]))
summary['source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
(OUT/'fit_checks.json').write_text(json.dumps(summary,indent=2)+'\n')
np.savez(OUT/'fit_spectra.npz',velocity=velocity,**spectra)

fig, axes = plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
ax = axes[0,0]
ax.errorbar(obs_v,100*observed,yerr=100*error,fmt='.',ms=3,color='.55',alpha=.8,label='Zenodo data')
for name, label, color, style in [
    ('baseline','Original example','0.5',':'),
    ('manual','Manual: 14000 K, 1e15 g/s','C1','--')]:
    offset = manual['cases'][name]['constant_baseline']
    ax.plot(velocity,100*(saved[name+'_actual']+offset),color=color,ls=style,label=label)
for name,label,color in [('radial_only','Gradient fit: radial flow','C0'),
                         ('fixed_horizontal','Gradient fit: + fixed horizontal flow','C3')]:
    offset = summary['selections'][name]['best']['baseline']
    ax.plot(velocity,100*(spectra[name]+offset),color=color,label=label)
    pred = np.interp(obs_v,velocity[::-1],spectra[name][::-1])+offset
    axes[1,0].plot(obs_v,(pred-observed)/error,'.-',ms=3,color=color,label=label)
ax.set(title='A constant offset is fitted for every curve',ylabel='Line residual [%]',xlim=(-100,100))
ax.legend(fontsize=7)
axes[1,0].axhspan(-1,1,color='.9')
axes[1,0].axhline(0,color='.5',lw=.7)
axes[1,0].set(xlabel='Velocity from H-alpha rest center [km/s]',ylabel='Residual / supplied uncertainty',xlim=(-100,100))
for name,label,color,style in [('baseline','Original example','.5',':'),('manual','Manual candidate','C1','--')]:
    radius = saved[name+'_radius_rp']
    axes[0,1].plot(radius,saved[name+'_temperature_k'],color=color,ls=style,label=label)
    axes[1,1].plot(radius,saved[name+'_radial_velocity_kms'],color=color,ls=style,label=label)
for name,label,color in [('radial_only','Radial-only fit','C0'),('fixed_horizontal','Fit with horizontal flow','C3')]:
    axes[0,1].plot(model.radius_rp,profiles[name]['temperature_k'],color=color,label=label)
    axes[1,1].plot(model.radius_rp,profiles[name]['radial_velocity_kms'],color=color,label=label)
axes[0,1].set(title='Temperature remains prescribed',ylabel='Gas temperature [K]')
axes[0,1].legend(fontsize=8)
axes[1,1].set(xlabel='Radius / Rp',ylabel='Radial Parker speed [km/s]')
fig.suptitle('Exploration before NUTS: asymmetry is possible; the full line shape is still imperfect')
fig.supxlabel('Data: Y. Zhang (2026), doi:10.5281/zenodo.20707255, CC BY 4.0. Phase averaging and data processing are not modeled.',fontsize=8)
fig.savefig(OUT/'fit_comparison.png',dpi=160)
plt.close(fig)
print(json.dumps(summary,indent=2),flush=True)
