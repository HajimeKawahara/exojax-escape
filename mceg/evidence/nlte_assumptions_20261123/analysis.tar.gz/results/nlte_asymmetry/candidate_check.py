"""Isolate the observer velocity mechanism in a manually chosen atmosphere.

No physical validation or self-consistent static/inflow solution is implied by
the fixed-population Doppler controls. All products stay in results/.
"""

from pathlib import Path
from unittest.mock import patch
import hashlib
import json

import jax
import jax.numpy as jnp
import matplotlib
import numpy as np
import pandas as pd
from scipy.signal import find_peaks

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from escape.nlte_forward import HydrogenNLTEForwardModel
from generate_spectra import load_observations, OBSERVATION_PATH
from verify_nlte_spectrum import NIST_ROW, uncertainty_scaled_difference

jax.config.update("jax_enable_x64", True)
OUT = Path("/tmp/exojax-escape-nlte-spectrum/results/nlte_asymmetry")
OUT.mkdir(parents=True, exist_ok=True)
TIDE = 3 * (2 * np.pi / (1.48 * 86400)) ** 2


def construct(tide, **overrides):
    config = dict(nlayer=128, nlon=12, nlat=6, nnu=601,
                  tidal_coefficient_s2=tide)
    config.update(overrides)
    with patch("exojax.database.nist.api.fetch_nist_lines",
               lambda *a, **kw: (pd.DataFrame(NIST_ROW), [])):
        return HydrogenNLTEForwardModel(**config)


def peaks(velocity, spectrum):
    order = np.argsort(velocity)
    v, f = velocity[order], spectrum[order]
    index, props = find_peaks(f, prominence=max(np.ptp(f) * .005, 1e-12))
    keep = np.abs(v[index]) < 80
    index = index[keep]
    prominence = props["prominences"][keep]
    result = {"count": int(len(index)), "peaks": [
        dict(velocity_kms=float(v[i]), flux=float(f[i]), prominence=float(p))
        for i, p in zip(index, prominence)
    ], "double_peaked": False}
    if len(index) == 2 and index[1] - index[0] > 1:
        left, right = index
        trough = left + np.argmin(f[left:right+1])
        result.update(
            double_peaked=bool(left < trough < right),
            red_minus_blue_ppm=float(1e6 * (f[right] - f[left])),
            red_over_blue=float(f[right] / f[left]),
            trough_velocity_kms=float(v[trough]), trough_flux=float(f[trough]),
            peak_to_trough_ppm=[float(1e6 * (f[i] - f[trough])) for i in index],
        )
    return result


def formation(model, p, observer_radial):
    phi = jax.vmap(model._line_profiles)(p["temperature_k"], observer_radial)
    alpha = np.asarray(jnp.sum(p["halpha_branch_extinction_integral"][:, :, None] * phi, axis=1))
    emission = np.asarray(jnp.sum(p["halpha_branch_emissivity_integral"][:, :, None] * phi, axis=1))
    source = emission / alpha
    dtau = alpha * np.asarray(model.thickness_cm)[:, None]
    tau = np.cumsum(dtau, axis=0)
    rows = []
    for sample in [0., -30., 30., -25., 25.]:
        pixel = np.argmin(np.abs(np.asarray(model.velocity_kms) - sample))
        index = int(np.searchsorted(tau[:, pixel], 1.))
        row = {"sample_velocity_kms": float(model.velocity_kms[pixel]),
               "total_tau": float(tau[-1, pixel]), "reaches_tau_one": index < len(dtau)}
        if index < len(dtau):
            row.update(radius_rp=float(model.radius_rp[index]),
                       radial_velocity_kms=float(p["radial_velocity_kms"][index]),
                       source=float(source[index, pixel]),
                       temperature_k=float(p["temperature_k"][index]),
                       ionized_fraction=float(p["ionized_fraction"][index]))
        rows.append(row)
    return rows, source[:, np.argmin(np.abs(np.asarray(model.velocity_kms)))]


report = {
    "scope": "Manual existence demonstration and fixed-population Doppler controls, not an atmospheric validation or data fit.",
    "data_sha256": hashlib.sha256(OBSERVATION_PATH.read_bytes()).hexdigest(),
    "jax_version": jax.__version__, "jax_x64": True,
    "fixed": {"wind_mu": .5, "radiation_dilution": .025, "radiation_temperature_k": 10000.,
              "temperature_base_k": 6000., "rotation_kms": 0., "zonal_kms": 0., "phase": .375},
    "formation_scope": "Representative vertical ray; first layer midpoint with cumulative tau >= 1. Not a disk contribution function.",
    "cases": {}, "refinements": {},
}
arrays = {}
cases = {}
for name, tide, top, mass in [("baseline", 0., 10000., 1e13),
                               ("manual", TIDE, 14000., 1e15)]:
    model = construct(tide)
    kw = dict(temperature_top_k=top, mass_loss_g_s=mass)
    p = model.population_profiles(**kw)
    velocity = np.asarray(model.velocity_kms)

    @jax.jit
    def transfer(factor):
        return model._transfer_line_coefficients(
            p["halpha_branch_extinction_integral"], p["halpha_branch_emissivity_integral"],
            factor * p["radial_velocity_kms"], 0., 0., p["temperature_k"],
        )

    spectra = {key: np.asarray(transfer(factor)) for key, factor in
               [("actual", 1.), ("doppler_off", 0.), ("doppler_reversed", -1.)]}
    obs_v, observed, error = load_observations(model.line_center_cm)
    pred = np.interp(obs_v, velocity[::-1], spectra["actual"][::-1])
    baseline = np.average(observed - pred, weights=error**-2)
    rest_form, source = formation(model, p, jnp.zeros_like(p["radial_velocity_kms"]))
    moving_form, _ = formation(model, p, -p["radial_velocity_kms"])
    record = {
        "parameters": {"tidal_coefficient_s2": tide, **kw},
        "constant_baseline": float(baseline),
        "rms_residual_over_supplied_error": float(np.sqrt(np.mean(((pred+baseline-observed)/error)**2))),
        "peaks": {key: peaks(velocity, spectrum) for key, spectrum in spectra.items()},
        "all_local_solves_converged": bool(np.all(p["converged"])),
        "all_spectra_finite": bool(all(np.isfinite(f).all() for f in spectra.values())),
        "max_conservation_error": float(np.max(p["conservation_error"])),
        "max_scaled_rate_residual": float(np.max(p["rate_residual_norm"])),
        "radial_velocity_range_kms": [float(np.min(p["radial_velocity_kms"])), float(np.max(p["radial_velocity_kms"]))],
        "wind_mu": .5,
        "nlte_mu_range": [float(np.min(p["mean_molecular_weight_nlte"])), float(np.max(p["mean_molecular_weight_nlte"]))],
        "rest_vertical_tau_one": rest_form,
        "moving_vertical_tau_one": moving_form,
    }
    report["cases"][name] = record
    arrays.update({f"{name}_{key}": value for key, value in spectra.items()})
    for key in ["temperature_k", "radial_velocity_kms", "n_h_cm3", "n2_cm3", "n3_cm3",
                "ionized_fraction", "mean_molecular_weight_nlte"]:
        arrays[f"{name}_{key}"] = np.asarray(p[key])
    arrays[f"{name}_radius_rp"] = np.asarray(model.radius_rp)
    arrays[f"{name}_rest_center_source"] = source
    cases[name] = (model, p, spectra, baseline)
    print(json.dumps({name: record}), flush=True)
    (OUT / "candidate_metrics.json").write_text(json.dumps(report, indent=2)+"\n")
    np.savez(OUT / "candidate_arrays.npz", velocity=velocity, **arrays)

manual = cases["manual"][2]["actual"]
for name, overrides in [("layers_128_to_256", {"nlayer": 256}),
                         ("nmax_15_to_20", {"nmax": 20})]:
    fine = construct(TIDE, **overrides)
    candidate = np.asarray(fine.spectrum(temperature_top_k=14000., mass_loss_g_s=1e15))
    comparison = uncertainty_scaled_difference(
        np.interp(obs_v, velocity[::-1], manual[::-1]),
        np.interp(obs_v, velocity[::-1], candidate[::-1]), error,
    )
    comparison["peaks"] = peaks(velocity, candidate)
    report["refinements"][name] = comparison
    arrays[name] = candidate
    print(json.dumps({name: comparison}), flush=True)
    (OUT / "candidate_metrics.json").write_text(json.dumps(report, indent=2)+"\n")
    np.savez(OUT / "candidate_arrays.npz", velocity=velocity, **arrays)

fig, ax = plt.subplots(2, 3, figsize=(14, 8), constrained_layout=True)
ax[0, 0].errorbar(obs_v, 100*observed, yerr=100*error, fmt='.', color='.6',
                   markersize=3, label='Zenodo observation')
for name, color in [("baseline", "C0"), ("manual", "C3")]:
    model, p, spectra, baseline = cases[name]
    radius = np.asarray(model.radius_rp)
    ax[0, 0].plot(velocity, 100*(spectra['actual']+baseline), color=color,
                  label=name.capitalize()+' + constant baseline')
    ax[1, 0].plot(radius, p['temperature_k'], color=color, label=name.capitalize())
    ax[1, 1].plot(radius, p['radial_velocity_kms'], color=color, label=name.capitalize())
    ax[1, 2].semilogy(radius, p['n2_cm3'], color=color, label=name+' n2')
    ax[1, 2].semilogy(radius, p['n3_cm3'], color=color, ls='--', label=name+' n3')
for key, label, style in [('actual', 'Outflow', '-'), ('doppler_off', 'Doppler off', '--'),
                           ('doppler_reversed', 'Doppler reversed', ':')]:
    ax[0, 1].plot(velocity, 100*cases['manual'][2][key], style, label=label)
for name, color in [("baseline", "C0"), ("manual", "C3")]:
    ax[0, 2].plot(arrays[name+'_radius_rp'], arrays[name+'_rest_center_source'],
                  color=color, label=name.capitalize())
ax[0, 0].set(title='Qualitative comparison; not a fitted atmosphere',
               xlabel='Velocity [km/s]', ylabel='Residual / contrast [%]', xlim=(-100,100))
ax[0, 1].set(title='Same populations; change observer Doppler only',
               xlabel='Velocity [km/s]', ylabel='Intrinsic line contrast [%]', xlim=(-80,80))
ax[0, 2].set(title='Rest-center source function', xlabel='Radius / Rp',
               ylabel='Source [cgs per wavenumber]', xlim=(1,2))
ax[1, 0].set(title='Prescribed temperature', xlabel='Radius / Rp', ylabel='Temperature [K]')
ax[1, 1].set(title='Nonisothermal Parker flow', xlabel='Radius / Rp', ylabel='Radial speed [km/s]')
ax[1, 2].set(title='Solved NLTE populations', xlabel='Radius / Rp', ylabel='Population [cm$^{-3}$]')
for axis in ax.flat:
    axis.legend(fontsize=8)
fig.suptitle('Manual asymmetry check: tides, Ttop=14000 K, mass loss=1e15 g/s\n'
             'Baseline: no tides, Ttop=10000 K, mass loss=1e13 g/s; fixed wind mu=0.5')
fig.supxlabel('Data: Y. Zhang (2026), doi:10.5281/zenodo.20707255, CC BY 4.0. '
               'Phase averaging and data processing are not modeled.', fontsize=9)
fig.savefig(OUT / 'candidate_diagnostics.png', dpi=150)
plt.close(fig)
