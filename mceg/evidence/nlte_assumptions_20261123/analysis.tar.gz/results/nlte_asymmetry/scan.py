"""Recompute Parker densities and local NLTE for a small physical scan."""
from pathlib import Path
from unittest.mock import patch
import json
import time
import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd
from scipy.signal import find_peaks
from escape.nlte_forward import HydrogenNLTEForwardModel
from generate_spectra import load_observations
from verify_nlte_spectrum import NIST_ROW

jax.config.update('jax_enable_x64', True)
out = Path('/tmp/exojax-escape-nlte-spectrum/results/nlte_asymmetry')
out.mkdir(parents=True, exist_ok=True)
tidal = 3 * (2 * np.pi / (1.48 * 86400)) ** 2
records = []
arrays = {}
for tide_name, tide in [('no_tides', 0.), ('tides', tidal)]:
    with patch('exojax.database.nist.api.fetch_nist_lines',
               lambda *a, **kw: (pd.DataFrame(NIST_ROW), [])):
        model = HydrogenNLTEForwardModel(nlayer=128, nlon=12, nlat=6, nnu=601,
                                        tidal_coefficient_s2=tide)
    velocity = np.asarray(model.velocity_kms)
    obs_v, observed, error = load_observations(model.line_center_cm)
    for temperature in [8000., 10000., 12000., 14000.]:
        for mass in [1e12, 1e13, 1e14, 1e15]:
            t0 = time.monotonic()
            kw = dict(temperature_top_k=temperature, mass_loss_g_s=mass)
            profiles = model.population_profiles(**kw)
            spectrum = np.asarray(model.spectrum(**kw))
            prediction = np.interp(obs_v, velocity[::-1], spectrum[::-1])
            baseline = np.average(observed-prediction, weights=1/error**2)
            indices, _ = find_peaks(spectrum, prominence=max(spectrum.max()*0.005, 1e-12))
            indices = indices[np.abs(velocity[indices]) < 80]
            peaks = sorted([(float(velocity[i]), float(spectrum[i])) for i in indices])
            record = dict(tides=tide_name, temperature_top_k=temperature,
                          mass_loss_g_s=mass, baseline=float(baseline),
                          residual_rms=float(np.sqrt(np.mean(((prediction+baseline-observed)/error)**2))),
                          peaks=peaks, radial_min=float(profiles['radial_velocity_kms'].min()),
                          radial_max=float(profiles['radial_velocity_kms'].max()),
                          ionization_min=float(profiles['ionized_fraction'].min()),
                          valid=bool(np.all(profiles['converged']) and np.isfinite(spectrum).all()),
                          elapsed_s=time.monotonic()-t0)
            records.append(record)
            key = f'{tide_name}_T{temperature:g}_M{mass:g}'
            arrays[key] = spectrum
            (out / 'scan.json').write_text(json.dumps(records, indent=2)+'\n')
            np.savez(out/'scan.npz', velocity=velocity, **arrays)
            print(json.dumps(record), flush=True)
