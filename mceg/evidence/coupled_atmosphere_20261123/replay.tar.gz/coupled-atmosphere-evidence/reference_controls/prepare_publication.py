"""Select replayable thermochemical outputs and redact private stellar input."""
from hashlib import sha256
import json
from pathlib import Path
import numpy as np

ROOT = Path('/tmp/escape-reference-final')
RUNS = {
    'R1500': ('escape-solar-default-atom-control', 0),
    'R3000': ('escape-solar-default-atom-fine-continuum', 0),
    'R6000': ('escape-solar-default-atom-continuum005', 0),
    'R30000_oi': ('escape-solar-default-atom-mesh30000-oi', 0),
    'R60000_oi': ('escape-solar-default-atom-mesh60000-oi', 0),
    'R60000_oi_narrow': ('escape-solar-default-atom-mesh60000-oi-narrow', 0),
    'native_matched_H15_solar_chemistry': ('escape-primary-solar-chemistry-1e13', 0),
    'native_matched_H15_hhe_chemistry': ('escape-primary-hhe-chemistry-1e13', 0),
    'stopped_strict_thermal_final': ('escape-sunbather-solar-default25-strict', 4),
}
FILES = ('model.in', 'model.out', 'input_profiles.npz', 'cloudy_profiles.npz',
         'profiles.npz', 'model.conditions', 'model.overview', 'model.levels',
         'model.mass', 'model.heating', 'model.cooling', 'model.pressure', 'model.radius')
manifest = [{"source": str(ROOT/"publication_scope.md"), "path": "reference_controls/README.md"},
            {"source": str(ROOT/"prepare_publication.py"), "path": "reference_controls/prepare_publication.py"}]
for label, (name, iteration) in RUNS.items():
    base = Path('/tmp')/name
    prefix = f'reference_controls/raw/{label}'
    manifest.append({'source': str(base/'receipt.json'), 'path': f'{prefix}/receipt.json'})
    step = f'iteration_{iteration:03d}'
    for filename in FILES:
        source = base/step/filename
        if source.exists():
            manifest.append({'source': str(source), 'path': f'{prefix}/{step}/{filename}'})

figures = ROOT/'figures'
if (figures/'derived_profiles_spectra.npz').exists():
    public = ROOT/'public_figures'
    public.mkdir(exist_ok=True)
    private_path = figures/'derived_profiles_spectra.npz'
    data = dict(np.load(private_path))
    removed = ['stellar_reference']
    if any(key not in data for key in removed):
        raise ValueError('The expected stellar reference input is missing; inspect the artifact schema.')
    for key in removed:
        del data[key]
    public_path = public/'derived_profiles_spectra.npz'
    np.savez_compressed(public_path, **data)
    redaction = {
        'scope': 'Public derived planet/coadded spectra and thermochemical profiles, with local stellar input removed.',
        'removed_arrays': removed,
        'private_input_sha256': sha256(private_path.read_bytes()).hexdigest(),
        'public_output_sha256': sha256(public_path.read_bytes()).hexdigest(),
        'unchanged_arrays': sorted(data),
        'private_provenance': 'The separately archived provenance.json retains the hash of the original private NPZ. This receipt identifies the intentionally different public NPZ.',
    }
    (public/'redaction.json').write_text(json.dumps(redaction,indent=2)+'\n')
    for source in (public_path, public/'redaction.json'):
        manifest.append({'source': str(source), 'path': f'figures/cloudy_reference/{source.name}'})
    for filename in ('atmosphere_profiles.png', 'halpha_observation.png', 'provenance.json'):
        source = figures/filename
        if source.exists():
            manifest.append({'source': str(source), 'path': f'figures/cloudy_reference/{filename}'})

for item in manifest:
    if not Path(item['source']).is_file():
        raise FileNotFoundError(item['source'])
(ROOT/'publication_files.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(f'{len(manifest)} files, {sum(Path(item["source"]).stat().st_size for item in manifest)/1e6:.2f} MB')
