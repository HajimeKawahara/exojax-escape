"""Compare independent fixed-profile Cloudy continuum controls at common radii."""
from pathlib import Path
from hashlib import sha256
import json
import numpy as np

BASE = Path('/tmp')
ROOT = Path('/tmp/escape-reference-final')
RUNS = {
    'R1500': 'escape-solar-default-atom-control',
    'R3000': 'escape-solar-default-atom-fine-continuum',
    'R6000': 'escape-solar-default-atom-continuum005',
    'R30000_oi': 'escape-solar-default-atom-mesh30000-oi',
    'R60000_oi': 'escape-solar-default-atom-mesh60000-oi',
    'R60000_oi_narrow': 'escape-solar-default-atom-mesh60000-oi-narrow',
}
RP = 1.9*7.1492e9
RADIUS = np.array([1.1, 1.3, 1.8, 2.5])
FIELDS = ['heating_erg_cm3_s', 'cooling_erg_cm3_s', 'n2_cm3', 'n3_cm3',
          'mean_molecular_weight', 'electron_cm3']
result = {
    'scope': 'Same prescribed T, density, velocity, full chemistry, default C23 H atom, and unbroadened PHOENIX SED. Continuum mesh varies; Cloudy adaptive spatial zones are not independently converged.',
    'sample_radius_rp': RADIUS.tolist(),
    'sampling': 'Log-linear positive quantities from raw Cloudy zone centers; no 48-node population projection.',
    'physical_interpretation': 'These are prescribed-state radiation/statistical-equilibrium controls, not thermal/wind equilibria or native-Solar validation.',
    'runs': {}, 'comparisons': {},
}
for name, directory in RUNS.items():
    run = BASE/directory
    path = run/'iteration_000/cloudy_profiles.npz'
    if not path.exists():
        result['runs'][name] = {'complete': False}
        continue
    data = dict(np.load(path))
    x = data['radius_cm']/RP
    sample = {field: np.exp(np.interp(RADIUS, x, np.log(data[field]))) for field in FIELDS}
    ratio = sample['n3_cm3']/sample['n2_cm3']
    sample['n3_over_n2'] = ratio
    sample['halpha_shell_source_temperature_k'] = 6.62607015e-27*2.99792458e10*15233.146/(1.380649e-16*np.log(18/(8*ratio)))
    result['runs'][name] = {
        'complete': True, 'zone_count': len(x), 'raw_profile_sha256': sha256(path.read_bytes()).hexdigest(),
        'receipt_sha256': sha256((run/'receipt.json').read_bytes()).hexdigest(),
        'input_profile_sha256': sha256((run/'iteration_000/input_profiles.npz').read_bytes()).hexdigest(),
        'sample': {key: value.tolist() for key,value in sample.items()},
    }
for coarse, fine in [('R1500','R3000'), ('R3000','R6000'), ('R6000','R30000_oi'),
                     ('R30000_oi','R60000_oi'), ('R60000_oi','R60000_oi_narrow')]:
    if not all(result['runs'][key]['complete'] for key in (coarse,fine)):
        continue
    before, after = (result['runs'][key]['sample'] for key in (coarse,fine))
    result['comparisons'][f'{coarse}_to_{fine}'] = {
        'fine_over_coarse': {key: (np.asarray(after[key])/before[key]).tolist() for key in before},
        'net_radiative_change_over_fine_heating_plus_cooling': (((np.asarray(after['heating_erg_cm3_s'])-after['cooling_erg_cm3_s'])-(np.asarray(before['heating_erg_cm3_s'])-before['cooling_erg_cm3_s']))/(np.asarray(after['heating_erg_cm3_s'])+after['cooling_erg_cm3_s'])).tolist(),
        'halpha_shell_source_temperature_change_k': (np.asarray(after['halpha_shell_source_temperature_k'])-before['halpha_shell_source_temperature_k']).tolist(),
    }
(ROOT/'fixed_profile_mesh_controls.json').write_text(json.dumps(result,indent=2)+'\n')
for name, comparison in result['comparisons'].items():
    print(name)
    for field in ('heating_erg_cm3_s','cooling_erg_cm3_s','n2_cm3','n3_cm3'):
        print(field, np.array(comparison['fine_over_coarse'][field]))
    print('Source temperature delta', comparison['halpha_shell_source_temperature_change_k'])
