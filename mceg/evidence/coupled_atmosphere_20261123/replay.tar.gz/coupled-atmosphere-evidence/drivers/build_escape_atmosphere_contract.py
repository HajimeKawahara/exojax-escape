"""Assemble the scoped review; no provider import or runtime dependency."""
from pathlib import Path
import argparse
import hashlib
from importlib.metadata import version
import json
import re
import shutil
import sys
import xml.etree.ElementTree as ET

import yaml

from mceg.validator import load_contract
from mceg.schema_v03 import Equation, EquationBinding, binding_digest, equation_digest
from mceg.schema_v04 import decision_basis_digest

ROOT = Path('/tmp/escape-coupled-atmosphere')
parser = argparse.ArgumentParser()
parser.add_argument('--revision', default='4b3fdd651a01eac752e96f3662c611a18940ccf1')
args = parser.parse_args()
DEST = ROOT / 'mceg/evidence/coupled_atmosphere_20261123'
DEST.mkdir(exist_ok=True)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


composition_path = Path('/tmp/escape-composition-summary.json')
metal_path = Path('/tmp/cloudy-metal-diagnostic/summary.json')
composition, metal = read(composition_path), read(metal_path)
comparison = Path('/tmp/escape-atmosphere-reference')
source_files = [
    'atmosphere.py', 'atmosphere_wind.py', 'coupled_forward.py', 'coupled_hydrogen.py',
    'radiation.py', 'hydrogen_continuum.py', 'hydrogen_atom.py', 'hydrogen_rates.py', 'hydrogen_collisions.py',
    'hydrogen_nlte.py', 'hydrogen_bound_free.py', 'hydrogen_mixing.py',
    'nlte_forward.py', 'hydrogen_forward.py', 'reactive_flow.py', 'nonisothermal.py',
    'parker.py', 'observation.py', 'hydrogen_populations.py', 'stellar_radiation.py', '__init__.py',
]
selected = {f'src/escape/{name}': digest(ROOT / 'src/escape' / name) for name in source_files}
review = {
    'review_date': '2026-11-23',
    'scope': 'Connected native pure-H spectrum; numerical implementation checks and scientific adequacy are separate.',
    'entry_point': 'src/escape/atmosphere.py:HydrogenAtmosphereModel.spectrum',
    'implementation_revision': args.revision,
    'source_sha256': selected,
    'author_configuration': {'composition': 'unknown', 'complete_cloudy_inputs': 'unavailable'},
    'target_selection': 'The user selected solar composition for the current target on 2026-11-23. This choice does not establish the unpublished author abundance or validate the native pure-H model.',
    'composition': {
        'scope': composition['scope'],
        'input_note': 'Prescribed profiles represent the same nominal mass density and temperature. Adaptive Cloudy zones are interpolated at the listed radii; this is not a converged thermal/wind comparison.',
        'radius_rp': composition['radius_rp'],
        'planet_mass_mj': composition['planet_mass_mj'],
        'planet_radius_rj': composition['planet_radius_rj'],
        'mass_loss_g_s': composition['mass_loss_g_s'],
        'summary_sha256': digest(composition_path),
        'cases': {},
    },
    'metal_heating': {
        'scope': 'Reporting-only diagnostic of the final Cloudy iteration, solar composition with molecules disabled. Per-species net collisional heating, not direct attribution of the original pumping photon.',
        'summary_sha256': digest(metal_path),
        'diagnostic_cpp_sha256': metal['diagnostic_cpp_sha256'],
        'unchanged_outputs_against_unmodified_cloudy': metal['unchanged_outputs'],
        'samples': [],
    },
    'controlled_columns': {
        'scope': 'Fixed T/nH slab component comparison; no solved atmosphere or complete observer validation.',
        'settings': {'nmax': 15, 'temperature_k': 8000, 'density_cm3': 1e12,
                     'blackbody_temperature_k': 10000, 'dilution': 0.025,
                     'column_cm2': [1e18, 1e21], 'native_layers': 8,
                     'native_transfer': 'static plane slab CRD, normal incident beam',
                     'wing_breakpoints_doppler_widths': [30, 100, 300, 1000]},
        'wing_refinement': read(comparison / 'native_wing_summary.json'),
        'cloudy_continuum_refinement': read(comparison / 'continuum_refinement.json'),
        'provenance_sha256': {name: digest(comparison / name) for name in (
            'native_wing_summary.json', 'native_wing_refinement.json', 'continuum_refinement.json',
        )},
        'remaining': 'Historical VS80/full-J controls, before the default Anderson n=4,5 correction. See subsequent_diagnostics for the causal collision/alternate-closure experiments. Spatial/angular convergence and full-atmosphere reference matching remain unresolved.',
    },
    'observation_processing': {
        'scope': 'Explicit-array JAX processing operator and public exposure times; publication-specific normalization, masters, masks and coadd are not recovered.',
        'cadence': read('/tmp/escape-observation-processing/cadence_summary.json'),
        'best_approximate_data_reconstruction': read('/tmp/escape-observation-processing/data_reconstruction.json')['best'],
        'unresolved_settings': ['Original stellar reference and continuum fits', 'Nightly master weights and masks', 'Exposure integration and final binning', 'Secondary-occultation visibility for the late exposures approaching phase 0.493'],
        'provenance_sha256': {name: digest(Path('/tmp/escape-observation-processing') / name) for name in (
            'reconstruct_data.py', 'cadence_summary.json', 'data_reconstruction.json',
        )},
    },
    'source_audit': {
        'cloudy_version': 'C23.01',
        'line_closure': 'iso_create.cpp assigns special Ly-alpha, Doppler-core CRD to other Lyman lines, and CRD with wings to subordinate lines. rt_line_one.cpp/iso_level.cpp use escape, destruction and continuum pumping. The native full-J CRD slab is a different closure.',
        'internal_reprocessing': 'rt_ots.cpp distributes destroyed line photons through continuum opacity into ionization and excess-energy heating. The native one-way two-photon channel does not reabsorb its diffuse continuum.',
        'metal_budget': 'species2.cpp adds max(0,-dBaseSpecies.CoolTotal); prt_lines_general.cpp reports each species. The diagnostic prints the same per-species quantities without changing the solve.',
        'interpretation': 'Do not add escape probabilities to the existing full-J rate equations: that would count trapping twice. Any alternate closure must replace the matching rates and energy accounting consistently.',
    },
    'artifact_policy': 'Compact derived results and hashes are retained. No raw PHOENIX SED or multi-gigabyte Cloudy diagnostics are redistributed. The summary does not by itself permit exact reruns without the separately obtained inputs.',
}
for name, values in composition['models'].items():
    directory = Path(values['raw_directory'])
    receipt = read(directory / 'receipt.json')
    result = {key: values[key] for key in (
        'cloudy_molecules_enabled', 'density_g_cm3', 'mean_molecular_weight',
        'n2_cm3', 'n3_cm3', 'heating_erg_cm3_s', 'cooling_erg_cm3_s',
    )}
    result['net_heating_erg_cm3_s'] = [h-c for h, c in zip(values['heating_erg_cm3_s'], values['cooling_erg_cm3_s'])]
    result['provenance'] = {key: receipt[key] for key in (
        'source_profiles_sha256', 'cloudy_sha256', 'composition', 'boundary',
        'nmax', 'continuum_resolution', 'spectrum',
    )}
    result['provenance']['input_sha256'] = digest(directory / 'iteration_000/model.in')
    result['provenance']['saved_output_sha256'] = {
        name: digest(directory / 'iteration_000' / name) for name in (
            'model.conditions', 'model.heating', 'model.cooling', 'model.levels',
        )
    }
    if name == 'solar_chemistry':
        rows = []
        for line in (directory / 'iteration_000/model.heating').read_text().splitlines():
            fields = [value.strip() for value in line.split('\t')]
            try:
                depth = float(fields[0])
            except ValueError:
                continue
            if len(fields) < 7:
                continue
            if rows and depth < rows[-1][0]:
                rows = []
            rows.append((depth, fields))
        depth, fields = min(rows, key=lambda row: abs(3-row[0]/1.358348e10-1.1))
        fractions = dict(zip(fields[5::2], fields[6::2]))
        result['heating_channels_near_1p1_rp'] = {
            'radius_rp': 3-depth/1.358348e10,
            'database_bound_bound_fraction': float(fractions['DbLn']),
            'hminus_fraction': float(fractions['H-']),
        }
    review['composition']['cases'][name] = result
for point in metal['scopes']:
    review['metal_heating']['samples'].append({
        'radius_rp': point['radius_rp'], 'temperature_k': point['temperature_k'],
        'total_heating_erg_cm3_s': point['heating_erg_cm3_s'],
        'database_net_heating_erg_cm3_s': point['database_net_heating'],
        'database_fraction_total_heating': point['database_net_heating'] / point['heating_erg_cm3_s'],
        'top_species': [{key: species[key] for key in (
            'species', 'database', 'levels', 'net_cooling', 'fraction_total_heating',
        )} for species in point['top_species'][:8]],
    })

extra = Path('/tmp/escape-atmosphere-probes/subsequent_diagnostics.json')
if extra.exists():
    detail = read(extra)
    collision = detail['hydrogen_collision_repair']
    metals = detail['metal_microphysics']
    ionic = detail['ionic_molecular_microphysics']
    joint = detail['joint_fixed_temperature']
    observer = detail['reference_observable']
    review['subsequent_diagnostics'] = {
        'scope': detail['scope'],
        'detailed_archive_record': {
            'source': 'execution/subsequent_diagnostics.json in the immutable replay archive',
            'sha256': digest(extra),
            'locator': 'mceg/evidence/coupled_atmosphere_20261123/archive.json',
        },
        'hydrogen_collision_repair': {key: collision[key] for key in (
            'production_change','causal_frozen_rate_swap','independent_source','interpretation')},
        'metal_microphysics': {'species': metals['species'], 'scope': metals['scope'],
                              'local_kernel_receipt_sha256': metals['receipt']['sha256']},
        'ionic_molecular_microphysics': {'scope': ionic['receipt']['result']['scope'],
                                        'independent_checks': ionic['independent_checks'],
                                        'receipt_sha256': ionic['receipt']['sha256']},
        'joint_fixed_temperature': {
            'scope': joint['caveat'],
            'convergence': joint['convergence']['result'],
            'verification': joint['verification']['result'],
            'frozen_source_reverification': joint.get('frozen_source_reverification'),
        },
        'reference_convergence': {key: detail['reference_convergence'][key] for key in (
            'status','finding','threshold_control','interpretation','measured_controls_provenance')},
        'reference_observable': {
            'scope': observer['result']['scope'], 'interpretation': observer['interpretation'],
            'source_sha256': observer['sha256'],
            'mesh_effect_ppm': observer['result']['maximum_R1500_to_R60000_processed_difference_ppm'],
            'mesh_effect_over_supplied_error': observer['result']['maximum_R1500_to_R60000_processed_difference_over_supplied_error'],
            'raw_to_48_node_projection_ppm': [case['input_grid_projection_control_max_difference_ppm'] for case in observer['result']['cases']],
        },
        'remaining_for_selected_solar_use': detail['remaining_for_selected_solar_use'],
    }

tests = Path('/tmp/escape-atmosphere-probes/current_tests.xml')
test_ready = tests.exists()
test_result = 'not_run'
review['tests'] = {'status': 'awaiting_final_execution'}
if test_ready:
    execution_receipt = read('/tmp/escape-atmosphere-probes/current_tests_receipt.json')
    assert all(execution_receipt['source_files'].get(path) == sha for path, sha in selected.items()), 'Sources changed after the retained execution.'
    tree = ET.parse(tests)
    suites = tree.findall('.//testsuite')
    assertion_failed = bool(tree.findall('.//failure')) or any(int(s.get('failures', 0)) for s in suites)
    execution_error = bool(tree.findall('.//error')) or any(int(s.get('errors', 0)) for s in suites)
    test_ready = bool(suites) and not assertion_failed and not execution_error
    cases = tree.findall('.//testcase')
    required = {'test_joint_root_closes_mass_charge_and_thermal_flow',
                'test_complete_spectrum_implicit_gradient',
                'test_spectrum_consumes_the_same_nonlocal_populations'}
    completed = [case for case in cases if not any(case.find(tag) is not None for tag in ('skipped','failure','error'))]
    test_ready &= required <= {case.get('name') for case in completed}
    test_result = 'passed' if test_ready else ('failed' if assertion_failed else 'unknown')
    shutil.copyfile(tests, DEST / 'tests.xml')
    review['tests'] = {
        'status': 'passed' if test_ready else 'not_passed',
        'evidence_result': test_result,
        'execution_error': execution_error,
        'assertion_failed': assertion_failed,
        'skipped_tests': len(tree.findall('.//skipped')),
        'source_sha256': selected,
        'execution_receipt_sha256': digest('/tmp/escape-atmosphere-probes/current_tests_receipt.json'),
        'exojax_source_revision': execution_receipt['exojax_source_revision'],
        'environment': {'python': sys.version.split()[0],
                        **{name: version(name) for name in ('jax', 'jaxlib', 'numpy', 'pytest')},
                        'JAX_PLATFORMS': 'cpu', 'OMP_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1',
                        'NUMBA_CACHE_DIR': '/tmp/escape-numba-cache', 'MPLCONFIGDIR': '/tmp/escape-matplotlib',
                        'PYTHONPATH': '/tmp/escape-coupled-atmosphere/src:/tmp/exojax-spectrum-upstream/src:/tmp/escape-coupled-atmosphere/examples:/tmp/escape-coupled-atmosphere/tools'},
        'test_count': len(cases),
        'distinct_test_cases': execution_receipt['distinct_test_cases'],
        'execution_batches': execution_receipt['batches'],
        'source_change_verification': execution_receipt.get('source_change_verification'),
        'initial_consolidated_attempt': 'Terminated with SIGTERM (exit 143) after 48 progress dots, without a JUnit report. Cause unrecorded; not a passed or failed scientific test. Completed retries are recorded separately below.',
        'test_source_sha256': {str(path.relative_to(ROOT)): digest(path) for path in sorted(ROOT.glob('tests/test_*.py')) if 'tests.'+path.stem in {case.get('classname') for case in cases}},
        'scope': 'Small numerical control, not the PHOENIX or solar atmosphere: nlayer=4, nmax=3, nnu=61, nlon=4, nlat=2, wind_ngrid=33, Mdot=1e15 g/s; initial/base T=8000 K, inner BB4500 K, outer BB10000 K intensity scale .05, tide=3*(2*pi/(1.48 days))^2.',
        'metrics': {prop.get('name'): float(prop.get('value')) for prop in tree.findall('.//property')
                    if prop.get('name') in ('joint_atmosphere_residual', 'thermal_flow_balance',
                        'atmosphere_spectrum_gradient_relative_error', 'feedback_population_change',
                        'coupled_root_residual', 'spectrum_gradient_relative_error')},
        'tests_sha256': digest(DEST / 'tests.xml'),
    }
    test_groups = {
        'current_new': ['slab_transfer', 'thermal_exchange', 'atmosphere', 'atmosphere_wind',
                      'coupled_forward', 'low_temperature_rates', 'line_wing_grid',
                      'observation'],
        'current_old_flow': ['coupled_equilibrium', 'coupled_flow', 'reactive_flow'],
        'current_old_atom': ['hydrogen_rates', 'hydrogen_atom', 'nlte_forward', 'halpha_transfer', 'higher_hydrogen_collisions'],
        'current_external': ['cloudy_atmosphere_tool', 'cloudy_halpha_reference'],
    }
    review['tests']['retry_groups'] = [{
        'command': ['taskset', '-c', next(batch['affinity'] for batch in execution_receipt['batches'] if batch['name']==group), '/home/kawahara/miniconda3/bin/python', '-m', 'pytest', '-q',
                    *['tests/test_'+name+'.py' for name in names],
                    '--junitxml=/tmp/escape-atmosphere-probes/'+group+'.xml'],
        'source_xml_sha256': digest(tests.with_name(group+'.xml')),
    } for group, names in test_groups.items() if tests.with_name(group+'.xml').exists()]
(DEST / 'review.json').write_text(json.dumps(review, indent=2, allow_nan=False) + '\n')

SUBJECT, CONTEXT = 'connected_observer', 'kelt9b_atmosphere'
doc = ROOT / 'doc/coupled_atmosphere.tex'
artifact = {'source': 'mceg/evidence/coupled_atmosphere_20261123/review.json', 'sha256': digest(DEST / 'review.json')}


def evidence(id, kind, summary, scope, sources, *, result=None, artifacts=()):
    item = dict(id=id, kind=kind, summary=summary, scope=scope, sources=sources,
                subject=SUBJECT, context=CONTEXT, artifacts=list(artifacts),
                provenance=dict(role='primary', inspection='inspected', location=scope,
                                note='Source review and retained measurements are limited to the stated conditions; no general physical acceptance follows.'))
    if result:
        item['result'] = result
    return item


evidences = [
    evidence('reference_scope', 'literature',
             'The paper and sunbather require radiation/population feedback, thermal advection/expansion, composition-dependent pressure and observation processing.',
             'Zhang IV-V; Linssen 2.1-2.2.3. Complete customized author inputs, including abundance choice, are unavailable.',
             ['https://arxiv.org/html/2606.23899v1', 'https://arxiv.org/html/2404.12775v2']),
    evidence('formulation', 'theory', 'The authored equations distinguish the connected pure-H implementation from physical equivalence.',
             'doc/coupled_atmosphere.tex labels eq:mass, wind, se, rt, cell, thermal, collheat, ad. Static mappings are declarations; selected-path tests check execution.',
             ['doc/coupled_atmosphere.tex'], artifacts=[{'source': 'doc/coupled_atmosphere.tex', 'sha256': digest(doc)}]),
    evidence('execution', 'numerical_test', 'Retained selected-path tests of the joint root and observer; numerical control only.',
             'Small atom/grid, blackbody control and the mass-loss derivative; not a continuous parameter envelope or the physical target.',
             [artifact['source']], result=test_result, artifacts=[artifact] + ([{'source': 'mceg/evidence/coupled_atmosphere_20261123/tests.xml', 'sha256': digest(DEST / 'tests.xml')}] if tests.exists() else [])),
    evidence('composition_experiment', 'benchmark',
             'At about 1.1 Rp, database metal bound-bound processes supply 94.65% of molecule-disabled solar heating and 84.1% with full chemistry (H-minus: 10.9%). Full-chemistry H+He net heating is -4.68e-4 and solar is +3.02e-2 erg cm^-3 s^-1.',
             'Coarse-mesh prescribed PHOENIX proxy and density/T profiles; independent solar composition, not inferred author abundance. These percentages are not converged: subsequent frequency refinement changes heating materially. The omission of solar channels remains real.',
             [artifact['source'], 'tools/cloudy_atmosphere.py'], result='failed', artifacts=[artifact]),
    evidence('column_comparison', 'numerical_test',
             'Historical full-J/VS80 controls differ from Cloudy by up to 43.60% in n3. A later consistent escape-probability experiment with Anderson n=4,5 collisions reduces interior differences below 5%, but illuminated thick-column surface differences still reach 31.5%.',
             'Fixed T=8000 K, nH=1e12 cm^-3, nmax=15, BB10000 K W=.025; historical full-J eight-layer and later separate 16-layer EP prototypes. The new selected default corrects collisions only; EP is not silently substituted into the production path.',
             [artifact['source'], 'tools/verify_atmosphere_reference.py'], result='failed', artifacts=[artifact]),
    evidence('closure_audit', 'implementation',
             'Cloudy line escape/destruction differs from native full-J CRD; internal two-photon reabsorption, He/metals and a validated dense lower patch remain missing or unvalidated.',
             'Cloudy C23.01 iso_create.cpp, iso_level.cpp, rt_line_one.cpp, rt_ots.cpp; native radiation_state, thermal_energy_exchange and atmosphere.solve.',
             [artifact['source'], 'https://gitlab.nublado.org/cloudy/cloudy'], artifacts=[artifact]),
    evidence('observation_audit', 'numerical_test',
             'Actual public cadences contain 84 and 59 exposures. An explicit-array operator is tested, but the publication-specific master and exact reduction settings remain unavailable.',
             'An approximate archived-data reconstruction differs by 0.954 sigma RMS even for the best tested recipe; it is not an exact reconstruction.',
             [artifact['source'], 'https://zenodo.org/records/20707255'], result='unknown', artifacts=[artifact]),
]


def symbol(latex, description, unit):
    return dict(latex=latex, description=description, unit=unit)


common = {
    'radius': symbol('r', 'Radius', 'cm'),
    'density': symbol(r'\rho', 'Mass density', 'g cm^-3'),
    'temperature': symbol('T', 'Gas temperature', 'K'),
    'mu': symbol(r'\mu', 'Mean molecular weight per hydrogen-mass unit', '1'),
    'velocity': symbol('v', 'Radial velocity', 'cm s^-1'),
    'electron': symbol('n_e', 'Electron number density; equals proton density', 'cm^-3'),
    'bound': symbol('n_i', 'Bound-state number density', 'cm^-3'),
    'mean': symbol(r'J_\nu', 'Mean intensity', 'erg s^-1 cm^-2 sr^-1 Hz^-1'),
}
specs = {
    'mass': ('Mass continuity and the pure-H equation of state',
             {**{k: common[k] for k in ('radius','density','temperature','mu','velocity','electron')},
              'mass_loss': symbol(r'\dot M', 'Mass-loss rate', 'g s^-1')},
             'No helium/metals or nontrace H-minus contribution to mass, charge or pressure.'),
    'wind': ('Transonic wind with variable T/mu and a linear tide',
             {**{k: common[k] for k in ('radius','temperature','mu','velocity')},
              'sound_squared': symbol('a^2', 'Pressure divided by density', 'cm^2 s^-2'),
              'tide': symbol(r'\kappa', 'Linear tidal coefficient', 's^-2')},
             'One regular sonic point. Log(T/mu) has zero endpoint slopes and is held constant to the outer wind boundary.'),
    'se': ('Local statistical equilibrium with nucleus and charge conservation',
           {'electron': common['electron'], 'bound': common['bound'],
            'rates': symbol(r'\{R_{ij},\alpha_i,\beta_i,\Gamma_i,q_{i,\rm ion}\}', 'Atomic rates; units follow each coefficient', 'mixed rate units')},
           'Resolved lower nl states and configured collapsed shells. No population advection or inverse two-photon radiation.'),
    'rt': ('Static transfer and profile-averaged mean intensity',
           {'mean': common['mean'], 'profiles': symbol(r'\phi_{ul}', 'Normalized line profiles', 'Hz^-1'),
            'emission': symbol(r'j_\nu', 'Emission coefficient', 'erg s^-1 cm^-3 sr^-1 Hz^-1'),
            'extinction': symbol(r'\chi_\nu', 'Extinction coefficient', 'cm^-1')},
           'Plane-parallel CRD transport; no velocity shifts in the internal radiation solve. The stellar input is a normally incident beam.'),
    'cell': ('Exact homogeneous-cell outgoing and average intensities',
             {'depth': symbol('t', 'Optical depth along a ray', '1'),
              'first': symbol('w_1', 'First exponential average', '1'),
              'second': symbol('w_2', 'Second exponential average', '1')},
             'Nonnegative extinction. Analytic series supply the transparent limit.'),
    'thermal': ('Kinetic thermal balance including advection and expansion',
                {k: common[k] for k in ('radius','density','temperature','mu','velocity')},
                'Monatomic local-SE closure, gamma=5/3. The prescribed bottom temperature or LTE patch replaces the energy equation there; chemical binding energy is not separately advected.'),
    'collheat': ('Bound-bound collisional kinetic-energy exchange',
                 {'electron': common['electron'], 'bound': common['bound'],
                  'rates': symbol('q_{ij}', 'Electron collision coefficients, indexed from/to', 'cm^3 s^-1'),
                  'energy': symbol('E_i', 'Bound-state excitation energy', 'erg')},
                 'The full thermal function adds photoelectron, recombination, ionizing/three-body collision, free-free and optional H-minus terms. No extra two-photon thermal loss is added.'),
    'ad': ('Implicit derivative of a converged atmospheric root',
           {'state': symbol('y', 'Log-temperature and population-ratio coordinates', '1'),
            'parameters': symbol(r'\theta', 'Explicit physical inputs with their declared units', 'mixed input units'),
            'residual': symbol(r'\mathcal F', 'Scaled coupled residual', '1')},
           'A converged admissible root and nonsingular residual Jacobian on a fixed branch are required. An iteration history is not the differentiated mathematical model.'),
}
equations = []
for match in re.finditer(r'\\begin\{(equation|align)\}(.*?)\\end\{\1\}', doc.read_text(), re.S):
    content = match[2]
    label = re.search(r'\\label\{eq:([^}]+)\}', content)[1]
    latex = re.sub(r'\\label\{[^}]+\}', '', content).replace(r'\kb', r'{k_{\mathrm B}}').replace(r'\mh', r'{m_{\mathrm H}}').strip()
    latex = re.sub(r'\s+', ' ', latex)
    if match[1] == 'align':
        latex = r'\begin{aligned}' + latex.replace(r'\notag', '') + r'\end{aligned}'
    if label == 'cell':
        latex = r'w_1=(1-e^{-t})/t,\quad w_2=(1-w_1)/t,\quad ' + latex
    description, symbols, assumption = specs[label]
    equations.append(dict(id=label, revision='1', latex=latex,
                          description=f'{description} (document label eq:{label}).',
                          scope='The selected native pure-H formulation, not a Cloudy-equivalence claim.',
                          symbols=symbols, assumptions=[assumption], evidence=['formulation']))


def binding(id, equation, source, function, arguments, note):
    return dict(id=id, equation={'id': equation, 'revision': '1'}, subject=SUBJECT,
                source='src/escape/'+source, symbol=function,
                arguments={key: {'symbol': value} for key, value in arguments.items()}, note=note)


bindings = [
    binding('se_ratios', 'se', 'hydrogen_nlte.py', '_bound_ratios',
            {'electron_density': 'electron', 'rates': 'rates'},
            'Returns n_i/n_p from the local rate matrix. The actual atmosphere residual recomputes the rates from its own internal radiation and supplies this target.'),
    binding('radiation_occupations', 'rt', 'coupled_hydrogen.py', 'CoupledHydrogenModel._occupations',
            {'mean': 'mean', 'profiles': 'profiles'},
            'Integrates the line profiles against the solved J and converts J to photon occupations. Transfer itself is a decorated JAX function; this binding does not establish its call graph.'),
    binding('cell_weights', 'cell', 'radiation.py', '_cell_weights', {'depth': 'depth'},
            'Returns only (w1,w2); solve_slab_transfer uses them for outgoing and cell-average intensities. This helper mapping does not independently prove the complete transfer solution.'),
    binding('flow_heat', 'thermal', 'atmosphere_wind.py', 'thermal_flow_terms',
            {'radius_cm': 'radius', 'density_g_cm3': 'density', 'temperature_k': 'temperature',
             'mean_molecular_weight': 'mu', 'velocity_cm_s': 'velocity'},
            'Returns q_adv and q_exp. The complete atmosphere residual adds kinetic radiative heating/cooling and replaces the bottom boundary rows explicitly.'),
    binding('collision_heat', 'collheat', 'hydrogen_continuum.py', 'thermal_energy_exchange',
            {'bound_cm3': 'bound', 'electron_cm3': 'electron', 'rates': 'rates'},
            'The excitation array implements the displayed double sum as one part of the returned total kinetic exchange. Energy levels come from atom.excitation_energy_erg.'),
]

claim_specs = [
    ('radiation_connection', 'numerical_verification',
     'In the retained numerical controls, the selected spectrum consumes its own coupled radiation/population root, with no silent local-SE fallback.',
     'Actual HydrogenAtmosphereModel.spectrum path plus the separately identified fixed-T coupled-observer control. No physical accuracy claim.',
     ['se','rt','cell'], 'execution', 'supported' if test_ready else 'unknown',
     'Direct path inspection and the retained root/observer tests support only the stated numerical controls.'),
    ('thermal_wind_connection', 'numerical_verification',
     'At the retained control point, the selected atmospheric root closes mass/charge conservation and kinetic thermal balance with variable-mu transonic flow.',
     'Four layers, nmax=3 and Mdot=1e15 g/s blackbody control; the fixed bottom temperature is a boundary, not a solved energy equation.',
     ['mass','wind','thermal','collheat'], 'execution', 'supported' if test_ready else 'unknown',
     'The retained test checks mass flux, mu, nonconstant temperature and the signed heating/cooling/advection/expansion residual.'),
    ('implicit_derivatives', 'numerical_verification',
     'The complete spectrum derivative with respect to log mass loss agrees with centered finite differences at the retained converged control.',
     'This one directional derivative is not all-parameter, all-domain or NUTS validation.',
     ['ad'], 'execution', 'supported' if test_ready else 'unknown',
     'The actual selected spectrum is differentiated, including its radiation, temperature and wind roots; success is restricted to the recorded sample and tolerance.'),
    ('reference_agreement', 'numerical_verification',
     'The solved native atmosphere and observer agree with independently converged, boundary-matched Cloudy references within an observable error budget.',
     'Whole-atmosphere use. Fixed-T component comparisons and unknown author inputs are kept separate.',
     [], 'column_comparison', 'unknown',
     'No matched complete atmospheric comparison exists. Later collision and consistent EP experiments improve controlled columns, but boundary differences and full-atmosphere thermal/reference convergence remain unresolved.'),
    ('composition_reduction', 'numerical_verification',
     'The pure-H reduction retains the dominant heating channels of the explicitly specified solar-composition proxy.',
     'Prescribed PHOENIX proxy and density/T profiles near 1.1-1.8 Rp. The paper author abundance choice remains unknown; this is not a claim about it.',
     [], 'composition_experiment', 'contradicted',
     'Controlled solar calculations contain large omitted metal pumping/collisional heating and molecular cooling. Reported coarse-grid percentages change with frequency refinement and are not accepted precise budgets. No evidence validates removing these channels for the selected solar target.'),
    ('line_closure', 'physical_validation',
     'Static CRD transport and an escaping two-photon channel are adequate approximations for the target atmospheric radiation and level populations.',
     'Requires redistribution, moving-medium/geometry and internal two-photon reabsorption error bounds; neither a conserved slab nor a resolved frequency grid is sufficient.',
     ['rt'], 'closure_audit', 'unknown',
     'Cloudy uses a distinct line escape/destruction and continuum reprocessing treatment. The current implementation does not establish equivalent rates or quantify these omissions.'),
    ('lower_atmosphere', 'physical_validation',
     'The low-temperature rates, optional LTE lower patch and H-minus continuum provide an adequate dense lower boundary for the target spectrum.',
     'Cloudy-style rate extrapolation to 4000 K and a supplied fixed LTE patch are explicit approximations, not a solved photosphere.',
     [], 'closure_audit', 'unknown',
     'No demonstrated thermalized join or pressure-domain check validates the paper-like dense 4500 K extension. Direct lower-line-removal controls do not bound its thermal/wind feedback or chemistry. H-minus trace LTE is not full chemistry.'),
    ('numerical_resolution', 'numerical_verification',
     'Spatial, angular, frequency, atom-size and wind-domain refinement bound errors in the full atmospheric solution and selected observable.',
     'The requested atmospheric domain and observation uncertainties, not only root residuals or profile normalization.',
     [], 'column_comparison', 'unknown',
     'Far-wing refinement improves controlled columns, but spatial convergence and the T/mu extension to 32 Rp remain unresolved. No full-spectrum error budget has been met.'),
    ('observation_operator', 'physical_validation',
     'Explicit observation processing reproduces the publication-specific transformation of the generated phase spectra.',
     'Exposure phases and occultation visibility, planet/stellar Doppler shifts, continuum normalization, nightly master division, stellar mask and per-pixel weighted coadd, with integration/binning as needed.',
     [], 'observation_audit', 'unknown',
     'The JAX operator and actual cadence do not recover the original master weights, masks, continuum fits, integration and binning. Secondary occultation is omitted in the current observer; the retained late-signal controls do not bound its effect throughout the intended atmospheric domain. No exact publication processing or automatic spectrum-to-operator connection is inferred.'),
]
claims, assessments = [], []
for id, kind, statement, scope, refs, ev, status, reason in claim_specs:
    claims.append(dict(id=id, revision='2', kind=kind, statement=statement, scope=scope,
                       equations=[{'id': e, 'revision': '1'} for e in refs]))
    assessments.append(dict(id=id+'_review', kind='evidence_support', claim=id, claim_revision='2',
                            subject=SUBJECT, context=CONTEXT, status=status, origin='reviewed',
                            method=dict(id='scoped_evidence_review', revision='1', description='Inspect the actual path and retained scope. A FollowUp handles a concern but cannot provide physical support.'),
                            evidence=[ev, 'formulation'] if refs else [ev],
                            reasons=[reason if test_ready or ev!='execution' else 'Final current-source execution is pending; earlier successful controls do not automatically refresh support.']))
actions = {
    'reference_agreement': 'First resolve controlled-column discrepancies while independently refining Cloudy/native grids, then compare the same complete atmosphere and observable under matched boundary conditions.',
    'composition_reduction': 'For the user-selected solar composition, complete and validate shared H/metal ionization, multilevel pumping, radiation, charge and thermal feedback, including H-minus/H2-plus chemistry, metal continua and remaining coolants. The scoped prototypes are progress, not support for the selected production model.',
    'line_closure': 'Compare consistent alternate redistribution/destruction closures and two-photon continuum reabsorption; propagate rate and energy differences to the selected spectrum without double counting trapped radiation.',
    'lower_atmosphere': 'Validate low-temperature atomic extrapolations, pressure/domain limits and a thermalized LTE join; measure lower-boundary and H-minus chemistry sensitivity.',
    'numerical_resolution': 'Refine spatial/angle/frequency/atom grids and wind outer-domain extension on matched roots; require observable changes below a declared fraction of the actual data errors.',
    'observation_operator': 'Recover or explicitly bracket the unavailable reduction settings and secondary-occultation visibility. Connect the selected phase spectra to the explicit-array operator and verify final coadds against the public data.',
}
for id, *_ in claim_specs[:3]:
    if not test_ready:
        actions[id] = 'Run the selected current-source tests and retain their sample, metrics and hashes before updating this implementation Assessment.'
followups = [dict(id='verify_'+key, target_kind='assessment', target=key+'_review', action=action,
                 completion='Retain independent scoped evidence and update or supersede the Assessment; recording work as handled does not make the scientific use ready.')
             for key, action in actions.items()]
implementation = dict(repository='https://github.com/HajimeKawahara/exojax-escape',
                      revision=args.revision,
                      entry_points=[review['entry_point']] + [b['source']+':'+b['symbol'] for b in bindings])
contract = dict(
    schema_version='0.4',
    model=dict(id='escape.coupled_atmosphere', name='Connected pure-H atmosphere: implementation and adequacy',
               description='The selected spectrum connects radiation/SE, thermal flow and a variable-mu wind. Numerical tests do not establish Cloudy equivalence; the solar-composition heating reduction is contradicted.',
               implementation=implementation),
    assumptions=[dict(statement='Pure atomic H, local SE without population advection, kinetic thermal flow, static plane-slab CRD radiation and spherical mass continuity. Boundary spectra, LTE patch and H-minus are explicit inputs/options.', evidence=['formulation']),
                 dict(statement='The user selected solar composition as the target; the controlled solar proxy is a sensitivity test. The published customized author composition and full inputs remain unknown.', evidence=['reference_scope','composition_experiment'])],
    limitations=[dict(statement='No full-atmosphere Cloudy equivalence, spatial convergence, validated photospheric join, original observation pipeline or NUTS-domain validation is established.', evidence=['column_comparison','closure_audit','observation_audit'])],
    domains=[dict(kind='scientific_applicability', status='unknown', description='The intended atmospheric use is not ready: composition is contradicted for the stipulated solar proxy; other required physical support remains unresolved.', conditions=[], evidence=['composition_experiment','column_comparison']),
             dict(kind='numerical_evaluation', status='documented', description='Finite numerical controls only; see retained exact tests and provider validity checks.',
                  conditions=['Float64; finite positive material state; admissible atomic/H-minus rates; nonnegative slab extinction; converged atmospheric/wind roots with nonsingular Jacobians.',
                              'Default Cloudy-style low-temperature extrapolation stops at 4000 K; no silent clipping or fallback spectrum.',
                              'Fixed input/geometry/atom choices are not a validated continuous parameter envelope.'], evidence=['formulation','execution'])],
    subjects=[dict(id=SUBJECT, implementation=implementation, selected_files=selected)],
    contexts=[dict(id=CONTEXT, scope='Actual HydrogenAtmosphereModel.spectrum plus explicitly qualified numerical controls and intended KELT-9b-like use. Each Claim states which evidence applies; no component support is silently promoted to physical support.',
                   settings=dict(native_composition='pure-H; optional trace-LTE H-minus',
                                 shell_collision_model='anderson_n45 (new default); n>5 remains VS80, unlike C23 default Lebedev',
                                 target_composition='solar, explicitly selected by the user; author composition unknown',
                                 internal_transfer='static slab CRD; normal stellar beam',
                                 thermal_closure='local SE, gamma=5/3; thermal advection and expansion',
                                 wind_outer_radius_rp=32.,
                                 physical_inputs='review.json: prescribed PHOENIX proxy/profile hashes; not author configuration',
                                 numerical_control='review.json/tests: four layers, nmax=3, blackbody, Mdot=1e15 g/s',
                                 publication_processing='not recovered'))],
    claims=claims, evidence=evidences, equations=equations, bindings=bindings,
    assessments=assessments, follow_ups=followups,
)
path = ROOT / 'mceg/contracts/escape.coupled_atmosphere.yaml'
eqs = {e['id']: Equation.model_validate(e) for e in equations}
bs = {b['id']: EquationBinding.model_validate(b) for b in bindings}
for assessment, claim in zip(assessments, claims):
    ids = {e['id'] for e in claim['equations']}
    if ids:
        assessment['equation_pins'] = [dict(id=ref['id'], revision='1', sha256=equation_digest(eqs[ref['id']])) for ref in claim['equations']]
        assessment['binding_pins'] = [dict(id=b.id, sha256=binding_digest(b)) for b in bs.values() if b.equation.id in ids]
path.write_text(yaml.safe_dump(contract, sort_keys=False, width=100, allow_unicode=False))
validated = load_contract(path)
contract['decisions'] = [dict(
    id='target_composition', revision='1', subject=SUBJECT, context=CONTEXT,
    question='Which chemical composition defines the current target and reference comparisons?',
    scope='Current requested solar-composition atmosphere. This does not waive any scientific-readiness requirement.',
    options=[dict(id='solar', description='Use explicitly specified Cloudy-default solar abundances as the target and quantify necessary native He/metal physics.'),
             dict(id='pure_h', description='Restrict the scientific target to a pure-H atmosphere, without a solar adequacy claim.')],
    selected='solar',
    reasons=['The user explicitly selected solar composition on 2026-11-23.',
             'The retained solar counterexample identifies dominant heating missing from the current pure-H implementation.'],
    basis=[dict(kind='assessment', id='composition_reduction_review',
                sha256=decision_basis_digest(validated, 'assessment', 'composition_reduction_review'))],
    limitations=['The author abundance choice remains unknown. This target choice supplies no support for the contradicted reduction or for Cloudy equivalence.'],
    reconsider_when=['The user changes the target composition or the authors provide their complete abundance/input configuration.'],
)]
path.write_text(yaml.safe_dump(contract, sort_keys=False, width=100, allow_unicode=False))
validated = load_contract(path)
use = dict(schema_version='0.1', id='escape.yapeng_structure',
           purpose='Treat the selected native spectrum as adequate for Yapeng-style atmospheric interpretation, including explicitly required composition, transfer and observation checks. Author inputs remain unknown.',
           mode='scientific', target=dict(contract='../contracts/escape.coupled_atmosphere.yaml', subject=SUBJECT, context=CONTEXT, entry_point=review['entry_point']),
           requirements=[dict(assessment=a.id, role='implementation' if i<3 else 'physical_support',
                              sha256=decision_basis_digest(validated, 'assessment', a.id)) for i,a in enumerate(validated.assessments)])
(ROOT / 'mceg/uses/yapeng_atmosphere.yaml').write_text(yaml.safe_dump(use, sort_keys=False, width=100))
print(json.dumps({'tests_ready': bool(test_ready), 'claims': len(claims), 'equations': len(equations), 'bindings': len(bindings), 'artifacts': [p.name for p in DEST.iterdir()]}))
