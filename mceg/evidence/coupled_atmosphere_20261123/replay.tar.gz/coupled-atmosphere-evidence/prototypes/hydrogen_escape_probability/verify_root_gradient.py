"""Check the implicit derivative of the converged EP population root."""
from pathlib import Path
import json
import jax
import jax.numpy as jnp
import numpy as np
from native_slab import EPSlab
jax.config.update('jax_enable_x64',True)
root=Path(__file__).resolve().parent
model=EPSlab(15,16,1e18,1e12,8000.,scattering_attenuation=True)
initial=jnp.asarray(np.load(root/'native_n15_col18_z16_v3/solution.npz')['state'])
def observable(theta):
 solution=model.solve(1e12*jnp.exp(theta[0]),.025*jnp.exp(theta[1]),initial)
 value=jnp.log(jnp.mean(solution['bound_cm3'][:,3:6].sum(axis=1)))
 return jnp.where(solution['converged'],value,jnp.nan)
zero=jnp.zeros(2)
grad=np.asarray(jax.jit(jax.grad(observable))(zero))
epsilon=1e-4
fd=np.array([(float(observable(zero+jnp.eye(2)[i]*epsilon))-float(observable(zero-jnp.eye(2)[i]*epsilon)))/(2*epsilon) for i in range(2)])
error=abs(grad-fd)
report=dict(observable='log mean(n3) at fixed geometry/T, free populations and radiative feedback',parameters=['log nH','log dilution'],
 derivative=grad.tolist(),finite_difference=fd.tolist(),absolute_error=error.tolist(),
 passed=bool(np.all(np.isfinite(grad)) and np.all(error<1e-6+2e-5*abs(fd))))
(root/'root_gradient.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
