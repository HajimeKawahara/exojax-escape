// Read-only diagnostic inclusion of the unmodified C23.01 implementation.
#include "/tmp/cloudy-reference-run/c23.01/source/opacity_createall.cpp"
#include <iostream>
#include <iomanip>
int main() {
  hydro.DampOnFac=1.;
  std::cout<<std::setprecision(17);
  double energy;
  while(std::cin>>energy)std::cout<<rayleh(energy)<<"\n";
}
