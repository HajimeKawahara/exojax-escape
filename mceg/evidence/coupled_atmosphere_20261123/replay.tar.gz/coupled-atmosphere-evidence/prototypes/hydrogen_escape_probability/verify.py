"""Compare JAX ports to unchanged C23 kernels; check AD and photon accounting."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess

import jax
import jax.numpy as jnp
import numpy as np

import line_closure as closure

jax.config.update("jax_enable_x64",True)
ROOT=Path(__file__).resolve().parent
SOURCE=Path("/tmp/cloudy-causal-rates/source")


def sample(executable, values):
    process=subprocess.run([str(ROOT/executable)],input="\n".join(" ".join(format(float(x),".17g") for x in row) for row in values)+"\n",
                           text=True,capture_output=True,check=True)
    return np.array([[float(x) for x in line.split()] for line in process.stdout.splitlines()])


def difference(expected,actual,*,rtol=8e-7,atol=1e-35):
    relative=abs(actual-expected)/np.maximum(abs(expected),atol)
    passed=np.all(np.isfinite(actual)) and np.all(abs(actual-expected)<=atol+rtol*abs(expected))
    return dict(passed=bool(passed),maximum_relative_error=float(relative.max()),rtol=rtol,atol=atol)


def rounded_difference(expected,actual,budget):
    allowed=budget+2e-6*abs(expected)+1e-35
    return dict(passed=bool(np.all(np.isfinite(actual)) and np.all(abs(actual-expected)<=allowed)),
                maximum_error_over_roundoff_budget=float(np.max(abs(actual-expected)/allowed)),
                maximum_absolute_error=float(np.max(abs(actual-expected))),
                explanation="Absolute budget propagates C23 realnum escape-probability rounding through 1-Pesc; JAX retains float64")


def main():
    rng=np.random.default_rng(1729)
    tau=np.r_[0.,np.geomspace(1e-9,1e12,65)]
    inputs=np.array([[t,a,b,al,d] for t in tau for a in (1e-5,5.275e-4,.01,1.)
                     for b,al in ((0.,0.),(1e-10,0.),(1e-6,.3),(.01,.7)) for d in (0.,.01,1e3)])
    expected=sample("sample_c23.exe",inputs)
    t,a,b,al,d=map(jnp.asarray,inputs.T)
    e,de=closure.lya_one_side(t,b,al)
    actual=np.stack([closure.doppler_core_escape(t),closure.crd_wing_escape(t,a),closure.prd_escape(t,a),
                     e,de,closure.federman_shield(t,a),closure.federman_shield(t,a,d)],axis=1)
    checks={name:difference(expected[:,i],actual[:,i]) for i,name in enumerate(
        ("doppler_core","crd_wing","prd","lya_escape","lya_destruction","federman_point","federman_zone_average"))}
    stable=(inputs[:,4]==0)|(inputs[:,4]/(1+inputs[:,0])>=1e-7)
    checks["federman_zone_average"]=difference(expected[stable,6],actual[stable,6])
    checks["lya_destruction"]=rounded_difference(expected[:,4],actual[:,4],2*np.finfo(np.float32).eps*(1-inputs[:,3]))
    checks["federman_log_cancellation"]={"passed":bool(np.all(np.isfinite(actual[~stable,6]))),
        "intentional_change":"log1p(delta_tau/(1+tau)) replaces log(1+delta_tau/(1+tau)); avoids cancellation in the C23 arithmetic",
        "maximum_relative_difference_from_c23":float(np.max(abs(actual[~stable,6]/expected[~stable,6]-1))),
        "maximum_absolute_difference_from_c23":float(np.max(abs(actual[~stable,6]-expected[~stable,6])))}

    inverted=np.array([[t,a,0.,0.,-.01] for t in (-29.,-5.,-.5,-.11,-.1,-.09,-1e-6)
                       for a in (1e-5,.001,.1)])
    inverted_c23=sample("sample_c23.exe",inverted)
    t,a,_,_,delta=map(jnp.asarray,inverted.T)
    inverted_jax=np.stack([closure.doppler_core_escape(t),closure.crd_wing_escape(t,a),
                          closure.prd_escape(t,a),closure.federman_shield(t,a),closure.federman_shield(t,a,delta)],axis=1)
    checks["bounded_maser_kernels"]=difference(inverted_c23[:,[0,1,2,5,6]],inverted_jax,rtol=1e-12)
    energy=np.unique(np.r_[np.geomspace(1e-5,2.,101),.05,.646,.74959-.001,.74959,.74959+.001,1.])
    rayleigh_c23=sample("sample_rayleigh.exe",energy[:,None])[:,0]
    checks["rayleigh_cross_section"]=difference(rayleigh_c23,np.asarray(closure.hydrogen_rayleigh_cross_section(energy)),rtol=1e-12)

    count=300
    kind=np.arange(count)%4
    tin=10**rng.uniform(-6,9,count)
    tout=10**rng.uniform(-6,9,count)
    lp=10**rng.uniform(-18,-5,count)
    op=np.column_stack((kind,tin,tin+tout,10**rng.uniform(-6,9,count),10**rng.uniform(-5,-2,count),
                       lp,lp*1.1,np.where(np.arange(count)%2,0.,lp*3),lp*10**rng.uniform(-12,-1,count),
                       10**rng.uniform(4,13,count),10**rng.uniform(6,9,count),np.full(count,2.),
                       np.full(count,6.),10**rng.uniform(-12,-3,count),10**rng.uniform(-15,-6,count),
                       10**rng.uniform(2,10,count),10**rng.uniform(-1,8,count),rng.uniform(0,.8,count)))
    # C23 stores these inputs as realnum. Compare identical stored states,
    # including its float32 tau_total-tau_in cancellation near a slab edge.
    float32_columns=[1,2,3,4,10,13,14]
    op[:,float32_columns]=op[:,float32_columns].astype(np.float32).astype(float)
    def evaluate(data):
        k,ti,tt,tp,a,kl,klo,km,kc,ne,A,gl,gu,ni,no,dz,nu,al=map(jnp.asarray,data.T)
        return closure.line_operators(k,tau_in=ti,tau_total=tt,tau_pump=tp,damping=a,
            line_extinction_cm1=kl,lower_absorption_cm1=klo,multiplet_extinction_cm1=km,
            continuum_absorption_cm1=kc,electron_cm3=ne,einstein_a_s=A,lower_weight=gl,upper_weight=gu,
            incident_occupation=ni,outward_continuum_occupation=no,zone_width_cm=dz,
            upper_population_cm3=nu,albedo=al)
    operator_expected=sample("sample_operators.exe",op)
    operator_actual=np.asarray(evaluate(op)).T
    stable_op=((op[:,5]+op[:,8])*op[:,15]<=1e-3)|((op[:,5]+op[:,8])*op[:,15]/(1+op[:,3])>=1e-7)
    checks.update({"operator_"+name:difference(operator_expected[stable_op,i],operator_actual[stable_op,i],rtol=2e-6)
                   for i,name in enumerate(closure.LineOperators._fields)})
    eps=np.finfo(np.float32).eps
    effective=np.where(op[:,7]>0,op[:,7],op[:,5])
    beta=op[:,8]/(np.sqrt(np.pi)*effective+op[:,8])
    fit=np.minimum(1e-3,8.5*beta)
    dest_budget=np.where(op[:,0]==0,2*eps*(1-op[:,-1]),eps*fit/(1+fit))
    electron=op[:,9]*closure.SIGMA_THOMSON
    eratio=electron/(electron+np.where(op[:,7]>0,op[:,7],op[:,6]))
    for i,budget in ((1,dest_budget),(2,eratio*(eps+dest_budget)),(6,dest_budget*op[:,10]*op[:,16])):
        checks["operator_"+closure.LineOperators._fields[i]]=rounded_difference(operator_expected[stable_op,i],operator_actual[stable_op,i],budget[stable_op])

    inverted_op=op[:30].copy()
    inverted_op[:,0]=1+np.arange(30)%3
    inverted_op[:,1]=-np.geomspace(1e-6,5.,30)
    inverted_op[:,2]=2*inverted_op[:,1]
    inverted_op[:,3]=inverted_op[:,1]
    inverted_op[:,5]=-abs(inverted_op[:,5])
    inverted_op[:,7]=0.
    inverted_op[:,8]=np.minimum(inverted_op[:,8],abs(inverted_op[:,5])/2)
    inverted_op[:,float32_columns]=inverted_op[:,float32_columns].astype(np.float32).astype(float)
    inverted_operator_c23=sample("sample_operators.exe",inverted_op)
    inverted_operator_jax=np.asarray(evaluate(inverted_op)).T
    checks["bounded_maser_operators"]=difference(inverted_operator_c23[:,[0,1,3,4,5,6]],inverted_operator_jax[:,[0,1,3,4,5,6]],rtol=2e-6)
    einv=inverted_op[:,9]*closure.SIGMA_THOMSON
    checks["bounded_maser_electron_roundoff"]=rounded_difference(inverted_operator_c23[:,2],inverted_operator_jax[:,2],
                                                               np.finfo(np.float32).eps*einv/(einv+inverted_op[:,6]))

    def grad_function(theta):
        row=jnp.asarray(op[122:123])
        row=row.at[0,1:4].multiply(jnp.exp(theta[0]))
        row=row.at[0,8].multiply(jnp.exp(theta[1]))
        row=row.at[0,13:15].multiply(jnp.exp(theta[2]))
        return jnp.log(jnp.asarray(evaluate(row))[:,0])
    theta=jnp.zeros(3)
    derivative=np.asarray(jax.jacrev(grad_function)(theta))
    step=1e-5
    numerical=np.column_stack([(np.asarray(grad_function(theta+jnp.eye(3)[i]*step))-
                                np.asarray(grad_function(theta-jnp.eye(3)[i]*step)))/(2*step) for i in range(3)])
    checks["operator_ad_vs_finite_difference"]=difference(numerical,derivative,rtol=3e-5,atol=1e-9)

    photons=jnp.array([1e10,2e10])
    frequency=jnp.array([2.466e15,2.923e15])
    opacity=jnp.array([[1e-10,2e-10],[4e-10,5e-10]])
    threshold=jnp.array([3.4,1.51])*1.602176634e-12
    density=jnp.array([1e7,2e7])
    total=opacity.sum(axis=1)*2  # Half the opacity deliberately remains unresolved.
    result=closure.on_the_spot_return(photons,frequency,opacity,density,threshold,total)
    checks["ots_photon_conservation"]=difference(np.asarray(photons),np.asarray(result.absorbed_photons_cm3_s.sum(axis=-1)+result.unresolved_photons_cm3_s),rtol=1e-13)
    absorbed_energy=result.absorbed_photons_cm3_s*closure.PLANCK*frequency[:,None]
    recorded=result.photoelectron_heating_erg_cm3_s+result.absorbed_photons_cm3_s*threshold
    checks["ots_excess_energy_accounting"]=difference(np.asarray(absorbed_energy),np.asarray(recorded),rtol=1e-13)
    checks["missing_opacity_returned_not_heated"]=dict(passed=bool(np.allclose(result.unresolved_photons_cm3_s,photons/2)),unresolved_fraction=.5)
    report=dict(scope="Primitive/operator equivalence to C23 with supplied external continuum and columns; no atmospheric/population equivalence claimed",
                kernel_samples=len(inputs),operator_samples=count,operator_strict_samples=int(stable_op.sum()),
                c23_float32_input_columns=float32_columns,checks=checks,
                passed=all(x["passed"] for x in checks.values()),
                limitations=["Continuum transport, coupled column/population root, and metal chemistry are external",
                             "No moving-medium transfer or saturated masers; bounded C23 gain is tested",
                             "Upper-lifetime internal damping must be supplied; observer damping is separate",
                             "OTS must be fed back into all absorber photo-rates before a closure is self-consistent"],
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in
                               [ROOT/"line_closure.py",ROOT/"sample_c23.cpp",ROOT/"sample_operators.cpp",Path(__file__),
                                SOURCE/"rt_escprob.cpp",SOURCE/"rt_continuum_shield_fcn.cpp",SOURCE/"rt_line_one.cpp",
                                SOURCE/"libcloudy.a",ROOT/"sample_rayleigh.cpp",
                                Path("/tmp/cloudy-reference-run/c23.01/source/opacity_createall.cpp")]})
    np.savez_compressed(ROOT/"comparison.npz",kernel_inputs=inputs,kernel_c23=expected,kernel_jax=actual,
                        operator_inputs=op,operator_c23=operator_expected,operator_jax=operator_actual,
                        gradient_ad=derivative,gradient_fd=numerical,
                        inverted_kernel_inputs=inverted,inverted_kernel_c23=inverted_c23,inverted_kernel_jax=inverted_jax,
                        inverted_operator_inputs=inverted_op,inverted_operator_c23=inverted_operator_c23,
                        inverted_operator_jax=inverted_operator_jax,rayleigh_energy_ryd=energy,rayleigh_c23=rayleigh_c23)
    print(json.dumps(checks,indent=2),flush=True)
    (ROOT/"verification.json").write_text(json.dumps(report,indent=2,allow_nan=False)+"\n")
    print(json.dumps({"passed":report["passed"],"checks":checks},indent=2))
    if not report["passed"]:
        raise SystemExit(1)


if __name__=="__main__":
    main()
