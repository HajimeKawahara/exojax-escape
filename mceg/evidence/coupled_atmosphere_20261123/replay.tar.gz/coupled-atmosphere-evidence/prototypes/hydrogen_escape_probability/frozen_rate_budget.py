from pathlib import Path
import sys,json
import numpy as np
sys.path.insert(0,'/tmp/escape-coupled-atmosphere/tools')
from cloudy_rates_diagnosis import rate_blocks,solve_frozen,matrix
p=Path(__file__).resolve().parent
raw=np.load(p/'col21_rates/operators.npz');op={k:v.tolist() for k,v in raw.items()};c=rate_blocks(op)
a=dict(np.load(p/'col21_rates/frozen_native_rates.npz'))
ne=op['header'][4];proton=op['header'][7];n=np.array(op['solution']);results={}
for key in ['all_cloudy','all_native',*c]:
 rates=c.copy()
 if key=='all_native':rates=a.copy()
 elif key!='all_cloudy':rates[key]=a[key]
 solution=solve_frozen(rates,1e12,ne)
 results[key]={k:v for k,v in solution.items() if k!='bound_cm3'}
 report=matrix(rates,ne);res=proton*report[1]-report[0]@n
 results[key]['n3_net_production_at_cloudy_cm3_s']=float(sum(res[3:6]))
results['definition']='Frozen coefficient swap at C23 final zone8 NH1e21, fixed ne and boundary/state; no global re-equilibration. Ratios are diagnostic, not additive causal fractions.'
(p/'frozen_rate_swaps.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
for label,r in [('cloudy',c),('native',a)]:
 print(label,'low-level photo',r['photoionization_s'][:6], 'recomb',r['radiative_recombination_cm3_s'][:6])
print('collisional ratio resolved low6')
print(np.divide(a['electron_bound_bound_cm3_s'][:6,:6],c['electron_bound_bound_cm3_s'][:6,:6],out=np.ones((6,6)),where=c['electron_bound_bound_cm3_s'][:6,:6]!=0))
