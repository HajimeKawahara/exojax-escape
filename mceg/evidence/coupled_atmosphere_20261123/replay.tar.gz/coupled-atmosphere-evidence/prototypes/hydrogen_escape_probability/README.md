# Conditional C23 hydrogen closure experiment

This evidence tests fixed-temperature, fixed-density pure-H slabs, not a solar
planetary atmosphere or a fit. Each slab uses T=8000 K, nH=1e12 cm^-3,
blackbody irradiation Tstar=10000 K with W=0.025, a normal incoming beam,
16 uniform cells, and the same truncated nmax=15 atom (three resolved shells).

The native prototype closes populations, continuum radiation, line escape
probabilities, and absorption of destroyed line photons into the H bound-free
rates. The line closure uses C23 Doppler-core escape for higher Lyman lines,
its separate Ly-alpha fit, wing escape for subordinate lines, Stark escape,
and electron escape. Line pumping excludes trapped local line radiation.
Destroyed photons are returned as photoionization and induced recombination;
they are not all classified as heat. Internal line damping uses only the upper
lifetime, as C23 does; this does not change the observer's damping convention.

`verification.json` compares primitives against unchanged C23 functions,
including its limited gain branch and Rayleigh cross section. `root_gradient.json`
checks the implicit derivative of a converged population root against finite
differences in density and radiation dilution. These numerical checks are not
claims of atmospheric equivalence.

The remaining thick-slab error was traced through a final C23 statistical-
equilibrium matrix. Swapping native radiative line coefficients alone changed
n3 by 0.071%; swapping the older shell-collision matrix changed it by 68.15%.
The n3-to-n4 and n3-to-n5 collision channels accounted for 95.7% of the net
collisional residual at that frozen state. Unlike the previous VS80+A-branch
approximation, C23 sums the Anderson n=4,5 orbital collision strengths.
`higher_collision_verification.json` compares the 13 summed pairs at 8
independent temperatures with the actual C23 HlikeCSInterp function.

With that correction, the thick-slab central n3 discrepancy falls from 42.98%
to 4.01%. The illuminated two coarse cells still differ by 23.8% and31.5%; all
other cells differ by <=4.25%. The thinner slab has maximum n2/n3 differences
3.96%/3.98%. Do not omit the surface counterexample or infer spatial convergence.
`population_comparison.png` shows both atomic choices and the C23 reference.

Known remaining differences include the C23 front-of-zone continuum convention,
continuum diffuse/scattering approximations, transported two-photon radiation,
and higher-shell collisions above n=5. The optional per-zone scattering
attenuation reproduces C23's 1/(1+tau_sct) approximation; it is not a conservative
angular scattering solution and is never counted as gas absorption/heating.
Cloudy's forced first zone warns that it is larger than optimal. Uniform 16-cell
results are matched-grid diagnostics, not a grid-converged physical atmosphere.

## Reproduce

Use the repository's current source plus the retained ExoJAX AdbNist version.
Enable JAX float64 (the drivers do), CPU execution, and single-thread BLAS.
The C23 installation used here is `/tmp/cloudy-reference-run/c23.01`; the
primitive harnesses also reference an earlier C23 tree with unchanged kernel
files. Edit these paths to your local C23.01 distribution before compiling.
The upstream archive, data, library and executable hashes are recorded in the
receipts and verification records; executable/object files are not included.

Compile a diagnostic harness with `g++ -std=c++11 -O2 -no-pie -fno-pie`, the
C23 source include directory, and `-L<C23/source> -lcloudy`. `sample_hcs.cpp`
requires `CLOUDY_DATA_PATH=<C23/data>`. The readout executables link
`maincl.o`, the retained modified diagnostic object(s), and the original
library. Readout changes only print values; they do not change rates.

Run `verify.py` and `verify_higher_collisions.py` after compilation. For each
column, invoke `native_slab.py --reference <case>/profile.npz --output <output>
--nmax 15 --cells 16 --column <NH> --scattering-attenuation
--collision-model <vs80|anderson_n45>` (separate option names and numbers in the
actual command). Run the gradient and summary scripts afterwards. The scripts
retain the historical `/tmp/escape-ep-prototype` path in some defaults; adapt
those paths to this evidence directory. Derived arrays and raw C23 output are
both retained. No raw PHOENIX spectrum is included.
