// Diagnostic-only calls into unchanged C23.01 H collision-table code.
#include "/tmp/cloudy-reference-run/c23.01/source/hydrocollid.cpp"
#include "cddrive.h"
#include <iostream>
#include <iomanip>
int main(){
 cdInit();
 iso_sp[ipH_LIKE][ipHYDROGEN].n_HighestResolved_max=3;
 std::cout<<std::setprecision(17);
 std::cerr<<std::setprecision(17)<<"COLL_CONST "<<COLL_CONST<<"\n";
 double temperature; long nhi,nlo,llo;
 while(std::cin>>temperature>>nhi>>nlo>>llo){
  phycon.te=temperature;
  std::cout<<HlikeCSInterp(ipHYDROGEN,ipELECTRON,nhi,-1,2,nlo,llo,2)<<"\n";
 }
}
