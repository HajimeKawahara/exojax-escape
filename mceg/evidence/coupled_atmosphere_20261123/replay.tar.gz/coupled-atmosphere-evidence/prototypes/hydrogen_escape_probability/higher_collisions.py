"""Conditional C23 Anderson et al. (2000/2002) n=4,5 collision-table adapter.

Data derived from C23 h_coll_str.dat by summing collision strengths over every
l sublevel in each collapsed shell, as HlikeCSInterp does; not by radiative A.
Original source/data: Cloudy (C)1978--2023 Gary J. Ferland et al.; see license.
Linear interpolation in temperature and the explicit low-T Cloudy extension
are approximations inherited from that implementation. Existing n<=3 and
n>5 collision prescriptions are intentionally untouched in this control.
"""
from pathlib import Path
import json
import jax.numpy as jnp
import numpy as np

DATA=json.loads(Path(__file__).with_name('higher_collision_strengths.json').read_text())
TEMPERATURE=jnp.asarray(DATA['temperature_k'])
STRENGTH=jnp.asarray(DATA['strength'])
UPPER=jnp.asarray(DATA['upper_index'])
LOWER=jnp.asarray(DATA['lower_index'])


def replace_n45_collisions(atom,temperature,coefficients):
    """Replace only n=4,5 shell rates, preserving detailed balance."""
    active=np.asarray(DATA['upper_index'])<len(atom.principal_n)
    upper,lower=UPPER[active],LOWER[active]
    strength=STRENGTH[active]
    upsilon=jnp.array([jnp.interp(temperature,TEMPERATURE,row) for row in strength])
    upsilon=jnp.where(temperature<TEMPERATURE[0],strength[:,0]*temperature/TEMPERATURE[0],upsilon)
    down=8.6291321808518402e-6*upsilon/(atom.statistical_weights[upper]*jnp.sqrt(temperature))
    up=down*atom.statistical_weights[upper]/atom.statistical_weights[lower]*jnp.exp(
        -(atom.excitation_energy_erg[upper]-atom.excitation_energy_erg[lower])/(1.380649e-16*temperature))
    return coefficients.at[upper,lower].set(down).at[lower,upper].set(up)
