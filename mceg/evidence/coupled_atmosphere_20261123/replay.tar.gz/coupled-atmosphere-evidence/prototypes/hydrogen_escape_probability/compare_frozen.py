"""Evaluate the native construction at the exact retained Cloudy populations."""
import json
from pathlib import Path
import jax
import jax.numpy as jnp
import numpy as np
from native_slab import EPSlab
jax.config.update('jax_enable_x64',True)
root=Path(__file__).resolve().parent
report={}
for case,column in [('col18_allstates',1e18),('col21_allstates',1e21)]:
 model=EPSlab(15,16,column,1e12,8000.,scattering_attenuation=True)
 ref=np.load(root/case/'profile.npz'); states=np.load(root/case/'ep_states.npz')['values']; states=states[states[:,1]>0]
 bound=jnp.asarray(ref['bound_cm3'][::-1]); ne=jnp.asarray(ref['electron_cm3'][::-1])
 result=jax.jit(model.population_state)(bound,ne,ne,.025)
 actual={k:np.asarray(v) for k,v in result.items() if not isinstance(v,tuple)}
 ops=np.asarray(result['line_operators']); np.savez_compressed(root/case/'frozen_native.npz',**actual,operators=ops)
 out={}
 for hi,lo,label in ((2,0,'Lyalpha'),(4,0,'Lybeta'),(3,2,'Halpha_3s'),(4,1,'Halpha_3p'),(5,2,'Halpha_3d')):
  subset=states[(states[:,2]==hi)&(states[:,3]==lo)]; iz=16-subset[:,1].astype(int)
  il=np.flatnonzero((np.asarray(model.atom.line_upper)==hi)&(np.asarray(model.atom.line_lower)==lo))[0]
  pairs={'tau_in':(actual['tau_in'][iz,il],subset[:,6]),'tau_total':(np.broadcast_to(actual['tau_total'][il],len(iz)),subset[:,7]),
         'line_opacity':(actual['line_extinction_cm1'][iz,il],subset[:,10]),
         'continuum_opacity':(actual['line_continuum_absorption_cm1'][iz,il],subset[:,13]),
         'multiplet_opacity':(actual['multiplet_extinction_cm1'][iz,il],subset[:,12]),
         'albedo':(actual['line_albedo'][iz,il],subset[:,22]),
         'external_occupation':(actual['pump_occupation'][iz,il],subset[:,18]+subset[:,19]),
         'escape':(ops[0,iz,il],subset[:,23]),'destruction':(ops[1,iz,il],subset[:,24]),'pump':(ops[3,iz,il],subset[:,26])}
  out[label]={k:{'median_ratio':float(np.median(a[b!=0]/b[b!=0])), 'max_ratio':float(np.max(a[b!=0]/b[b!=0])), 'min_ratio':float(np.min(a[b!=0]/b[b!=0]))} for k,(a,b) in pairs.items() if (b!=0).any()}
 report[case]=out
(root/'frozen_final_comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
