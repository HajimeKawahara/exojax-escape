"""Retain conditional population comparisons without atmospheric support labels."""
from pathlib import Path
import hashlib,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent
summary={'scope':'Fixed T8000 K, nH1e12 cm-3, BB10000 K W0.025, matched16-zone H nmax15 slab; no solar atmosphere equivalence',
 'closure':'C23 EP plus formal continuum, C23 attenuation approximation, upper lifetime, Stark escape, H OTS feedback',
 'boundary':'Normal incident beam at top; no bottom incoming intensity',
 'unsupported':['NH1e21 population agreement','spatial convergence','conservative continuum scattering','transported two-photon continuum','full solar thermal/chemical closure'],
 'cases':{}}
fig,axes=plt.subplots(2,3,figsize=(11.5,6.5),sharex=True)
for i,c in enumerate(['18','21']):
 ref=np.load(p/('col'+c)/'profile.npz');directory=p/('native_n15_col'+c+'_final');got=np.load(directory/'solution.npz')
 q=np.argsort(got['depth_cm']);x=got['depth_cm'][q]/10**(int(c)-12)
 r=ref['bound_cm3'];a=got['bound_cm3'][q]
 corrected=np.load(p/('native_n15_col'+c+'_anderson')/'solution.npz')
 corrected_bound=corrected['bound_cm3'][q]
 corrected_outputs={'n2':corrected_bound[:,1:3].sum(axis=1),'n3':corrected_bound[:,3:6].sum(axis=1),'electron':corrected['electron_cm3'][q]}
 outputs={'n2':(r[:,1:3].sum(axis=1),a[:,1:3].sum(axis=1)),'n3':(r[:,3:6].sum(axis=1),a[:,3:6].sum(axis=1)),
          'electron':(ref['electron_cm3'],got['electron_cm3'][q])}
 case={'converged':bool(got['converged']),'root_residual':float(got['residual_norm']),
       'continuum_residual':float(got['continuum_transfer_error']),'populations':{}}
 for j,(key,(b,a)) in enumerate(outputs.items()):
  ratio=a/b-1
  case['populations'][key]={'maximum_relative_difference':float(max(abs(ratio))),
                            'relative_difference_by_zone':ratio.tolist()}
  axes[i,j].plot(x,b,'o-',ms=3,label='Cloudy C23.01',color='black');axes[i,j].plot(x,a,'--',label='EP + legacy shell collisions',color='tab:orange')
  axes[i,j].plot(x,corrected_outputs[key],'-',label='EP + Anderson n=4,5',color='tab:blue')
  case['populations'][key]['anderson_maximum_relative_difference']=float(max(abs(corrected_outputs[key]/b-1)))
  axes[i,j].set_yscale('log');axes[i,j].set_title(f'$N_H=10^{{{c}}}$ cm$^{{-2}}$: {key}')
  axes[i,j].set_ylabel('Population [cm$^{-3}$]');axes[i,j].grid(alpha=.2)
  if i==1:axes[i,j].set_xlabel('Depth / total slab depth')
 summary['cases']['NH1e'+c]=case
axes[0,0].legend(fontsize=9)
fig.suptitle('Conditional fixed-state closure comparison; thick-slab discrepancy remains')
fig.tight_layout();fig.savefig(p/'population_comparison.png',dpi=180)
summary['anderson_table_verification']=json.loads((p/'higher_collision_verification.json').read_text())
summary['kernel_verification']=json.loads((p/'verification.json').read_text())['passed']
summary['implicit_gradient']=json.loads((p/'root_gradient.json').read_text())
summary['source_sha256']={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in
                        [p/'native_slab.py',p/'line_closure.py',p/'sample_c23.cpp',p/'sample_operators.cpp',p/'sample_rayleigh.cpp',
                         p/'rt_line_one_final.cpp',p/'iso_level_readout.cpp',p/'verify.py',p/'verify_root_gradient.py',Path(__file__)]}
(p/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:{f:v for f,v in d.items() if f!='populations'} for k,d in summary['cases'].items()},indent=2))
