"""Attribute the remaining thick-slab residual at frozen C23 populations."""
from pathlib import Path
import sys,json
import jax
import jax.numpy as jnp
import numpy as np
sys.path.insert(0,'/tmp/escape-coupled-atmosphere/tools')
from cloudy_rates_diagnosis import parse_operator,rate_blocks
from native_slab import EPSlab
jax.config.update('jax_enable_x64',True)
p=Path(__file__).resolve().parent
op=parse_operator(p/'col21_rates/model.out.gz')
np.savez_compressed(p/'col21_rates/operators.npz',**{k:np.asarray(v) for k,v in op.items()})
expected=rate_blocks(op)
print('reference keys',expected.keys(),flush=True)
m=EPSlab(15,16,1e21,1e12,8000.,scattering_attenuation=True)
ref=np.load(p/'col21/profile.npz');bound=jnp.asarray(ref['bound_cm3'][::-1]);ne=jnp.asarray(ref['electron_cm3'][::-1])
r=jax.jit(m.population_state)(bound,ne,ne,.025)
iz=16-8;n=np.asarray(bound[iz]);e=float(ne[iz]);rates=r['rates'];print('native',rates._fields,flush=True)
np.savez_compressed(p/'col21_rates/frozen_native_rates.npz',**{k:np.asarray(v)[iz] for k,v in rates._asdict().items()})
actual={k:np.asarray(v)[iz] for k,v in rates._asdict().items()}
report={}
for key,v in expected.items():
 if key not in actual:continue
 a=np.asarray(actual[key]);b=np.asarray(v); mask=abs(b)>1e-30
 report[key]=dict(maximum_relative_difference=float(np.max(abs(a[mask]/b[mask]-1))),median_ratio=float(np.median(a[mask]/b[mask])))
print(json.dumps(report,indent=2),flush=True)
(p/'frozen_rate_comparison.json').write_text(json.dumps(report,indent=2)+'\n')
