"""Compare grouped-table interpolation against unchanged HlikeCSInterp."""
from pathlib import Path
import subprocess,json,os
import jax
import numpy as np
jax.config.update('jax_enable_x64',True)
import higher_collisions as data
p=Path(__file__).resolve().parent
rows=[];actual=[];n=[1,2,2,3,3,3,4,5];ell=[0,0,1,0,1,2,-1,-1]
for t in [4000.,4500.,5802.,6000.,8000.,11604.,12000.,14000.]:
 for upper,lower,strength in zip(data.DATA['upper_index'],data.DATA['lower_index'],data.DATA['strength']):
  rows.append([t,n[upper],n[lower],ell[lower]])
  actual.append(np.interp(t,data.DATA['temperature_k'],strength) if t>=5802 else strength[0]*t/5802)
process=subprocess.run([str(p/'sample_hcs.exe')],input='\n'.join(' '.join(map(str,r)) for r in rows)+'\n',
                       text=True,capture_output=True,check=True,env=dict(os.environ,CLOUDY_DATA_PATH='/tmp/cloudy-reference-run/c23.01/data'))
expected=np.array([float(v) for v in process.stdout.splitlines()]);actual=np.array(actual)
error=abs(actual/expected-1)
report=dict(samples=len(expected),max_relative_error=float(max(error)),passed=bool(np.all(error<3e-7)),cloudy_constants=process.stderr.strip(),
 scope='13 grouped n4/5 collision-strength pairs over4000–14000K; same C23 piecewise-linear interpolation and bounded low-T extrapolation')
(p/'higher_collision_verification.json').write_text(json.dumps(report,indent=2)+'\n');np.savez_compressed(p/'higher_collision_verification.npz',inputs=rows,c23=expected,native=actual)
print(json.dumps(report,indent=2))
