// Diagnostic harness: original C23.01 function bodies are included unchanged.
// Cloudy (C) 1978--2023 Gary J. Ferland et al.; see Cloudy_LICENSE.txt.
#include "/tmp/cloudy-causal-rates/source/rt_escprob.cpp"
#include "/tmp/cloudy-causal-rates/source/rt_continuum_shield_fcn.cpp"
#include <iostream>
#include <iomanip>

int main() {
    opac.albedo.resize(1);
    double tau, damping, beta, albedo, delta;
    std::cout << std::setprecision(17);
    while (std::cin >> tau >> damping >> beta >> albedo >> delta) {
        opac.albedo[0] = albedo;
        realnum esc, dest;
        if(tau>=0) RTesc_lya_1side(tau,beta,&esc,&dest,0); else esc=dest=0.;
        double shield=shieldFederman(tau,damping,false);
        double average=delta>1e-3 ? avg_shield(shield,shieldFederman(tau+delta,damping,false),delta,tau) : shield;
        std::cout << esca0k2(tau) << " " << esc_CRDwing_1side(tau,damping)
                  << " " << esc_PRD_1side(tau,damping) << " " << double(esc)
                  << " " << double(dest) << " " << shield << " " << average << "\n";
    }
}
