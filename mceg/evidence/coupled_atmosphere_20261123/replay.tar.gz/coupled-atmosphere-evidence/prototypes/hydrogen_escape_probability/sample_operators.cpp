// Diagnostic adapter for unchanged C23.01 function bodies; no model solve.
// Cloudy (C) 1978--2023 Gary J. Ferland et al.; see Cloudy_LICENSE.txt.
#include "/tmp/cloudy-causal-rates/source/rt_escprob.cpp"
#include "/tmp/cloudy-causal-rates/source/rt_continuum_shield_fcn.cpp"
#include "/tmp/cloudy-causal-rates/source/rt_line_one.cpp"
#include <iostream>
#include <iomanip>

int main() {
    qList states("prototype",3);
    TransitionList lines("prototype",&states,1);
    TransitionProxy t=lines[0];
    t.setLo(1); t.setHi(2); t.AddLine2Stack(); t.ipCont()=1;
    opac.albedo.resize(2); opac.opacity_abs.resize(2);
    rfield.OccNumbIncidCont.resize(2); rfield.OccNumbContEmitOut.resize(2);
    rfield.nflux=2; rfield.lgInducProcess=true;
    conv.lgFirstSweepThisZone=true; conv.nTotalIoniz=1;
    rt.lgAbsorLineEscape=true; rt.lgElecScatEscape=true; rt.lgElecScatInten=true;
    rt.nLineContShield=LINE_CONT_SHIELD_FEDERMAN; cosmology.lgDo=false; iteration=2;
    int kind;
    double tin,ttot,tpump,a,kl,klower,kmulti,kc,ne,A,gl,gu,nin,nout,dz,nupper,albedo;
    std::cout << std::setprecision(17);
    while(std::cin>>kind>>tin>>ttot>>tpump>>a>>kl>>klower>>kmulti>>kc>>ne>>A>>gl>>gu>>nin>>nout>>dz>>nupper>>albedo) {
        t.Emis().TauIn()=tin; t.Emis().TauTot()=ttot; t.Emis().TauCon()=tpump;
        t.Emis().damp()=a; t.Emis().PopOpc()=kl; t.Emis().opacity()=1.;
        t.Emis().mult_opac()=kmulti; t.Emis().Aul()=A;
        states[1].Pop()=klower; states[1].g()=gl; states[2].g()=gu;
        opac.opacity_abs[0]=kc; opac.albedo[0]=albedo; dense.eden=ne;
        radius.drad_x_fillfac=dz;
        rfield.OccNumbIncidCont[0]=nin; rfield.OccNumbContEmitOut[0]=nout;
        DestType destruction;
        if(kind==0) {
            double inward,dest;
            t.Emis().iRedisFun()=ipLY_A;
            t.Emis().Pesc()=RTesc_lya(&inward,&dest,kl,t,1.);
            destruction.t=DestType::ipDEST_LYA; destruction.dest=dest;
        } else {
            if(kind==1) { t.Emis().iRedisFun()=ipCRD; t.Emis().Pesc()=esc_CRDcore(tin,ttot); }
            if(kind==2) { t.Emis().iRedisFun()=ipCRDW; t.Emis().Pesc()=esc_CRDwing(tin,ttot,a); }
            if(kind==3) { t.Emis().iRedisFun()=ipPRD; t.Emis().Pesc()=esc_PRD(tin,ttot,a); }
            destruction.t=kind==3 ? DestType::ipDEST_INCOM : DestType::ipDEST_K2;
        }
        RT_DestProb(t,1.,destruction);
        RT_line_pumping(t,true,1.);
        double stimulated=t.Emis().pump()*gl/gu;
        std::cout<<t.Emis().Pesc()<<" "<<t.Emis().Pdest()<<" "<<t.Emis().Pelec_esc()
                 <<" "<<t.Emis().pump()<<" "<<stimulated<<" "
                 <<A*t.Emis().Ploss()+stimulated<<" "<<nupper*A*t.Emis().Pdest()<<"\n";
    }
}
