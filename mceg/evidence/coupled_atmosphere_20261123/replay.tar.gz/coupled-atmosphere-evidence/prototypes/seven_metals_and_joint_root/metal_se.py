"""Experimental JAX multilevel metal SE; no atmosphere or ionization closure.

Read-only loading of C23.01-distributed STOUT/CHIANTI files is separate from
the differentiable kernel. Species abundance, line pumping and net radiative
loss probabilities must be supplied, not inferred from fitted heating curves.

Interpolation and fallback conventions follow C23.01 species2.cpp,
atmdat_chianti.cpp and transition.cpp (Cloudy license retained alongside).
This is an explicitly altered prototype, not an endorsed Cloudy port.
"""
from __future__ import annotations

from pathlib import Path
from typing import NamedTuple
import hashlib

import jax
import jax.numpy as jnp
import numpy as np

KB = 1.380649e-16
PLANCK = 6.62607015e-27
C = 2.99792458e10
ME = 9.1093837015e-28
RYDBERG = 1.0973731568160e5
ALPHA = 7.2973525693e-3
COLLISION_CONSTANT = (PLANCK**2 / (2*np.pi*KB*ME))**1.5 * KB / PLANCK
A_CONSTANT = 4*np.pi*PLANCK*ALPHA/ME


class Atom(NamedTuple):
    energy_wavenumber: jax.Array
    weight: jax.Array
    spontaneous: jax.Array
    lower: jax.Array
    upper: jax.Array
    collision_kind: jax.Array
    collision_energy_ryd: jax.Array
    collision_scale: jax.Array
    collision_x: jax.Array
    collision_y: jax.Array
    collision_count: jax.Array
    ion_stage: jax.Array


def _rows(path):
    for line in path.read_text().splitlines():
        row = line.split()
        if row and (row[0]=='-1' or row[0].startswith('*')):
            return
        if row and not row[0].startswith('#'):
            yield row, line


def load_atom(data_root, species, levels):
    """Load one declared C23.01 data selection; never fetch or copy the data.

    These files are the sources selected by the matching Cloudy diagnostic.
    Only electron collision tables are loaded here. Other colliders, ionization,
    recombination and charge exchange remain explicitly separate obligations.
    """
    roots = {
        'Fe II': ('stout/fe/fe_2/fe_2_Smyth19', 2),
        'Ca II': ('chianti/ca/ca_2/ca_2', 2),
        'Mg II': ('chianti/mg/mg_2/mg_2', 2),
        'Si II': ('stout/si/si_2/si_2', 2),
        'C I': ('stout/c/c_1/c_1', 1),
        'Al II': ('chianti/al/al_2/al_2', 2),
        'Mn II': ('stout/mn/mn_2/mn_2', 2),
    }
    stem, ion = roots[species]
    prefix = Path(data_root) / stem
    chianti = stem.startswith('chianti')
    suffixes = ('.elvlc', '.wgfa', '.splups') if chianti else ('.nrg', '.tp', '.coll')
    files = [Path(str(prefix)+suffix) for suffix in suffixes]
    raw_levels = []
    for row, line in _rows(files[0]):
        if not row[0].isdigit() or (not chianti and row[:3] == ['17', '09', '05']):
            continue
        identifier = int(row[0])
        if chianti:
            energy, weight = float(line[40:55]), float(line[37:40])
            if energy <= 0 and identifier != 1:
                continue  # the selected reference uses experimental energies
        else:
            energy, weight = float(row[1]), float(row[2])
        raw_levels.append((identifier, energy, weight))
    raw_levels = sorted(raw_levels, key=lambda row: row[1])[:levels]
    if len(raw_levels) != levels:
        raise ValueError('Insufficient retained levels.')
    index = {row[0]: i for i, row in enumerate(raw_levels)}
    energies = np.array([row[1] for row in raw_levels])
    weights = np.array([row[2] for row in raw_levels])
    spontaneous = np.zeros((levels, levels))
    for row, _ in _rows(files[1]):
        if chianti:
            if len(row) < 5 or not row[0].isdigit():
                continue
            lower, upper, value = int(row[0]), int(row[1]), float(row[4])
        else:
            if row[0] != 'A':
                continue
            lower, upper, value = int(row[1]), int(row[2]), float(row[3])
        if lower in index and upper in index:
            low, high = sorted((index[lower], index[upper]))
            spontaneous[high, low] += value
    entries, temperature = [], None
    for row, _ in _rows(files[2]):
        if chianti:
            if len(row) < 12 or not row[0].isdigit():
                continue
            lower, upper, kind = map(int, row[2:5])
            energy, scale = float(row[6]), float(row[7])
            values = np.array(list(map(float, row[8:])))
            if kind < 6:
                values = np.maximum(values, 0)
            coordinate = np.linspace(0, 1, len(values))
        else:
            if row[0] == 'TEMP':
                temperature = np.array(list(map(float, row[1:])))
                continue
            if row[0] not in ('CS', 'RATE') or row[1] != 'ELECTRON':
                continue
            lower, upper = map(int, row[2:4])
            kind, energy, scale = (0 if row[0] == 'CS' else -1), 1., 1.
            values, coordinate = np.array(list(map(float, row[4:]))), temperature.copy()
            if values.shape != coordinate.shape:
                raise ValueError('Collision table has mismatched temperature/value count.')
        if lower in index and upper in index:
            low, high = sorted((index[lower], index[upper]))
            entries.append((low, high, kind, energy, scale, coordinate, values))
    width = max((len(row[5]) for row in entries), default=2)
    xx, yy = np.empty((len(entries), width)), np.empty((len(entries), width))
    for i, entry in enumerate(entries):
        n = len(entry[5])
        xx[i, :n], yy[i, :n] = entry[5], entry[6]
        xx[i, n:] = entry[5][-1] + np.arange(1, width-n+1)
        yy[i, n:] = entry[6][-1]
    atom = Atom(*map(jnp.asarray, (
        energies, weights, spontaneous,
        [row[0] for row in entries], [row[1] for row in entries],
        [row[2] for row in entries], [row[3] for row in entries], [row[4] for row in entries],
        xx, yy, [len(row[5]) for row in entries], ion,
    )))
    return atom, dict(species=species, levels=levels, electron_table_pairs=len(entries),
                     possible_pairs=levels*(levels-1)//2,
                     files={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in files})


@jax.jit
def electron_collision_coefficients(atom, temperature):
    """Return q[from,to], including declared Cloudy g-bar/tiny-CS fallbacks.

    STOUT interpolates linearly in T and holds endpoint values outside its table.
    CHIANTI uses Burgess-Tully coordinates and linear, not cubic, interpolation
    as in C23.01. These conventions are not new atomic data or validation.
    """
    difference = atom.energy_wavenumber[:, None] - atom.energy_wavenumber[None, :]
    safe_difference = jnp.where(difference > 0, difference, 1.)
    y = safe_difference * PLANCK*C/(KB*temperature)
    gf = atom.spontaneous * atom.weight[:, None] / (A_CONSTANT*safe_difference**2)
    neutral = jnp.where(y < .01, .29*(jnp.log1p(1/y)-.4/(y+1)**2)*jnp.exp(-y),
                        jnp.where(y > 10, .066/jnp.sqrt(y),
                                  .015819068+1.3018207*jnp.exp(-.5*(jnp.log(y/.002689623)/2.5486007)**2)))
    ionic = .6+.28*(jnp.log1p(1/y)-.4/(y+1)**2)
    gaunt = jnp.where(gf >= 1e-8, jnp.where(atom.ion_stage==1, neutral, ionic), .15)
    missing_cs = jnp.where(gf > 0, gaunt*14.5104*RYDBERG*gf/safe_difference, 1e-10)
    down = jnp.where(difference > 0, COLLISION_CONSTANT*missing_cs/(atom.weight[:,None]*jnp.sqrt(temperature)), 0.)
    if atom.lower.size == 0:
        inverse = down * atom.weight[:,None]/atom.weight[None,:] * jnp.exp(-jnp.maximum(difference,0)*PLANCK*C/(KB*temperature))
        return down + inverse.T
    kind, scale = atom.collision_kind, atom.collision_scale
    reduced_temperature = temperature / atom.collision_energy_ryd / 1.57888e5
    logarithmic = (kind==1) | (kind==4)
    coordinate = jnp.where(kind <= 0, temperature,
                          jnp.where(logarithmic, 1-jnp.log(scale)/jnp.log(reduced_temperature+scale),
                                    reduced_temperature/(reduced_temperature+scale)))

    def interpolate(x, y, count, query):
        location = jnp.clip(jnp.searchsorted(x, query, side='right')-1, 0, count-2)
        fraction = jnp.clip((query-x[location])/(x[location+1]-x[location]), 0., 1.)
        return y[location]*(1-fraction)+y[location+1]*fraction

    scaled = jax.vmap(interpolate)(atom.collision_x, atom.collision_y, atom.collision_count, coordinate)
    upsilon = jnp.where(kind==1, scaled*jnp.log(reduced_temperature+jnp.e),
                       jnp.where(kind==3, scaled/(reduced_temperature+1),
                         jnp.where(kind==4, scaled*jnp.log(reduced_temperature+scale),
                           jnp.where(kind==5, scaled/reduced_temperature,
                             jnp.where(kind==6, 10**jnp.where(kind==6,scaled,0.), scaled)))))
    coefficients = jnp.where(kind==-1, scaled, COLLISION_CONSTANT*upsilon/(atom.weight[atom.upper]*jnp.sqrt(temperature)))
    down = down.at[atom.upper, atom.lower].set(coefficients)
    inverse = down * atom.weight[:,None]/atom.weight[None,:] * jnp.exp(-jnp.maximum(difference,0)*PLANCK*C/(KB*temperature))
    return down + inverse.T


@jax.jit
def populations(total_rate, species_density):
    """Solve closed local SE by positive GTH elimination, rates [from,to].

    Grassmann, Taksar & Heyman (1985), Operations Research 33, 1107;
    the same rearrangement is used in C23.01 atom_leveln.cpp:gthsolve.
    This JAX implementation avoids subtracting large outgoing sums in a
    nearly singular normalized rate matrix. Irreducible nonnegative rates
    are required; externally supplied ionization sources/sinks are excluded.
    """
    rate = total_rate-jnp.diag(jnp.diag(total_rate))
    size=rate.shape[0]
    indices=jnp.arange(size)

    def eliminate(step,state):
        reduced,inverse=state
        current=size-1-step
        active=indices<current
        reciprocal=1/jnp.sum(jnp.where(active,reduced[current,:],0.))
        update=reduced[:,current,None]*reduced[current,None,:]*reciprocal
        reduced=reduced+jnp.where(active[:,None]&active[None,:],update,0.)
        return reduced,inverse.at[current].set(reciprocal)

    reduced,inverse=jax.lax.fori_loop(0,size-1,eliminate,(rate,jnp.ones(size)))
    def substitute(current,values):
        incoming=jnp.sum(jnp.where(indices<current,values*reduced[:,current],0.))
        return values.at[current].set(inverse[current]*incoming)
    relative=jax.lax.fori_loop(1,size,substitute,jnp.zeros(size).at[0].set(1.))
    return species_density*relative/relative.sum()


@jax.jit
def kinetic_line_heating(population, collision_rate, energy_wavenumber):
    """Signed collisional heat, positive for de-excitation heating [erg/cm3/s]."""
    energy = PLANCK*C*energy_wavenumber
    return jnp.sum(population[:,None]*collision_rate*(energy[:,None]-energy[None,:]))


@jax.jit
def solve_species(atom, temperature, electron_density, species_density,
                  pump_up, loss_probability, additional_radiative_rate,
                  additional_collision_rate):
    """Conditional atom kernel with explicit external closure inputs.

    pump_up has only upper-triangular entries [lower,upper]; spontaneous and
    loss_probability are lower triangular [upper,lower]. Additional radiative
    terms include explicitly supplied overlap/continuum-destruction effects.
    Cloudy supplies these quantities for the first controlled validation only.
    Their fixed-input derivatives are not atmospheric implicit derivatives.
    """
    collision = electron_density*electron_collision_coefficients(atom,temperature)+additional_collision_rate
    stimulated = pump_up.T*atom.weight[None,:]/atom.weight[:,None]
    radiative = (pump_up+stimulated+atom.spontaneous*loss_probability
                 +additional_radiative_rate)
    population = populations(radiative+collision,species_density)
    return population, kinetic_line_heating(population,collision,atom.energy_wavenumber)
