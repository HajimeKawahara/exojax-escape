"""Compare the JAX fit against the unmodified C23 method bodies compiled in C++."""
from pathlib import Path
import hashlib
import json
import subprocess

import jax
import jax.numpy as jnp
import numpy as np

from photoionization import load_photoionization, photoionization_cross_sections, photoionization_rates

jax.config.update('jax_enable_x64', True)
root = Path(__file__).parent
data = Path('/tmp/cloudy-reference-run/c23.01/data')
source = Path('/tmp/cloudy-reference-run/c23.01/source/atmdat_adfa.cpp')
text = source.read_text()
original = text[text.index('inline long t_ADfA::set_vshell_index'):text.index('double t_ADfA::hpfit')]
prefix = r'''
#include <algorithm>
#include <cassert>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
using namespace std;
#define DEBUG_ENTRY(x) ((void)0)
#define ASSERT(x) assert(x)
#define POW2(x) ((x)*(x))
enum { PHFIT_UNDEF, PHFIT95, PHFIT96 };
const int ipARGON=17,ipCALCIUM=19,ipSCANDIUM=20,ipTITANIUM=21,ipMANGANESE=24,ipIRON=25;
const double EVRYD=13.605693122994;
struct { double potential[30][30]; double getIonPot(int z,int q){return potential[z][q];} } atmdat;
struct t_ADfA {
    int version=PHFIT96; long L[7],NINN[30],NTOT[30];
    float PH1[7][30][30][6]={}, PH2[30][30][7]={};
    long set_vshell_index(long ne,long Z) const;
    double getEthresh(long nshell,long nel,long Z) const;
    double phfit(long nz,long ne,long is,double e);
};
bool row(ifstream &file,string &s) {
    while(getline(file,s)) { s=s.substr(0,s.find('#')); if(s.find_first_not_of(" \t\r")==string::npos) continue; return true; }
    return false;
}
'''
suffix = r'''
int main(int argc,char**argv) {
    t_ADfA model; string line; ifstream table(string(argv[1])+"/phfit.dat"); row(table,line);
    row(table,line); {istringstream r(line);for(int i=0;i<7;++i)r>>model.L[i];}
    row(table,line); {istringstream r(line);for(int i=0;i<30;++i)r>>model.NINN[i];}
    row(table,line); {istringstream r(line);for(int i=0;i<30;++i)r>>model.NTOT[i];}
    while(row(table,line)) {istringstream r(line); int s,n,z;r>>s>>n>>z;if(s<0)break;for(int i=0;i<6;++i)r>>model.PH1[s][n][z][i];}
    while(row(table,line)) {istringstream r(line); int n,z;r>>n>>z;if(n<0)break;for(int i=0;i<7;++i)r>>model.PH2[n][z][i];}
    ifstream potentials(string(argv[1])+"/ionization_potentials.dat");row(potentials,line);
    while(row(potentials,line)) {istringstream r(line);int z,q;double wn;if(!(r>>z>>q>>wn))continue;if(z>30)break;atmdat.potential[z-1][q]=wn*(6.62607015e-27*2.99792458e10/1.602176634e-12)/EVRYD;}
    int z,q,s; double e;cout<<setprecision(17);
    while(cin>>z>>q>>s>>e)cout<<model.phfit(z,z-q,s,e)*1e-18<<"\n";
}
'''
cpp = root/'photoionization_reference.cpp'
cpp.write_text('/* Reporting harness; original C23.01 method bodies follow. See Cloudy-license.txt. */\n'+prefix+original+suffix)
binary = root/'photoionization_reference'
subprocess.run(['g++','-O2','-std=c++11',str(cpp),'-o',str(binary)],check=True)
queries, expected, cases = [], [], []
for z in (6,12,13,14,20,25,26):
    for q in (0,1,2):
        fit = load_photoionization(data,z,q)
        thresholds = np.asarray(fit.threshold_ev)[np.asarray(fit.valid)]
        energy = np.unique(np.concatenate((np.geomspace(.1,1e5,80),thresholds*(1-1e-8),thresholds*(1+1e-8))))
        sigma = np.asarray(photoionization_cross_sections(fit,energy))
        queries.extend(f'{z} {q} {shell+1} {e:.17e}\n' for e in energy for shell in range(7))
        expected.extend(sigma.ravel())
        derivative = np.asarray(jax.jacfwd(lambda x:photoionization_cross_sections(fit,jnp.exp(x)))(np.log(30.125)))
        step=1e-5
        finite=np.asarray((photoionization_cross_sections(fit,30.125*np.exp(step))-photoionization_cross_sections(fit,30.125*np.exp(-step)))/(2*step))
        meaningful=abs(finite)>1e-30
        error=float(np.max(abs(derivative[meaningful]/finite[meaningful]-1))) if meaningful.any() else 0.
        cases.append({'Z':z,'charge':q,'energy_points':len(energy),'energy_gradient_max_relative_error':error})
result=subprocess.run([str(binary),str(data)],input=''.join(queries),text=True,capture_output=True,check=True)
reference=np.fromstring(result.stdout,sep='\n'); expected=np.array(expected)
nonzero=reference>0
relative=float(np.max(abs(expected[nonzero]/reference[nonzero]-1)))
worst=np.flatnonzero(nonzero)[np.argmax(abs(expected[nonzero]/reference[nonzero]-1))]
print('Worst sample',queries[worst].strip(),expected[worst],reference[worst],relative,flush=True)
assert np.array_equal(expected==0,reference==0)
assert relative<2e-12
assert max(c['energy_gradient_max_relative_error'] for c in cases)<2e-7
# A smooth external photon field makes intensity differentiation independently
# checkable by exact linear scaling; this is not Cloudy's local radiation field.
fit=load_photoionization(data,6,0)
energy=jnp.unique(jnp.concatenate((jnp.geomspace(.1,1e3,4000),fit.threshold_ev)))
flux=1e18*energy**2/jnp.expm1(energy/(8.617333262e-5*10000))
def intensity(log_scale):
    rate,heat=photoionization_rates(fit,energy,flux*jnp.exp(log_scale))
    return jnp.concatenate((rate,heat))
signal=np.asarray(intensity(0.)); gradient=np.asarray(jax.jacfwd(intensity)(0.))
np.testing.assert_allclose(gradient,signal,rtol=1e-13,atol=0.)
report={'scope':'C23 ground-state partial shell cross sections and supplied-field integrals. No excited-state, secondary-electron, diffuse-radiation or coupled ionization/thermal claim.',
        'queries':len(queries),'maximum_cross_section_relative_error':relative,'zero_support_identical':True,
        'source_method_sha256':hashlib.sha256(original.encode()).hexdigest(),
        'files_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (source,data/'phfit.dat',data/'ionization_potentials.dat',root/'photoionization.py',cpp)},
        'cases':cases,'passed':True}
(root/'photoionization_verification.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print('PASS',len(queries),'partial shell samples; maximum relative difference',relative)
