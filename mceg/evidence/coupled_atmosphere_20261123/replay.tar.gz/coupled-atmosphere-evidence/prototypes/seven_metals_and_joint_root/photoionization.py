"""Ground-state C23 Verner shell fits; no ionization or transfer closure.

Explicitly altered JAX implementation of C23.01 atmdat_adfa.cpp::phfit.
Cloudy's license is retained alongside. Fit data: Verner & Yakovlev (1995),
A&AS 109, 125; Verner et al. (1996), ApJ 465, 487. The valence thresholds use
C23 ionization_potentials.dat, rather than the older fitted thresholds.
"""
from pathlib import Path
from typing import NamedTuple

import jax
import jax.numpy as jnp
import numpy as np

EV_ERG = 1.602176634e-12
WAVENUMBER_EV = 6.62607015e-27 * 2.99792458e10 / EV_ERG


class PhotoFit(NamedTuple):
    angular_momentum: jax.Array
    fit95: jax.Array
    fit96: jax.Array
    threshold_ev: jax.Array
    valid: jax.Array
    inner_shell: jax.Array
    outer_shell: jax.Array
    inner_fit_threshold_ev: jax.Array


def _data(path):
    for line in Path(path).read_text().splitlines():
        row = line.split('#', 1)[0].split()
        if row:
            yield row


def load_photoionization(data_root, atomic_number, charge):
    """Read one ion's seven shell fits, with C23 realnum rounding preserved."""
    z, ne = int(atomic_number), int(atomic_number-charge)
    if not 1 <= ne <= z <= 30:
        raise ValueError('Fits require 1 <= bound electrons <= Z <= 30.')
    rows = iter(_data(Path(data_root)/'phfit.dat'))
    assert next(rows) == ['20061204']
    angular = np.array(next(rows), dtype=int)
    ninner = int(next(rows)[ne-1])
    nouter = int(next(rows)[ne-1])
    if z == ne and z > 18 or z == ne+1 and z in (20, 21, 22, 25, 26):
        nouter = 7
    fit95 = np.ones((7, 6))
    exists = np.zeros(7, dtype=bool)
    for row in rows:
        shell, electrons, element = map(int, row[:3])
        if shell < 0:
            break
        if electrons == ne-1 and element == z-1:
            fit95[shell] = np.array(row[3:], dtype=np.float32).astype(float)
            exists[shell] = True
    fit96 = np.ones(7)
    for row in rows:
        electrons, element = map(int, row[:2])
        if electrons < 0:
            break
        if electrons == ne-1 and element == z-1:
            fit96 = np.array(row[2:], dtype=np.float32).astype(float)
    potential = next(float(row[2]) for row in _data(Path(data_root)/'ionization_potentials.dat')
                     if len(row) > 2 and int(row[0]) == z and int(row[1]) == charge)
    threshold = fit95[:, 0].copy()
    threshold[nouter-1] = potential*WAVENUMBER_EV
    valid = exists & (np.arange(1, 8) <= nouter)
    if z in (19, 20) and ne >= 19:
        valid[5] = False
    if z in (15, 17, 19) or z > 20 and z != 26:
        inner_threshold = 0.
    elif ne < 3:
        inner_threshold = 1e30
    else:
        inner_threshold = threshold[nouter-1] if ninner == nouter else fit95[ninner-1, 0]
    return PhotoFit(*map(jnp.asarray, (angular, fit95, fit96, threshold, valid,
                                      ninner, nouter, inner_threshold)))


@jax.jit
def photoionization_cross_sections(fit, photon_energy_ev):
    """Partial ground-state cross sections [cm2], final axis = 7 shells.

    Input energies are positive. Threshold discontinuities are physical; grids
    used for rate integrals should explicitly resolve every retained threshold.
    """
    energy = jnp.asarray(photon_energy_ev)[..., None]
    evaluation_energy = jnp.maximum(energy, fit.threshold_ev)
    p = fit.fit95
    y = evaluation_energy/p[:, 1]
    width95 = (p[:, 5].astype(jnp.float32)**2).astype(p.dtype)
    old = p[:, 2]*((y-1)**2+width95)*y**(.5*p[:, 4]-fit.angular_momentum-5.5)
    old *= (1+jnp.sqrt(y/p[:, 3]))**(-p[:, 4])
    p = fit.fit96
    x = evaluation_energy/p[0]-p[5]
    width96 = (p[4].astype(jnp.float32)**2).astype(p.dtype)
    smooth96 = (p[6].astype(jnp.float32)**2).astype(p.dtype)
    y = jnp.sqrt(x*x+smooth96)
    modern = p[1]*((x-1)**2+width96)*y**(.5*p[3]-5.5)*(1+jnp.sqrt(y/p[2]))**(-p[3])
    shell = jnp.arange(1, 8)
    use_old = (shell <= fit.inner_shell) | (energy >= fit.inner_fit_threshold_ev)
    shell_gap = (shell < fit.outer_shell) & (shell > fit.inner_shell) & ~use_old
    cross = jnp.where(use_old, old, modern)
    return jnp.where(fit.valid & (energy >= fit.threshold_ev) & ~shell_gap, cross*1e-18, 0.)


@jax.jit
def photoionization_rates(fit, photon_energy_ev, photon_flux_per_ev):
    """Per-ion shell rates [s-1] and primary excess energy [erg/s].

    The supplied flux is the angle-integrated photon intensity (4*pi*J_E),
    including any direct beam, in photons/cm2/s/eV. It is not a fitted Cloudy
    rate. Auger branching, secondary electrons, excited-state photoionization,
    diffuse radiation, and feedback on the flux are separate missing closures.
    """
    energy = jnp.asarray(photon_energy_ev)
    integrand = photoionization_cross_sections(fit, energy)*photon_flux_per_ev[..., None]
    ionization = jnp.trapezoid(integrand, energy, axis=-2)
    excess = jnp.maximum(energy[..., None]-fit.threshold_ev, 0.)*EV_ERG
    heating = jnp.trapezoid(integrand*excess, energy, axis=-2)
    return ionization, heating
