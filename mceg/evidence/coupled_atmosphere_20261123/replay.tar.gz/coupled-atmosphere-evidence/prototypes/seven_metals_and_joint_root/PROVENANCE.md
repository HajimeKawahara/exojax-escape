# Corrected runtime provenance

The preceding v3 receipt attributed all provider imports to one revision without
capturing their file identities at process start. Development continued in the
shared checkout during that campaign. V3 is retained as historical evidence;
its single provider-revision field must not be treated as proof of every imported
file's identity.

V4 does not infer the original imports. It rechecks the archived state and its
implicit derivative using an independently frozen provider source tree extracted
from commit `4b3fdd651a01eac752e96f3662c611a18940ccf1`. The tree is included in
`provider_source/src/escape`. `joint_result/verification.json` records the actual
imported provider and ExoJAX Python files and their hashes. H-API and ionic-rate
helpers are local frozen copies; Cota coefficients are loaded from this snapshot.

The archived state is an initial guess for the new residual/derivative checks.
Original continuation timings and outputs are under `joint_result_original`;
they are not the source-pinned execution claim of this recheck. The fresh report
requires convergence of the base and both finite-difference roots, continuum
transfer convergence, and the stated conservation/gradient tests.

This frozen provider predates the later Anderson-default and formal-beam fixes
in the production branch. The experiment uses H n<=3, but that limited domain
does not authorize treating it as a test of a different source revision or of
the selected production observer. Scientific equivalence remains unverified.

Python caches and executable build products are excluded. NPZ files contain
numerical inputs or results, not executable binaries. No raw PHOENIX SED is
included. External C23.01 and ExoJAX input identities remain recorded in the
individual kernel receipts.
