"""Conditional ion ladder using C23 readout totals plus H/He charge transfer.

Neutral H/He total density approximates the ground-state collider population.
Any nonadjacent Auger transfer or explicit chemistry source/sink is omitted.
This tests bookkeeping closure using reference inputs, not independent atomic
photoionization/recombination data or a self-consistent atmosphere.
"""
from pathlib import Path
import json
import numpy as np

root = Path(__file__).parent
reference = json.loads((root / "ionic_diagnostics.json").read_text())
output = []
for row in reference["rows"]:
    collider = row["collider_densities_cm3"]
    ratios, details = [], []
    for charge in (0, 1):
        rate = row["charge_rates"][str(charge)]
        ct_up = (rate["H_CharExcIonOf_cm3_s"] * collider["H II"]
                 + rate["He_CharExcIonOf_cm3_s"] * collider["He II"])
        ct_down = (rate["H_CharExcRecTo_cm3_s"] * collider["H I"]
                   + rate["He_CharExcRecTo_cm3_s"] * collider["He I"])
        total_up = rate["RateIonizTot_s1"] + ct_up
        total_down = rate["RateRecomTot_s1"] + ct_down
        ratios.append(total_up / total_down)
        details.append({
            "from_charge": charge, "up_s1": total_up, "down_s1": total_down,
            "ct_fraction_ionization": ct_up / total_up,
            "ct_fraction_recombination": ct_down / total_down,
        })
    predicted = np.array([1., ratios[0], ratios[0] * ratios[1]])
    predicted /= predicted.sum()
    actual = np.array([row["stage_fraction"][str(stage)] for stage in (1, 2, 3)])
    output.append({
        "element": row["element"], "radius_rp": row["radius_rp"],
        "predicted_stage_1_2_3_fractions": predicted.tolist(),
        "actual_stage_1_2_3_fractions": actual.tolist(),
        "population_relative_l1": float(np.sum(abs(predicted - actual)) / actual.sum()),
        "maximum_relative_difference_for_fraction_above_1e_7": float(np.max(
            abs(predicted[actual > 1e-7] / actual[actual > 1e-7] - 1))),
        "rate_budget": details,
    })
report = {
    "scope": __doc__, "c23_index_semantics": reference["index_semantics"],
    "cases": output,
}
path = root / "ionic_ladder_validation.json"
path.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
for row in output:
    print(row["element"], round(row["radius_rp"], 5),
          "relative L1", row["population_relative_l1"])
