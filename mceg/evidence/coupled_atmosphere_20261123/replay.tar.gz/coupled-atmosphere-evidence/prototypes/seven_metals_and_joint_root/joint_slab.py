"""Shared-continuum H + seven-metal fixed-T population-root experiment.

This is circuit verification, not a solar thermal/wind or Cloudy-equivalent
model. See metal_network.py for explicit omissions. Neutral helium is a fixed
reservoir; its charge-transfer terms vanish for the retained q<=2 stages.
"""
from functools import partial
from pathlib import Path
import argparse
import json
import time

import jax
import jax.numpy as jnp
import numpy as np

from native_slab import EPSlab
from escape.hydrogen_atom import atom_cross_sections, atom_milne_population
from escape.hydrogen_nlte import _bound_ratios
from escape.reactive_flow import _newton
from metal_network import MetalNetwork, SPECIES, frequency_edges

DATA='/tmp/cloudy-reference-run/c23.01/data'


class JointSlab:
    def __init__(self,nmax=3,cells=2,column=1e18,density=1e12,temperature=8000.):
        self.hydrogen=EPSlab(nmax,cells,column,density,temperature,order=4,angles=4,
                            extra_frequency_edges=frequency_edges(DATA),cloudy_bound_free=True)
        h=self.hydrogen
        self.metal=MetalNetwork(h.frequency,h.weights,h.widths,temperature,
            data_root=DATA,cota_data=dict(np.load(Path(__file__).with_name('rates')/'cota_coefficients.npz')))
        self.density,self.cells,self.temperature=density,cells,temperature
        self.hydrogen_size=len(h.atom.statistical_weights)
        self.metal_line_frequency=jnp.concatenate([line[2] for line in self.metal.lines])
        self.hydrogen_cross_at_metals=atom_cross_sections(h.atom,self.metal_line_frequency)
        self.hydrogen_inverse_at_metals=atom_milne_population(h.atom,temperature,self.metal_line_frequency)
        # C23 default.abn; explicit retained-element subset, not a complete solar gas.
        self.abundance=jnp.array([2.45e-4,3.47e-5,2.95e-6,3.47e-5,2.29e-6,2.88e-7,2.82e-5])

    def unpack(self,state,metal_scale):
        fractions=jax.nn.softmax(jnp.column_stack((state[:,:self.hydrogen_size],jnp.zeros(self.cells))),axis=1)
        bound=self.density*fractions[:,:-1]
        proton=self.density*fractions[:,-1]
        element_density=jnp.broadcast_to(self.density*self.abundance*metal_scale,(self.cells,len(SPECIES)))
        ions,_=self.metal.unpack(state[:,self.hydrogen_size:],element_density)
        electron=proton+jnp.einsum('csq,q->c',ions,jnp.arange(3))
        return bound,proton,electron,element_density,ions

    def evaluate(self,state,dilution,metal_scale):
        h=self.hydrogen
        bound,proton,electron,elements,ions=self.unpack(state,metal_scale)
        metal_opacity=self.metal.continuum_opacity(ions)
        hstate=h.population_state(bound,proton,electron,dilution,additional_opacity=metal_opacity)
        metal=self.metal.evaluate(state[:,self.hydrogen_size:],elements,electron,bound[:,0],proton,
            jnp.full(self.cells,.1*self.density),jnp.zeros(self.cells),hstate,h.atom.line_frequency_hz)
        flux=metal['ots_photon_flux_cm2_s']
        photo=flux@self.hydrogen_cross_at_metals.T
        alpha=flux@(self.hydrogen_cross_at_metals*self.hydrogen_inverse_at_metals).T
        # These effective source/sink rates are only used for H statistical
        # equilibrium. CT is not relabelled as radiative heat in an energy ledger.
        photo=photo.at[:,0].add(metal['hydrogen_ct_ionization_s'])
        alpha=alpha.at[:,0].add(metal['hydrogen_ct_recombination_s']/electron)
        rates=hstate['rates']._replace(
            photoionization_s=hstate['rates'].photoionization_s+photo,
            radiative_recombination_cm3_s=hstate['rates'].radiative_recombination_cm3_s+alpha)
        target_h=jnp.log(jax.vmap(_bound_ratios)(electron,rates))
        target=jnp.concatenate((target_h,metal['target_state']),axis=1)
        return target,dict(bound_cm3=bound,proton_cm3=proton,electron_cm3=electron,
            metal_ion_cm3=ions,metal_heat_erg_cm3_s=metal['collision_heat_erg_cm3_s'],
            mean_intensity=hstate['mean_intensity'],metal_opacity_cm1=metal_opacity,
            metal_photoionization_s=metal['ground_photoionization_s'],
            valid=metal['valid']&jnp.all(jnp.isfinite(target)))

    @partial(jax.jit,static_argnums=0,static_argnames=('iterations',))
    def warm(self,state,dilution,metal_scale,iterations=8):
        def step(_,current):
            target,_=self.evaluate(current,dilution,metal_scale)
            return current+.3*jnp.clip(target-current,-5.,5.)
        return jax.lax.fori_loop(0,iterations,step,state)

    @partial(jax.jit,static_argnums=0,static_argnames=('iterations',))
    def solve(self,state,dilution,metal_scale,iterations=30):
        shape=state.shape
        def residual(flat):
            current=flat.reshape(shape)
            target,_=self.evaluate(current,dilution,metal_scale)
            return (current-target).ravel()
        root=jax.lax.custom_root(residual,state.ravel(),lambda fn,guess:_newton(fn,guess,iterations),
            lambda linear,rhs:jnp.linalg.solve(jax.jacfwd(linear)(jnp.zeros_like(rhs)),rhs))
        result=root.reshape(shape)
        _,physical=self.evaluate(result,dilution,metal_scale)
        return result,jnp.max(abs(residual(root))),physical


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--cells',type=int,default=2)
    parser.add_argument('--iterations',type=int,default=25)
    parser.add_argument('--initial',type=Path,default=Path('/tmp/escape-ep-prototype/native_n3_col18_v3/solution.npz'))
    args=parser.parse_args()
    jax.config.update('jax_enable_x64',True)
    model=JointSlab(cells=args.cells)
    initial=np.load(args.initial)
    old=np.asarray(initial['state'])
    hstate=np.column_stack([np.interp((np.arange(args.cells)+.5)/args.cells,(np.arange(len(old))+.5)/len(old),column) for column in old.T])
    mstate=model.metal.initialize(jnp.broadcast_to(model.density*model.abundance,(args.cells,len(SPECIES))))
    state=jnp.column_stack((hstate,mstate))
    start=time.time(); history=[]
    for scale in (1e-3,.03,1.):
        # Newton's residual-based backtracking keeps trial states in the finite
        # domain. An unguarded Picard warmup can cross a line-inversion boundary.
        state,norm,physical=model.solve(state,.025,scale,iterations=args.iterations)
        row={'metal_abundance_scale':scale,'residual_norm':float(norm) if np.isfinite(norm) else None,'valid':bool(physical['valid'])}
        history.append(row);print(row,flush=True)
        if not row['valid'] or row['residual_norm'] is None or row['residual_norm']>1e-8:break
    args.output.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(args.output/'solution.npz',state=np.asarray(state),**{k:np.asarray(v) for k,v in physical.items()})
    report={'scope':__doc__,'cells':args.cells,'nmax':3,'temperature_k':8000.,'nH_cm3':1e12,'column_cm2':1e18,
        'frequency_nodes':len(model.hydrogen.frequency),'metal_lines':len(model.metal_line_frequency),
        'unknowns':int(state.size),'history':history,'elapsed_seconds':time.time()-start,
        'continuum_gain_model':'C23 per-level max(0, net bound-free extinction), explicitly selected for consistency with its line escape closure.',
        'converged':history[-1]['valid'] and history[-1]['residual_norm'] is not None and history[-1]['residual_norm']<1e-8 and history[-1]['metal_abundance_scale']==1.,
        'missing_physics':['Metal RR/DR continuum emission','Metal collisional/excited-state ionization','H-minus and H2-plus chemistry/energy','Additional coolants and charge stages','Helium ionization','Thermal/wind closure','Actual stellar spectrum and observation operator']}
    (args.output/'metrics.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps(report,indent=2),flush=True)


if __name__=='__main__':main()
