"""Numerical checks for the conditional prototype; no solar-atmosphere claim."""
import jax
import jax.numpy as jnp
import numpy as np
import pytest

from metal_se import (
    C, PLANCK, KB, electron_collision_coefficients, kinetic_line_heating,
    load_atom, populations,
)

jax.config.update("jax_enable_x64", True)


@pytest.mark.parametrize("species,size", [
    ("Fe II", 80), ("Ca II", 15), ("Mg II", 15), ("Si II", 15), ("C I", 15),
    ("Al II", 15), ("Mn II", 45),
])
def test_collision_only_lte_and_zero_heat(species, size):
    atom, _ = load_atom("/tmp/cloudy-reference-run/c23.01/data", species, size)
    temperature, electron, abundance = 5481.75, 4e10, 2e8
    rate = electron * electron_collision_coefficients(atom, temperature)
    population = populations(rate, abundance)
    lte = atom.weight * jnp.exp(-PLANCK * C * atom.energy_wavenumber / (KB * temperature))
    lte = abundance * lte / lte.sum()
    np.testing.assert_allclose(population, lte, rtol=2e-12, atol=1e-20)
    assert float(jnp.min(population)) >= 0
    assert abs(float(kinetic_line_heating(population, rate, atom.energy_wavenumber))) < 1e-12


def test_general_rate_solution_and_gradient():
    base = jnp.array([[0., 3., .2], [2., 0., 4.], [1., 5., 0.]])

    def solve(parameter):
        rates = base.at[0, 2].set(jnp.exp(parameter))
        return populations(rates, 8.)

    result = solve(0.)
    rate = base.at[0, 2].set(1.)
    residual = result @ rate - result * rate.sum(axis=1)
    np.testing.assert_allclose(residual, 0., atol=1e-13)
    np.testing.assert_allclose(jnp.sum(result), 8., rtol=1e-14)
    derivative = jax.jacfwd(solve)(0.)
    finite = (solve(1e-4) - solve(-1e-4)) / 2e-4
    np.testing.assert_allclose(derivative, finite, rtol=3e-8, atol=1e-12)


@pytest.mark.parametrize("species,size", [("Fe II", 80), ("C I", 15)])
def test_collision_temperature_gradient_is_finite(species, size):
    atom, _ = load_atom("/tmp/cloudy-reference-run/c23.01/data", species, size)
    function = lambda log_t: electron_collision_coefficients(atom, jnp.exp(log_t))
    derivative = jax.jacfwd(function)(jnp.log(5481.75))
    assert np.all(np.isfinite(derivative))
