"""Conditional native H slab root with continuum RT, line EP, and line OTS.

Prototype only: fixed T/density, pure H, no hydrodynamics. Two-photon decay
escapes without its continuum being transported; inverse/induced two-photon,
and Cloudy's recombination escape approximation are not matched.
Stark escape and local Rayleigh albedo follow C23; scattering is not yet transported.
The continuum instead uses the existing formal transfer. This experiment
isolates what the C23 line closure changes; it is not full Cloudy equivalence.
"""
from __future__ import annotations

import argparse
from functools import partial
import json
from pathlib import Path
import time

import jax
import jax.numpy as jnp
import numpy as np

from exojax.opacity.lpf.lpf import vvoigt
from escape.hydrogen_atom import make_hydrogen_atom, atom_cross_sections, atom_milne_population, atom_collision_rates
from escape.hydrogen_continuum import hydrogen_free_free_coefficients, planck_intensity_hz
from escape.hydrogen_mixing import mixing_bound_bound_cm3_s
from escape.hydrogen_nlte import RateCoefficients, _bound_ratios
from escape.hydrogen_rates import PLANCK_CGS, LIGHT_SPEED_CGS, BOLTZMANN_CGS, TWO_PHOTON_A_S
from escape.radiation import solve_slab_transfer, _cell_weights
from escape.reactive_flow import _newton
from line_closure import line_operators, hydrogen_stark_escape, hydrogen_rayleigh_cross_section, LYA, CORE, WING


class EPSlab:
    def __init__(self,nmax,cells,column_cm2,density_cm3,temperature_k,*,order=4,angles=4,
                 overlap=True,upper_lifetime=True,ots=True,stark=True,rayleigh=True,extra_frequency_edges=(),scattering_attenuation=False,cloudy_bound_free=False):
        self.atom=atom=make_hydrogen_atom(nmax)
        self.cells,self.temperature,self.angles=cells,temperature_k,angles
        self.ots,self.stark,self.rayleigh=ots,stark,rayleigh
        self.scattering_attenuation=scattering_attenuation
        self.cloudy_bound_free=cloudy_bound_free
        self.edges=jnp.linspace(0.,column_cm2/density_cm3,cells+1)
        self.widths=jnp.diff(self.edges)
        # Nonoverlapping continuum quadrature split at every edge and pump frequency.
        limits=np.array([1e-4,100.])*1.602176634e-12/PLANCK_CGS
        edges=np.unique(np.r_[np.geomspace(*limits,49),np.asarray(atom.ionization_energy_erg)/PLANCK_CGS,
                               np.asarray(atom.line_frequency_hz),np.asarray(extra_frequency_edges)])
        x,w=np.polynomial.legendre.leggauss(order)
        delta=np.diff(np.log(edges))[:,None]
        freq=edges[:-1,None]*np.exp(delta*(x+1)/2)
        self.frequency=jnp.asarray(freq.ravel())
        self.weights=jnp.asarray((freq*delta*w/2).ravel())
        self.sigma=jax.jit(lambda nu:atom_cross_sections(atom,nu))(self.frequency)
        self.inverse=atom_milne_population(atom,temperature_k,self.frequency)
        self.sigma_line=jax.jit(lambda nu:atom_cross_sections(atom,nu))(atom.line_frequency_hz)
        self.inverse_line=atom_milne_population(atom,temperature_k,atom.line_frequency_hz)
        self.rayleigh_grid=hydrogen_rayleigh_cross_section(self.frequency/(2.99792458e10*1.0973731568160e5))
        self.rayleigh_line=hydrogen_rayleigh_cross_section(atom.line_frequency_hz/(2.99792458e10*1.0973731568160e5))
        self.photo_kernel=8*jnp.pi/LIGHT_SPEED_CGS**2*self.frequency**2*self.sigma*self.weights
        self.bb=planck_intensity_hz(self.frequency,10000.)
        u,l=atom.line_upper,atom.line_lower
        self.kind=jnp.where(l==0,CORE,WING).at[0].set(LYA)
        decay=jnp.zeros_like(atom.statistical_weights).at[u].add(atom.einstein_a_s).at[1].add(TWO_PHOTON_A_S)
        gamma=(decay[u]+(0 if upper_lifetime else decay[l]))/(4*jnp.pi)
        velocity=np.sqrt(2*BOLTZMANN_CGS*temperature_k/1.67262192369e-24)
        width=atom.line_frequency_hz*velocity/LIGHT_SPEED_CGS
        self.damping=gamma/width
        self.kappa_factor=(LIGHT_SPEED_CGS**2*atom.einstein_a_s/(8*jnp.pi*atom.line_frequency_hz**2)
                           /(jnp.sqrt(jnp.pi)*width))
        line_phi=vvoigt(atom.line_frequency_hz[None,:]-atom.line_frequency_hz[:,None],width/jnp.sqrt(2),gamma)
        self.fine_matrix=(line_phi*jnp.sqrt(jnp.pi)*width[:,None] if overlap else jnp.eye(len(width)))
        n=np.asarray(atom.principal_n)
        self.multiplets=jnp.asarray((n[np.asarray(u),None]==n[np.asarray(u)][None,:])&
                                    (n[np.asarray(l),None]==n[np.asarray(l)][None,:]))
        collision,ion,q3=atom_collision_rates(atom,temperature_k)
        self.collision=collision.at[1,2].set(0.).at[2,1].set(0.)
        self.ion,self.q3=ion,q3

    def _outward_mean(self,chi,emission):
        x,w=np.polynomial.legendre.leggauss(self.angles)
        def direction(mu):
            tau=chi*self.widths[:,None]/mu
            emitted=emission*self.widths[:,None]/mu
            first,second=_cell_weights(tau)
            def cell(incoming,values):
                t,e,f,s=values
                return incoming*jnp.exp(-t)+e*f,incoming*f+e*s
            return jax.lax.scan(cell,jnp.zeros_like(self.frequency),(tau,emitted,first,second),reverse=True)[1]
        means=jax.vmap(direction)(jnp.asarray((x+1)/2))
        return jnp.einsum("a,acf->cf",jnp.asarray(w/4),means)

    def state(self,ratios,density,dilution):
        fractions=jax.nn.softmax(jnp.column_stack((ratios,jnp.zeros(self.cells))),axis=1)
        bound=density*fractions[:,:-1]
        electron=density*fractions[:,-1]
        result=self.population_state(bound,electron,electron,dilution)
        return (bound,electron,result["rates"],result["line_operators"],result["continuum"],
                result["photoionization_ots_s"],result["net_ots_bound_free_cm3_s"])

    def population_state(self,bound,proton,ne,dilution,*,additional_opacity=0.,additional_emission=0.):
        """Common H/metal interface; supplied populations need not satisfy ne=np.

        Arrays are [cell,level] or [cell,frequency], cells bottom to top.
        Additional continuum coefficients use cm^-1 and cgs emissivity/sr/Hz.
        Returned continuum J and pump J use cgs specific intensity. OTS flux
        is photons/cm²/s at each H line, without an implicit spectral width.
        A joint root must add this field to metal PI as well as H rates.
        """
        atom=self.atom
        pair=ne*proton
        chi_bf=bound@self.sigma-pair[:,None]*jnp.sum(self.sigma*self.inverse,axis=0)
        if self.cloudy_bound_free:
            # C23 opacity_add1subshell.cpp:116-126 suppresses continuum gain
            # separately for each level. This is a declared model option.
            net_by_level=(bound[:,:,None]-pair[:,None,None]*self.inverse[None,:,:])*self.sigma[None,:,:]
            chi_bf=jnp.sum(jnp.maximum(net_by_level,0.),axis=1)
        emission_bf=(2*PLANCK_CGS/LIGHT_SPEED_CGS**2*self.frequency**3
                     *pair[:,None]*jnp.sum(self.sigma*self.inverse,axis=0))
        chi_ff,j_ff=jax.vmap(lambda electron,ion:hydrogen_free_free_coefficients(
            self.temperature,electron,ion,self.frequency))(ne,proton)
        chi,emission=chi_bf+chi_ff+additional_opacity,emission_bf+j_ff+additional_emission
        # C23 rt_continuum.cpp:314 removes scattered photons from the
        # propagated continuum using 1/(1+tau_sct) per cell. This is an
        # explicit C23 attenuation approximation, not conservative scattering
        # transfer and must never be counted as gas absorption/heating.
        scattering_grid=ne[:,None]*6.6524587321e-25+bound[:,0,None]*self.rayleigh_grid
        transport_chi=chi+(jnp.log1p(scattering_grid*self.widths[:,None])/self.widths[:,None]
                           if self.scattering_attenuation else 0.)
        zero=jnp.zeros_like(self.frequency)
        transfer=solve_slab_transfer(self.edges,transport_chi,emission,zero,zero,angle_order=self.angles,
                                     beam_mean_intensity=dilution*self.bb)
        prefactor=2*PLANCK_CGS/LIGHT_SPEED_CGS**2*self.frequency**3
        occupation=transfer.mean_intensity/prefactor
        dtauc=transport_chi*self.widths[:,None]
        above=jnp.cumsum(dtauc[::-1],axis=0)[::-1]-dtauc
        incident=dilution*self.bb*jnp.exp(-above)*_cell_weights(dtauc)[0]
        pump_field=(incident+self._outward_mean(transport_chi,emission))/prefactor
        pump_occupation=jax.vmap(lambda x:jnp.interp(atom.line_frequency_hz,self.frequency,x))(pump_field)
        continuum_opacity=jax.vmap(lambda x:jnp.interp(atom.line_frequency_hz,self.frequency,x))(chi)
        u,l=atom.line_upper,atom.line_lower
        g=atom.statistical_weights
        kappa=self.kappa_factor*(bound[:,l]*g[u]/g[l]-bound[:,u])
        absorption=self.kappa_factor*bound[:,l]*g[u]/g[l]
        fine=kappa@self.fine_matrix
        multiplet=kappa@self.multiplets
        delta=fine*self.widths[:,None]
        # C23 convention: escape and TauCon at front of each zone; shielding
        # then applies its explicit finite-zone correction, separately.
        # An exclusive sum preserves the exact zero at the illuminated face;
        # inclusive-sum minus local depth can round to a tiny negative in XLA.
        tau_in=jnp.concatenate((jnp.cumsum(delta[::-1],axis=0)[:-1][::-1],jnp.zeros_like(delta[:1])),axis=0)
        tau_total=jnp.sum(delta,axis=0)
        scattering=ne[:,None]*6.6524587321e-25
        if self.rayleigh:
            scattering=scattering+bound[:,0,None]*self.rayleigh_line
        albedo=scattering/(scattering+continuum_opacity)
        operators=line_operators(self.kind,tau_in=tau_in,tau_total=tau_total,tau_pump=tau_in,
            damping=self.damping,line_extinction_cm1=kappa,lower_absorption_cm1=absorption,
            multiplet_extinction_cm1=multiplet,continuum_absorption_cm1=continuum_opacity,
            electron_cm3=ne[:,None],einstein_a_s=atom.einstein_a_s,lower_weight=g[l],upper_weight=g[u],
            incident_occupation=pump_occupation,outward_continuum_occupation=0.,
            zone_width_cm=self.widths[:,None],upper_population_cm3=bound[:,u],albedo=albedo,
            stark_escape_probability=hydrogen_stark_escape(atom.principal_n[u],atom.principal_n[l],
                ne[:,None],self.temperature,tau_in) if self.stark else 0.)
        photon_flux=operators.destroyed_photons_cm3_s/continuum_opacity
        photo_ots=photon_flux@self.sigma_line.T
        recombination_ots=photon_flux@(self.sigma_line*self.inverse_line).T
        photo=occupation@self.photo_kernel.T
        alpha=(1+occupation)@(self.photo_kernel*self.inverse).T
        if self.ots:
            photo,alpha=photo+photo_ots,alpha+recombination_ots
        radiation=jnp.zeros((self.cells,len(g),len(g)))
        radiation=radiation.at[:,l,u].add(operators.pump_up_s)
        radiation=radiation.at[:,u,l].add(operators.radiative_down_s)
        radiation=radiation.at[:,1,0].set(TWO_PHOTON_A_S)
        collisions=self.collision+(proton/ne)[:,None,None]*jax.vmap(lambda electron:mixing_bound_bound_cm3_s(atom,self.temperature,electron))(ne)
        rates=RateCoefficients(radiation,collisions,photo,alpha,
                               jnp.broadcast_to(self.ion,bound.shape),jnp.broadcast_to(self.q3,bound.shape))
        # Sum net BF absorption of destroyed photons; residual is mainly FF.
        net_ots_bf=jnp.sum(bound*photo_ots-pair[:,None]*recombination_ots,axis=1)
        return dict(rates=rates,line_operators=operators,continuum=transfer,
                    mean_intensity=transfer.mean_intensity,pump_mean_intensity=pump_field*prefactor,
                    continuum_opacity_cm1=chi,continuum_emission=emission,
                    photoionization_ots_s=photo_ots,recombination_ots_cm3_s=recombination_ots,
                    net_ots_bound_free_cm3_s=net_ots_bf,ots_photon_flux_cm2_s=photon_flux,
                    line_continuum_absorption_cm1=continuum_opacity,
                    tau_in=tau_in,tau_total=tau_total,line_extinction_cm1=kappa,
                    multiplet_extinction_cm1=multiplet,line_albedo=albedo,
                    pump_occupation=pump_occupation)

    @partial(jax.jit,static_argnums=0,static_argnames=("iterations",))
    def solve(self,density,dilution,initial,*,iterations=40):
        shape=initial.shape
        def residual(flat):
            ratios=flat.reshape(shape)
            _,ne,rates,*_=self.state(ratios,density,dilution)
            target=jax.vmap(_bound_ratios)(ne,rates)
            return (ratios-jnp.log(target)).ravel()
        root=jax.lax.custom_root(residual,initial.ravel(),
            lambda fn,guess:_newton(fn,guess,iterations),
            lambda linear,rhs:jnp.linalg.solve(jax.jacfwd(linear)(jnp.zeros_like(rhs)),rhs))
        state=root.reshape(shape)
        norm=jnp.max(jnp.abs(residual(root)))
        bound,ne,rates,ops,transfer,photo_ots,net_ots=self.state(state,density,dilution)
        return dict(state=state,bound_cm3=bound,electron_cm3=ne,residual_norm=norm,
                    converged=transfer.converged&jnp.isfinite(norm)&(norm<1e-8),
                    photoionization_s=rates.photoionization_s,photoionization_ots_s=photo_ots,
                    destruction_cm3_s=ops.destroyed_photons_cm3_s,
                    net_ots_bound_free_cm3_s=net_ots,continuum_transfer_error=transfer.residual_norm)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--nmax",type=int,default=3)
    parser.add_argument("--cells",type=int,default=8)
    parser.add_argument("--column",type=float,default=1e18)
    parser.add_argument("--order",type=int,default=4)
    parser.add_argument("--iterations",type=int,default=40)
    parser.add_argument("--without-ots",action="store_true")
    parser.add_argument("--without-stark",action="store_true")
    parser.add_argument("--without-rayleigh",action="store_true")
    parser.add_argument("--full-lifetime",action="store_true")
    parser.add_argument("--scattering-attenuation",action="store_true")
    args=parser.parse_args()
    jax.config.update("jax_enable_x64",True)
    model=EPSlab(args.nmax,args.cells,args.column,1e12,8000.,order=args.order,ots=not args.without_ots,stark=not args.without_stark,
                 rayleigh=not args.without_rayleigh,upper_lifetime=not args.full_lifetime,
                 scattering_attenuation=args.scattering_attenuation)
    data=np.load(args.reference)
    depth=args.column/1e12-(np.asarray(model.edges[:-1])+np.asarray(model.edges[1:]))/2
    bound=np.column_stack([np.exp(np.interp(depth,data["depth_cm"],np.log(row)))
                           for row in data["bound_cm3"][:,:args.nmax+3].T])
    ne=np.interp(depth,data["depth_cm"],data["electron_cm3"])
    initial=jnp.log(bound/ne[:,None])
    start=time.time()
    result=model.solve(jnp.asarray(1e12),jnp.asarray(.025),initial,iterations=args.iterations)
    arrays={k:np.asarray(v) for k,v in result.items()}
    args.output.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(args.output/"solution.npz",**arrays,depth_cm=depth)
    metrics=dict(configuration={k:str(v) if isinstance(v,Path) else v for k,v in vars(args).items()},
                 elapsed_seconds=time.time()-start,converged=bool(arrays["converged"]),
                 residual_norm=float(arrays["residual_norm"]),continuum_transfer_error=float(arrays["continuum_transfer_error"]),
                 n2_cm3=(arrays["bound_cm3"][:,1:3].sum(axis=1)).tolist(),
                 n3_cm3=(arrays["bound_cm3"][:,3:6].sum(axis=1)).tolist())
    (args.output/"metrics.json").write_text(json.dumps(metrics,indent=2)+"\n")
    print(json.dumps(metrics,indent=2),flush=True)


if __name__=="__main__":
    main()
