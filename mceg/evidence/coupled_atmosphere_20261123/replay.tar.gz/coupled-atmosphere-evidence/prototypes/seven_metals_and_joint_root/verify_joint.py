"""Check conservation and an implicit derivative of the converged fixed-T root."""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import time

import jax
import jax.numpy as jnp
import numpy as np

from joint_slab import JointSlab


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory',type=Path)
    args=parser.parse_args()
    prior=json.loads((args.directory/'metrics.json').read_text())
    assert prior['converged'], 'Implicit derivative is not certified at an unconverged root.'
    jax.config.update('jax_enable_x64',True)
    model=JointSlab(cells=prior['cells'])
    data=np.load(args.directory/'solution.npz')
    initial=jnp.asarray(data['state'])
    start=time.time()
    initial,base_norm,base_physical=model.solve(initial,.025,1.,iterations=12)
    assert bool(base_physical['valid']) and float(base_norm)<1e-8

    def signal(log_dilution):
        _,_,physical=model.solve(initial,.025*jnp.exp(log_dilution),1.,iterations=12)
        n3=jnp.sum(physical['bound_cm3'][:,3:6],axis=1)
        return jnp.log(jnp.sum(n3*model.hydrogen.widths))

    automatic=float(jax.jit(jax.grad(signal))(0.))
    step=1e-4
    signals=[]
    shifted_norms=[]
    for shift in (step,-step):
        _,norm,physical=model.solve(initial,.025*jnp.exp(shift),1.,iterations=12)
        assert bool(physical['valid']) and float(norm)<1e-8
        signals.append(float(jnp.log(jnp.sum(jnp.sum(physical['bound_cm3'][:,3:6],axis=1)*model.hydrogen.widths))))
        shifted_norms.append(float(norm))
    finite=(signals[0]-signals[1])/(2*step)
    relative=abs(automatic-finite)/max(abs(finite),1e-30)
    bound,proton,electron,elements,ions=model.unpack(initial,1.)
    hydrogen_error=float(jnp.max(abs((jnp.sum(bound,axis=1)+proton)/model.density-1)))
    element_error=float(jnp.max(abs(jnp.sum(ions,axis=2)/elements-1)))
    electron_error=float(jnp.max(abs((proton+jnp.einsum('csq,q->c',ions,jnp.arange(3)))/electron-1)))
    hstate=model.hydrogen.population_state(bound,proton,electron,.025,
        additional_opacity=model.metal.continuum_opacity(ions))
    transfer=hstate['continuum']
    assert bool(transfer.converged)
    photo=data['metal_photoionization_s']
    leakage=float(np.sum(data['metal_ion_cm3'][:,:,2]*photo[:,:,2])/
                  np.sum(data['metal_ion_cm3'][:,:,:2]*photo[:,:,:2]))
    record={'scope':'Two-cell fixed-T H n<=3 plus seven-metal population root, BB10000 W=.025, nH1e12, NH1e18. Conditional implementation check; omissions in metrics.json still apply.',
            'observable':'log integrated n=3 H column versus log incident dilution',
            'automatic_derivative':automatic,'finite_difference':finite,'derivative_relative_error':relative,
            'hydrogen_conservation_relative_error':hydrogen_error,'element_conservation_relative_error':element_error,
            'charge_conservation_relative_error':electron_error,'omitted_top_stage_photoevent_fraction':leakage,
            'root_residual_norm':float(base_norm),'finite_difference_root_residuals':shifted_norms,
            'continuum_converged':bool(transfer.converged),'continuum_residual_norm':float(transfer.residual_norm),
            'runtime_source_files':{name:{'path':module.__file__,'sha256':hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()}
                for name,module in sys.modules.copy().items() if (name=='escape' or name.startswith('escape.') or name=='exojax' or name.startswith('exojax.'))
                and getattr(module,'__file__',None) and str(module.__file__).endswith('.py')},
            'elapsed_seconds':time.time()-start,
            'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (
                Path(__file__),Path(__file__).with_name('joint_slab.py'),Path(__file__).with_name('metal_network.py'))}}
    passed=np.isfinite(automatic) and relative<1e-4 and max(hydrogen_error,element_error,electron_error)<1e-12
    record['passed']=bool(passed)
    (args.directory/'verification.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    np.savez_compressed(args.directory/'solution_rechecked.npz',state=np.asarray(initial),
        **{key:np.asarray(value) for key,value in base_physical.items()})
    print(json.dumps(record,indent=2),flush=True)
    assert passed


if __name__=='__main__':main()
