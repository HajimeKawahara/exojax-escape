# Shared H/metal population root

This experiment connects the independently checked atomic kernels to one
population-dependent radiation field. It is a fixed-temperature numerical
experiment, not a solar-composition thermal/wind model or a reproduction of
the observed planet spectrum. It is outside the packaged escape code.

The test uses two uniform cells, nH=1e12 cm^-3, NH=1e18 cm^-2, T=8000 K,
and a normal incident blackbody beam with Tstar=10000 K and W=0.025. Hydrogen
resolves n<=3; C I, Mg II, Al II, Si II, Ca II, Mn II, and Fe II retain 200
excitation levels and 3,427 radiative transitions in total. Each metal has
three charge stages. There are 426 log-population unknowns.

`joint_slab.py` passes H and metal bound-free opacity to the same continuum
transfer solver. The resulting intensity supplies both H and metal
photoionization and line pumping. H and metal line destruction produces local
OTS photons shared among the same absorbers. The metal charge ladders use the
independently evaluated RR, DR with density suppression, H/He CT, Cota, and
ground-state photoionization kernels. CT transfers are returned to H in the
opposite direction. Electron density is proton density plus the retained metal
charges. Excited metal states solve their full local rate matrices while their
populations update line optical depths and escape probabilities.

Two integration details mattered. Proton l-mixing uses ne for Debye screening
but np for the collision frequency. Also, the signed formal bound-free
extinction used by the earlier H prototype can become weakly negative near
the n=3 threshold. Cloudy's EP continuum instead suppresses gain **per level**
in `opacity_add1subshell.cpp:116-126`. The final experiment explicitly selects
that C23 model option, `cloudy_bound_free=True`; it does not silently alter the
signed formal-transfer model. Earlier failed attempts are retained separately.

| Check | Result |
| --- | --- |
| Joint log-population residual | 3.29e-13 |
| d log integrated H(n=3) column / d log W, implicit AD | 0.425710039845 |
| Same derivative, centered finite difference | 0.425710034548 |
| Relative derivative difference | 1.24e-8 |
| H-nucleus and retained-charge conservation | 0 at printed precision |
| Element-nucleus conservation | 2.22e-16 relative |
| PI events into omitted charge stages, this test only | 2.07e-10 of retained metal PI events |

Metal abundance continuation (.001, .03, 1 of the stated subset abundances)
is only a root-initialization method. No Cloudy populations, heating curves,
photoionization rates, or line escape probabilities are supplied to this joint
root. A previously converged native H slab supplies the starting guess.

Known omissions remain: metal RR/DR continuum emission, metal collisional and
excited-state photoionization, non-electron/nonthermal metal excitation,
H-minus/H2-plus chemistry and energy, helium ionization, additional coolants,
thermal and wind equations, the actual stellar spectrum, and the observation
operator. The full-chemistry reference shows H-minus free-bound and H2-plus
terms accounting for about 43% and 22% of cooling near 1.1 Rp, respectively.
Seven metal heating channels alone therefore cannot establish the solar
thermal closure. The reference's actual PHOENIX continuum resolution and this
joint model's spatial/atomic convergence also remain unverified.

The executable entrypoint for this experiment is `joint_slab.py:JointSlab`,
not `escape.atmosphere.HydrogenAtmosphereModel.spectrum`. These results must
not be used as physical support for that packaged observer or for Yapeng-model
equivalence. The appropriate next step is a separate, reviewed implementation
with explicit closure and convergence requirements.
