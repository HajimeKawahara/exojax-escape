"""Validate the conditional metal kernel against actual C23.01 SE matrices."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

import jax
import jax.numpy as jnp
import numpy as np

from metal_se import (COLLISION_CONSTANT, load_atom, electron_collision_coefficients,
                      populations, kinetic_line_heating, solve_species)

jax.config.update('jax_enable_x64',True)
ROOT=Path('/tmp/escape-metal-prototype')
LABELS={26:'Fe II',20:'Ca II',12:'Mg II',14:'Si II',6:'C I',13:'Al II',25:'Mn II'}


def parse(path):
    rows=[line.split() for line in path.read_text().splitlines()]
    head=list(map(float,rows[0][1:]))
    iteration, zone, radius, temperature, electron, abundance, count, cooling, constant=head
    count=int(count)
    result=dict(iteration=int(iteration),zone=int(zone),radius_rp=radius,temperature=temperature,
                electron=electron,abundance=abundance,levels=count,cooling=cooling,
                collision_constant=constant,path=str(path),
                source_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    level=np.array([list(map(float,row[1:])) for row in rows if row[0]=='LEVEL'])
    result.update(weight=level[:,1],energy=level[:,2],population=level[:,3],source=level[:,4],sink=level[:,5])
    matrices={name:np.zeros((count,count)) for name in ('radiative','collision','electron_coefficient','base_pump','a','loss','extra_radiative')}
    for row in rows:
        if row[0]=='ELEMENT':
            result['element'],result['element_total']=int(row[1]),float(row[2])
        if row[0]=='ION':
            result.setdefault('ions',{})[row[1]]=float(row[2])
        if row[0]=='COLLIDERS':
            result['collider_densities_cm3']=dict(zip(('electron','H I','H II','He I','He II','He III'),map(float,row[1:])))
        if row[0]=='CHARGE_RATE':
            result.setdefault('charge_rates',{})[row[1]]=dict(zip(
                ('RateIonizTot_s1','RateRecomTot_s1','RR_rate_coef_used_cm3_s','DR_Badnell_rate_coef_cm3_s',
                 'CX_recomb_rate_used','H_CharExcIonOf_cm3_s','H_CharExcRecTo_cm3_s',
                 'He_CharExcIonOf_cm3_s','He_CharExcRecTo_cm3_s'),map(float,row[2:])))
        if row[0]!='RATE':continue
        lo,hi=map(int,row[1:3]);esc,dest,up,down,clu,cul,qe,a,base,cool,nonthermal=map(float,row[3:])
        matrices['radiative'][lo,hi]=up
        matrices['radiative'][hi,lo]=esc+dest+down
        matrices['collision'][lo,hi]=clu
        matrices['collision'][hi,lo]=cul
        matrices['electron_coefficient'][hi,lo]=qe
        matrices['base_pump'][lo,hi]=base
        matrices['a'][hi,lo]=a
        matrices['loss'][hi,lo]=(esc+dest)/a if a>0 else 0
        matrices['extra_radiative'][lo,hi]=up-base
        matrices['extra_radiative'][hi,lo]=down-base*result['weight'][lo]/result['weight'][hi]
    result.update(matrices)
    return result


def relative_l1(value,reference):
    return float(np.sum(np.abs(np.asarray(value)-reference))/np.sum(np.abs(reference)))


records=[parse(path) for path in (ROOT/'solar-column').glob('metal_atom_*.txt')]
last_iteration=max(record['iteration'] for record in records)
records=[record for record in records if record['iteration']==last_iteration]
report={'scope':'Conditional local multilevel SE and kinetic line heating. Cloudy supplies ion abundance, line pumping/loss and non-electron/extra rates. No independent solar atmosphere or ionization closure.',
        'cloudy_iteration':last_iteration,'cases':[],'ion_fractions':[],
        'source_sha256':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in ('metal_se.py','validate.py','species2.cpp')},
        'baseline_identical':{}}
for name in ('model.in','model.conditions','model.heating','model.cooling','model.levels','model.overview'):
    report['baseline_identical'][name]=(ROOT/'solar-column'/name).read_bytes()==(Path('/tmp/escape-sunbather-solar-1e13/iteration_000')/name).read_bytes()

for element,species in LABELS.items():
    candidates=[record for record in records if record['element']==element]
    for target in (1.1,1.3,1.8,2.5):
        ref=min(candidates,key=lambda record:abs(record['radius_rp']-target))
        if abs(ref['radius_rp']-target)>.06:continue
        report['ion_fractions'].append(dict(species=species,radius_rp=ref['radius_rp'],
            element_total_cm3=ref['element_total'],species_density_cm3=ref['abundance'],
            stage_fraction={stage:amount/ref['element_total'] for stage,amount in ref['ions'].items() if amount/ref['element_total']>1e-8},
            ion_sum_over_element_total=sum(ref['ions'].values())/ref['element_total'],
            charge_rates=ref.get('charge_rates',{}),collider_densities_cm3=ref.get('collider_densities_cm3',{})))
        atom, provenance=load_atom('/tmp/cloudy-reference-run/c23.01/data',species,ref['levels'])
        solved=populations(ref['radiative']+ref['collision'],ref['abundance'])
        heat=kinetic_line_heating(solved,ref['collision'],ref['energy'])
        qe=np.asarray(electron_collision_coefficients(atom,ref['temperature']))
        lower=np.tril(np.ones_like(qe,dtype=bool),k=-1)
        qe_ref=ref['electron_coefficient']
        # Detailed balance constructs the reverse electron coefficients; all
        # remaining collider/nonthermal terms remain explicit reference input.
        de=ref['energy'][:,None]-ref['energy'][None,:]
        full_qref=qe_ref+(qe_ref*ref['weight'][:,None]/ref['weight'][None,:]
                          *np.exp(-np.maximum(de,0)*6.62607015e-27*2.99792458e10/(1.380649e-16*ref['temperature']))).T
        extra_collision=ref['collision']-ref['electron']*full_qref
        native,native_heat=solve_species(atom,ref['temperature'],ref['electron'],ref['abundance'],
            ref['base_pump'],ref['loss'],ref['extra_radiative'],extra_collision)
        row=dict(species=species,radius_rp=ref['radius_rp'],temperature_k=ref['temperature'],
                 electron_cm3=ref['electron'],levels=ref['levels'],provenance=provenance,
                 reference_matrix_sha256=ref['source_sha256'],
                 matrix_population_relative_l1=relative_l1(solved,ref['population']),
                 matrix_heating_relative_error=float(heat/(-ref['cooling'])-1),
                 reference_heating_erg_cm3_s=-ref['cooling'],
                 energy_max_absolute_wavenumber_difference=float(np.max(abs(np.asarray(atom.energy_wavenumber)-ref['energy']))),
                 electron_down_relative_l1=relative_l1(qe[lower],qe_ref[lower]),
                 electron_down_max_relative_error=float(np.max(abs(qe[lower]/qe_ref[lower]-1))),
                 atomic_a_relative_l1=relative_l1(atom.spontaneous,ref['a']),
                 parsed_population_relative_l1=relative_l1(native,ref['population']),
                 parsed_heating_relative_error=float(native_heat/(-ref['cooling'])-1),
                 maximum_source_cm3_s=float(max(abs(ref['source']))),maximum_sink_s1=float(max(abs(ref['sink']))),
                 extra_collision_relative_l1=float(np.sum(abs(extra_collision))/np.sum(abs(ref['collision']))),
                 extra_radiative_relative_l1=float(np.sum(abs(ref['extra_radiative']))/np.sum(abs(ref['radiative']))))
        row['conditional_omission_controls']={}
        for name, extra_rad, extra_coll in (
            ('remove_overlap_and_extra_radiation',np.zeros_like(ref['extra_radiative']),extra_collision),
            ('electron_collisions_only',ref['extra_radiative'],np.zeros_like(extra_collision)),
        ):
            control, control_heat=solve_species(atom,ref['temperature'],ref['electron'],ref['abundance'],
                ref['base_pump'],ref['loss'],extra_rad,extra_coll)
            row['conditional_omission_controls'][name]={
                'population_relative_l1_change':relative_l1(control,np.asarray(native)),
                'signed_heat_relative_change':float((control_heat-native_heat)/abs(native_heat)),
                'scope':'Fixed local T/ne/ion density and fixed Cloudy pumping/loss; not an atmosphere or observable error bound.'}
        if target==1.1:
            def signal(parameters):
                return solve_species(atom,ref['temperature']*jnp.exp(parameters[0]),
                    ref['electron']*jnp.exp(parameters[1]),ref['abundance'],
                    ref['base_pump']*jnp.exp(parameters[2]),ref['loss'],ref['extra_radiative'],extra_collision)[1]
            point=jnp.zeros(3); derivative=np.asarray(jax.grad(signal)(point))
            step=1e-4
            finite=np.array([(signal(point.at[i].set(step))-signal(point.at[i].set(-step)))/(2*step) for i in range(3)])
            row['conditional_gradient_relative_errors']=(abs(derivative-finite)/np.maximum(abs(finite),1e-30)).tolist()
        report['cases'].append(row)
        print(species,round(ref['radius_rp'],4),'matrixPop',row['matrix_population_relative_l1'],
              'parsedQ',row['electron_down_relative_l1'],'heat',row['parsed_heating_relative_error'],flush=True)
assert len(report['cases'])==28
assert all(report['baseline_identical'].values())
assert max(row['matrix_population_relative_l1'] for row in report['cases'])<1e-12
assert max(abs(row['matrix_heating_relative_error']) for row in report['cases'])<1e-10
assert max(row['parsed_population_relative_l1'] for row in report['cases'])<1e-6
assert max(abs(row['parsed_heating_relative_error']) for row in report['cases'])<5e-5
assert max(error for row in report['cases'] for error in row.get('conditional_gradient_relative_errors',[]))<1e-6
report['conditional_checks_passed']=True
temporary=ROOT/'validation.inprogress.json'
temporary.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
temporary.replace(ROOT/'validation.json')
print('Wrote',ROOT/'validation.json',flush=True)
