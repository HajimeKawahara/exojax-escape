"""Create a reporting-only C23.01 matrix diagnostic outside the provider repo."""
from pathlib import Path
import shutil
import subprocess

root = Path('/tmp/escape-metal-prototype')
source = Path('/tmp/cloudy-reference-run/c23.01/source')
text = (source/'species2.cpp').read_text()
text = text.replace('#include "atmdat.h"', '#include "atmdat.h"\n#include "radius.h"')
before = '\t\tatom_levelN(\n'
assert text.count(before) == 1
# Debug builds clear the downward pump after solving. Preserve its input;
# the observer must not reconstruct it from the post-solve mutable argument.
text = text.replace(before, '''        vector<double> diagnostic_pump_down(dBaseSpecies[ipSpecies].numLevels_local*dBaseSpecies[ipSpecies].numLevels_local);
        for (long dhi=1; dhi<dBaseSpecies[ipSpecies].numLevels_local; ++dhi)
            for (long dlo=0; dlo<dhi; ++dlo)
                diagnostic_pump_down[dhi*dBaseSpecies[ipSpecies].numLevels_local+dlo]=AulPump[dhi][dlo];
''' + before)
anchor = '\t\tdBaseSpecies[ipSpecies].CoolTotal = cooltl;'
assert text.count(anchor) == 1
diagnostic = r'''
        // Reporting-only modification: overwrite the latest local SE matrices.
        // No coefficient or solution is modified; files are temporary diagnostics.
        const int diagnostic_element = dBaseStates[ipSpecies][0].nelem();
        const int diagnostic_ion = dBaseStates[ipSpecies][0].IonStg();
        const bool diagnostic_species =
            ((diagnostic_element==26 || diagnostic_element==20 || diagnostic_element==12 || diagnostic_element==14 || diagnostic_element==13 || diagnostic_element==25) && diagnostic_ion==2)
            || (diagnostic_element==6 && diagnostic_ion==1);
        const double diagnostic_radius = 3. - radius.depth_mid_zone/1.358348e10;
        if (diagnostic_species && (fabs(diagnostic_radius-1.1)<.001 || fabs(diagnostic_radius-1.3)<.001 || fabs(diagnostic_radius-1.8)<.006 || fabs(diagnostic_radius-2.5)<.06)) {
            char diagnostic_path[256];
            snprintf(diagnostic_path, sizeof(diagnostic_path), "metal_atom_%d_%d_zone%05ld.txt", diagnostic_element, diagnostic_ion, nzone);
            FILE* diagnostic_file=open_data(diagnostic_path,"w");
            if (diagnostic_file) {
                fprintf(diagnostic_file,"META %ld %ld %.17e %.17e %.17e %.17e %ld %.17e %.17e\n", iteration,nzone,diagnostic_radius,phycon.te,dense.eden,(double)abund,dBaseSpecies[ipSpecies].numLevels_local,cooltl,COLL_CONST);
                fprintf(diagnostic_file,"ELEMENT %d %.17e\n",diagnostic_element,(double)dense.gas_phase[diagnostic_element-1]);
                fprintf(diagnostic_file,"COLLIDERS %.17e %.17e %.17e %.17e %.17e %.17e\n",dense.eden,(double)dense.xIonDense[0][0],(double)dense.xIonDense[0][1],(double)dense.xIonDense[1][0],(double)dense.xIonDense[1][1],(double)dense.xIonDense[1][2]);
                for (int stage=0; stage<=diagnostic_element; ++stage)
                    fprintf(diagnostic_file,"ION %d %.17e\n",stage+1,(double)dense.xIonDense[diagnostic_element-1][stage]);
                for (int charge=0; charge<4; ++charge) {
                    const int element_index=diagnostic_element-1;
                    fprintf(diagnostic_file,"CHARGE_RATE %d %.17e %.17e %.17e %.17e %.17e %.17e %.17e %.17e %.17e\n",charge,ionbal.RateIonizTot(element_index,charge),ionbal.RateRecomTot[element_index][charge],ionbal.RR_rate_coef_used[element_index][charge],ionbal.DR_Badnell_rate_coef[element_index][charge],ionbal.CX_recomb_rate_used[element_index][charge],atmdat.CharExcIonOf[0][element_index][charge],atmdat.CharExcRecTo[0][element_index][charge],atmdat.CharExcIonOf[1][element_index][charge],atmdat.CharExcRecTo[1][element_index][charge]);
                }
                for (long level=0; level<dBaseSpecies[ipSpecies].numLevels_local; ++level)
                    fprintf(diagnostic_file,"LEVEL %ld %.17e %.17e %.17e %.17e %.17e\n",level,g[level],ex[level],pops[level],source[level],sink[level]);
                for (TransitionList::iterator tr=dBaseTrans[ipSpecies].begin(); tr!=dBaseTrans[ipSpecies].end(); ++tr) {
                    const int hi=tr->ipHi(), lo=tr->ipLo();
                    if (hi>=dBaseSpecies[ipSpecies].numLevels_local) continue;
                    const bool real=tr->ipCont()>0;
                    fprintf(diagnostic_file,"RATE %d %d %.17e %.17e %.17e %.17e %.17e %.17e %.17e %.17e %.17e %.17e %.17e\n",lo,hi,AulEscp[hi][lo],AulDest[hi][lo],AulPump[lo][hi],diagnostic_pump_down[hi*dBaseSpecies[ipSpecies].numLevels_local+lo],CollRate[lo][hi],CollRate[hi][lo],(double)tr->Coll().rate_coef_ul()[ipELECTRON],real?(double)tr->Emis().Aul():0.,real?(double)tr->Emis().pump():0.,Cool[hi][lo],(double)tr->Coll().rate_lu_nontherm());
                }
                fclose(diagnostic_file);
            }
        }
'''
(root/'species2.cpp').write_text(text.replace(anchor,anchor+diagnostic))
flags = ['g++','-std=c++11','-O2','-fno-pie','-I'+str(source),
         '-DSYS_CONFIG="'+str(source/'cloudyconfig.h')+'"']
subprocess.run(flags+['-c',str(root/'species2.cpp'),'-o',str(root/'species2.o')],check=True)
subprocess.run(['g++','-no-pie','-o',str(root/'cloudy_matrix_rates.exe'),str(source/'maincl.o'),str(root/'species2.o'),str(source/'libcloudy.a')],check=True)
baseline=Path('/tmp/escape-sunbather-solar-1e13/iteration_000')
shutil.copyfile(baseline/'model.in',root/'solar-column/model.in')
sed=root/'solar-column/SED'
if not sed.exists(): sed.symlink_to(baseline/'SED',target_is_directory=True)
print('Reporting-only matrix binary ready.')
