# Conditional metal excitation prototype

This scratch experiment implements a differentiable local multilevel atom and
its signed collisional heating. It does **not** implement a solar-composition
atmosphere. Cloudy still supplies the ion abundance, line pumping, line loss
probabilities, and residual non-electron/nonthermal rates in the parity check.
Its derivatives hold these external inputs fixed.

For transition rates `R[i,j]` from level i to j, the kernel solves

```math
\sum_j n_j R_{ji}-n_i\sum_jR_{ij}=0,\qquad \sum_i n_i=n_{\rm ion},
\qquad Q_{\rm coll}=\sum_{ij}n_i C_{ij}(E_i-E_j).
```

Positive `Q_coll` means gas heating by collisional de-excitation. Absorbed
photons are not automatically heat: radiative decay and further excitation
remain in the same level balance. The positive GTH elimination avoids losing
the small transitions in a rate matrix with widely separated time scales.
Automatic differentiation passes through this fixed-size JAX solve.

## Data and verification

`metal_se.py` reads the actual C23.01 tables: Fe II (80 levels, STOUT Smyth19),
Ca II, Mg II, and Al II (15 each, CHIANTI), Si II and C I (15 each, STOUT),
and Mn II (45 levels, STOUT). It implements
the C23 linear interpolation of effective collision strengths, CHIANTI
Burgess-Tully scaling, and C23 g-bar fallback for missing electron data. The
finite-difference gradient check varies log T, log ne, and log pump strength.

`make_readout.py` makes a reporting-only copy of `species2.cpp`, links it against
the unmodified C23.01 library, and writes the rate matrix at selected radii.
The downward pumping array is saved **before** `Atom_LevelN`: debug builds reset
that mutable argument after solving. The diagnostic does not alter any rate.
The reference column is a fixed-temperature/density PHOENIX-irradiated atomic
experiment; it is not the converged solar atmosphere or the author's input.
No raw PHOENIX spectrum is included here.

`validation.json` records all 28 cases (7 species, 4 radii). The final diagnostic
input and conditions, heating, cooling, levels, and overview outputs are byte
identical to the original unmodified Cloudy run. The extracted matrix reproduces
level populations to 4.49e-16 relative L1 and signed heat to 9.71e-14 relative
error. Rebuilding electron rates from the atomic tables gives population error
below 1.66e-8 and signed heat error below 8.05e-6; this also includes C23's
single-precision storage of some atomic quantities. Conditional AD versus
centered finite differences differs by at most 2.07e-7. These are numerical
checks at these supplied conditions, not physical validation of a solar model.

Ten tests check collisional LTE for all seven atoms, zero LTE net heat,
population conservation, a general rate-matrix derivative, and finite
temperature derivatives. Mn II has no electron collision tables for these
levels in the selected C23 data and uses the declared g-bar/tiny-CS fallbacks.
Run from this directory:

```sh
env JAX_PLATFORMS=cpu OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
  taskset -c 60-63 /home/kawahara/miniconda3/bin/python -m pytest -q test_metal_se.py
env JAX_PLATFORMS=cpu OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
  taskset -c 60-63 /home/kawahara/miniconda3/bin/python validate.py
```

The diagnostic build/run is `python make_readout.py`, then
`../cloudy_matrix_rates.exe -r model` in `solar-column`. The data root and
external baseline paths are deliberately explicit in these scratch scripts.
Use a new output directory for another campaign; completed receipts must not
be read while a Cloudy run is replacing its files.

## Ionization and omitted closures

`photoionization.py` independently evaluates C23's ground-state partial shell
cross sections, reads modern valence thresholds, and integrates a supplied
angle-integrated photon intensity into primary ionization and photoelectron
excess-energy rates. `verify_photoionization.py` compiles the unchanged C23
method bodies as an independent C++ reference. Across 13,202 shell/energy samples
for seven elements and three charge states, the maximum relative cross-section
difference is 3.34e-15 and zero support is identical. Energy derivatives and the
linear response to incident intensity also pass. This includes C23 float32
rounding of the fit coefficients; it does not include excited-state
photoionization, Auger branches, secondary electrons, or a local radiation solve.
The reported reference spectrum's own continuum-mesh convergence remains
unverified; matching its local matrix is not evidence of an accurate irradiation
or converged reference atmosphere.

`ionic_diagnostics.json` preserves the actual element and ion densities and
C23 coefficient arrays. Its metadata distinguishes their indexing: entry q of
the recombination arrays takes charge q+1 to q. `RateIonizTot` and `RateRecomTot`
exclude H/He charge transfer, which C23 adds directly to the ion matrix.
`validate_ionic_ladder.py` reconstructs three charge stages using these totals
plus charge transfer. With neutral H/He totals approximating ground populations,
the maximum total-population relative L1 error is 1.61e-4 (C at 1.1 Rp); the
minor C II fraction there differs by 1.24%. This conditional bookkeeping check
does not independently compute photoionization, Auger, or chemistry terms.

Fixed ion fractions would be a poor reduction. Between 1.1 and 2.516 Rp, Ca II
falls from 99.996% to 8.60%, Fe II from 99.994% to 75.67%, and C I from 99.35%
to 0.0318%. Charge transfer dominates the Fe II/III and Si II/III balance at
the lower sampled radius. Independent photoionization, recombination and charge
transfer must be coupled to H/He and charge conservation.

The local controls in `validation.json` remove residual radiative rates or
non-electron/nonthermal collisions while retaining Cloudy's other inputs. Extra
radiative rates are zero for these selected atoms and conditions. Omitting
non-electron/nonthermal collisions changes the lower-layer metal heating by
up to 2.06%; the relative change for weak upper-layer C I heat reaches 30.2%.
Neither test bounds the change in a coupled atmosphere or observed spectrum.
The first five ions account for about 93.8% of database line heating near
1.1 Rp; including Al II and Mn II raises this to about 99.59% in that fixed
state. The remaining terms cannot be declared negligible without a specified
observable error budget, especially near cancellation of total heating/cooling.

To integrate this kernel, independently update the metal ion ladder, ne/H/He,
continuum attenuation, and every retained line's pump and escape/destruction
probabilities. Then close thermal balance and wind, synthesize the same observed
spectrum, and test species/level/process reductions against the full solar
reference. H-minus, helium, missing coolants, and the lower-atmosphere law remain
separate required checks. A frozen Cloudy heat curve or ion fraction would not
meet this scope.

## Source and license

The equations/interpolation follow C23.01 `species2.cpp`, `atom_leveln.cpp`, and
`transition.cpp`. Ion-matrix bookkeeping follows `ion_solver.cpp:679-747` and
`ion_recomb.cpp:83`. The diagnostic is an explicitly modified reporting copy;
`Cloudy-license.txt` preserves the original license. Atomic table source paths
and SHA-256 hashes are in the per-case provenance. Those table files retain
their own scientific references; they are not redistributed in the snapshot.
