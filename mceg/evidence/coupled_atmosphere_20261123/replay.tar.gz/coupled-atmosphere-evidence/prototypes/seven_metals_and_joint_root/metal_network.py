"""Experimental seven-element population callback for a shared H continuum.

Circuit verification only. Ground-state PI, three charge stages, electron-only
excitation and C23-like escape probabilities are explicit reductions. Metal RR/
DR continuum emission, excited-state PI, collisional ionization, secondary
electrons, and omitted species are not implemented. No thermal closure claim.
"""
from functools import partial

import jax
import jax.numpy as jnp
import numpy as np

from ionic_rates import read_fits, radiative_recombination, raw_dielectronic_recombination, charge_exchange
from dr_suppression import suppression
from cota_recombination import recombination as cota_recombination
from line_closure import line_operators, CORE, WING, PRD
from metal_se import load_atom, electron_collision_coefficients, populations, kinetic_line_heating, PLANCK, C, KB
from photoionization import load_photoionization, photoionization_cross_sections, EV_ERG

SPECIES = (('C I',6,15,0,12.011),('Mg II',12,15,1,24.305),
           ('Al II',13,15,1,26.982),('Si II',14,15,1,28.085),
           ('Ca II',20,15,1,40.078),('Mn II',25,45,1,54.938),
           ('Fe II',26,80,1,55.845))


def frequency_edges(data_root):
    edges=[]
    for _,z,_,_,_ in SPECIES:
        for charge in range(3):
            fit=load_photoionization(data_root,z,charge)
            edges.extend(np.asarray(fit.threshold_ev)[np.asarray(fit.valid)]*EV_ERG/PLANCK)
    return np.unique(edges)


class MetalNetwork:
    def __init__(self,frequency_hz,weights_dnu,widths_cm,temperature_k,*,data_root,cota_data):
        self.frequency=jnp.asarray(frequency_hz)
        self.weights=jnp.asarray(weights_dnu)
        self.widths=jnp.asarray(widths_cm)
        self.temperature=temperature_k
        self.fits=read_fits(data_root)
        self.cota=cota_data
        self.atoms=[]
        self.photo=[]
        self.lines=[]
        self.slices=[]
        offset=0
        for label,z,count,stage,mass in SPECIES:
            atom,_=load_atom(data_root,label,count)
            self.atoms.append(atom)
            self.photo.append(tuple(load_photoionization(data_root,z,q) for q in range(3)))
            upper,lower=np.where(np.asarray(atom.spontaneous)>0.)
            upper,lower=jnp.asarray(upper),jnp.asarray(lower)
            a=atom.spontaneous[upper,lower]
            frequency=(atom.energy_wavenumber[upper]-atom.energy_wavenumber[lower])*C
            velocity=jnp.sqrt(2*KB*temperature_k/(mass*1.66053906660e-24))
            width=frequency*velocity/C
            lifetime_rate=jnp.sum(atom.spontaneous,axis=1)
            damping=lifetime_rate[upper]/(4*jnp.pi*width)
            factor=C*C*a/(8*jnp.pi*frequency**2)/(jnp.sqrt(jnp.pi)*width)
            kind=jnp.where(lower==0,CORE,WING) if z==26 else jnp.full_like(lower,PRD)
            self.lines.append((upper,lower,frequency,a,damping,factor,kind))
            self.slices.append(slice(offset,offset+count+1))
            offset+=count+1  # two ion ratios and count-1 excited-level ratios
        self.state_size=offset
        self.cross=self.cross_sections(self.frequency)

    def cross_sections(self,frequency):
        energy=jnp.asarray(frequency)*PLANCK/EV_ERG
        return jnp.stack([jnp.stack([jnp.sum(photoionization_cross_sections(fit,energy),axis=-1)
                                    for fit in fits]) for fits in self.photo])

    def unpack(self,state,element_density):
        """Positive densities; each element conserves its explicitly supplied total."""
        ions=[]
        levels=[]
        for atom,spec,block in zip(self.atoms,SPECIES,self.slices):
            local=state[:,block]
            charge=jax.nn.softmax(jnp.column_stack((local[:,0],jnp.zeros(len(local)),local[:,1])),axis=1)
            index=len(ions)
            ion=element_density[:,index,None]*charge
            excitation=jax.nn.softmax(jnp.column_stack((jnp.zeros(len(local)),local[:,2:])),axis=1)
            ions.append(ion)
            levels.append(ion[:,spec[3],None]*excitation)
        return jnp.stack(ions,axis=1),tuple(levels)

    def continuum_opacity(self,ion_density):
        return jnp.einsum('csq,sqf->cf',ion_density,self.cross)

    def initialize(self,element_density):
        cells=len(element_density)
        blocks=[]
        for atom in self.atoms:
            excitation=jnp.log(atom.weight[1:]/atom.weight[0])-PLANCK*C*(atom.energy_wavenumber[1:]-atom.energy_wavenumber[0])/(KB*self.temperature)
            blocks.append(jnp.broadcast_to(jnp.r_[0.,0.,excitation],(cells,len(excitation)+2)))
        return jnp.concatenate(blocks,axis=1)

    def evaluate(self,state,element_density,electron,hydrogen_ground,proton,helium_ground,helium_ion,hydrogen_state,hydrogen_line_frequency):
        """Return target populations and metal destruction events in the shared field."""
        ion,level_populations=self.unpack(state,element_density)
        mean=hydrogen_state['mean_intensity']
        pump=hydrogen_state['pump_mean_intensity']
        opacity=hydrogen_state['continuum_opacity_cm1']
        photon_integral=4*jnp.pi*mean/(PLANCK*self.frequency)*self.weights
        photo=jnp.einsum('cf,sqf->csq',photon_integral,self.cross)
        h_cross=self.cross_sections(hydrogen_line_frequency)
        photo+=jnp.einsum('cf,sqf->csq',hydrogen_state['ots_photon_flux_cm2_s'],h_cross)
        target_excitation=[]
        heat=[]
        destroyed_flux=[]
        line_frequencies=[]
        valid=jnp.asarray(True)
        for atom,levels,line in zip(self.atoms,level_populations,self.lines):
            upper,lower,nu,a,damping,factor,kind=line
            g=atom.weight
            kappa=factor*(levels[:,lower]*g[upper]/g[lower]-levels[:,upper])
            absorption=factor*levels[:,lower]*g[upper]/g[lower]
            delta=kappa*self.widths[:,None]
            tau_in=jnp.concatenate((jnp.cumsum(delta[::-1],axis=0)[:-1][::-1],jnp.zeros_like(delta[:1])),axis=0)
            continuum=jax.vmap(lambda row:jnp.interp(nu,self.frequency,row))(opacity)
            local_pump=jax.vmap(lambda row:jnp.interp(nu,self.frequency,row))(pump)
            operators=line_operators(kind,tau_in=tau_in,tau_total=jnp.sum(delta,axis=0),tau_pump=tau_in,
                damping=damping,line_extinction_cm1=kappa,lower_absorption_cm1=absorption,
                continuum_absorption_cm1=continuum,electron_cm3=electron[:,None],einstein_a_s=a,
                lower_weight=g[lower],upper_weight=g[upper],incident_occupation=local_pump/(2*PLANCK*nu**3/C**2),
                outward_continuum_occupation=0.,zone_width_cm=self.widths[:,None],upper_population_cm3=levels[:,upper])
            radiation=jnp.zeros((len(state),len(g),len(g))).at[:,lower,upper].add(operators.pump_up_s)
            radiation=radiation.at[:,upper,lower].add(operators.radiative_down_s)
            collision=electron[:,None,None]*electron_collision_coefficients(atom,self.temperature)
            population=jax.vmap(populations)(radiation+collision,jnp.sum(levels,axis=1))
            target_excitation.append(jnp.log(population[:,1:]/population[:,:1]))
            heat.append(jax.vmap(kinetic_line_heating,in_axes=(0,0,None))(levels,collision,atom.energy_wavenumber))
            destroyed_flux.append(operators.destroyed_photons_cm3_s/continuum)
            line_frequencies.append(nu)
            valid&=jnp.all(jnp.isfinite(population))
        event_frequency=jnp.concatenate(line_frequencies)
        event_flux=jnp.concatenate(destroyed_flux,axis=1)
        photo+=jnp.einsum('cf,sqf->csq',event_flux,self.cross_sections(event_frequency))
        blocks=[]
        hydrogen_ct_ionization=jnp.zeros_like(electron)
        hydrogen_ct_recombination=jnp.zeros_like(electron)
        for index,((_,z,_,_,_),excitation) in enumerate(zip(SPECIES,target_excitation)):
            upward=[]
            downward=[]
            for q in (1,2):
                hi,hr,hei,her=charge_exchange(self.temperature,z,q,self.fits)
                recombination=(radiative_recombination(self.temperature,z,q,self.fits)
                    +raw_dielectronic_recombination(self.temperature,z,q,self.fits)*suppression(self.temperature,electron,z,q)
                    +cota_recombination(self.temperature,electron,q,self.cota))
                upward.append(photo[:,index,q-1]+hi*proton+hei*helium_ion)
                downward.append(electron*recombination+hr*hydrogen_ground+her*helium_ground)
                hydrogen_ct_ionization+=hr*ion[:,index,q]
                hydrogen_ct_recombination+=hi*ion[:,index,q-1]
            charge_ratios=jnp.column_stack((jnp.log(downward[0]/upward[0]),jnp.log(upward[1]/downward[1])))
            blocks.append(jnp.column_stack((charge_ratios,excitation)))
        return dict(target_state=jnp.concatenate(blocks,axis=1),ion_density_cm3=ion,
                    level_population_cm3=level_populations,collision_heat_erg_cm3_s=jnp.stack(heat,axis=1),
                    electron_density_cm3=jnp.einsum('csq,q->c',ion,jnp.arange(3)),
                    destroyed_line_frequency_hz=event_frequency,ots_photon_flux_cm2_s=event_flux,
                    ground_photoionization_s=photo,
                    hydrogen_ct_ionization_s=hydrogen_ct_ionization,
                    hydrogen_ct_recombination_s=hydrogen_ct_recombination,valid=valid)
