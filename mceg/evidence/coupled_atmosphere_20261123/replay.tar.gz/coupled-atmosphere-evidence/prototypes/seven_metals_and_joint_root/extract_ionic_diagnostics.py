"""Extract diagnostic ion fractions and explicitly indexed C23 coefficients."""
from pathlib import Path
import json

ROOT = Path(__file__).parent
LABELS = {26: "Fe", 20: "Ca", 12: "Mg", 14: "Si", 6: "C", 13: "Al", 25: "Mn"}
RATE_NAMES = (
    "RateIonizTot_s1", "RateRecomTot_s1", "RR_rate_coef_used_cm3_s",
    "DR_Badnell_rate_coef_cm3_s", "CX_recomb_rate_used",
    "H_CharExcIonOf_cm3_s", "H_CharExcRecTo_cm3_s",
    "He_CharExcIonOf_cm3_s", "He_CharExcRecTo_cm3_s",
)


def read(path):
    result = {"ions": {}, "charge_rates": {}, "source": str(path)}
    for line in path.read_text().splitlines():
        row = line.split()
        if row[0] == "META":
            result.update(zip(("iteration", "zone", "radius_rp", "temperature",
                               "electron", "abundance", "levels", "cooling",
                               "collision_constant"), map(float, row[1:])))
        elif row[0] == "ELEMENT":
            result.update(element=int(row[1]), element_total=float(row[2]))
        elif row[0] == "ION":
            result["ions"][row[1]] = float(row[2])
        elif row[0] == "CHARGE_RATE":
            result["charge_rates"][row[1]] = dict(zip(RATE_NAMES, map(float, row[2:])))
        elif row[0] == "COLLIDERS":
            result["collider_densities_cm3"] = dict(zip(
                ("electron", "H I", "H II", "He I", "He II", "He III"),
                map(float, row[1:])))
    return result


def main():
    records = [read(path) for path in (ROOT / "solar-column").glob("metal_atom_*.txt")]
    last = max(row["iteration"] for row in records)
    records = [row for row in records if row["iteration"] == last]
    output = []
    for element, label in LABELS.items():
        subset = [row for row in records if row["element"] == element]
        for target in (1.1, 1.3, 1.8, 2.5):
            row = min(subset, key=lambda row: abs(row["radius_rp"] - target))
            if abs(row["radius_rp"] - target) > .06:
                continue
            selected = {key: row[key] for key in (
                "radius_rp", "temperature", "electron", "element_total",
                "abundance", "charge_rates", "collider_densities_cm3", "source")}
            selected.update(element=label, requested_radius_rp=target,
                            stage_fraction={stage: amount / row["element_total"]
                                            for stage, amount in row["ions"].items()})
            output.append(selected)
    report = {
        "scope": "Fixed T/rho PHX atomic controlled column, final Cloudy iteration. Diagnostic readout, not an independent ionization calculation.",
        "index_semantics": {
            "stage_fraction": "Spectroscopic stage = ionic charge + 1.",
            "charge_rates": "Key q is zero-based ion charge. Ionization entry leaves q; recombination entry takes q+1 to q. RR/DR are coefficients for q+1 to q, not recombination of q.",
            "RateIonizTot_s1": "C23 ionbal aggregate only. Excludes CT separately added to the ion matrix in ion_solver.cpp:679-725; chemistry may contribute further sources/sinks.",
            "RateRecomTot_s1": "C23 ionbal aggregate ne*(RR+DR+Cota three-body), ion_recomb.cpp:83. Excludes H/He CT added directly to the ion matrix.",
            "CX_recomb_rate_used": "C23 diagnostic cache; do not add it to the matrix together with the explicitly reconstructed CT terms.",
            "CT_matrix": "Ionization q->q+1 uses sum k_ion(H/He)*n(H+/He+); recombination q+1->q uses sum k_rec(H/He)*n(H/He ground). Current COLLIDERS neutral totals are not exact ground populations.",
        },
        "cloudy_iteration": last,
        "rows": output,
    }
    path = ROOT / "ionic_diagnostics.json"
    temporary = path.with_suffix(".inprogress.json")
    temporary.write_text(json.dumps(report, indent=2) + "\n")
    temporary.replace(path)
    print(path, len(output), "cases")


if __name__ == "__main__":
    main()
