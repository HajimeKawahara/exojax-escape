"""Check selected molecular kernels; no chemical-equilibrium claim."""
from pathlib import Path
import hashlib
import json
import subprocess

import jax
import jax.numpy as jnp
import numpy as np

from molecular_rates import hminus_attachment,hminus_cross_section,hminus_spline,attachment_cooling

jax.config.update('jax_enable_x64',True)
root = Path(__file__).resolve().parent
temperature = np.geomspace(10,20000,1800)
energy = np.linspace(.01,2,1800)
rows = np.column_stack((temperature,energy))
raw = subprocess.run([str(root/'sample_molecular.exe')],input='\n'.join(
    ' '.join(f'{x:.17g}' for x in row) for row in rows)+'\n',capture_output=True,text=True,check=True)
reference = np.array([[float(x) for x in line.split()] for line in raw.stdout.splitlines()])
spline = hminus_spline()
actual = np.column_stack((hminus_attachment(temperature),hminus_cross_section(energy,spline)))
error = abs(actual-reference)/np.maximum(abs(reference),1e-60)
gradient=[]
for t in (4500.,7000.,10000.):
    def fun(logt):
        return jnp.log(jnp.array(attachment_cooling(t*jnp.exp(logt),1e13,1e10,1e10)))
    ad=np.asarray(jax.jacfwd(fun)(0.));fd=np.asarray((fun(1e-5)-fun(-1e-5))/2e-5)
    gradient.append(dict(temperature=t,passed=bool(np.allclose(ad,fd,rtol=1e-7,atol=1e-8))))
report=dict(scope='Spontaneous H-minus attachment and photodetachment cross section; attachment-cooling AD only. No H-minus/H2-plus chemical equilibrium, inverse-process closure or atmospheric adequacy established.',
       samples=len(rows),maximum_relative_error=error.max(axis=0).tolist(),
       passed=bool(np.allclose(actual,reference,rtol=1e-11,atol=1e-50)) and all(x['passed'] for x in gradient),
       gradient=gradient,
       source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in
                      [root/'molecular_rates.py',root/'sample_molecular.cpp',Path(__file__),
                       Path('/tmp/cloudy-causal-rates/source/mole_reactions.cpp'),
                       Path('/tmp/cloudy-causal-rates/source/cool_eval.cpp'),
                       Path('/tmp/cloudy-causal-rates/source/opacity_createall.cpp')]})
(root/'molecular_rate_verification.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
np.savez_compressed(root/'molecular_comparison.npz',inputs=rows,c23=reference,jax=actual)
print(json.dumps(report,indent=2))
raise SystemExit(0 if report['passed'] else 1)
