"""Compare the restricted implicit Cota kernel against the original C23 code."""
from pathlib import Path
import hashlib
import json
import subprocess

import jax
import jax.numpy as jnp
import numpy as np

from cota_recombination import recombination

jax.config.update('jax_enable_x64',True)
root = Path(__file__).resolve().parent
data = dict(np.load(root/'cota_coefficients.npz'))
rng = np.random.default_rng(729)
temperatures = np.r_[np.geomspace(4000,15000,500),np.exp(rng.uniform(np.log(4000),np.log(15000),500))]
densities = np.geomspace(1e5,1e14,len(temperatures))
rows = np.array([[q,t,ne] for q in (1,2,3) for t,ne in zip(temperatures,densities)])
raw = subprocess.run([str(root/'sample_cota.exe')],input='\n'.join(
     ' '.join(f'{x:.17g}' for x in row) for row in rows)+'\n',capture_output=True,text=True,check=True)
reference = np.array([float(x) for x in raw.stdout.split()])
actual = np.concatenate([np.asarray(recombination(jnp.array(temperatures),jnp.array(densities),q,data)) for q in (1,2,3)])
error = abs(actual/reference-1)
derivatives = []
for q in (1,2,3):
    def fun(x):
        return jnp.log(recombination(7000*jnp.exp(x[0]),1e11*jnp.exp(x[1]),q,data))
    x = jnp.zeros(2)
    ad = np.asarray(jax.grad(fun)(x))
    fd = np.array([float((fun(x+jnp.eye(2)[i]*1e-5)-fun(x-jnp.eye(2)[i]*1e-5))/2e-5) for i in (0,1)])
    derivatives.append(dict(charge=q,ad=ad.tolist(),fd=fd.tolist(),passed=bool(np.allclose(ad,fd,rtol=1e-5,atol=1e-8))))
report = dict(scope='Effective Cota recombination coefficient, q=1..3, T4000..15000 K, ne>=1e5 cm-3; not complete ionization balance.',
       samples=len(rows),maximum_relative_error=float(error.max()),tolerance=.001,
       intentional_numerical_changes=['Continuous parabolic fit at tabulated nodes, no +-1e-5 logT plateau',
                                      'Implicit inverse mapping solved to machine tolerance, instead of relative1e-4 iteration stop'],
       passed=bool(np.all(error<.001)) and all(x['passed'] for x in derivatives),derivatives=derivatives,
       source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in
                      [root/'sample_cota.cpp',root/'cota_recombination.py',root/'cota_coefficients.npz',Path(__file__),
                       Path('/tmp/cloudy-causal-rates/source/atmdat_3body.cpp')]})
np.savez_compressed(root/'cota_comparison.npz',inputs=rows,c23=reference,jax=actual)
(root/'cota_verification.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,indent=2))
raise SystemExit(0 if report['passed'] else 1)
