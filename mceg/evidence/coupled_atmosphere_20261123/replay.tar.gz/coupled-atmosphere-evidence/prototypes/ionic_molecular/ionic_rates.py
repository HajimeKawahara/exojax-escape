"""Diagnostic JAX kernels for low-charge C23 data; not a full ionization model.

Altered adaptation of Cloudy C23.01 atmdat_char_tran.cpp and
ion_recomb_Badnell.cpp / atmdat_adfa.cpp. Original Cloudy zlib notice must
accompany any distribution. The RR and raw DR fits exclude density suppression,
three-body terms, excited-state photoionization and charge feedback; this file
never presents their sum as Cloudy's complete recombination coefficient.
"""
from pathlib import Path
import hashlib
import json
import re
import jax.numpy as jnp
import numpy as np


def read_fits(data):
    """Read C23 ground-parent fits with recorded data identities."""
    data = Path(data)
    rr, dr_c, dr_e = {}, {}, {}
    target = rr
    for name in ('badnell_rr.dat', 'badnell_dr.dat'):
        target = rr if name == 'badnell_rr.dat' else dr_c
        for line in (data/name).read_text().splitlines():
            fields = line.split()
            if fields[:4] == ['Z', 'N', 'M', 'W']:
                if fields[4] == 'E1':
                    target = dr_e
                continue
            try:
                z, n, m, w = map(int, fields[:4])
                values = [float(v) for v in fields[4:]]
            except (ValueError, IndexError):
                continue
            if m == 1:
                target[z, n] = values
    # ADfA coefficients are stored as C++ realnum (float32), then evaluated
    # in double. Preserve that rounding for a meaningful source comparison.
    iterator = iter((data/'rad_rec.dat').read_text().split())
    next(iterator)
    old, new, iron = {}, {}, {}
    for table, count in ((old, 2), (new, 4)):
        while True:
            i, j = int(next(iterator)), int(next(iterator))
            if (i, j) == (-1, -1):
                break
            table[i, j] = np.array([float(next(iterator)) for _ in range(count)], dtype=np.float32).astype(float)
    while True:
        i = int(next(iterator))
        if i == -1:
            break
        iron[i] = np.array([float(next(iterator)) for _ in range(3)], dtype=np.float32).astype(float)
    ct_ion = np.loadtxt(data/'ctiondata.dat', skiprows=1).reshape(30, 4, 8)
    ct_rec = np.loadtxt(data/'ctrecombdata.dat', skiprows=1).reshape(30, 4, 7)
    return dict(rr=rr, dr_c=dr_c, dr_e=dr_e, old_rr=old, new_rr=new, iron_rr=iron,
                ct_ion=ct_ion, ct_rec=ct_rec,
                sha256={name:hashlib.sha256((data/name).read_bytes()).hexdigest()
                        for name in ('badnell_rr.dat','badnell_dr.dat','rad_rec.dat','ctiondata.dat','ctrecombdata.dat')})


def radiative_recombination(temperature_k, z, charge, data):
    """Ground-parent q+ -> (q-1)+ RR coefficient [cm^3/s], q=1..3."""
    if not 1 <= charge <= min(z, 3):
        raise ValueError('This diagnostic covers only low-charge stages 1..3.')
    temperature = jnp.asarray(temperature_k)
    key = z, z-charge
    if key in data['rr']:
        p = list(data['rr'][key])
        p += [0.] * (6-len(p))
        a, b, t0, t1, c, t2 = p
        b = b + c*jnp.exp(-t2/temperature)
        x, y = jnp.sqrt(temperature/t0), jnp.sqrt(temperature/t1)
        value = a/(x*(1+x)**(1-b)*(1+y)**(1+b))
    else:
        n_after = z-charge+1
        if n_after <= 3 or n_after == 11 or z in (6, 7, 8, 10) or (z == 26 and n_after > 11):
            a, b, t0, t1 = data['new_rr'][n_after-1, z-1]
            x, y = jnp.sqrt(temperature/t0), jnp.sqrt(temperature/t1)
            value = a/(x*(1+x)**(1-b)*(1+y)**(1+b))
        elif z == 26 and n_after <= 13:
            a, b, c = data['iron_rr'][n_after-1]
            scaled = temperature/1e4
            value = a/scaled**(b+c*jnp.log10(scaled))
        else:
            a, b = data['old_rr'][n_after-1, z-1]
            value = a/(temperature/1e4)**b
    return jnp.where(temperature > 0, value, jnp.nan)


def raw_dielectronic_recombination(temperature_k, z, charge, data):
    """Pre-suppression DR; NOT Cloudy's final density-dependent coefficient."""
    if not 1 <= charge <= min(z, 3):
        raise ValueError('This diagnostic covers only low-charge stages 1..3.')
    temperature = jnp.asarray(temperature_k)
    key = z, z-charge
    if key in data['dr_c']:
        c, e = jnp.array(data['dr_c'][key]), jnp.array(data['dr_e'][key])
        value = jnp.sum(c*jnp.exp(-e/temperature[..., None]), axis=-1)/temperature**1.5
    else:
        value = jnp.zeros_like(temperature) + (3.78e-13, 1.70e-12, 8.14e-12)[charge-1]
        if z == 26:
            # Arnaud & Raymond 1992, as C23 atmdat_dielrec_fe.cpp; low q.
            e, c = (([5.12,12.9],[2.20e-4,1.00e-4]),
                    ([16.7,31.4],[2.30e-3,2.70e-3]),
                    ([28.6,52.1],[1.50e-2,4.70e-3]))[charge-1]
            value += jnp.sum(jnp.array(c)*jnp.exp(-jnp.array(e)/(temperature[...,None]*8.617333262145e-5)),axis=-1)/temperature**1.5
    return jnp.where(temperature > 0, value, jnp.nan)


def hydrogen_charge_exchange(temperature_k, z, charge, data):
    """Return ionization by H+ and recombination by H0 [cm^3/s].

    These are the baseline Kingdon--Ferland tables. Element-specific later
    overrides in ChargTranEval and molecular chemistry are not folded in.
    The selected C, Mg, Si, Ca, Fe low stages need a separate override audit.
    """
    if not 1 <= charge <= 3 or z <= charge:
        raise ValueError('Use a bound low-charge metal stage 1..3.')
    temperature = jnp.asarray(temperature_k)
    rates = []
    for name in ('ct_ion', 'ct_rec'):
        p = data[name][z-1, charge-1]
        a,b,c,d,tlo,thi = p[:6]
        scaled = jnp.maximum(jnp.clip(temperature,tlo,thi)*1e-4,1e-100)
        rate = a*1e-9*scaled**b*(1+c*jnp.exp(d*scaled))
        if name == 'ct_ion':
            rate *= jnp.exp(-p[6]*1e4/temperature)
        rates.append(jnp.where(temperature > 0, rate, jnp.nan))
    return tuple(rates)


def charge_exchange(temperature_k, z, charge, data):
    """Selected default-C23 H/He CT coefficients, in cm^3/s.

    Return H-ionization, H-recombination, He-ionization, He-recombination.
    charge=q labels (q-1)+ -> q+ for ionization and its reverse. Collider
    densities must be supplied separately, using ground H0/He0 for capture.
    The optional UMIST/Leiden override and molecular/grain reactions are absent.
    No temperature-range clipping is added beyond the original table formulas.
    """
    if z not in (6,12,13,14,20,25,26) or charge not in (1,2,3):
        raise ValueError('Use C/Mg/Al/Si/Ca/Mn/Fe, charge 1..3.')
    temperature = jnp.asarray(temperature_k)
    hi, hr = hydrogen_charge_exchange(temperature,z,charge,data)
    if charge == 1:
        if z == 26:
            hi = jnp.zeros_like(temperature)+5.4e-9
        elif z == 13:
            hi = jnp.zeros_like(temperature)+3e-9
        elif z in (12,14):
            a,b,c,d = (9.76e-12,3.14,55.54,1.12) if z == 12 else (.92e-12,1.15,.80,.24)
            hi = jnp.where(temperature < 1e5,a*(temperature/1e4)**b*(1+c*jnp.exp(-d*temperature/1e4)),0.)
    hei, her = jnp.zeros_like(temperature), jnp.zeros_like(temperature)
    tev = temperature/11604.518121550082
    if z == 6:
        if charge == 1:
            hei = 6.3e-15*(temperature/300)**.75
        elif charge == 2:
            hei = 5e-20*temperature**2*jnp.exp(-.07e-4*temperature-6.29/tev)
        elif charge == 3:
            her = 4.6e-19*temperature**2
    elif z == 12 and charge == 3:
        her = jnp.zeros_like(temperature)+7.5e-10
    elif z == 14:
        if charge == 1:
            hei = jnp.zeros_like(temperature)+3.3e-9
        elif charge == 2:
            hei = 1.5e-11*temperature**.25*jnp.exp(-6.91/tev)
        elif charge == 3:
            hei = 1.15e-11*jnp.sqrt(temperature)*jnp.exp(-8.88/tev)
            her = 1.3*1.5e-12*temperature**.7
    return tuple(jnp.where(temperature > 0,x,jnp.nan) for x in (hi,hr,hei,her))


if __name__ == '__main__':
    import jax
    jax.config.update('jax_enable_x64',True)
    data=read_fits('/tmp/cloudy-causal-rates/data')
    output={'scope':'Coefficient prototype; independent source validation and full ionic closure pending.',
            'sources':data['sha256'],'cases':[]}
    for name,z in [('C',6),('Mg',12),('Si',14),('Ca',20),('Fe',26)]:
        for charge in (1,2,3):
            values={}
            for temperature in (4500.,6000.,8000.,10000.):
                ion,rec=hydrogen_charge_exchange(temperature,z,charge,data)
                values[str(temperature)]={'RR':float(radiative_recombination(temperature,z,charge,data)),
                     'DR_before_suppression':float(raw_dielectronic_recombination(temperature,z,charge,data)),
                     'CT_ion':float(ion),'CT_rec':float(rec)}
            output['cases'].append({'element':name,'charge_before_recombination':charge,'values':values})
    Path('/tmp/escape-atmosphere-probes/ionic_rates.json').write_text(json.dumps(output,indent=2)+'\n')
    print('Prepared',len(output['cases']),'low-stage coefficient diagnostics.')
