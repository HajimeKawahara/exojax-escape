"""Selected C23 H-minus attachment and H2-plus cooling/formation kernels.

Altered adaptation of Cloudy C23.01 mole_reactions.cpp, cool_eval.cpp and
opacity_createall.cpp. Original Cloudy license is retained alongside this file.
These rates alone are NOT chemical or thermal closure. Inverse photo-processes,
collisions, other reactions, and molecular continuum transfer remain required.
"""
from __future__ import annotations

import jax.numpy as jnp
import numpy as np

RYDBERG_ERG = 2.1798723611035e-11
HMINUS_THRESHOLD_RYD = .055432956


def hminus_attachment(temperature_k):
    """Spontaneous radiative attachment H+e->H-+photon [cm^3/s]."""
    t = jnp.asarray(temperature_k)
    value = jnp.select([t<31.62,t<90,t<1200,t<3800,t<=14000],
        [8.934e-18*t**.505,5.159e-18*t**.664,2.042e-18*t**.87,
         8.861e-18*t**.663,8.204e-17*t**.393],default=5.70e-16*t**.19)
    return jnp.where(t>0,value,jnp.nan)


def attachment_cooling(temperature_k,neutral_h_cm3,proton_cm3,electron_cm3):
    """Return separate H-minus and H2-plus cooling terms [erg cm^-3/s].

    The H2+ empirical cooling fit differs from its formation-rate fit below.
    This reproduces the C23 prescription; it is not a detailed-balance proof.
    Do not add these to a Milne-based thermal ledger that already counts them.
    """
    t = jnp.asarray(temperature_k)
    hminus = hminus_attachment(t)*RYDBERG_ERG*t*1.15e-5*electron_cm3*neutral_h_cm3
    h2plus = jnp.maximum((2.325*t-1875)*1e-20,0)*neutral_h_cm3*proton_cm3*1.66e-11
    return hminus,h2plus


def h2plus_attachment(temperature_k):
    """C23 radiative association H+H+->H2++photon [cm^3/s]."""
    t = jnp.asarray(temperature_k)
    return jnp.where(t>0,jnp.maximum(2.325*jnp.minimum(5000,t)-1375,0)*1e-20,jnp.nan)


def hminus_spline():
    """Construct the static natural cubic from C23's Doughty/Wishart table."""
    from scipy.interpolate import CubicSpline
    energy = np.array([0,.001459,.003296,.005256,.007351,.009595,.01201,.01460,.01741,
        .02044,.02375,.02735,.03129,.03563,.04043,.04576,.05171,.05841,.06601,.07469,
        .08470,.09638,.1102,.1268,.1470,.1723,.2049,.2483,.3090,.4001,.5520,.8557,1.7669])
    cross = np.array([0,.124,.398,.708,1.054,1.437,1.805,2.176,2.518,2.842,3.126,
        3.377,3.580,3.741,3.851,3.913,3.925,3.887,3.805,3.676,3.511,3.306,3.071,2.810,
        2.523,2.219,1.898,1.567,1.233,.912,.629,.39,.19])*1e-17
    return energy,CubicSpline(energy,cross,bc_type='natural').c


def hminus_cross_section(photon_energy_ryd,spline):
    """C23 photodetachment cross section [cm^2], zero outside its table."""
    knots,coefficients = (jnp.asarray(x) for x in spline)
    energy = jnp.asarray(photon_energy_ryd)-HMINUS_THRESHOLD_RYD
    index = jnp.clip(jnp.searchsorted(knots,energy,side='right')-1,0,len(knots)-2)
    delta = energy-knots[index]
    c = coefficients[:,index]
    value = ((c[0]*delta+c[1])*delta+c[2])*delta+c[3]
    return jnp.where((energy>=knots[0])&(energy<=knots[-1]),value,0.)
