"""Compare native metal coefficients with completed C23 diagnostic states."""
from pathlib import Path
import hashlib
import json

import jax
import jax.numpy as jnp
import numpy as np

from dr_suppression import suppression
from ionic_rates import read_fits, radiative_recombination, raw_dielectronic_recombination, charge_exchange

jax.config.update('jax_enable_x64',True)
root = Path(__file__).resolve().parent
source = Path('/tmp/escape-metal-five-species-validated-v1/ionic_diagnostics.json')
data = read_fits('/tmp/cloudy-causal-rates/data')
rows = json.loads(source.read_text())['rows']
elements = dict(C=6,Mg=12,Al=13,Si=14,Ca=20,Mn=25,Fe=26)
names = ('RR_rate_coef_used_cm3_s','DR_Badnell_rate_coef_cm3_s',
         'H_CharExcIonOf_cm3_s','H_CharExcRecTo_cm3_s',
         'He_CharExcIonOf_cm3_s','He_CharExcRecTo_cm3_s')
records = []
for row in rows:
    z = elements[row['element']]
    temperature,ne = row['temperature'],row['electron']
    for q in (1,2,3):
        reference = row['charge_rates'][str(q-1)]
        def rates(t):
            return jnp.array((radiative_recombination(t,z,q,data),
                 raw_dielectronic_recombination(t,z,q,data)*suppression(t,ne,z,q),
                 *charge_exchange(t,z,q,data)))
        actual = np.asarray(rates(temperature))
        expected = np.array([reference[name] for name in names])
        error = abs(actual-expected)/np.maximum(abs(expected),1e-40)
        positive = expected > 0
        derivative = np.asarray(jax.jacfwd(lambda x: rates(temperature*jnp.exp(x)))(0.))
        step = 1e-5
        numerical = np.asarray((rates(temperature*np.exp(step))-rates(temperature*np.exp(-step)))/(2*step))
        ad_error = abs(derivative-numerical)/np.maximum(abs(numerical),1e-40)
        records.append(dict(element=row['element'],radius_rp=row['radius_rp'],charge=q,
              actual=actual.tolist(),reference=expected.tolist(),relative_error=error.tolist(),
              logT_derivative=derivative.tolist(),finite_difference=numerical.tolist(),
              coefficient_pass=bool(np.allclose(actual,expected,rtol=2e-6,atol=1e-40)),
              derivative_pass=bool(np.all(abs(derivative-numerical)<=1e-40+1e-5*np.maximum(abs(numerical),abs(actual))))))
report = dict(scope='Independent RR, DR including suppression, and H/He CT coefficients. No photoionization, Cota three-body, molecular/grain exchange, ion fractions or atmospheric closure inferred.',
              coefficient_order=names,states=len(records),coefficient_rtol=2e-6,
              passed=all(r['coefficient_pass'] and r['derivative_pass'] for r in records),
              maximum_relative_error=max(max(r['relative_error']) for r in records),
              source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in
                             [source,root/'ionic_rates.py',root/'dr_suppression.py',Path(__file__)]},
              data_sha256=data['sha256'],records=records)
(root/'ionic_rate_verification.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print({k:v for k,v in report.items() if k not in ('records','source_sha256','data_sha256')})
for r in records:
    if not r['coefficient_pass'] or not r['derivative_pass']:
        print(r['element'],r['radius_rp'],r['charge'],r['relative_error'])
raise SystemExit(0 if report['passed'] else 1)
