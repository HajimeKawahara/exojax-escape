// Original C23 kernels exposed for an independent diagnostic comparison.
// Cloudy (C)1978--2023 Gary J. Ferland et al.; see Cloudy.txt.
#include "/tmp/cloudy-causal-rates/source/mole_reactions.cpp"
#include "/tmp/cloudy-causal-rates/source/opacity_createall.cpp"
#include <iostream>
#include <iomanip>
int main() {
    double t,energy;
    std::cout << std::setprecision(17);
    while(std::cin>>t>>energy) {
        phycon.sqrte=sqrt(t); phycon.te70=pow(t,.7); phycon.te20=pow(t,.2);
        phycon.te10=pow(t,.1); phycon.te03=pow(t,.03); phycon.te01=pow(t,.01);
        phycon.te003=pow(t,.003); phycon.te001=pow(t,.001);
        std::cout<<hmirat(t)<<" "<<hmiopc(energy)<<"\n";
    }
}
