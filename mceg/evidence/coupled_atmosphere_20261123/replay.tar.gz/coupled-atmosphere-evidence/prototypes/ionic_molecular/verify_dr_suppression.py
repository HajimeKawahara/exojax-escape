"""Independent C23 source comparison of the restricted JAX DR kernel."""
from pathlib import Path
import hashlib
import json
import subprocess

import jax
import jax.numpy as jnp
import numpy as np

from dr_suppression import suppression

jax.config.update('jax_enable_x64', True)
root = Path(__file__).resolve().parent
rows = np.array([[z,q,t,n] for z in (6,12,13,14,20,25,26) for q in (1,2,3)
                 for t in np.geomspace(4000,15000,11) for n in np.geomspace(1e6,1e16,21)])
run = subprocess.run([str(root/'sample_ionic.exe')], input='\n'.join(
    f'{int(z)} {int(q)} {t:.17g} {n:.17g}' for z,q,t,n in rows)+'\n',
    text=True, capture_output=True, check=True)
reference = np.array([float(x) for x in run.stdout.split()])
actual = np.concatenate([np.asarray(suppression(jnp.asarray(rows[i:i+231,2]),
                        jnp.asarray(rows[i:i+231,3]),int(rows[i,0]),int(rows[i,1])))
                         for i in range(0,len(rows),231)])
relative = abs(actual/reference-1)
derivatives = []
for z,q in ((6,1),(6,2),(6,3),(12,2),(14,1),(26,1)):
    def fun(x):
        return jnp.log(suppression(7000*jnp.exp(x[0]),1e12*jnp.exp(x[1]),z,q))
    x = jnp.zeros(2)
    ad = np.asarray(jax.grad(fun)(x))
    fd = np.array([float((fun(x+jnp.eye(2)[i]*1e-5)-fun(x-jnp.eye(2)[i]*1e-5))/2e-5) for i in range(2)])
    derivatives.append(dict(z=z,q=q,ad=ad.tolist(),fd=fd.tolist(),passed=bool(np.allclose(ad,fd,rtol=3e-5,atol=1e-9))))
report = dict(scope='DR density-suppression coefficient only; not complete ionic/thermal balance.',
              samples=len(rows),maximum_relative_error=float(relative.max()),
              tolerance=2e-10, passed=bool(np.all(relative<2e-10)) and all(x['passed'] for x in derivatives),
              derivatives=derivatives,
              source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in
                             [root/'dr_suppression.py',root/'sample_ionic.cpp',Path(__file__),
                              Path('/tmp/cloudy-causal-rates/source/ion_recomb_Badnell.cpp')]})
np.savez_compressed(root/'dr_suppression_comparison.npz',inputs=rows,c23=reference,jax=actual)
(root/'dr_suppression_verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
raise SystemExit(0 if report['passed'] else 1)
