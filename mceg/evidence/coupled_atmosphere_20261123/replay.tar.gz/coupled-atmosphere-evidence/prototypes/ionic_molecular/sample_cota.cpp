// Unchanged C23 Cota implementation, exposed only for reference/data extraction.
// Cloudy (C)1978--2023 Gary J. Ferland et al.; see Cloudy.txt.
#include "/tmp/cloudy-causal-rates/source/atmdat_3body.cpp"
#include <iostream>
#include <iomanip>
template<class T> void dump(const char* name, const T* values, int n) {
    std::cout << name;
    for (int i=0;i<n;++i) std::cout << " " << values[i];
    std::cout << "\n";
}
int main(int argc, char**) {
    std::cout << std::setprecision(17);
    if (argc>1) {
        blkdata1();
        dump("a0",a0,83); dump("b0",b0,83); dump("x0",x0,83);
        dump("a1",a1,83); dump("b1",b1,83); dump("x1",x1,83);
        dump("a2",a2,63); dump("b2",b2,63); dump("x2",x2,63);
        dump("tz",tz,83); dump("zlog2",zlog2,28); dump("zlog7",zlog7,28);
    } else {
        double q,t,ne;
        while(std::cin>>q>>t>>ne) std::cout<<da(q,t,ne)<<"\n";
    }
}
