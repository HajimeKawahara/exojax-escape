// Original C23 function bodies, unmodified; diagnostic harness only.
// Cloudy (C)1978--2023 Gary J. Ferland et al.; see Cloudy.txt.
#include "/tmp/cloudy-causal-rates/source/ion_recomb_Badnell.cpp"
#include <iostream>
#include <iomanip>
int main() {
    int z, q;
    double t, ne;
    std::cout << std::setprecision(17);
    while (std::cin >> z >> q >> t >> ne)
        std::cout << CollisSuppres(z,q,ne,t) << "\n";
}
