"""Restricted C23 Cota recombination kernel with an implicit inverse mapping.

Altered adaptation of Cloudy C23.01 atmdat_3body.cpp. The original Cloudy
license accompanies the data. This is its effective density-dependent
coefficient [cm^3/s], not a constant three-body coefficient [cm^6/s].
"""
from __future__ import annotations

import jax
import jax.numpy as jnp


def _parabola(x, y, query):
    x1,x2,x3 = x
    y1,y2,y3 = y
    d13,d12 = x1-x3,x1-x2
    s13,s12 = (x1+x3)*d13,(x1+x2)*d12
    b = ((y1-y2)*s13-(y1-y3)*s12)/(d12*s13-d13*s12)
    a = ((y1-y3)-d13*b)/s13
    c = y1-a*x1*x1-b*x1
    return a*query*query+b*query+c


def recombination(temperature_k, electron_cm3, charge, data):
    """C23 effective Cota coefficient for q=1..3, 4000–15000 K, ne>=1e5.

    Uses the original parabolic fits continuously, omitting the tiny
    exact-node shortcut. Solves the inverse mapping to machine tolerance,
    instead of C23's relative 1e-4 stop, and differentiates it implicitly.
    The restricted domain avoids Cota's low-temperature discontinuities.
    """
    if charge not in (1,2,3):
        raise ValueError('Supported ionic charges are 1..3.')
    temperature, density = jnp.broadcast_arrays(jnp.asarray(temperature_k),jnp.asarray(electron_cm3))
    valid = (temperature>=4000)&(temperature<=15000)&(density>=1e5)&jnp.isfinite(density)
    zlog2,zlog7 = data['zlog2'][charge-1],data['zlog7'][charge-1]
    logt = jnp.log10(temperature)-zlog2
    logn = 5-zlog7
    grid = jnp.asarray(data['tz'])
    nearest = jnp.argmin(abs(logt[...,None]-grid),axis=-1)
    indices = nearest[...,None]+jnp.array([-1,0,1])
    abscissa = jnp.moveaxis(grid[indices],-1,0)
    def interpolate(name,offset=0):
        values = jnp.asarray(data[name])[indices-offset]
        return _parabola(abscissa,jnp.moveaxis(values,-1,0),logt)
    suffix,offset = ('2',20) if charge == 1 else ('1',0)
    c,d,u = (interpolate(name+suffix,offset) for name in ('a','b','x'))
    v = 9.4 if charge == 1 else 8.9
    def residual(logx):
        return c+d*10**(u*logx)-v*logx-logn
    def solve(function,guess):
        def step(_,value):
            derivative = d*10**(u*value)*u*jnp.log(10.)-v
            return value-jnp.clip(function(value)/derivative,-.09,.09)
        return jax.lax.fori_loop(0,20,step,guess)
    logx = jax.lax.custom_root(residual,(c-logn)/v,solve,
                              lambda linear,rhs: rhs/linear(jnp.ones_like(rhs)))
    a,b,y = (interpolate(name+'0') for name in ('a','b','x'))
    coefficient = charge*10**(a-y*logx+b*10**(-2.45*logx))*(density/1e5)**.25
    valid &= abs(residual(logx))<1e-10
    return jnp.where(valid,coefficient,jnp.nan)
