"""JAX C23 DR suppression for the explicitly selected low-charge metal ions.

Altered adaptation of CollisSuppres, ion_recomb_Badnell.cpp, Cloudy C23.01.
Cloudy copyright (C)1978--2023 Gary J. Ferland and others; see Cloudy.txt.
This coefficient is not an ionization solution or a complete rate model.
"""
from __future__ import annotations

import jax.numpy as jnp
from jax.scipy.special import erfc


def suppression(temperature_k, electron_cm3, z, charge):
    """Return DR suppression for C/Mg/Al/Si/Ca/Mn/Fe, q=1..3."""
    if z not in (6, 12, 13, 14, 20, 25, 26) or charge not in (1, 2, 3):
        raise ValueError("Only the selected seven elements and q=1..3 are supported.")
    temperature = jnp.asarray(temperature_k)
    density = jnp.asarray(electron_cm3)
    sequence, q = z-charge, float(charge)
    n1, n2 = (3, 10) if sequence <= 10 else ((11, 18) if sequence <= 18 else (19, 36))
    an = 12+10*n1+(10*n1-2*n2)*(sequence-n1)/(n1-n2)
    c = q/10
    ec = 0.
    if sequence == 3:
        ec = 1.96274+c*(20.30014+c*(-.97103+c*(.85453+c*(.13547+.02401*c))))
        an = 66.
        p = (4.55441+.08*q**1.11864, .3+2*q**-2*jnp.exp(-q/67.36368),
             -.4+.38*q**1.62248*jnp.exp(-q/2.78841),
             4.00192+.58*q**.93519*jnp.exp(-q/21.28094),
             .00198+.32*q**.84436*jnp.exp(-q/9.73494),
             .55031-.32251*q**.75493*jnp.exp(-q/19.89169))
    elif sequence == 4:
        ec = 5.78908+c*(34.08270+c*(1.51729+c*(-1.21227+c*(.77559-.00410*c))))
        an = 66.
        p = (2.79861+q**.82983*jnp.exp(-q/18.05422),
             -.01897+.05*q**1.34569*jnp.exp(-q/10.82096),
             -.56934+.68*q**.78839*jnp.exp(-q/2.77582),
             4.07101+q**.7175*jnp.exp(-q/25.89966),
             .44352+.05*q**3.54877*jnp.exp(-q/.94416),
             -.57838+.68*q**.08484*jnp.exp(-q/6.70076))
    elif sequence == 11:
        ec = 2.24809+c*(22.27768+c*(-1.12285+c*(.90267+c*(-.03860+.01468*c))))
    elif sequence == 12:
        ec = 2.74508+c*(19.18623+c*(-.54317+c*(.78685+c*(-.04249+.01357*c))))
    logt = jnp.log10(temperature)
    def adjustment(p):
        p1,p2,p3,p4,p5,p6 = p
        return 1+p3*jnp.exp(-.5*((logt-p1)/p2)**2)+p6*jnp.exp(-.5*((logt-p4)/p5)**2)
    if sequence in (3, 4):
        an *= 2/(1+jnp.exp(-jnp.sqrt(25000*q*q/temperature)))*adjustment(p)
    if sequence == 5:
        # C23 explicitly resets A_N here, discarding the preceding Psi factor.
        an = 52.
        g = (6.91078-1.6385*q**2.18197*jnp.exp(-q/1.45091),
             .4959-.08348*q**1.24745*jnp.exp(-q/8.55397),
             -.27525+.132*q**1.15443*jnp.exp(-q/3.79949),
             7.45975-2.6722*q**1.7423*jnp.exp(-q/1.19649),
             .51285-.60987*q**5.15431*jnp.exp(-q/.49095),
             -.24818+.125*q**.59971*jnp.exp(-q/8.34052))
        an *= adjustment(g)
    elif sequence == 13:
        g = (6.59628-3.03115*jnp.exp(-q/10.519821),
             1.20824-.85509*q**.21258*jnp.exp(-q/25.56),
             -.34292-.06013*q**4.09344*jnp.exp(-q/.90604),
             7.92025-3.38912*jnp.exp(-q/10.02741),
             .06976+.6453*q**.24827*jnp.exp(-q/20.94907),
             -.34108-.17353*jnp.exp(-q/6.0384))
        an *= adjustment(g)
    q0 = an*(1-.816497/jnp.sqrt(q))/jnp.sqrt(q)
    activation = 10.1821+jnp.log10((q/q0)**7*jnp.sqrt(temperature/(50000*q0*q0)))
    logn = jnp.log10(jnp.maximum(density, 1e-300))
    ordinary = jnp.exp(-jnp.log(2.)*(jnp.maximum(logn-activation, 0)/5.64586)**2)
    energy_ev = 20*erfc(2*(logn-10.1821)) if sequence == 10 else ec
    value = 1+(ordinary-1)*jnp.exp(-energy_ev*11604.518121550082/(10*temperature))
    return jnp.where((temperature > 0)&(density >= 0), value, jnp.nan)
