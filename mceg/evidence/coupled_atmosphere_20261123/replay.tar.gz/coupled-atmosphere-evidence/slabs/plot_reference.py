from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
root=Path('/tmp/escape-atmosphere-reference')
fig,axes=plt.subplots(2,2,figsize=(10.2,7.1),sharex=True)
summary={}
for column, exponent in enumerate((18,21)):
 length=10.**exponent/1e12
 cloudy=np.load(root/f'bb_t8000_n12_col{exponent}_adaptive'/'profile.npz')
 old=np.load(root/f'native_formal_beam_col{exponent}_z8_from_cloudy'/'state.npz')
 fine=np.load(root/f'native_wings_col{exponent}_z8_order8'/'state.npz')
 coarse=np.load(root/f'native_wings_col{exponent}_z8_order4'/'state.npz')
 summary[str(exponent)]={}
 for row,(key,slc) in enumerate((('n2_cm3',slice(1,3)),('n3_cm3',slice(3,6)))):
  ax=axes[row,column];label='n_2' if row==0 else 'n_3'
  original=old['bound_cm3'][:,slc].sum(axis=1);extended=fine['bound_cm3'][:,slc].sum(axis=1);low=coarse['bound_cm3'][:,slc].sum(axis=1)
  ax.plot(cloudy['depth_cm']/length,cloudy[key],color='black',lw=1.7,label='Cloudy C23.01 (adaptive)')
  ax.plot(old['depth_cm']/length,original,'--',color='#92939a',lw=1.5,label='Native, original frequency grid')
  ax.plot(fine['depth_cm']/length,extended,'o-',color='#1268b3',lw=1.5,ms=4,label='Native, resolved wings (order 8)')
  ax.set_yscale('log');ax.set_ylabel(r'$'+label+r'\ [\mathrm{cm}^{-3}]$');ax.grid(alpha=.2)
  reference=np.interp(fine['depth_cm'],cloudy['depth_cm'],cloudy[key])
  summary[str(exponent)][key]=dict(maximum_wing_order4_to_8_change=float(np.max(np.abs(low/extended-1))),maximum_cloudy_relative_error=float(np.max(np.abs(extended/reference-1))))
  if row==0:ax.set_title(r'$N_\mathrm{H}=10^{'+str(exponent)+r'}\ \mathrm{cm}^{-2}$')
  if row==1:ax.set_xlabel('Inward depth / slab thickness')
fig.suptitle('Controlled radiation–population comparison\nFixed T = 8000 K; nH = 10¹² cm⁻³; normal incident blackbody, Tstar = 10000 K, W = 0.025',fontsize=12,y=.985)
handles,labels=axes[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.5,.055),ncol=1,frameon=False,fontsize=9)
fig.text(.5,.013,'Native curves use only 8 spatial cells. They are converged roots; spatial adequacy and Cloudy equivalence are not established.',ha='center',fontsize=9,color='#71342f')
fig.tight_layout(rect=(0,.17,1,.91));fig.savefig(root/'cloudy_native_comparison.png',dpi=180)
(root/'native_wing_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
