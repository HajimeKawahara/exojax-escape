from pathlib import Path
import argparse,hashlib,json,time,traceback
import numpy as np
import jax,jax.numpy as jnp
jax.config.update('jax_enable_x64',True)
from escape.coupled_hydrogen import CoupledHydrogenModel
parser=argparse.ArgumentParser();parser.add_argument('--column',type=int,required=True);parser.add_argument('--cells',type=int,default=8);args=parser.parse_args()
root=Path('/tmp/escape-atmosphere-reference');dest=root/f'native_formal_beam_col{args.column}_z{args.cells}';dest.mkdir(exist_ok=False)
source=root/'native_snapshot/src/escape'
config=dict(column_cm2=10.**args.column,temperature_k=8000.,density_cm3=1e12,nmax=15,cells=args.cells,quadrature_order=4,angle_order=4,continuation_steps=8,iterations=24,transfer='formal',stellar_beam=True,radiation_temperature_k=10000.,dilution=.025)
meta=dict(configuration=config,status='running',source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.glob('*.py')},scope='Fixed-T pure-H static slab. Native formal CRD transfer differs from Cloudy escape probabilities and redistribution. No atmospheric thermal or wind validation.')
def write(): (dest/'receipt.json').write_text(json.dumps(meta,indent=2)+'\n')
write();t=time.monotonic()
try:
 L=config['column_cm2']/config['density_cm3'];edges=np.linspace(0,L,args.cells+1)
 model=CoupledHydrogenModel(edges,nmax=15,quadrature_order=4,spherical=False,transfer='formal',stellar_beam=True,angle_order=4)
 inner=jnp.zeros_like(model.grid.frequency_hz);outer=model.boundary_blackbody(10000.,.05)
 print('starting solve',args.column,args.cells,'freq',len(inner),flush=True)
 answer=model.solve_equilibrium(1e12,8000.,inner,outer,iterations=24,continuation_steps=8)
 answer.state.block_until_ready();elapsed=time.monotonic()-t
 fractions=jax.nn.softmax(jnp.concatenate((answer.state,jnp.zeros((args.cells,1))),axis=1),axis=1)
 data=dict(edges_cm=edges,depth_cm=(L-(edges[:-1]+edges[1:])/2),frequency_hz=np.asarray(model.grid.frequency_hz),state=np.asarray(answer.state),bound_cm3=np.asarray(answer.bound_cm3),electron_cm3=np.asarray(answer.electron_cm3),candidate_bound_cm3=1e12*np.asarray(fractions[:,:-1]),candidate_electron_cm3=1e12*np.asarray(fractions[:,-1]),mean_intensity=np.asarray(answer.radiation.mean_intensity),flux_moment_edges=np.asarray(answer.radiation.flux_moment_edges),profile_integrals=np.asarray(answer.radiation.profile_integrals))
 np.savez(dest/'state.npz',**data)
 meta.update(status='completed',elapsed_seconds=elapsed,converged=bool(answer.converged),residual_norm=float(answer.residual_norm),transfer_converged=bool(answer.radiation.converged),transfer_residual=float(answer.radiation.transfer_residual),radiation_balance_error=float(answer.radiation.radiation_balance_error),gain_optical_depth=float(answer.radiation.gain_optical_depth))
 if bool(answer.converged):
  cloudy=np.load(root/f'bb_t8000_n12_col{args.column}_adaptive'/'profile.npz');depth=data['depth_cm']
  comparisons={}
  for key,actual in [('n2_cm3',data['bound_cm3'][:,1:3].sum(axis=1)),('n3_cm3',data['bound_cm3'][:,3:6].sum(axis=1)),('electron_cm3',data['electron_cm3'])]:
   ref=np.interp(depth,cloudy['depth_cm'],cloudy[key]);comparisons[key]=dict(native=actual.tolist(),cloudy_at_native_centers=ref.tolist(),relative_error=(actual/ref-1).tolist())
  meta['comparison']=comparisons
except Exception as exc:
 meta.update(status='failed',elapsed_seconds=time.monotonic()-t,error=repr(exc),traceback=traceback.format_exc())
write();print(json.dumps({k:v for k,v in meta.items() if k not in ('source_sha256','comparison')},indent=2),flush=True)
