from pathlib import Path
import argparse,hashlib,json,time,traceback
import numpy as np
import jax,jax.numpy as jnp
jax.config.update('jax_enable_x64',True)
from escape.coupled_hydrogen import CoupledHydrogenModel
parser=argparse.ArgumentParser();parser.add_argument('--order',type=int,required=True);parser.add_argument('--column',type=int,default=18);args=parser.parse_args()
root=Path('/tmp/escape-atmosphere-reference');dest=root/f'native_wings_col{args.column}_z8_order{args.order}';dest.mkdir(exist_ok=False);source=root/'native_wings_snapshot/src/escape'
meta=dict(status='running',initialization='Converged native8 state on the original frequency grid',source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.glob('*.py')},configuration=dict(column_cm2=10.**args.column,temperature_k=8000.,density_cm3=1e12,nmax=15,cells=8,quadrature_order=args.order,angle_order=4,continuation_steps=1,iterations=32,transfer='formal',stellar_beam=True,line_wing_offsets=[30,100,300,1000]))
def write():(dest/'receipt.json').write_text(json.dumps(meta,indent=2)+'\n')
write();t=time.monotonic()
try:
 L=10.**args.column/1e12;edges=np.linspace(0,L,9);d=L-(edges[:-1]+edges[1:])/2;seed=np.load(root/f'native_formal_beam_col{args.column}_z8_from_cloudy'/'state.npz')
 model=CoupledHydrogenModel(edges,nmax=15,quadrature_order=args.order,spherical=False,transfer='formal',stellar_beam=True,angle_order=4,line_wing_offsets=(30,100,300,1000))
 inner=jnp.zeros_like(model.grid.frequency_hz);outer=model.boundary_blackbody(10000.,.05)
 print('starting wings',args.column,args.order,len(inner),flush=True)
 answer=model.solve_equilibrium(1e12,8000.,inner,outer,initial_state=jnp.asarray(seed['state']),iterations=32,continuation_steps=1);answer.state.block_until_ready()
 np.savez(dest/'state.npz',edges_cm=edges,depth_cm=d,state=np.asarray(answer.state),bound_cm3=np.asarray(answer.bound_cm3),electron_cm3=np.asarray(answer.electron_cm3),mean_intensity=np.asarray(answer.radiation.mean_intensity),frequency_hz=np.asarray(model.grid.frequency_hz))
 meta.update(status='completed',elapsed_seconds=time.monotonic()-t,converged=bool(answer.converged),residual_norm=float(answer.residual_norm),transfer_residual=float(answer.radiation.transfer_residual),radiation_balance_error=float(answer.radiation.radiation_balance_error))
 if bool(answer.converged):
  changes={};bound=np.asarray(answer.bound_cm3)
  for key,actual,previous in [('n2_cm3',bound[:,1:3].sum(axis=1),seed['bound_cm3'][:,1:3].sum(axis=1)),('n3_cm3',bound[:,3:6].sum(axis=1),seed['bound_cm3'][:,3:6].sum(axis=1)),('electron_cm3',np.asarray(answer.electron_cm3),seed['electron_cm3'])]:changes[key]=dict(maximum_relative_change=float(np.max(np.abs(actual/previous-1))),relative_change=(actual/previous-1).tolist())
  meta['change_from_original_grid']=changes
except Exception as exc:meta.update(status='failed',elapsed_seconds=time.monotonic()-t,error=repr(exc),traceback=traceback.format_exc())
write();print(json.dumps({k:v for k,v in meta.items() if k!='source_sha256'},indent=2),flush=True)
