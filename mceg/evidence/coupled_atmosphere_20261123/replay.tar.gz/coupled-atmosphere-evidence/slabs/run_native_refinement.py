from pathlib import Path
import hashlib,json,time,traceback
import numpy as np
import jax,jax.numpy as jnp
jax.config.update('jax_enable_x64',True)
from escape.coupled_hydrogen import CoupledHydrogenModel
root=Path('/tmp/escape-atmosphere-reference');dest=root/'native_formal_beam_col18_z16_from_native8';dest.mkdir(exist_ok=False);source=root/'native_snapshot/src/escape'
meta=dict(status='running',initialization='Converged native8 state interpolated in log population/proton ratios',source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.glob('*.py')},configuration=dict(column_cm2=1e18,temperature_k=8000.,density_cm3=1e12,nmax=15,cells=16,quadrature_order=4,angle_order=4,continuation_steps=1,iterations=24,transfer='formal',stellar_beam=True))
def write():(dest/'receipt.json').write_text(json.dumps(meta,indent=2)+'\n')
write();t=time.monotonic()
try:
 edges=np.linspace(0,1e6,17);d=1e6-(edges[:-1]+edges[1:])/2;seed=np.load(root/'native_formal_beam_col18_z8_from_cloudy'/'state.npz')
 state=np.column_stack([np.interp(d,seed['depth_cm'][::-1],seed['state'][::-1,i]) for i in range(18)])
 model=CoupledHydrogenModel(edges,nmax=15,quadrature_order=4,spherical=False,transfer='formal',stellar_beam=True,angle_order=4)
 inner=jnp.zeros_like(model.grid.frequency_hz);outer=model.boundary_blackbody(10000.,.05)
 print('starting native16 from native8',flush=True)
 answer=model.solve_equilibrium(1e12,8000.,inner,outer,initial_state=jnp.asarray(state),iterations=24,continuation_steps=1);answer.state.block_until_ready()
 np.savez(dest/'state.npz',edges_cm=edges,depth_cm=d,state=np.asarray(answer.state),bound_cm3=np.asarray(answer.bound_cm3),electron_cm3=np.asarray(answer.electron_cm3),mean_intensity=np.asarray(answer.radiation.mean_intensity))
 meta.update(status='completed',elapsed_seconds=time.monotonic()-t,converged=bool(answer.converged),residual_norm=float(answer.residual_norm),transfer_residual=float(answer.radiation.transfer_residual),radiation_balance_error=float(answer.radiation.radiation_balance_error))
 if bool(answer.converged):
  coarse=np.load(root/'native_formal_beam_col18_z8_from_cloudy'/'state.npz');fine=np.asarray(answer.bound_cm3)
  changes={}
  for k,values,old in [('n2_cm3',fine[:,1:3].sum(axis=1),coarse['bound_cm3'][:,1:3].sum(axis=1)),('n3_cm3',fine[:,3:6].sum(axis=1),coarse['bound_cm3'][:,3:6].sum(axis=1)),('electron_cm3',np.asarray(answer.electron_cm3),coarse['electron_cm3'])]:
   sampled=np.interp(coarse['depth_cm'],d[::-1],values[::-1]);changes[k]=dict(maximum_relative_change=float(np.max(np.abs(sampled/old-1))),relative_changes=(sampled/old-1).tolist())
  meta['refinement']=changes
except Exception as exc:meta.update(status='failed',elapsed_seconds=time.monotonic()-t,error=repr(exc),traceback=traceback.format_exc())
write();print(json.dumps({k:v for k,v in meta.items() if k!='source_sha256'},indent=2),flush=True)
