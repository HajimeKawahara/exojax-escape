from pathlib import Path
import sys,json
import numpy as np
import jax
jax.config.update('jax_enable_x64',True)
sys.path.insert(0,'/tmp/escape-coupled-atmosphere/tools')
from cloudy_rates_diagnosis import parse_operator
from cloudy_reference import artifact_sha256,sha256
from escape.hydrogen_rates import collision_rates, MIN_TEMPERATURE_K
root=Path('/tmp/escape-atmosphere-reference/low_temperature')
pairs=[(1,0),(2,0),(3,0),(3,1),(3,2),(4,0),(4,1),(4,2),(5,0),(5,1),(5,2)]
results={}
for T in (4000,4500,5802,6000,10000,14000):
 p=root/f't{T}';op=parse_operator(p/'model.out.gz');bb=np.asarray(op['bb'])
 lookup={(int(r[0]),int(r[1])):r[7] for r in bb}
 cloudy=np.array([lookup[k] for k in pairs]);native=np.asarray(collision_rates(float(T),low_temperature_extrapolation='cloudy')[0]);actual=np.array([native[k] for k in pairs]);errs=actual/cloudy-1
 results[str(T)]=dict(cloudy_electron_deexcitation_cm3_s=cloudy.tolist(),escape_electron_deexcitation_cm3_s=actual.tolist(),relative_errors=errs.tolist(),maximum_relative_error=float(np.max(np.abs(errs))),cloudy_output_sha256=artifact_sha256(p/'model.out'),source_input_sha256=sha256(p/'model.in'))
 print(T,'maxerror',float(np.max(np.abs(errs))))
 print('cloudy',repr(cloudy.tolist()))
summary=dict(escape_source_sha256={name:sha256(Path('/tmp/escape-coupled-atmosphere/src/escape')/name) for name in ('hydrogen_rates.py','hydrogen_atom.py')},scope='Non-l-changing resolved electron deexcitation coefficients only; not populations or low-T atomic accuracy.',pairs=pairs,source='Cloudy C23.01 hydrocollid.cpp HCSAR_interp; h_coll_str.dat from Anderson et al. (2000/2002); explicit linear-to-zero extrapolation below 5802 K',cloudy_temperature_k=5802.,escape_temperature_k=MIN_TEMPERATURE_K,results=results)
(root/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
