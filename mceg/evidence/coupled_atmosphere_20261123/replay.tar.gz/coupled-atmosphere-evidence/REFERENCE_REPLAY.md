# Offline reference replay

The package has no Cloudy or sunbather runtime dependency. These commands are independent verification experiments. The exact unpublished Zhang et al. settings are not available.

Build the unmodified Cloudy C23.01 release (`make -j4` in source). Source archive SHA256: `a9ad2dc037e88f552389de0e483d68f54310976dee32154ed13830882aedae0b`; URL: https://data.nublado.org/cloudy_releases/c23/c23.01.tar.gz . This campaign's executable SHA256 is `3001d9a71499dba72d3cf532538f34345b5df2de56cbfedf84b3970b13002305`. Use its original data tree, including `abundances/default.abn` SHA256 `be3689c7054fbc34ee9114571f7fd56273a79c656b9dda2e835c489434921012`. No diagnostic or physical source patch was used for the final reference controls.

For thermal iterations only, install sunbather1.1.0 in an external environment. Its public tag is commit `0d6d50a384303eb2c021329f81e58363f48be253`; `solveT.py` SHA256 is `fc71bac37ff0a474e1b7e3e69b6f6090d924da6334fd4c18c634c948f38ef2de`. The driver invokes its actual relaxation/construction functions, with explicitly recorded numerical damping and strict energy-balance stopping.

Supply the archived `input_profiles.npz` (outward radius, temperature, hydrogen nuclei density, velocity), and separately retrieve the PHOENIX10000K/logg4 surface spectrum using `examples/fetch_phoenix.py`. The source spectrum and copied `SED/incident.sed` tables are not redistributed: preserve the source hash and retrieval instructions. The chosen irradiation is Fincident=0.1Fsurface, zero outside the native500Å–5.5µm coverage; no stellar broadening or XUV tail was inserted.

A fixed-state solar control is:

```sh
PYTHONPATH=src python tools/cloudy_atmosphere.py --profiles INPUT.npz --cloudy CLOUDY_EXE --cloudy-data CLOUDY_DATA --output NEW_DIRECTORY --composition solar --molecules --hydrogen-atom cloudy-default --sed PHOENIX_SURFACE.npz --flux-scale .1 --resolution .1
```

The physical reference uses C23.01 default H: resolved n<=10, 15 collapsed shells through25, recombination topoff enabled. The native-matched15-shell/resolved3/topoff-off case is a separate control via `--hydrogen-atom native-matched --nmax 15`. Full chemistry includes H-minus; `--no-molecules` removes it and is only an atomic-composition ablation.

For the coupled thermal/wind experiment, add `--iterations 40 --mass-loss-g-s 1e13 --planet-mass-mj 2.17 --outer-wind-radius-cm 434671360000 --tidal-coefficient-s2 7.243193304369553e-9 --dense-lower-patch --temperature-relaxation .5 --wind-relaxation .5`. The dense lower prescription is conditional: linear T from4500K to the admissible Cloudy join, Saha/Cloudy ionization bridge, LTE lower excitation. Lower energy balance is unsolved (NaN); LTE join departures and base pressure are separate diagnostics.

A locally refined continuum uses `--continuum-mesh continuum_mesh.ini --resolution 1`. The supplied mesh files refine .016–1.83Ryd and retain the original mesh outside. Their hashes are recorded. The stellar SED is unchanged. Spectral and spatial mesh convergence must be assessed independently; `--max-zone-cm` supplies a separate Cloudy spatial refinement. A small temperature update alone never passes the default strict energy criterion; `--allow-smoothed-thermal` exists only to reproduce earlier public-sunbather stopping experiments.

The observer accepts full25-shell profiles with `--high-n-cross-sections halpha_n20_25.npz`. The fixture is extracted directly from C23.01 `H_photo_cs_log10`; extractor source, compile command, library and fixture hashes accompany it. It supplements the reference continuum only, without extending or validating the native statistical-equilibrium atom. Full source populations, the n20-truncated control and the tail contribution are saved separately.

For a fixed-profile observer, add `--raw-cloudy-profiles` to retain the original Cloudy zone centers. The adjacent `cloudy_profiles.npz` and `input_profiles.npz` are required. The two uncovered boundary half-zones use the nearest thermochemical value; velocity is interpolated from its prescribed input. Stub widths and raw/input hashes are recorded. The original input-grid projected observer is evaluated separately, so this projection error can be measured instead of hidden. This option rejects patched lower atmospheres. Use `--nlayer 128 --nlon 48 --nlat 24 --nnu 601` for the final diagnostic figures.

The external reference tests passed (10 tests), with JUnit receipt `reference_tests.xml`; source hashes are in `source_hashes.json`, pinned to escape commit1863739.
