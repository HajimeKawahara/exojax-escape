from pathlib import Path
from collections import defaultdict
import hashlib
import json
import numpy as np
root=Path('/tmp/cloudy-metal-diagnostic/solar-column')
iterations=[{'species':{},'lines':{}}]
previous=0
for line in (root/'model.out').open():
    s=line.split()
    if s[:1]==['METAL_SPEC'] and len(s)==13:
        depth=float(s[1])
        if depth<previous-1e5:
            iterations.append({'species':{},'lines':{}})
        previous=depth
        key=(depth,s[6]+' '+s[7])
        iterations[-1]['species'][key]=dict(depth_cm=depth,radius_rp=float(s[2]),temperature_k=float(s[3]),total_heating=float(s[4]),total_cooling=float(s[5]),species=key[1],database=s[8],levels=int(s[9]),net_cooling=float(s[10]),gross_transition_heating=float(s[11]),gross_transition_cooling=float(s[12]))
    elif s[:1]==['METAL_LINE'] and len(s)>=20:
        key=(float(s[1]),s[2]+' '+s[3],int(s[4]),int(s[5]))
        iterations[-1]['lines'][key]=dict(species=key[1],lower_index=key[2],upper_index=key[3],wavelength_angstrom=float(s[6]),delta_energy_k=float(s[7]),heating=float(s[8]),cooling=float(s[9]),lower_cm3=float(s[10]),upper_cm3=float(s[11]),lower_g=float(s[12]),upper_g=float(s[13]),einstein_a=float(s[14]),pump_up_s1=float(s[15]),loss_probability=float(s[16]),electron_deexcitation_cm3_s=float(s[17]))
last=iterations[-1]
report={'iteration_blocks':len(iterations),'scopes':[],'unchanged_outputs':{},'diagnostic_cpp_sha256':hashlib.sha256(Path('/tmp/cloudy-metal-diagnostic/prt_lines_general.cpp').read_bytes()).hexdigest()}
for name in ['model.in','model.conditions','model.heating','model.cooling','model.overview','model.levels']:
    baseline=Path('/tmp/escape-sunbather-solar-1e13/iteration_000')/name
    report['unchanged_outputs'][name]=baseline.read_bytes()==(root/name).read_bytes()
for target in [1.1,1.3,1.8]:
    depth=min({key[0] for key in last['species']},key=lambda d:abs(3-d/1.358348e10-target))
    group=[x for (d,sp),x in last['species'].items() if d==depth]
    top=sorted(group,key=lambda x:x['net_cooling'])[:8]
    h=top[0]['total_heating']
    print('\nR',top[0]['radius_rp'],'T',top[0]['temperature_k'],'heat',h,'DbLn%',sum(max(0,-x['net_cooling']) for x in group)/h*100)
    case={'requested_radius_rp':target,'radius_rp':top[0]['radius_rp'],'temperature_k':top[0]['temperature_k'],'heating_erg_cm3_s':h,'database_net_heating':sum(max(0,-x['net_cooling']) for x in group),'top_species':top,'transitions':{}}
    for x in top:
        x['fraction_total_heating']=max(0,-x['net_cooling'])/h
        print(x['species'],x['database'],x['levels'],'fraction',x['fraction_total_heating'],'net',x['net_cooling'],'grossheat',x['gross_transition_heating'],'grosscool',x['gross_transition_cooling'])
        lines=sorted([v for (d,sp,lo,hi),v in last['lines'].items() if d==depth and sp==x['species']],key=lambda v:v['heating'],reverse=True)[:8]
        case['transitions'][x['species']]=lines
        for v in lines[:4]:
            print('  ',v['lower_index']+1,v['upper_index']+1,v['wavelength_angstrom'],'A',v['einstein_a'],'pump',v['pump_up_s1'],'heat',v['heating'],'fractiontotal',v['heating']/h)
    report['scopes'].append(case)
print('iterations',len(iterations),'baseline agreement',report['unchanged_outputs'])
Path('/tmp/cloudy-metal-diagnostic/summary.json').write_text(json.dumps(report,indent=2))
