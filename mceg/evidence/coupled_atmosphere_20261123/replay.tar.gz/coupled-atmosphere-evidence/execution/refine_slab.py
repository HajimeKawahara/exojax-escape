"""Boundary-refined native slab control, independent of planetary fits."""
from pathlib import Path
import hashlib
import json
import time
import jax
import jax.numpy as jnp
import numpy as np
from escape.coupled_hydrogen import CoupledHydrogenModel

jax.config.update('jax_enable_x64', True)
root = Path('/tmp/escape-atmosphere-reference')
cloudy = np.load(root / 'bb_t8000_n12_col18_adaptive/profile.npz')
source = Path('/tmp/escape-coupled-atmosphere/src/escape')
sample = np.array([.01, .1, .3, .5, .7, .9, .99]) * 1e6
previous = None
for count in (16, 32):
    dest = root / f'native_refined_wings_col18_z{count}'
    dest.mkdir(exist_ok=False)
    near = np.geomspace(1e-3, .5, count // 2)
    edges = np.r_[0., near, 1 - near[-2::-1], 1.] * 1e6
    depth = 1e6 - (edges[1:] + edges[:-1]) / 2
    state = np.column_stack([
        np.interp(depth, cloudy['depth_cm'], np.log(cloudy['bound_cm3'][:, i] / cloudy['proton_cm3']))
        for i in range(18)
    ])
    meta = dict(status='running', source_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                for p in source.glob('*.py')}, cells=count, initial='independent Cloudy profile',
                seed_sha256=hashlib.sha256((root / 'bb_t8000_n12_col18_adaptive/profile.npz').read_bytes()).hexdigest(),
                nmax=15, quadrature_order=8, angle_order=4, sample_depth_cm=sample.tolist())
    (dest / 'receipt.json').write_text(json.dumps(meta, indent=2))
    model = CoupledHydrogenModel(edges, nmax=15, quadrature_order=8, spherical=False,
              transfer='formal', stellar_beam=True, angle_order=4, line_wing_offsets=(30, 100, 300, 1000))
    start = time.monotonic()
    answer = model.solve_equilibrium(1e12, 8000., jnp.zeros_like(model.grid.frequency_hz),
              model.boundary_blackbody(10000., .05), initial_state=jnp.asarray(state),
              iterations=32, continuation_steps=1)
    answer.state.block_until_ready()
    bound = np.asarray(answer.bound_cm3)
    values = dict(n2_cm3=bound[:, 1:3].sum(1), n3_cm3=bound[:, 3:6].sum(1),
                  electron_cm3=np.asarray(answer.electron_cm3))
    sampled = {k: np.interp(sample, depth[::-1], v[::-1]) for k, v in values.items()}
    meta.update(status='completed', converged=bool(answer.converged),
                residual_norm=float(answer.residual_norm), seconds=time.monotonic()-start,
                sampled={k: v.tolist() for k, v in sampled.items()},
                cloudy_relative_error={k: (v/np.interp(sample, cloudy['depth_cm'], cloudy[k])-1).tolist()
                                       for k, v in sampled.items()})
    if previous is not None:
        meta['previous_grid_relative_change'] = {k: (sampled[k]/previous[k]-1).tolist() for k in sampled}
    previous = sampled
    np.savez(dest / 'state.npz', edges_cm=edges, depth_cm=depth, state=np.asarray(answer.state),
             bound_cm3=bound, **values)
    (dest / 'receipt.json').write_text(json.dumps(meta, indent=2) + '\n')
    print(json.dumps({k:v for k,v in meta.items() if k!='source_sha256'}), flush=True)
