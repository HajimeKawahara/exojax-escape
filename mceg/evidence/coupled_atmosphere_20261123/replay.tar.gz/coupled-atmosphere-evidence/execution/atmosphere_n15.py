import time,json
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as jnp
import numpy as np
import pandas as pd
from exojax.database.nist import api
api.fetch_nist_lines=lambda *a,**k:(pd.DataFrame({'wav':[15233.146],'A':[44101000.],'El':[82259.158],'Eu':[97492.304],'gl':[8.],'gu':[18.],'jl':[3.5],'ju':[8.5],'species':['H_I']}),[])
from escape.atmosphere import HydrogenAtmosphereModel
model=HydrogenAtmosphereModel(nlayer=4,nmax=15,nnu=61,nlon=4,nlat=2,wind_ngrid=33,tidal_coefficient_s2=3*(2*np.pi/(1.48*86400))**2)
inner=model.radiation.boundary_blackbody(4500)
outer=model.radiation.boundary_blackbody(10000,.05)
for mdot in (1e15,1e14,1e13):
 t=time.time()
 s=model.solve(mdot,jnp.full(4,8000.),inner,outer,iterations=24,continuation_steps=8)
 jax.block_until_ready(s)
 d={k:np.asarray(s[k]).tolist() for k in ('converged','residual_norm','temperature_k','n_h_cm3','n2_cm3','n3_cm3','radial_velocity_kms','mean_molecular_weight','state')}
 d.update(mdot=mdot,seconds=time.time()-t)
 print(json.dumps(d,allow_nan=True),flush=True)
 np.savez(f'/tmp/escape-atmosphere-probes/atmosphere_n15_{mdot:.0e}.npz',**{k:np.asarray(v) for k,v in s.items() if k!='wind_info'})
