"""Retain current-source regression receipt without overwriting historical runs."""
from pathlib import Path
import hashlib
import importlib.metadata as metadata
import json
import platform
import subprocess
import xml.etree.ElementTree as ET

root = Path('/tmp/escape-coupled-atmosphere')
out = Path('/tmp/escape-atmosphere-probes')
groups = {'current_new': '48-51', 'current_old_flow': '52-55',
          'current_old_atom': '56-63', 'current_external': '48-51',
          'current_postfix_slab': None, 'current_postfix_gradient': '32-47'}
joined = ET.Element('testsuites')
batches = []
for name, affinity in groups.items():
    path = out / (name + '.xml')
    suites = ET.parse(path).getroot()
    counts = {key: sum(int(s.get(key, '0')) for s in suites) for key in ('tests', 'failures', 'errors')}
    assert not counts['failures'] and not counts['errors'], (name, counts)
    batches.append(dict(name=name, affinity=affinity, **counts,
                        code_revision=('ff13b848be0202083b86249a7ec9061feb7285f4' if 'postfix' in name else '1863739a05ed50ef8d9649bc536ac9264a33bc72'),
                        seconds=sum(float(s.get('time', 0)) for s in suites),
                        xml_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    joined.extend(suites)
ET.ElementTree(joined).write(out/'current_tests.xml', encoding='utf-8', xml_declaration=True)
receipt = dict(
    code_revision=subprocess.check_output(['git','rev-parse','HEAD'], cwd=root, text=True).strip(),
    source_root=str(root/'src'),
    exojax_source_revision='38cb2e44f153ad6d729e3253e235702de52920cf',
    python=platform.python_version(),
    versions={name: metadata.version(name) for name in ('jax','jaxlib','numpy','scipy','pandas','matplotlib','astropy')},
    batches=batches, total_tests=sum(b['tests'] for b in batches),
    source_files={str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in sorted((root/'src/escape').rglob('*')) if p.suffix in ('.py','.txt')},
    notes='Anderson n=4,5 is the default; VS80 remains an explicit legacy option. Historical final_*.xml receipts use earlier code and are preserved separately.',
    source_change_verification=json.loads(Path('/tmp/escape-beam-postfix-receipt.json').read_text()),
)
receipt['distinct_test_cases'] = len({(case.get('classname'),case.get('name')) for case in joined.findall('.//testcase')})
(out/'current_tests_receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(dict(tests=receipt['total_tests'], revision=receipt['code_revision'])))
