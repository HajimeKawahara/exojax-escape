# Yapeng model-structure audit (23 November 2026)

## Scope decision

A differentiable pure-hydrogen radiation/population calculation is an essential component, not yet a reproduction of the published atmospheric model. Claim three separate things: (1) the feedback graph is connected, (2) a fully specified reduced model agrees with matched Cloudy cases, and (3) the particular paper atmosphere is reproduced. Current public information permits (1) and a controlled route to (2); it does not identify all inputs needed for (3).

The paper specifies Cloudy c23.01, a customized sunbather iteration, PHOENIX 10000 K, mass-loss grid, radial domain, approximate lower-temperature prescription, and observer processing. It does not disclose the exact abundance file, complete SED identifier/resampling, Cloudy input, detailed lower extrapolation, convergence settings, or customized driver. Neither pure H nor solar composition may be attributed to the authors without those inputs. Public sunbather defaults to a solar mixture and explicitly warns that metal line cooling matters even at solar metallicity; this is evidence to test composition, not proof of this paper's chosen composition.

## Minimum connected equation system

Let mu be dimensionless in proton-mass units. The reference structure is

    rho = Mdot / (4 pi r^2 v)
    P = rho k_B T / (mu m_H)
    v dv/dr = -(1/rho) dP/dr - G Mp/r^2 + kappa r
    kappa = 3 G Mstar/a^3

The regular transonic branch must be selected; a fixed-inflow finite-domain solution is a different boundary-value problem. With c_T^2=k_B T/(mu m_H), the critical conditions are v^2=c_T^2 and 2c_T^2/r-dc_T^2/dr-GMp/r^2+kappa r=0. The density and ionization state must update mu and feed back into momentum.

For the sunbather thermal closure (gamma=5/3):

    -rho v d[k_B T/((gamma-1) mu m_H)]/dr
    + (k_B T v/(mu m_H)) d rho/dr + Gamma - Lambda = 0.

Every term is erg cm^-3 s^-1. The first term transports thermal energy; the second represents expansion cooling. A local Gamma=Lambda solve misses both. Public sunbather explicitly neglects advective transport of ion/atom populations. Therefore local statistical equilibrium coupled to radiation, variable mu and this thermal equation is the appropriate baseline. The existing chemically advected finite-inflow solver is an extension, not a condition for matching that baseline. The customized paper does not independently establish whether this omission was changed.

For each species/state: sum_j(n_j P_ji-n_i P_ij)+recombination-photo/collisional ionization=0, with nucleus and charge conservation. Rates depend on local electron density, T and the transported radiation field. The radiation solver must include absorption, local emission, trapping and photon destruction; prescribing the same external J at every altitude cannot pass this requirement. Cloudy implements net radiative brackets using escape/destruction probabilities, including special resonance-line redistribution treatment. A static CRD moment solver and Cloudy are alternative closures, not identical equations. Use matched optically thick benchmarks to quantify their discrepancy; do not call an increase in transfer sophistication an automatic accuracy guarantee.

## Boundaries and geometry

Public sunbather sends stellar radiation into a plane-parallel column from the *top*, converts r to depth=r_outer-r, and uses `double optical depths` so line photons do not freely escape into the planet at the back. This is not spherical irradiation from an inner central star. Hydrodynamic spherical dilution and radiative-transfer geometry must be independent options. A native column with an outward lower thermal boundary and inward stellar illumination needs a documented comparison to that Cloudy boundary convention; isotropic two-stream intensity and incident stellar flux are not interchangeable.

The published calculation extends to 3 Rp and patches the high-pressure region P>1e-3 bar with a lower temperature approaching 4500 K. The current collision-data validity floor 5802 K excludes that gas. Do not clip to 5802 K and declare the lower atmosphere reproduced. Either supply validated low-temperature rates or explicitly use a separate dense LTE/literature lower-atmosphere closure, demonstrate the join is in a thermalized region, and include its uncertainty. A 4500 K continuum boundary alone does not establish the radial source/opacity profile of the lower atmosphere.

H-minus bound-free opacity and an equilibrium H-minus abundance are explicit parts of the paper's observer calculation. They are required for reproducing the published continuum treatment, even if a numerical experiment later finds a small effect for a particular normalized spectrum. He and metals are not automatically optional: measure their electron donation, UV opacity and thermal contributions using matched pure-H, H+He and solar Cloudy runs, then bound any reduction in the final observable.

## Smallest useful implementation partition

1. Connect existing radiation+SE to the existing observer path; expose convergence, field and net-rate diagnostics. Compare frozen-field/local-SE and converged-feedback solutions at identical density/T, without fitting away the difference.
2. Nest or jointly solve the thermal equation above with the variable-mu transonic wind. Reuse isothermal initialization, continuation and implicit derivatives; stop on invalid atomic domain or missing critical branch.
3. Maintain an offline Cloudy column/reference driver with explicit composition, SED, depth orientation, resolved/collapsed atom, optical boundary and all raw inputs/outputs. Initially hold density/T fixed to isolate chemistry/RT; only then iterate thermal balance and wind. Cloudy is a verification executable, never a runtime dependency of escape.
4. Add the prescribed dense lower closure and H-minus continuum. Use matching pressure/temperature/populations and a visible join diagnostic.
5. Forward-process spectra with dayside-only integration, rotation proportional to 1/r, radial wind, 11.6 km/s zonal wind, phase interpolation, stellar-frame masking, master-spectrum subtraction/normalization and R=98000 convolution. Exact cadence/master weights remain unknown if absent from the public archive. Keep that limitation visible.

This sequence does not justify stopping after step 1 and calling the model equivalent. It does produce an inspectable connected solver and an independent target against which missing physics can be prioritized.

## Quantitative validation without a universal 5% rule

Separate numerical convergence from physical agreement. A converged equation residual is not a Cloudy comparison; thin-atom agreement is not an optically thick atmosphere comparison.

* Thermal reference convergence: sunbather documents total-heating/total-cooling between 1/1.1 and 1.1 at all radii, with a typical temperature smoothing floor below 50 K. Report the exact chosen threshold, and both local imbalance and profile changes. Tighten the reference before testing accuracy at smaller scales.
* Grid/atom convergence: run N and 2N radial/frequency/angle settings and nmax increments on identical inputs. Compare n2, n3/n2, T, mu, integrated line optical depth and processed spectrum. Quote the measured numerical envelope, including source-function sensitive layers, rather than declaring every quantity needs 5%.
* Matched Cloudy comparison: first use identical pure-H atom settings at fixed T,nH and explicit boundary flux. Span optically thin, intermediate and thermalizing Lyman depths. Require consistent limits (LTE deep source, thin radiative limit), finite energy/nucleus/charge conservation, and confidence intervals set by each solver's resolution/atomic settings. Any discrepancy larger than that envelope stays contradicted until attributed to a named closure/rate difference.
* Composition reduction: compare pure-H / H+He / solar at the same mass density and incident spectrum, first fixed-T and then thermally relaxed. If changing composition moves T, n3/n2 or the processed line beyond the actual numerical envelope, composition cannot be dropped for that purpose.
* Observational relevance: propagate the profile differences into the same processed spectrum. Use a declared error budget relative to the observed per-bin uncertainties or covariance (e.g. a predeclared fraction of one sigma, rather than a universal relative flux percentage). This is a design choice, not a criterion supplied by the paper. Near zero flux use absolute residuals. The published model itself is narrower than the observations, so matching the observed width is not a necessary test of paper-structure fidelity.
* Derivatives: compare implicit gradients against centered finite differences across step sizes only at converged, domain-valid solutions, including radiation-to-population, ionization-to-mu and T-to-wind paths.

MCEG use gates should require assessments for the *connected entry point*: radiation feedback, thermal-flow closure, composition reduction, lower boundary/domain, observer transformation, reference agreement and differentiability. A known-gap FollowUp or exploration-only Decision does not satisfy a reproduction or inference use gate. Structural equivalence can be supported while author-configuration reproduction stays unknown; a failed matched comparison is contradicted, not merely unverified.

## Primary sources

- Zhang et al., sections IV–V: https://arxiv.org/html/2606.23899v1
- Linssen et al., sunbather equations and explicit neglect of population advection: https://arxiv.org/html/2404.12775v2 (sections 2.1–2.2.3).
- Public sunbather driver: https://github.com/antonpannekoek/sunbather/blob/main/src/sunbather/convergeT_parker.py (double optical depths, stellar-face normalization).
- Public sunbather I/O/composition: https://github.com/antonpannekoek/sunbather/blob/main/src/sunbather/tools.py (`get_abundances`, `write_Cloudy_in`, `alt_array_to_Cloudy`).
- Cloudy C23 methods: https://arxiv.org/html/2311.10163v1 ; local C23.01 source `/tmp/cloudy-causal-rates/source/{iso_level.cpp,rt_line_one.cpp,emission.h}`.

Caution: the sunbather paper's printed tidal term has a sign convention inconsistency relative to the displayed Yapeng momentum equation. Use the explicit outward +3GMstar r/a^3 term in Yapeng and verify the limiting wind; do not copy the printed sign without checking.

## Measured reference updates

The offline driver is now `tools/cloudy_atmosphere.py`; it uses an external Cloudy executable, and optionally the actual `sunbather.solveT` relaxation/construction functions installed outside the repository. Temperature convergence at fixed rho,v now precedes a wind update. An earlier simultaneous thermal/wind relaxation diverged; its outputs must not be presented as equilibrium atmospheres.

At matched **mass density**, identical 6000–8000 K profiles and a diluted 10000 K blackbody, a 200-zone diagnostic changed mu from 0.500–0.501 (H-only) to 0.647–0.670 (solar), base n2 by -39%, and base n3 by -28%. This does not isolate metal cooling: helium, hydrogen abundance, electron budget and metals all change. The separate H+He test is required.

For the primary PHOENIX proxy, Mp=2.17 Mj, Rp=1.9 Rj, Mdot=1e13 g/s and the prescribed 4500→8000 K initial profile, matched H-only/solar Cloudy runs give H-alpha source temperatures at 1.1,1.3,1.8,2.5 Rp of [6408,5798,4000,3918] K (H-only) and [6349,5521,3962,3928] K (solar). This is a fixed-profile radiation/population result, not a converged thermal/wind solution. In the solar run the maximum electron contribution from He ionization is 1.79e-6 and He stays at least 99.998% neutral. Passive neutral He is therefore a strongly motivated minimal reduction for this particular PHOENIX input and state range; the blackbody case does not support it (up to ~8% of electrons from He).

At the same initial profile, Mdot=1e14 gives base nH~6.9e15/cm3 and P~5.4e-3 bar. The paper's lower-atmosphere patch is quantitatively necessary, not a cosmetic correction. A masked shared H/solar reference begins at 1.07264 Rp and T=5253 K; that join is a declared experimental choice and still requires thermalization validation.

Raw PHOENIX source data and copied `SED/incident.sed` tables remain local only. Their redistribution license was not established; publish input hashes and retrieval/normalization instructions, not those source arrays.

A matched H+He (He/H=0.1) run separates composition effects. Near 1.1 Rp its radiative heating/cooling are 4.16e-4 / 1.42e-3 erg cm^-3 s^-1, versus 3.23e-2 / 1.98e-3 for solar. The net energy exchange reverses sign. The solar heating is 94.65% `DbLn` there, 60.38% at 1.3 Rp, and 77.59% at 1.8 Rp. Cloudy `heat_save.cpp` identifies this as database-species line heating, distinct from H/He iso-sequence line heating. In these molecule-free experiments it is metallic bound-bound heating; adding only passive He, metal electrons or photoionization opacity does not supply this process. Solar cooling at 1.3 Rp is dominated by Mg II (38.6%), free-free (29.9%) and Ca II (14.7%). At 1.8 Rp Mg II supplies 52.8% of cooling. A later diagnostic-only readout identifies Fe II, Ca II, Mg II and Si II as the main contributors. These numerical fractions belong to the explicitly coarse continuum grid and are not a converged physical thermal budget.

An actual Cloudy radiative-equilibrium initializer (same prescribed density, solar mixture, PHOENIX proxy, no thermal-flow terms yet) converged in 483 zones and 4 iterations; max(H/C,C/H)=1.00513. Its temperatures at 1,1.1,1.3,1.8,2.5,3 Rp are 5616,6313,6734,7953,7648,6841 K. This supplies a verified independent inversion/turnover target and a better starting guess for the sunbather thermal/wind loop. It is not a converged hydrodynamic atmosphere. A fixed 4500 K lower patch and the dynamical feedback remain separate requirements.

Important chemistry scope: Cloudy's `no molecules` also removes H-minus (`mole_species.cpp:553–560`), because its formation/destruction is coupled to H2 chemistry. Therefore the atomic-mixture cases above do not test the full default sunbather chemistry. The offline tool makes this explicit with `--molecules`/`--no-molecules`, and a full-chemistry sensitivity run is separate. Do not use an atomic-only solar reference to mark the H-minus/continuum requirement supported.

The H-only fixed-density thermal experiment eventually changes by less than 50 K per iteration, but its strict H/C imbalance remains ~2.2. Updating the transonic wind at that cold solution raises the base nH to ~1.23e20/cm3. This exceeds the stated Cloudy/paper domain by five orders of magnitude and is not an admissible converged paperlike atmosphere. It is a controlled diagnostic of the reduced closure and boundary, not a statement that the authors' model fails.

The full-chemistry H+He control has now completed. At 1.1 Rp its net radiative exchange is -4.68e-4 erg cm^-3 s^-1, while full solar gives +3.023e-2. At 1.8 Rp the respective values are -2.38e-8 and +6.23e-7. Thus the sign reversal attributed to the metallic processes persists after including H-minus chemistry. In the full solar case H-minus contributes 10.9% of heating at 1.1 Rp, versus 84.1% from database line heating; H2/H never exceeds 2.02e-6. All of these remain fixed-profile causal comparisons, not claims of author-specific equivalence.

### Thermal iteration and dense lower boundary

The full-chemistry solar thermal/wind reference now includes the explicitly conditional lower prescription (fixed 4500 K base, linear T to the first admissible Cloudy point, Saha-to-Cloudy ionization bridge, LTE lower excitation, fixed non-H background electron fraction). It checks the actual Cloudy domain, P<=1e-3 bar and nH<=1e15 cm^-3, and reports the separate base pressure bound of 10 bar. Lower heating/cooling values are NaN: the prescribed gas is not claimed to satisfy the upper thermal equation. Its n2 and n3/n2 departures from LTE at the join are retained, not blended away. The first two outer iterates have n2/LTE~0.4-0.5 at the join, so a numerically converged reference would still have a physically unverified lower closure.

An important numerical issue was isolated: sunbather's `smooth_gaus_savgol` enforces Gaussian sigma>=3 grid cells. On a 48-node diagnostic grid this is a broad smoothing scale, and its documented temperature-change stopping criterion accepts profiles with local H/C factors of 1.23-1.36. The raw wind fixed-point error contracted from 63.49 to 3.666 over those first two outer iterations, but it is not converged. A warm-start 1000-node continuation uses the unchanged public thermal algorithm at a much smaller physical smoothing scale; it must pass its own convergence checks before use. Numerical convergence and physical LTE-join validity are separate assessments.

The reference driver optionally log-damps a wind update while preserving the proposed mass flux exactly; stopping always uses the *undamped* fixed-point residual. Default weight is one, so this is a numerical stabilization control, not a changed physical closure or a weakened acceptance criterion.

The independent physical reference must also use the full public Cloudy hydrogen atom, rather than inheriting the native reduction. C23.01 defaults are resolved principal levels through n=10 and 15 collapsed shells through n=25 (`iso.cpp:193-194`), with recombination topoff enabled (`iso.cpp:65`). Public sunbather1.1.0 does not override these settings. The offline tool now defaults to this atom; `--hydrogen-atom native-matched` selects the separate n<=15/resolved<=3/topoff-off control. The saved observer population array retains the six n<=3 sublevels and sums higher resolved l states by principal shell. A fixed-state default-atom control is being run before interpreting the reduced-atom thermal iteration as a physical reference.

The default-atom control completed at matched density, temperature, PHOENIX spectrum, full chemistry and continuum resolution. Compared with the native-matched atom, C23 defaults change n2/n3 by -27%/-29% at1.02Rp, -3.1%/-4.0% at1.1Rp, and +6.7%/+7.5% at2.5Rp. Heating changes by approximately -1.6%, -0.9%, +0.2%, +2.9% at1.1,1.3,1.8,2.5Rp. This control requires promotion of the full default atom to the independent thermal reference, even though H-alpha source-temperature differences are smaller. The full-atom loop is `/tmp/escape-sunbather-solar-default25`; the previous reduced-atom refinement was explicitly stopped after its fourth completed iteration and is not a final reference.

The flow-density source also required correction. Cloudy evaluates tabulated DLAW at the zone back (`pressure_change.cpp:180-185`) but reports local diagnostics at the zone midpoint (`save_do.cpp:2131`). With its default adaptive density step this causes a roughly5% offset when the saved density is mapped onto the wind grid. Public sunbather `solveT.simtogrid` correctly uses the prescribed Parker rho,v (lines121-122) for flow derivatives, interpolating only T,mu,radiative heating/cooling from Cloudy. The reference now does the same; raw Cloudy density, saved zone widths and the projection discrepancy remain explicit. Finer input radial interpolation alone does not refine Cloudy's internal zones. A maximum-zone-size control is available independently of the continuum resolution.

### Reference continuum mesh and a C23 threshold inconsistency

For the full default H25/solar/full-chemistry fixed-state control, globally refining Cloudy from continuum multiplier0.2 to0.1 (optical resolving power1500 to3000) changes n3 by about-33% at1.8Rp and-29% at2.5Rp. Refining again to0.05/R6000 reduces subsequent n3 changes to+3%/-1%, but metallic line heating is still changing by tens of percent. At1.8Rp the database-line heating is1.94e-6,1.20e-6,0.91e-6 erg cm^-3 s^-1 atR1500,3000,6000; the non-database remainder stays near0.60e-6. Thus source-population convergence alone would miss a still-unconverged thermal closure. No stellar rotational broadening was inserted to suppress the discrepancy. Integrated incident flux changes below1%, so global point-normalization drift does not explain the effect.

The R12000 global control and the first R30000/R60000 locally refined controls fail before any zone. C23.01's special O I opacity (`opacity_createall.cpp:655`) is zero below a rounded13.62eV, while its continuum ionization pointer follows the NIST109837.02cm^-1 threshold. A sufficiently fine cell falls in the small interval between them and triggers `SanityCheckBegin`'s positive-cross-section assertion. This is a reference-code threshold inconsistency, not a physical thermal instability. The active workaround changes no source, cross section, abundance or SED: an explicitly recorded coarse cell spans1.0007--1.0013Ryd so both thresholds remain in the same threshold cell, while the rest of the supplied PHX band is refined. A1.0008--1.0012Ryd cell checks its sensitivity. No assertion is bypassed. These controls must complete and be assessed before claiming reference convergence.

The independent observer now supports the full25-shell reference without silently enlarging the native SE model. It retains the native n<=20 continuum and adds n21--25 opacity/emissivity using a directly extracted C23 `H_photo_cs_log10` shell-averaged fixture and the same Milne convention. The n20 overlap agrees to1.64e-9 relative error; a16-layer diagnostic gives only1.28e-5ppm from the higher-shell continuum. This does not bound the high-shell cascade impact on level populations, which was measured separately and was much larger.

The R30000 and R60000 threshold-cell controls have completed. At1.1,1.3,1.8,2.5Rp the R60000/R30000 heating ratios are[0.9640,1.0006,1.2442,0.9983], while n3 ratios are[0.9476,0.9994,0.9929,0.9972]. The shell H-alpha source-temperature changes are[0.034,-2.06,-0.27,0.13]K. At1.8Rp the change in net radiative heating divided by fine-grid(heating+cooling) is0.1058. Hence this is still consequential for the thermal closure even though the fixed-temperature H-alpha excitation appears stable. These controls do not support a converged equilibrium reference. A raw-zone observer comparison now retains the resolved population structure and quantifies the previous48-node projection error separately.

The explicit O I-cell width control also completed. At1.1Rp narrowing[1.0007,1.0013] to[1.0008,1.0012]Ryd changes n2/n3 by+12.36%/+12.18%, electrons+5.97%, nH+0.60%, heating+3.86%, cooling+6.90%, but shell source temperature only-2.79K. Above1.3Rp the sampled populations/heating change by less than0.012%. This control also changes nearby mesh phase and adaptive zones; it does not isolate O I physical opacity. No binary/atomic-data assertion or cross section was modified. The remaining sensitivity is retained in the reference-convergence gap.
