"""Offline example and natural-width ablation; no fit or posterior sampling."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
OUTPUT = Path(__file__).resolve().parent
OBS = ROOT / 'data/zenodo_20707255/KELT9b_w6565_avg_p0.30-0.45.dat'
NIST_ROW = {'wav': [15233.146], 'A': [44101000.0], 'El': [82259.158],
            'Eu': [97492.304], 'gl': [8.0], 'gu': [18.0], 'jl': [3.5],
            'ju': [8.5], 'species': ['H_I']}


def snapshot():
    exojax = Path(next(iter(importlib.util.find_spec('exojax').submodule_search_locations)))
    paths = [Path(__file__).resolve(), OBS, ROOT / 'examples/nlte_halpha.py',
             ROOT / 'examples/generate_spectra.py']
    paths += list((ROOT / 'src/escape').rglob('*.py')) + list(exojax.rglob('*.py'))
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(paths)}


def worker(kind):
    import jax
    import jax.numpy as jnp
    import numpy as np
    import pandas as pd
    from unittest.mock import patch

    jax.config.update('jax_enable_x64', True)
    sys.path.insert(0, str(ROOT / 'examples'))
    with patch('exojax.database.nist.api.fetch_nist_lines',
               lambda *args, **kwargs: (pd.DataFrame(NIST_ROW).copy(), [])):
        if kind == 'example':
            sys.argv = [str(ROOT / 'examples/nlte_halpha.py'), '--output',
                        str(OUTPUT / 'example'), '--nlayer', '128', '--nmax', '15']
            runpy.run_path(sys.argv[0], run_name='__main__')
            return

        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        from escape.nlte_forward import HydrogenNLTEForwardModel
        from escape.hydrogen_rates import LIGHT_SPEED_CGS
        from exojax.database.core.broadening import doppler_sigma
        from exojax.opacity.lpf.lpf import vvoigt
        from exojax.utils.constants import c
        from generate_spectra import load_observations

        class LegacyNaturalWidth(HydrogenNLTEForwardModel):
            """Diagnostic-only isolated-transition width; all else unchanged."""
            def _line_profiles(self, temperature_k, velocity_kms):
                sigma = doppler_sigma(self.halpha_centers_cm, temperature_k,
                                      self.adb.line_masses[0])
                detuning = (self.halpha_rest_detuning_cm[None, :]
                            + self.halpha_centers_cm[:, None] * velocity_kms / c)
                gamma = jnp.full((3,), 44101000 / (4 * jnp.pi * LIGHT_SPEED_CGS))
                return vvoigt(detuning, sigma, gamma)

        configuration = dict(nlayer=128, nlon=12, nlat=6, nnu=601, nmax=15,
                             continuum_points=48, wind_ngrid=129)
        parameters = dict(mass_loss_g_s=1e13, radiation_dilution=.025,
                          radiation_temperature_k=10000., mean_molecular_weight=.5,
                          temperature_top_k=10000., rotation_kms=5., zonal_kms=10.)
        full = HydrogenNLTEForwardModel(**configuration)
        legacy = LegacyNaturalWidth(**configuration)
        population_parameters = {k: v for k, v in parameters.items()
                                 if k not in ('rotation_kms', 'zonal_kms')}
        profiles = full.population_profiles(**population_parameters)
        if not np.all(profiles['converged']):
            raise RuntimeError('A population solve did not converge.')
        spectrum = np.asarray(full.spectrum(**parameters))
        old_spectrum = np.asarray(legacy.spectrum(**parameters))
        if not np.isfinite(spectrum).all() or not np.isfinite(old_spectrum).all():
            raise RuntimeError('Nonfinite width-comparison spectrum.')
        velocity = np.asarray(full.velocity_kms)
        obs_velocity, obs_signal, obs_sigma = map(np.asarray, load_observations(full.line_center_cm))
        if obs_velocity.min() < velocity.min() or obs_velocity.max() > velocity.max():
            raise RuntimeError('Observer grid is not covered.')
        observed_full = np.interp(obs_velocity, velocity[::-1], spectrum[::-1])
        observed_old = np.interp(obs_velocity, velocity[::-1], old_spectrum[::-1])
        delta = spectrum - old_spectrum
        scaled = (observed_full - observed_old) / obs_sigma
        report = {
            'scope': 'Natural-width ablation only, at the same finite-atom population solution; not a fit or NUTS.',
            'configuration': configuration, 'parameters': parameters,
            'complete_lifetime_hwhm_cm1': np.asarray(full.halpha_natural_width_cm).tolist(),
            'legacy_hwhm_cm1': 44101000 / (4 * np.pi * LIGHT_SPEED_CGS),
            'contrast_full_range': [float(spectrum.min()), float(spectrum.max())],
            'contrast_legacy_range': [float(old_spectrum.min()), float(old_spectrum.max())],
            'max_absolute_difference_contrast': float(np.abs(delta).max()),
            'max_absolute_difference_over_full_peak': float(np.abs(delta).max() / np.abs(spectrum).max()),
            'rms_difference_contrast': float(np.sqrt(np.mean(delta ** 2))),
            'max_observer_difference_over_supplied_sigma': float(np.abs(scaled).max()),
            'rms_observer_difference_over_supplied_sigma': float(np.sqrt(np.mean(scaled ** 2))),
            'observation_pixel_count': len(obs_velocity),
            'all_population_solves_converged': bool(np.all(profiles['converged'])),
            'all_branch_extinction_integrals_positive': bool(np.all(profiles['halpha_branch_extinction_integral'] > 0)),
            'electron_density_cm3_range': [float(np.min(profiles['electron_density_cm3'])), float(np.max(profiles['electron_density_cm3']))],
            'limitations': ['Shared NIST branch center, prescribed radiation/temperature, no Stark/pressure broadening.',
                            'Observation uncertainty sets a comparison scale; this is not an observational fit.'],
        }
        path = OUTPUT / 'width_comparison'
        path.mkdir(exist_ok=True)
        (path / 'diagnostics.json').write_text(json.dumps(report, indent=2) + '\n')
        np.savetxt(path / 'spectra.csv', np.column_stack((velocity, spectrum, old_spectrum, delta)),
                   delimiter=',', header='velocity_kms,complete_lifetime_contrast,isolated_transition_contrast,difference', comments='')
        np.savetxt(path / 'observer_comparison.csv',
                   np.column_stack((obs_velocity, obs_signal, obs_sigma, observed_full, observed_old, scaled)),
                   delimiter=',', header='velocity_kms,observation,supplied_sigma,complete_lifetime_contrast,isolated_transition_contrast,difference_over_sigma', comments='')
        np.savez_compressed(path / 'spectra.npz', velocity_kms=velocity, complete_lifetime=spectrum,
                            isolated_transition=old_spectrum, obs_velocity_kms=obs_velocity,
                            observation=obs_signal, supplied_sigma=obs_sigma,
                            radius_rp=np.asarray(full.radius_rp), temperature_k=np.asarray(profiles['temperature_k']),
                            radial_velocity_kms=np.asarray(profiles['radial_velocity_kms']),
                            bound_cm3=np.asarray(profiles['bound_cm3']), electron_cm3=np.asarray(profiles['electron_density_cm3']))
        fig, axes = plt.subplots(1, 2, figsize=(10.4, 3.7), constrained_layout=True)
        axes[0].errorbar(obs_velocity, 100 * obs_signal, yerr=100 * obs_sigma,
                         fmt='.', color='.65', ms=2, label='Zenodo observation')
        for ax in axes:
            ax.plot(velocity, 100 * spectrum, label='Both level lifetimes', color='C0')
            ax.plot(velocity, 100 * old_spectrum, '--', label='Old isolated-transition width', color='C1')
            ax.axhline(0., color='.5', lw=.7)
            ax.set(xlabel='Velocity from H-alpha rest center [km/s]', ylabel='Line contrast [%]', xlim=(-100, 100))
        axes[0].set(title='Observation for scale only')
        axes[1].set(title='Width comparison, enlarged')
        axes[1].legend(fontsize=8)
        fig.suptitle('Same populations and Parker atmosphere; only natural widths differ', fontsize=12)
        fig.supxlabel('Data: Y. Zhang (2026), doi:10.5281/zenodo.20707255; CC BY 4.0', fontsize=8)
        fig.savefig(path / 'natural_width_comparison.png', dpi=180)
        plt.close(fig)
        print(json.dumps(report, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--worker', choices=('example', 'width'))
    parser.add_argument('--exojax-origin', default='38cb2e44f153ad6d729e3253e235702de52920cf')
    args = parser.parse_args()
    if args.worker:
        worker(args.worker)
        return
    before = snapshot()
    commands, checks = {}, {}
    started = datetime.now(timezone.utc).isoformat()
    escape_revision_before = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    for kind in ('example', 'width'):
        command = ['taskset', '-c', '40-47', sys.executable, str(Path(__file__).resolve()), '--worker', kind]
        commands[kind] = command
        start = time.perf_counter()
        with (OUTPUT / f'{kind}.log').open('w') as stream:
            result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
        checks[kind] = {'exit_code': result.returncode, 'elapsed_seconds': time.perf_counter() - start}
        print(json.dumps({kind: checks[kind]}), flush=True)
    after = snapshot()
    outputs = {str(path.relative_to(OUTPUT)): hashlib.sha256(path.read_bytes()).hexdigest()
               for path in OUTPUT.rglob('*') if path.is_file() and path.name != 'receipt.json'}
    report = {'purpose': 'Final example figures and controlled natural-width ablation; no NUTS.',
              'started_utc': started, 'ended_utc': datetime.now(timezone.utc).isoformat(),
              'commands': commands, 'runs': checks, 'nist_row': NIST_ROW,
              'nist_source': 'https://physics.nist.gov/PhysRefData/ASD/lines_form.html',
              'nist_retrieved_date': '2026-11-16', 'cpu_affinity': '40-47',
              'pythonpath': os.environ.get('PYTHONPATH'),
              'environment': {key: os.environ.get(key) for key in ('JAX_PLATFORMS', 'JAX_ENABLE_X64', 'OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS')}, 'source_hashes_before': before,
              'source_hashes_after': after, 'source_unchanged': before == after,
              'output_sha256': outputs,
              'escape_revision_before': escape_revision_before,
              'escape_revision_after': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
              'exojax_source_origin_commit': args.exojax_origin,
              'exojax_source_origin_evidence': 'Explicit origin argument for the clean source export; exact file hashes independently identify content.',
              'exojax_source_scope': 'Exported clean source tree without .git; source-file hashes record exact content.'}
    (OUTPUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
    if before != after or any(item['exit_code'] for item in checks.values()):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
