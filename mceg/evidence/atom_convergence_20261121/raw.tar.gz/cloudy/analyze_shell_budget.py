"""Independent frozen-operator attribution; no runtime-model coefficients used."""
from pathlib import Path
import importlib.util
import json
import numpy as np
ROOT=Path(__file__).resolve().parents[3]
spec=importlib.util.spec_from_file_location('diagnose',ROOT/'tools/cloudy_rates_diagnosis.py')
d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
base=Path(__file__).resolve().parent
answer={'scope':'Frozen reference-operator mechanism diagnosis, not a new plasma model; all coefficients remain at their recorded Cloudy state.','models':{}}
for n in (5,10):
    path=base/f'operator_nmax{n:02d}/model.out.gz'
    if not path.exists():path=path.with_suffix('')
    op=d.parse_operator(path); rates=d.rate_blocks(op)
    ne,np_=op['header'][4],op['header'][7]
    matrix,source=d.matrix(rates,ne)
    pop=np.asarray(op['solution']); sol=np.linalg.solve(matrix,source*np_)
    rel=float(np.max(np.abs(sol/pop-1)))
    assert rel<1e-7,rel
    principal=np.asarray(op['fb'])[:,1].astype(int)
    group=np.isin(principal,[3]); other=~group
    radiative=rates['radiative_bound_bound_s']; collisional=ne*rates['electron_bound_bound_cm3_s']
    grouped={}
    for name,mask in [('n1',principal==1),('n2',principal==2),('n4_5',np.isin(principal,[4,5])),('n6plus',principal>=6)]:
        incoming_rad=float((pop[mask,None]*radiative[np.ix_(mask,group)]).sum())
        outgoing_rad=float((pop[group,None]*radiative[np.ix_(group,mask)]).sum())
        incoming_col=float((pop[mask,None]*collisional[np.ix_(mask,group)]).sum())
        outgoing_col=float((pop[group,None]*collisional[np.ix_(group,mask)]).sum())
        grouped[name]={'radiative_in':incoming_rad,'radiative_out':outgoing_rad,'collisional_in':incoming_col,'collisional_out':outgoing_col,'net':incoming_rad+incoming_col-outgoing_rad-outgoing_col}
    rr=ne*np_*rates['radiative_recombination_cm3_s'];three=ne**2*np_*rates['three_body_recombination_cm6_s']
    photo=pop*rates['photoionization_s'];ion=pop*ne*rates['electron_ionization_cm3_s']
    fbnet=float((rr+three-photo-ion)[group].sum())
    grouped['continuum']={'radiative_recombination':float(rr[group].sum()),'three_body_recombination':float(three[group].sum()),'photoionization':float(photo[group].sum()),'collisional_ionization':float(ion[group].sum()),'net':fbnet}
    net=sum(x['net'] for x in grouped.values())
    scale=sum(abs(x['net']) for x in grouped.values())
    assert abs(net)/scale<1e-7,(net,scale)
    shell_cont={str(int(shell)):{'RR':float(rr[principal==shell].sum()),'three_body':float(three[principal==shell].sum()),'photo':float(photo[principal==shell].sum()),'collisional_ionization':float(ion[principal==shell].sum())} for shell in np.unique(principal)}
    answer['models'][str(n)]={'operator_sha256':d.sha256(path),'independent_solve_max_relative_error':rel,'ne':ne,'np':np_,'n3':float(pop[group].sum()),'n3_flux_budget_cm3_s':grouped,'n3_budget_relative_residual':abs(net)/scale,'shell_continuum_budget_cm3_s':shell_cont}
    if n==10:
        sliced={key:arr[:8,:8] if arr.ndim==2 else arr[:8] for key,arr in rates.items()}
        cases={}
        for label,atne in [('fixed_n10_electron_density',ne),('pure_H_charge_with_frozen_coefficients',None)]:
            full=d.solve_frozen(rates,1e12,atne); cut=d.solve_frozen(sliced,1e12,atne)
            cases[label]={'nmax5':cut,'nmax10':full,'n3_relative_change':full['n3_cm3']/cut['n3_cm3']-1,'warning':'Density-dependent rates are NOT reevaluated in this diagnostic.'}
        answer['frozen_interventions']=cases
(base/'shell_budget.json').write_text(json.dumps(answer,indent=2)+'\n')
for n,row in answer['models'].items():
    print(n,'n3',row['n3'],'residual',row['n3_budget_relative_residual'],'fluxes', {k:v['net'] for k,v in row['n3_flux_budget_cm3_s'].items()})
print('Frozen interventions:',{k:v['n3_relative_change'] for k,v in answer['frozen_interventions'].items()})
