"""Audit the retained matched-atom batch and independent convergence controls."""
from pathlib import Path
from hashlib import sha256
import importlib.util
import json
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'))
import verify_cloudy_cases as v
base=Path(__file__).resolve().parent
batchdir=base/'escape-final-001'
batch=json.loads((batchdir/'batch.json').read_text())
checked=v.evaluate_batch(batchdir)
assert checked['status']=='passed',checked['reasons']
manifest=json.loads((batchdir/'cases.json').read_text())
for rel,digest in checked['source_sha256'].items():
    assert sha256((ROOT/rel).read_bytes()).hexdigest()==digest,rel
rows={}
for c in manifest['cases']:
    r=json.loads((batchdir/c['id']/'receipt.json').read_text())
    rows.setdefault(c['condition_id'],{})[c['nmax']]={'escape':r['escape'],'cloudy':r['cloudy'],'relative_errors':r['relative_errors'],'receipt_sha256':sha256((batchdir/c['id']/'receipt.json').read_bytes()).hexdigest()}
changes={k:{x:abs(vals[20]['escape'][x]/vals[15]['escape'][x]-1) for x in ['n2_cm3','n3_cm3']} for k,vals in rows.items()}
tails={}
for condition,ref in [('baseline','baseline_nmax30'),('dilute_gas','dilute_gas_nmax40')]:
    cr=json.loads((base/'cloudy'/ref/'receipt.json').read_text())
    tails[condition]={'reference_directory':ref,'nmax':cr['configuration']['nmax'],'relative_errors':{x:abs(rows[condition][15]['escape'][x]/cr['cloudy'][x]-1) for x in ['n2_cm3','n3_cm3']}}
assert max(v for row in changes.values() for v in row.values())<.05
assert max(v for row in tails.values() for v in row['relative_errors'].values())<.05
result={'kind':'extended_atom_comparison_review','scope':'All14 matched finite-atom comparisons, seven nmax15-to20 changes and two separate larger-reference-tail checks. Population agreement only, not full atmospheric validity.','command':'PYTHONPATH=src:/home/kawahara/exojax/src JAX_PLATFORMS=cpu JAX_ENABLE_X64=1 /home/kawahara/miniconda3/bin/python tools/verify_cloudy_cases.py run --cases mceg/investigations/atom_convergence_cases.json --reference-batch results/atom-convergence/cloudy --record results/atom-convergence/escape-final-001','exit_code':0,'exit_code_note':'The parent subprocess exit status was returned by write_stdin after the CLI completed. Per-case execution and source identities are retained in batch receipts.','batch_sha256':sha256((batchdir/'batch.json').read_bytes()).hexdigest(),'manifest_sha256':sha256((batchdir/'cases.json').read_bytes()).hexdigest(),'audit_script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'comparison':checked,'populations':rows,'internal_convergence':changes,'external_tail_checks':tails,'summary':{'matched_cases':len(manifest['cases']),'matched_max_relative_error':max(x for row in checked['relative_errors'].values() for x in row.values()),'internal_max_relative_change':max(v for row in changes.values() for v in row.values()),'external_tail_max_relative_error':max(v for row in tails.values() for v in row['relative_errors'].values()),'all_sources_current':True,'status':'passed'}}
(base/'comparison_review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['summary'],indent=2))
