"""Compare frozen stellar-SED population profiles; no internal transfer solve."""
from __future__ import annotations

import argparse
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path

import jax
jax.config.update("jax_enable_x64", True)
import jax.numpy as jnp
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.special import voigt_profile

from escape.hydrogen_atom import atom_cross_sections, atom_natural_width_hz, make_hydrogen_atom
from escape.hydrogen_continuum import continuum_coefficients
from escape.hydrogen_forward import PLANET_RADIUS_CM
from escape.hydrogen_rates import BOLTZMANN_CGS as K, LIGHT_SPEED_CGS as C, PLANCK_CGS as H


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True,
                        help="Directory for JSON, diagnostic arrays and a figure.")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    # One in-memory snapshot prevents lazy ZIP reads from a concurrently replaced file.
    payload = args.input.read_bytes()
    with np.load(BytesIO(payload)) as data:
        arrays = {key: data[key] for key in data.files}
    radius = arrays["radius_rp"]
    spacing = -np.diff(radius)
    if not (radius.ndim == 1 and len(radius) > 1 and np.all(spacing > 0)
            and np.allclose(spacing, spacing[0], rtol=1e-12, atol=1e-12)):
        raise ValueError("Expected a uniform radial midpoint grid ordered outer to inner.")
    width = float(spacing[0])
    dr = np.full_like(radius, width * PLANET_RADIUS_CM)
    outer_radius = float(radius[0] + width / 2)
    atom = make_hydrogen_atom(15)
    expected_shape = (len(radius), len(atom.principal_n))
    index = int(np.flatnonzero((np.asarray(atom.line_lower) == 0)
                              & (np.asarray(atom.line_upper) == 4))[0])
    frequency = float(atom.line_frequency_hz[index])
    a31 = float(atom.einstein_a_s[index])
    weight_ratio = float(atom.statistical_weights[4] / atom.statistical_weights[0])
    gamma = float(atom_natural_width_hz(atom)[index])
    cross_sections = np.asarray(atom_cross_sections(atom, jnp.array([frequency])))[:, 0]
    nmax = int(np.max(atom.principal_n))
    report = {
        "scope": "Frozen nmax=15 charge/population profiles with blackbody or PHOENIX illumination. Optical depths from the finite outer boundary to cell midpoints. No internal scattering, radiation feedback, photon escape or new population solution.",
        "input": str(args.input.resolve()), "input_sha256": sha256(payload).hexdigest(),
        "script_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "nmax": nmax, "bound_shape": list(expected_shape),
        "radius_convention": "Uniform layer midpoint grid, outer to inner; thickness reconstructed and checked from saved radii.",
        "outer_boundary_rp": outer_radius, "planet_radius_cm": float(PLANET_RADIUS_CM),
        "line_wavelength_vacuum_angstrom": C / frequency * 1e8,
        "line_energy_ev": H * frequency / 1.602176634e-12,
        "charge_convention": "Pure hydrogen: ne=np=nH-sum(bound populations).",
        "cases": {},
    }
    output_arrays = {"radius_rp": radius, "thickness_cm": dr}
    cumulative = lambda chi: np.cumsum(chi * dr) - 0.5 * chi * dr
    continuum = jax.jit(jax.vmap(lambda t, bound, charge: continuum_coefficients(
        atom, t, bound, charge, charge, jnp.array([frequency]),
        include_free_free=True, include_hminus=False,
    )[0]))
    for atmosphere in ["previous_fit", "hot_manual"]:
        for field in ["blackbody", "PHOENIX"]:
            prefix = atmosphere + "_" + field
            bound = arrays[prefix + "_bound_cm3"]
            temperature = arrays[prefix + "_temperature_k"]
            velocity = arrays[prefix + "_radial_velocity_kms"]
            n_h = arrays[prefix + "_n_h_cm3"]
            if bound.shape != expected_shape:
                raise ValueError(f"{prefix}: bound shape does not match the full nmax=15 atom.")
            if not all(np.isfinite(x).all() for x in [bound, temperature, velocity, n_h]):
                raise ValueError(f"{prefix}: nonfinite input profiles.")
            if not np.all(bound >= 0):
                raise ValueError(f"{prefix}: negative bound population.")
            for shell, lo, hi in [(2, 1, 3), (3, 3, 6)]:
                np.testing.assert_allclose(bound[:, lo:hi].sum(axis=1),
                                           arrays[f"{prefix}_n{shell}_cm3"], rtol=1e-12)
            charge = n_h - bound.sum(axis=1)
            if not np.all(charge >= 0):
                raise ValueError(f"{prefix}: bound population exceeds hydrogen nuclei.")
            sigma = frequency * np.sqrt(K * temperature / 1.6735575e-24) / C
            integrated = C**2 / (8 * np.pi * frequency**2) * a31 * (
                weight_ratio * bound[:, 0] - bound[:, 4]
            )
            static = integrated * voigt_profile(0, sigma, gamma)
            # Inward stellar ray and outward gas: positive comoving frequency shift.
            moving = integrated * voigt_profile(frequency * velocity * 1e5 / C,
                                                sigma, gamma)
            bf = bound @ cross_sections
            net_continuum = np.asarray(continuum(temperature, bound, charge))[:, 0]
            values = {
                "static_lybeta_tau": cumulative(static),
                "radial_doppler_lybeta_tau": cumulative(moving),
                "positive_hydrogen_bf_tau": cumulative(bf),
                "net_hydrogen_continuum_tau": cumulative(net_continuum),
                "ground_column_cm2": cumulative(bound[:, 0]),
                "ground_density_cm3": bound[:, 0],
                "pressure_bar": (n_h + charge) * K * temperature / 1e6,
            }
            assert all(np.isfinite(value).all() for value in values.values())
            assert np.all(static > 0)
            output_arrays.update({prefix + "_" + key: value for key, value in values.items()})
            entry = {"samples": []}
            for target in [1.3, 1.8, 2.5]:
                q = int(np.argmin(abs(radius - target)))
                entry["samples"].append({
                    "radius_rp": float(radius[q]),
                    "temperature_k": float(temperature[q]),
                    "radial_velocity_kms": float(velocity[q]),
                    **{key: float(value[q]) for key, value in values.items()},
                })
            report["cases"][prefix] = entry

    # Material and velocity profiles must be unchanged in this boundary-SED experiment.
    for atmosphere in ["previous_fit", "hot_manual"]:
        for quantity in ["n_h_cm3", "temperature_k", "radial_velocity_kms"]:
            np.testing.assert_array_equal(arrays[f"{atmosphere}_blackbody_{quantity}"],
                                          arrays[f"{atmosphere}_PHOENIX_{quantity}"])
    report["fixed_material_profiles_equal"] = True
    (args.output / "stellar_opacity_budget.json").write_text(json.dumps(report, indent=2) + "\n")
    np.savez_compressed(args.output / "stellar_opacity_arrays.npz", **output_arrays)

    fig, axes = plt.subplots(2, 2, figsize=(12, 8), sharex=True, constrained_layout=True)
    colors = {"blackbody": "#333333", "PHOENIX": "#0072b2"}
    for column, atmosphere in enumerate(["previous_fit", "hot_manual"]):
        axes[0, column].set_title({"previous_fit": "Previous fitted atmosphere",
                                   "hot_manual": "Hot manual atmosphere"}[atmosphere])
        for field in ["blackbody", "PHOENIX"]:
            prefix = atmosphere + "_" + field
            color = colors[field]
            axes[0, column].semilogy(radius, output_arrays[prefix + "_static_lybeta_tau"],
                                     color=color, label=field + ": static")
            axes[0, column].semilogy(radius, output_arrays[prefix + "_radial_doppler_lybeta_tau"],
                                     color=color, ls="--", label=field + ": radial Doppler")
            axes[1, column].semilogy(radius, output_arrays[prefix + "_positive_hydrogen_bf_tau"],
                                     color=color, label=field + ": H bound-free")
        for row in range(2):
            axes[row, column].axhline(1, color="0.6", ls=":", lw=1, label="Optical depth = 1")
            axes[row, column].set_xlim(1.1, 2.9)
            axes[row, column].grid(alpha=0.15)
            axes[row, column].legend(fontsize=9, loc="best")
        axes[1, column].set_xlabel("Radius / Rp")
    axes[0, 0].set_ylabel("H I Ly-beta line-center optical depth")
    axes[1, 0].set_ylabel("Excited-H continuum optical depth at Ly-beta")
    fig.suptitle("Planetary hydrogen remains opaque at Ly-beta\n"
                 "Frozen blackbody/PHOENIX populations; optical depth from 3 Rp; no internal radiation solve")
    fig.savefig(args.output / "stellar_opacity.png", dpi=160)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
