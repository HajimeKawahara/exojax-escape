# Ly-beta absorption review

The first absorber to treat is neutral hydrogen itself, in both the stellar
photosphere that produces the boundary spectrum and the planetary atmosphere
that processes it. The conclusion does not require an unidentified extra
opacity. Other absorbers exist, but none is established by this review as the
cause of the H-alpha fit discrepancy.

## Ranked channels

| Location / absorber | Mechanism at 1025.7 Angstrom | Relevance and limitation |
| --- | --- | --- |
| Stellar photospheric H I | 1s to 3p resonance produces the stellar Ly-beta line profile | A smooth blackbody has no photospheric line; inspect the selected stellar SED at the actual line wavelength and across its profile. Boundary change alone does not solve planetary transfer. |
| Planetary ground-state H I | Resonant absorption, followed by Ly-beta re-emission or H-alpha conversion | First priority: the retained fit profiles have very large Ly-beta line-center optical depths. Local mean intensity is not direct incident intensity times a global attenuation factor. |
| O I near 1025.76 Angstrom | Near-resonant fluorescence (Bowen mechanism), cascades into O I infrared/optical lines | Physically real line overlap, about 12 km/s from Ly-beta. Neutral oxygen is detected in KELT-9b, but its relevant population and overlap opacity have not been calculated here. |
| Excited H bound-free | Ly-beta photons can ionize n>=2 hydrogen | Present atom already includes these rate cross sections; their attenuation is absent from the observer population path. At the retained outer fit layers their optical depth is tiny compared with H I line opacity. |
| Neutral metal bound-free | C I, Mg I, Si I and Fe I thresholds lie below 12.09 eV | Energetically allowed, but requires neutral abundances, cross sections and the actual radiation field. Ionization state matters; do not infer opacity from elemental abundance alone. |
| H-minus | Photodetachment continuum | Potentially important deeper down. The existing code's John fit does not cover 1025 Angstrom, so a returned zero is not a physical prediction at this wavelength. |
| H2 | Lyman/Werner-band absorption, fluorescence/dissociation | Known near-coincidence at 1025.93 Angstrom, but molecules are expected to be largely dissociated in the hot KELT-9b thermosphere. Lower priority than atomic H; a cold molecular reservoir would require a separate model. |

Ground-state H **bound-free** absorption is unavailable here: a Ly-beta photon
has 12.0875 eV, less than the 13.5984 eV H I ionization threshold. This must not
be confused with the very strong ground-state **bound-bound** resonance.
Ground-state O I (13.6181 eV) likewise cannot absorb it by photoionization,
although its near-coincident bound-bound transition can. Neutral He needs
still more energy. Interstellar absorption between this system and Earth is
not a screen between KELT-9 and its nearby planet and must not be applied to
the planet's incident spectrum.

## Quantitative frozen-profile check

`opacity_budget.py` uses the exact bound populations saved for the preceding
expanded fits, with no new population solve or stellar SED. The upper boundary
is 3 Rp. Extinction is integrated inward to layer midpoints, including
stimulated emission. Thermal Voigt profiles use the full spontaneous lifetime
of 3p. These are optical-depth diagnostics, not a solution for mean intensity
or escape probability.

| At 1.8046875 Rp | Nonisothermal fit | Independent isothermal-wind fit |
| --- | ---: | ---: |
| H I ground-state column above [cm^-2] | 1.54e18 | 2.17e19 |
| Static Ly-beta line-center optical depth | 1.88e4 | 2.65e5 |
| Stellar rest-center depth with radial Doppler shifts | 1.34e4 | 2.63e5 |
| Excited-H bound-free optical depth at Ly-beta | 4.88e-7 | 6.19e-6 |
| Gas pressure [bar] | 6.88e-8 | 2.55e-7 |

The formula used is

`chi_nu = c^2/(8*pi*nu0^2) * A31 * [(g3p/g1s)n1s - n3p] * phi(nu-nu0)`.

At 6000 K, the center cross section is about 1.22e-14 cm^2 per ground-state
atom. The radial Doppler diagnostic treats a stellar ray directed inward and
gas flowing outward; it does not include angular structure or scattering.
The large optical depths establish that transparent direct propagation is
inconsistent with these frozen populations. They do not establish whether the
self-consistent local mean intensity becomes larger or smaller than the
currently prescribed field, because populations and diffuse radiation respond.

The code's current Ly-beta wavelength is 1025.722086 Angstrom in vacuum,
obtained from its NIST-derived low-level energies. It is not the old approximate
Rydberg H-alpha center. The isolated 3p spontaneous branching fraction into
2s is A32/(A31+A32)=0.118337. The other 88.17 percent returns to 1s. This
branching is not an observed H-alpha efficiency: other excitation/destruction
channels and photon transport also participate.

## Couplings to retain

An actual line rate depends on the incident spectrum averaged over the
absorbing atom's profile in its rest frame. The planetary velocity, stellar
rotation/line shape and the finite stellar angular extent can change this
average. The H thermal Doppler b is approximately 10--13 km/s at 6000--10000 K,
comparable with the O I overlap separation. A single tabulated SED pixel is
not automatically a resolved pumping rate. Keep the vacuum wavelength
convention and document any stellar-profile broadening.

The existing static moment solver and hydrogen continuum module contain some
of the required internal-transfer ingredients. The current observer population
path does not call them: its local populations use the same line/continuum
occupation in every layer. O I, neutral-metal continua and H2 are absent from
that pure-hydrogen atom. H-minus is optional elsewhere, with a bound-free fit
starting at 0.125 micron, beyond Ly-beta (0.10257 micron).

## Primary sources

- [Zhang et al. 2026, Sections IV--V](https://arxiv.org/html/2606.23899v1#S4):
  PHOENIX boundary spectrum; depth-dependent excitation interpretation.
- [Garcia Munoz & Schneider 2019](https://arxiv.org/html/1910.00267v1):
  distinguishes direct and diffuse radiation, treats Ly-alpha transport and
  excited-H bound-free absorption, and assumes molecular dissociation in the
  hot thermosphere. Its reduced line-transfer treatment is not evidence that
  Ly-beta absorption can be ignored in the present atom.
- [Shaikhislamov et al. 2025](https://doi.org/10.1051/0004-6361/202453309):
  KELT-9b H/O excitation model, PHOENIX irradiation, H-minus and metal processes.
  The article places strong H-minus continuum absorption deeper than the
  tenuous layers sampled here; it does not provide an opacity calculation for
  this particular fit.
- [Borsa et al. 2022](https://www.nature.com/articles/s41550-021-01544-4):
  observed neutral-oxygen 777.4 nm triplet in KELT-9b. This establishes oxygen
  presence, not its Ly-beta overlap optical depth.
- [O I line emission with partial redistribution](https://academic.oup.com/mnras/article/374/1/220/961071):
  O I 1025.77 Angstrom / H Ly-beta near coincidence and fluorescence.
- [Liu & Dalgarno 1995, NASA archive](https://ntrs.nasa.gov/citations/19960016737):
  H2 (6,0) P(1) absorption at 1025.93 Angstrom pumped by solar Ly-beta on Jupiter;
  this identifies a possible transition, not evidence of H2 in KELT-9b.
- [NIST ionization energies](https://physics.nist.gov/cgi-bin/ASD/ie.pl?at_num_out=on&e_out=0&el_name_out=on&format=0&level_out=on&order=0&shells_out=on&spectra=H-Zn+I&submit=Retrieve+Data&units=1):
  H I 13.5984, C I 11.2603, O I 13.6181, Mg I 7.6462,
  Si I 8.1517 and Fe I 7.9024 eV.
