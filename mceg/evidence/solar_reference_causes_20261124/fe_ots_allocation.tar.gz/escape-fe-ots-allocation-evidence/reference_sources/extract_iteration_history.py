"""Extract completed diagnostic iterations; never mark an atmosphere converged."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import shutil
import sys

import numpy as np

sys.path.insert(0, "/tmp/escape-coupled-atmosphere/tools")
import cloudy_atmosphere as reference

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("directory", type=Path)
args = parser.parse_args()
directory = args.directory
original = dict(np.load(directory / "input_profiles.npz"))
top = original["radius_cm"][-1]
thickness = top - original["radius_cm"][0]
columns = dict(conditions=10, heating=5, pressure=6, mass=7, overview=11, radius=4)
level_lines = (directory / "history.levels").read_text().splitlines()
columns["levels"] = next(len(line.split()) for line in level_lines
                         if line.strip() and not line.lstrip().startswith("#"))
tables = {key: reference.numeric_rows(directory / ("history." + key), ncolumn)
          for key, ncolumn in columns.items()}
conditions = tables["conditions"]
starts = np.r_[0, 1 + np.flatnonzero(np.diff(conditions[:, 0]) < 0), len(conditions)]
log = (directory / "model.convergence").read_text()
completed_markers = [int(n) for n in re.findall(r"iteration (\d+) of", log)]
complete = max(len(starts) - 2, max(completed_markers, default=0))
destination = directory / "derived"
destination.mkdir(exist_ok=True)
scope = json.loads((directory / "scope.json").read_text())
for number in range(1, min(complete, len(starts) - 1) + 1):
    lower, upper = starts[number - 1:number + 1]
    output = destination / f"iteration_{number:03d}"
    if output.exists():
        continue
    if any(len(table) < upper for table in tables.values()):
        continue  # a diagnostic stream may not have flushed its final records
    selected = {key: table[lower:upper] for key, table in tables.items()}
    radius = selected["radius"]
    if (radius[0, 0] != 1 or radius[-1, 0] != len(radius)
            or abs(radius[-1, 2] + .5 * radius[-1, 3] - thickness) > 2e-4 * thickness):
        continue  # the selected sequence does not span the declared full column
    output.mkdir()
    for key, table in selected.items():
        np.savetxt(output / ("model." + key), table, fmt="%.17g")
    raw = reference.read_zone_profiles(output, top, 25, 10)
    metadata = reference.state_metadata(25)
    np.savez(output / "cloudy_profiles.npz", **raw, **metadata)
    projected = {}
    for key, value in raw.items():
        projected[key] = (np.interp(original["radius_cm"], raw["radius_cm"], value)
                          if value.ndim == 1 else np.column_stack([
                              np.interp(original["radius_cm"], raw["radius_cm"], column)
                              for column in value.T]))
    projected["radius_cm"] = original["radius_cm"]
    projected["velocity_cm_s"] = original["velocity_cm_s"]
    mass_per_h = np.median(raw["density_g_cm3"] / raw["n_h_cm3"])
    projected["wind_density_g_cm3"] = original["n_h_cm3"] * mass_per_h
    adv, exp, ratio = reference.thermal_balance(projected, original["velocity_cm_s"])
    projected.update(advection_erg_cm3_s=adv, expansion_erg_cm3_s=exp,
                     total_heating_cooling_ratio=ratio,
                     cloudy_mask=np.ones(len(ratio), dtype=bool))
    np.savez(output / "profiles.npz", **projected, **metadata)
    shutil.copyfile(directory / "input_profiles.npz", output / "input_profiles.npz")
    step = dict(iteration=number, zones=len(raw["radius_cm"]),
                max_heating_cooling_factor=float(np.max(np.maximum(ratio, 1 / ratio))),
                full_column_depth_cm=float(radius[-1, 2] + .5 * radius[-1, 3]))
    receipt = dict(scope="Completed iteration diagnostic only; no accepted reference or thermal/wind equilibrium.",
                   converged=False, thermal_converged=False, iterations=[step],
                   composition="solar", hydrogen_atom="cloudy-default", nmax=25,
                   local_tolerance=scope["local_ionization_and_electron_tolerance"],
                   parent_scope=scope,
                   source_history_paths={key: str(directory / ("history." + key)) for key in tables},
                   source_numeric_row_slice=[int(lower), int(upper)],
                   extractor_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                   reader_sha256=hashlib.sha256(Path(reference.__file__).read_bytes()).hexdigest(),
                   artifact_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                    for p in output.iterdir()})
    (output / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(output, flush=True)
