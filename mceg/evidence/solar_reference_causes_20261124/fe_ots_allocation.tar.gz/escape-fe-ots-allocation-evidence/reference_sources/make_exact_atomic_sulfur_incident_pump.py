"""Prototype only: exact incident line samples with coarse continuous transfer.

This is a numerical approximation to the fully line-centered mesh, not an
unmodified C23 reference. Its error must be checked against that independent
mesh. The input spectrum, atomic rates, and Cloudy guards stay unchanged.
"""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

source=Path('/tmp/cloudy-reference-run/c23.01/source')
root=Path('/tmp/cloudy-continuum-convergence-continuation/diagnostic')
original=(source/'rt_line_one.cpp').read_text()
updated=original.replace('#include "geometry.h"', '#include "geometry.h"\n#include "continuum.h"\n#include <unordered_map>')
anchor='/*RT_line_pumping pumping by external and locally emitted radiation fields */\nSTATIC void RT_line_pumping('
helper=r'''
// Experimental numerical interpolation. Only one constant incident beam is
// supported; continuum attenuation and diffuse emission retain the main mesh.
static double exact_atomic_sulfur_incident_line_ratio(const TransitionProxy& t)
{
    const double line=t.EnergyRyd();
    const int z=t.Lo()->nelem(), stage=t.Lo()->IonStg();
    const bool atomic_iso=t.systemIs(iso_sp[ipH_LIKE][ipHYDROGEN].tr) ||
        t.systemIs(iso_sp[ipH_LIKE][ipHELIUM].tr) || t.systemIs(iso_sp[ipHE_LIKE][ipHELIUM].tr);
    if(line<=.016 || line>=1.83 ||
       !(atomic_iso || (stage>=1 && stage<=3 && (z==6 || z==7 || z==8 || z==12 || z==13 || z==14 || z==16 || z==20 || z==25 || z==26))))
        return 1.;
    // Same reserved edge neighborhoods as the independent R6000 union mesh.
    const double edges[]={.249865,.999466,.999907,1.807139};
    for(double edge:edges)if(fabs(line/edge-1.)<=2./6000.)return 1.;
    if(line>=1.0007 && line<=1.0013)return 1.;
    ASSERT(rfield.nShape==1 && rfield.lgBeamed[0] && !rfield.lgTimeVary[0]);
    static std::unordered_map<const void*,double> cache;
    const void* key=&t.Emis().Aul();
    auto found=cache.find(key);
    if(found!=cache.end())return found->second;
    const double cell=rfield.anu(t.ipCont()-1);
    const long old_spec=rfield.ipSpec;
    const double cell_photons=ffun(cell), line_photons=ffun(line);
    rfield.ipSpec=old_spec;
    // ffun is photons per dE; occupation is proportional to ffun/E^2.
    // Do not cache before the incident normalization has been initialized.
    if(cell_photons<=0.)return 1.;
    const double ratio=(line_photons/cell_photons)*POW2(cell/line);
    ASSERT(ratio>=0. && std::isfinite(ratio));
    cache[key]=ratio;
    return ratio;
}

'''
assert updated.count(anchor)==1
updated=updated.replace(anchor,helper+anchor)
old='rfield.OccNumbIncidCont[t.ipCont()-1] + rfield.OccNumbContEmitOut[t.ipCont()-1] );'
new='rfield.OccNumbIncidCont[t.ipCont()-1]*exact_atomic_sulfur_incident_line_ratio(t) + rfield.OccNumbContEmitOut[t.ipCont()-1] );'
assert updated.count(old)==1
updated=updated.replace(old,new)
p=root/'rt_line_one_exact_atomic_sulfur_incident.cpp';p.write_text(updated)
patch=root/'exact_atomic_sulfur_incident_pump.patch';patch.write_text(''.join(difflib.unified_diff(original.splitlines(True),updated.splitlines(True),fromfile='C23.01/rt_line_one.cpp',tofile='numerical-prototype/rt_line_one.cpp')))
flags=['g++','-std=c++11','-O2','-fno-pie','-I'+str(source),'-DSYS_CONFIG="'+str(source/'cloudyconfig.h')+'"']
subprocess.run(flags+['-c',str(p),'-o',str(root/'rt_line_one_exact_atomic_sulfur_incident.o')],check=True)
for suffix,extra in [('',[]),('_dlaw025',[root/'radius_next.o'])]:
 binary=root/('cloudy_exact_atomic_sulfur_incident'+suffix+'.exe')
 subprocess.run(['g++','-no-pie','-o',str(binary),str(source/'maincl.o'),str(root/'cont_ffun.o'),str(root/'rt_line_one_exact_atomic_sulfur_incident.o'),*[str(root/(n+'_precision.o')) for n in ['save_special','save_do','heat_save']],*map(str,extra),str(source/'libcloudy.a')],check=True)
files=[p,patch,root/'cloudy_exact_atomic_sulfur_incident.exe',root/'cloudy_exact_atomic_sulfur_incident_dlaw025.exe']
(root/'exact_atomic_sulfur_incident_pump_provenance.json').write_text(json.dumps({'status':'Experimental numerical approximation; must agree with the independent fully line-centered mesh before use.', 'changed':'Only incident occupation in line pumping; exact source at line center / original source at cell center, with occupation E^-2 conversion. Cell continuum attenuation, diffuse occupation, shielding, rate data and all guards unchanged.', 'scope':'One constant beam, declared H/He + selected metal stages including S,0.016..1.83Ryd excluding reserved major-edge neighborhoods, same as R6000 union mesh.', 'hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}},indent=2)+'\n')
print('Built experimental exact-incident interpolation; validation required.')
