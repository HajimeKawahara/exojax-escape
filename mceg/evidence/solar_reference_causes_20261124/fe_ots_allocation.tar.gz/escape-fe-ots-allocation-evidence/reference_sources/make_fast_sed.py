"""Replace only C23's tabulated-SED interval search; preserve interpolation."""
from pathlib import Path
from hashlib import sha256
import subprocess,json,difflib
source=Path('/tmp/cloudy-reference-run/c23.01/source')
root=Path('/tmp/cloudy-continuum-convergence-continuation/diagnostic')
original=(source/'cont_ffun.cpp').read_text()
anchor='\t\t\tfor( i=1; i < rfield.ncont[rfield.ipSpec]; ++i )'
assert original.count(anchor)==1
replacement='''            // Numerical acceleration only: same first i with tNu[i] > xnu.
            // Endpoints, ties, extrapolation and interpolation below are unchanged.
            long left=1, right=rfield.ncont[rfield.ipSpec];
            while (left<right) {
                const long middle=left+(right-left)/2;
                if (xnu<rfield.tNu[rfield.ipSpec][middle].Ryd()) right=middle;
                else left=middle+1;
            }
            for( i=left; i < rfield.ncont[rfield.ipSpec]; ++i )'''
modified=original.replace(anchor,replacement)
(root/'cont_ffun.cpp').write_text(modified)
(root/'sed_search.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),modified.splitlines(True),fromfile='C23.01/cont_ffun.cpp',tofile='fast-search/cont_ffun.cpp')))
flags=['g++','-std=c++11','-O3','-fno-pie','-I'+str(source),'-DSYS_CONFIG="'+str(source/'cloudyconfig.h')+'"']
subprocess.run(flags+['-c',str(root/'cont_ffun.cpp'),'-o',str(root/'cont_ffun.o')],check=True)
for name,extra in [('cloudy_fast.exe',[]),('cloudy_fast_pump.exe',['prt_lines_general.o']),('cloudy_fast_dlaw025.exe',['radius_next.o'])]:
 subprocess.run(['g++','-no-pie','-o',str(root/name),str(source/'maincl.o'),str(root/'cont_ffun.o'),*[str(root/item) for item in extra],str(source/'libcloudy.a')],check=True)
paths=[source/'libcloudy.a',source/'cont_ffun.cpp',root/'cont_ffun.cpp',root/'sed_search.patch',*root.glob('cloudy_fast*.exe')]
(root/'fast_sed_provenance.json').write_text(json.dumps({'scope':'Same strict greater-than interval, same interpolation arithmetic, same data and physics; independent interval and full-output checks required.','source_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in paths}},indent=2)+'\n')
print('Built binary-search-only C23 and the separate diagnostic/spatial combinations.')
