"""Increase C23 reporting precision without changing state, rates, or iteration."""
from hashlib import sha256
from pathlib import Path
import difflib
import json
import re
import subprocess

source = Path('/tmp/cloudy-reference-run/c23.01/source')
root = Path('/tmp/cloudy-continuum-convergence-continuation/diagnostic')
names = ('save_special', 'save_do', 'heat_save')
patch = ''
counts = {}
flags = ['g++', '-std=c++11', '-O2', '-fno-pie', '-I'+str(source),
         '-DSYS_CONFIG="'+str(source/'cloudyconfig.h')+'"']
for name in names:
    original = (source/(name+'.cpp')).read_text()
    improved, count = re.subn(r'%\.([2-6])e', '%.12e', original)
    counts[name] = count
    assert count
    path = root/(name+'_precision.cpp')
    path.write_text(improved)
    patch += ''.join(difflib.unified_diff(original.splitlines(True), improved.splitlines(True),
                         fromfile='C23.01/'+name+'.cpp', tofile='reporting-only/'+name+'.cpp'))
    subprocess.run(flags+['-c', str(path), '-o', str(root/(name+'_precision.o'))], check=True)
(root/'reporting_precision.patch').write_text(patch)
for suffix, extra in [('', []), ('_dlaw025', [root/'radius_next.o'])]:
    binary = root/('cloudy_precision'+suffix+'.exe')
    subprocess.run(['g++', '-no-pie', '-o', str(binary), str(source/'maincl.o'),
                    str(root/'cont_ffun.o'), *[str(root/(n+'_precision.o')) for n in names],
                    *map(str, extra), str(source/'libcloudy.a')], check=True)
files = [source/(name+'.cpp') for name in names]+[root/'reporting_precision.patch',
         root/'cloudy_precision.exe', root/'cloudy_precision_dlaw025.exe', root/'cont_ffun.o']
(root/'reporting_precision_provenance.json').write_text(json.dumps({
    'scope': 'Only printf scientific-number formatting changes from 3-7 significant figures to 13; physical state and solver unchanged.',
    'replacement_counts': counts, 'lookup_patch': 'sed_search.patch; interval equivalence separately verified',
    'hashes': {str(p):sha256(p.read_bytes()).hexdigest() for p in files}}, indent=2)+'\n')
print(counts)
