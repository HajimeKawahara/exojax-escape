"""Build reporting-only and spatial-refinement C23 controls outside its source tree."""
from hashlib import sha256
from pathlib import Path
import difflib
import json
import subprocess

source=Path('/tmp/cloudy-reference-run/c23.01/source')
root=Path('/tmp/cloudy-continuum-convergence-continuation/diagnostic')
text=(Path('/tmp/cloudy-metal-diagnostic/prt_lines_general.cpp')).read_text()
text=text.replace('fabs(rplanet-1.1)<.025 || fabs(rplanet-1.3)<.025 || fabs(rplanet-1.8)<.025',
                  'fabs(rplanet-1.1)<.003 || fabs(rplanet-1.3)<.003 || fabs(rplanet-1.8)<.012')
anchor='''                        const bool real = tr->ipCont()>0;
                        fprintf(ioQQQ,"METAL_LINE'''
replacement='''                        const bool real = tr->ipCont()>0;
                        if (real) {
                            const long ci=tr->ipCont()-1;
                            fprintf(ioQQQ,"PUMP_SAMPLE %.12e %s %d %d %.12e %ld %.12e %.12e %.12e %.12e %.12e %.12e %.12e\\n",
                                radius.depth_mid_zone,dBaseSpecies[ipSpecies].chLabel,tr->ipLo(),tr->ipHi(),
                                tr->EnergyRyd(),ci,rfield.anu(ci),rfield.widflx(ci),
                                rfield.OccNumbIncidCont[ci],rfield.OccNumbContEmitOut[ci],
                                tr->Emis().pump(),tr->Coll().heat(),tr->Coll().cool());
                        }
                        fprintf(ioQQQ,"METAL_LINE'''
assert text.count(anchor)==1
text=text.replace(anchor,replacement)
(root/'prt_lines_general.cpp').write_text(text)
original=(source/'radius_next.cpp').read_text()
anchor='drTab = radius.drad*MAX2(0.2,0.10/MAX2(0.01,drTab));'
assert original.count(anchor)==1
refined=original.replace(anchor,'drTab = radius.drad*MAX2(0.2,0.025/MAX2(0.01,drTab));')
(root/'radius_next.cpp').write_text(refined)
(root/'spatial_refinement.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),refined.splitlines(True),fromfile='C23.01/radius_next.cpp',tofile='numerical-control/radius_next.cpp')))
flags=['g++','-std=c++11','-O2','-fno-pie','-I'+str(source),'-DSYS_CONFIG="'+str(source/'cloudyconfig.h')+'"']
for name in ('prt_lines_general','radius_next'):
 subprocess.run(flags+['-c',str(root/(name+'.cpp')),'-o',str(root/(name+'.o'))],check=True)
for name,objects in [('cloudy_pump_diagnostic.exe',['prt_lines_general.o']),('cloudy_dlaw025.exe',['radius_next.o'])]:
 subprocess.run(['g++','-no-pie','-o',str(root/name),str(source/'maincl.o'),*[str(root/x) for x in objects],str(source/'libcloudy.a')],check=True)
meta={'physical_rates_unchanged':True,'incident_spectrum_unchanged':True,'guards_unchanged':True,
      'spatial_change':'DLAW maximum relative density step10% ->2.5%; only radius_next.cpp numerical step selector changes.',
      'reporting_change':'Print selected-zone metal collisional heating and the actual continuum sample used by pumping; no coefficient changes.',
      'hashes':{str(p):sha256(p.read_bytes()).hexdigest() for p in [source/'libcloudy.a',source/'radius_next.cpp',source/'prt_lines_general.cpp',*root.glob('*.exe'),*root.glob('*.cpp')]}}
(root/'provenance.json').write_text(json.dumps(meta,indent=2)+'\n')
print('Built independent C23 diagnostics and spatial refinement.')
