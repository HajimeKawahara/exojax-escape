"""Compare completed columns on a declared shared input grid, without extrapolation."""
from pathlib import Path
from hashlib import sha256
import argparse,json
import numpy as np
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('coarse',type=Path);p.add_argument('fine',type=Path)
p.add_argument('grid',type=Path);p.add_argument('output',type=Path)
p.add_argument('--relative-budget',type=float,default=.01)
a=p.parse_args()
x,y,g=[dict(np.load(path)) for path in [a.coarse,a.fine,a.grid]]
r=g['radius_cm']
fields=['n2_cm3','n3_cm3','temperature_k','mean_molecular_weight','heating_erg_cm3_s','cooling_erg_cm3_s']
def interp(data,key):return np.interp(r,data['radius_cm'],data[key])
inside=(r>=max(x['radius_cm'][0],y['radius_cm'][0]))&(r<=min(x['radius_cm'][-1],y['radius_cm'][-1]))
mask=inside.copy()
for d in [x,y]:mask&=(interp(d,'gas_pressure_dyn_cm2')<=1000)&(interp(d,'n_h_cm3')<=1e15)
if not mask.any():raise ValueError('No common valid atmospheric grid points.')
values={}
for key in fields:
 coarse,fine=interp(x,key)[mask],interp(y,key)[mask]
 if np.any(fine<=0) or not np.all(np.isfinite(fine)) or not np.all(np.isfinite(coarse)):raise ValueError(key)
 err=abs(coarse/fine-1)
 values[key]={'coarse':coarse.tolist(),'fine':fine.tolist(),'relative_error':err.tolist(),'max_relative_error':float(err.max()),'max_error_radius_cm':float(r[mask][err.argmax()]),'within_budget':bool(np.all(err<=a.relative_budget))}
coarse=(interp(x,'electron_cm3')/interp(x,'n_h_cm3'))[mask]
fine=(interp(y,'electron_cm3')/interp(y,'n_h_cm3'))[mask];err=abs(coarse/fine-1)
values['electron_fraction']={'coarse':coarse.tolist(),'fine':fine.tolist(),'relative_error':err.tolist(),'max_relative_error':float(err.max()),'max_error_radius_cm':float(r[mask][err.argmax()]),'within_budget':bool(np.all(err<=a.relative_budget))}
report={'scope':'Fixed-profile reference refinement at all common input-grid centers inside both raw zone-center ranges, with both P<=1e-3 bar and nH<=1e15. Linear r interpolation, no extrapolation or tiny-ion floor. This is not a thermal/wind fixed-point certificate.','normalization':'abs(coarse/fine - 1), separately for each named positive quantity','relative_budget':a.relative_budget,'shared_input_radius_cm':r.tolist(),'comparison_mask':mask.tolist(),'comparison_radius_cm':r[mask].tolist(),'excluded_endpoint_or_dense_count':int((~mask).sum()),'quantities':values,'prescribed_velocity_not_independently_solved':True,'all_named_profiles_within_budget':all(v['within_budget'] for v in values.values()),'sha256':{str(path):sha256(path.read_bytes()).hexdigest() for path in [a.coarse,a.fine,a.grid,Path(__file__)]}}
a.output.write_text(json.dumps(report,indent=2)+'\n')
print({key:v['max_relative_error'] for key,v in values.items()})
