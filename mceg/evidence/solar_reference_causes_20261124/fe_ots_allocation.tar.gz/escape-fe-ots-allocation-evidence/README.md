# Fe/Ly-alpha source allocation in C23.01

These are completed **finite three-column, fixed-temperature/density** controls, not converged thermal atmospheres or a certified precision reference. The original and tracking-only binaries have byte-identical inputs and saved physical outputs. The altered variant retains H's total Ly-alpha destruction probability and Fe excitation but excludes the historically added Fe Pdest contribution from the generic continuum OTS field. It records the actual float addition, rather than subtracting a newly evaluated Fe rate. All other selected reference settings are identical.

## What is established

`tracking_identity.json` validates the instrumentation. `ledger_*.json` and the complete local `fe_ots_ledger.tsv` record H Ly-alpha destruction, the historical Fe allocation and the generic continuum allocation. This is a **local destruction-allocation identity**. It is not all-frequency photon-number conservation: Fe fluorescence cascades can change photon number. Float32 OTS-bin rounding and the time lag between rate calls are explicitly retained.

`channel_comparison.json` identifies changes using the same C23 heating/cooling grouping in both cases. Do not compare these net-grouped totals directly with a native sum of positive directional rates. `profile_comparison.json` describes the third completed column; the successive-column files separately quantify the still unresolved numerical iteration dependence. `reference_convergence_receipt.json` retains every reported local failure, including the exclusion run's iteration-3 zone-728 electron-change failure; exit code 0 does not certify local convergence. The intermediate completed-column direct H receiver reconstruction is a rejected main-cause hypothesis, not omitted evidence.

The input uses FeII716, SII72, default C23 H25, full default solar chemistry, the same exact-atomic incident PHX sampler, prescribed profiles, local1e-4 tolerance and 2.5% density zoning. An attempted stop-zone preflight follows a blank line and is ignored by C23 input termination; all three unchanged inputs therefore execute the full original three-column calculation. `input_receipt.json` documents that discovery. No result here relies on treating those runs as one-zone tests.

## Observation comparison

`observer_comparison.json` reports the difference between the two supplied profiles through the same observer, frozen at escape commit d9bce04ccd872a83c8db6cfb9795bb0a5b1f0173. This is a conditional spectrum comparison, not a fit or a self-consistent thermal response. It uses the measured 143-exposure cadence but approximate nightly-master weights, masks and phase combination; the exact published reduction is not recovered. The observer uses LTE trace H-minus rather than the actual C23 chemical H-minus abundance. The saved chemical abundance contrast remains separately available. The supplied uncertainty is used without claiming its confidence convention is independently established.

Only derived atmosphere/spectrum arrays are included. The public NPZ deliberately omits `stellar_reference`; no original PHX SED/FITS or full stellar-flux array is redistributed. The private boundary file is identified by hash in the input/provenance receipts. The Zenodo observational credit/license is retained; its original notice describes the earlier simple example, while the processing used in this archive is specified above and in the observer provenance.

## Replay

Obtain C23.01 and build the pinned original sources/library. The source/binary/object hashes and exact link commands are in `build_receipt.json`; the modified incident-sampler, precision and density-zoning sources/recipes are under `reference_sources/`. Apply the supplied Fe tracking patch and compile the same source with the allocation switch OFF and ON as recorded. Original Cloudy source credit and license are retained. Binaries/objects are excluded.

Use the archived identical input/profile/continuum-mesh files and obtain the separately identified PHX incident file. Run each case with the receipt's `-r model` command. Historical scripts contain local paths that must be adjusted. Raw saved histories allow every completed column and the local event summaries to be regenerated with the included extractors/summarizers. Compare the original and OFF saved physical tables before interpreting the ON contrast. The frozen escape commit and included cadence/high-n fixtures reproduce the conditional observer once the same private stellar boundary is provided.

The native Fe helper, Ca receiver-closure correction, all-atmosphere numerical convergence, thermal/wind feedback, and equivalence to the author's exact model are separate claims. This control does not certify them or prescribe altering an external reference merely to agree with the native implementation.
