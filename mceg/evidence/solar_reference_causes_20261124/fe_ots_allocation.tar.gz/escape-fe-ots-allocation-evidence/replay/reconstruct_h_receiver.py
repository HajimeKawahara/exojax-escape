"""Reconstruct only the H-Lya OTS component of H excited BF energy exchange.

The saved-zone populations and last OTS call need not be simultaneous. This is
an attribution diagnostic, not a substitute for actual C23 channel readouts.
"""
from pathlib import Path
import argparse,json,hashlib,numpy as np
p=argparse.ArgumentParser();p.add_argument('--iteration',type=int,default=1);p.add_argument('--output',type=Path,required=True);a=p.parse_args();root=Path(__file__).parent
cross=np.loadtxt(root/'lya_h_cross_sections_all.txt');assert cross.shape==(69,7)
n,ell,g,ev,threshold,sigma,analytic=cross.T
h=6.62607015e-27;kb=1.380649e-16;me=9.1093837015e-28;erg_ev=1.602176634e-12
case_results={};source_hashes={}
for case in ['smoke_tracking','exclude']:
 directory=root/case;derived=directory/'derived'/f'iteration_{a.iteration:03d}'
 levels=np.loadtxt(derived/'model.levels');conditions=np.loadtxt(derived/'model.conditions');raw=dict(np.load(derived/'cloudy_profiles.npz'))
 rows={}
 for line in (directory/'fe_ots_ledger.tsv').read_text().splitlines():
  if line.startswith('#'):continue
  try:row=np.array([float(x) for x in line.split()])
  except ValueError:continue
  if len(row)==16 and row[0]==a.iteration and row[1]>0:rows[int(row[1])]=row
 if set(range(1,len(levels)+1))-rows.keys():raise ValueError('Missing completed-zone OTS rows')
 ledger=np.stack([rows[i] for i in range(1,len(levels)+1)])
 population=levels[:,2:71];assert population.shape[1]==len(n)
 # Conditions columns: depth,T,nH,ne,H0,H+,other excited/molecular summaries.
 temp,ne,proton=conditions[:,1],conditions[:,3],conditions[:,2]*conditions[:,5]
 flux=ledger[:,13]/ledger[:,14]
 saha=(h*h/(2*np.pi*me*kb*temp))**1.5
 stimulated_population=(ne*proton*saha)[:,None]*(g/2)*np.exp((threshold-ev)[None,:]*erg_ev/(kb*temp[:,None]))
 energy=(ev-threshold)*erg_ev
 heat=flux[:,None]*population*sigma[None,:]*energy[None,:]
 cool=flux[:,None]*stimulated_population*sigma[None,:]*energy[None,:]
 net=(heat-cool).sum(axis=1)
 r=3-levels[:,0]/1.358348e10
 saved_n2p=levels[:,3]; mismatch=abs(saved_n2p/ledger[:,6]-1)
 samples=[]
 for target in [1.1,1.3,1.8,2.5]:
  sample=lambda v:float(np.interp(target,r[::-1],v[::-1]))
  samples.append({'radius_Rp':target,'gross_photoelectron_heat':sample(heat.sum(1)),'induced_recombination_cooling':sample(cool.sum(1)),'net_kinetic_heat_from_H_Lya_OTS':sample(net),'n2_net':sample((heat-cool)[:,n==2].sum(1)),'n3_net':sample((heat-cool)[:,n==3].sum(1)),'higher_n_net':sample((heat-cool)[:,n>3].sum(1)),'total_kinetic_heat':float(np.interp(target*1.358348e10,raw['radius_cm'],raw['heating_erg_cm3_s']-raw['cooling_erg_cm3_s']))})
 case_results[case]={'max_saved_vs_last_OTS_n2p_relative_difference':float(mismatch.max()),'samples':samples}
 for f in ['model.levels','model.conditions','cloudy_profiles.npz']:
  path=derived/f;source_hashes[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
comparison=[]
for x,y in zip(case_results['smoke_tracking']['samples'],case_results['exclude']['samples']):
 delta=y['total_kinetic_heat']-x['total_kinetic_heat'];reconstructed=y['net_kinetic_heat_from_H_Lya_OTS']-x['net_kinetic_heat_from_H_Lya_OTS']
 comparison.append({'radius_Rp':x['radius_Rp'],'measured_delta_total_Q':delta,'reconstructed_delta_H_Lya_excited_BF_Q':reconstructed,'reconstructed_over_measured':reconstructed/delta if delta else None})
report={'scope':'Conditional attribution at completed column '+str(a.iteration)+'. Original C23 H_photo_cs is evaluated at the NIST H-Lya center and harmonic reduced-mass thresholds, not the exact continuum-bin mean or fine-structure thresholds. Saved final populations can lag the OTS-call state; that discrepancy is reported. This estimates the directly assigned H-Lya OTS contribution only, not all radiation or an independent conservation certificate.','units':'erg cm^-3 s^-1; positive net heats the gas','photo_formula':'sum Phi_Lya * sigma_nl * n_nl * (Egamma-IP_nl)','induced_formula':'sum Phi_Lya * sigma_nl * ne*np*(g_nl/2)*lambda_e^3*exp((IP_nl-Egamma)/(kT))*(Egamma-IP_nl)','cross_section_table_vs_analytic_max_relative':float(np.max(abs(sigma/analytic-1))),'cases':case_results,'comparison':comparison,'source_sha256':source_hashes}
for path in [Path(__file__),root/'lya_h_cross_sections.cpp',root/'lya_h_cross_sections_all.txt',Path('/tmp/cloudy-reference-run/c23.01/source/hydro_bauman.cpp'),Path('/tmp/cloudy-reference-run/c23.01/source/libcloudy.a')]:report['source_sha256'][str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(comparison))
