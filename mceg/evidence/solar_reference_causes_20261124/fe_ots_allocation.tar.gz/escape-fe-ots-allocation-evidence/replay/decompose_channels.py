"""Compare like-defined C23 heating/cooling channels at fixed radii."""
from pathlib import Path
import argparse,json,hashlib,numpy as np
p=argparse.ArgumentParser();p.add_argument('original',type=Path);p.add_argument('excluded',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
RP=1.358348e10
def channel_table(path, total_index):
 rows=[]; labels=set()
 for line in path.read_text().splitlines():
  fields=line.split('\t')
  try:numeric=list(map(float,fields[:5]))
  except ValueError:continue
  if len(numeric)!=5:continue
  channels={}
  for i in range(5,len(fields)-1,2):
   try:fraction=float(fields[i+1])
   except ValueError:continue
   label=' '.join(fields[i].split());channels[label]=channels.get(label,0)+fraction*numeric[total_index];labels.add(label)
  rows.append((numeric,channels))
 if not rows:raise ValueError(f'No complete channel rows: {path}')
 depth=np.array([r[0][0] for r in rows]);assert np.all(np.diff(depth)>0)
 total=np.array([r[0][total_index] for r in rows])
 rates={label:np.array([r[1].get(label,0.) for r in rows]) for label in sorted(labels)}
 rates['__unprinted_residual__']=total-sum(rates.values())
 return depth,total,rates
def numeric_table(path,n):
 rows=[]
 for line in path.read_text().splitlines():
  try:row=list(map(float,line.split()[:n]))
  except ValueError:continue
  if len(row)==n:rows.append(row)
 return np.array(rows)
tables={}
for name,directory in [('original',a.original),('excluded',a.excluded)]:
 tables[name]={'heating':channel_table(directory/'model.heating',2),'cooling':channel_table(directory/'model.cooling',3),'overview':numeric_table(directory/'model.overview',22),'conditions':numeric_table(directory/'model.conditions',10)}
records=[]
for radius in [1.1,1.3,1.8,2.5]:
 depth=(3-radius)*RP;record={'radius_Rp':radius,'cases':{}}
 for name,data in tables.items():
  state={}
  for kind in ['heating','cooling']:
   x,total,channels=data[kind]
   if not x[0]<=depth<=x[-1]:raise ValueError('No radial extrapolation permitted')
   state[kind+'_erg_cm3_s']=float(np.interp(depth,x,total))
   state[kind+'_listed_channels']={key:float(np.interp(depth,x,value)) for key,value in channels.items()}
  state['net_kinetic_heat_erg_cm3_s']=state['heating_erg_cm3_s']-state['cooling_erg_cm3_s']
  v=data['overview']; c=data['conditions']
  columns={'temperature_k':1,'n_h_cm3':3,'electron_cm3':4,'2H2_over_H':5,'H0_fraction':6,'Hplus_fraction':7,'He0_fraction':8,'Heplus_fraction':9,'He2plus_fraction':10,'C0_fraction':12,'Cplus_fraction':13,'C2plus_fraction':14,'C3plus_fraction':15,'O0_fraction':16,'Oplus_fraction':17,'O2plus_fraction':18,'O3plus_fraction':19,'O4plus_fraction':20,'O5plus_fraction':21}
  state['saved_state']={key:float(np.interp(depth,v[:,0],v[:,col])) for key,col in columns.items()}
  state['saved_state']['Hminus_fraction']=float(np.interp(depth,c[:,0],c[:,9]))
  record['cases'][name]=state
 old,new=record['cases']['original'],record['cases']['excluded']
 record['delta_net_kinetic_heat_erg_cm3_s']=new['net_kinetic_heat_erg_cm3_s']-old['net_kinetic_heat_erg_cm3_s']
 record['delta_net_heat_over_original_max_heating_cooling']=record['delta_net_kinetic_heat_erg_cm3_s']/max(old['heating_erg_cm3_s'],old['cooling_erg_cm3_s'])
 for kind in ['heating','cooling']:
  x,y=old[kind+'_listed_channels'],new[kind+'_listed_channels']
  labels=x.keys()|y.keys(); changes=[{'channel':k,'original':x.get(k,0.),'excluded':y.get(k,0.),'delta':y.get(k,0.)-x.get(k,0.)} for k in sorted(labels)]
  record[kind+'_channel_changes']=sorted(changes,key=lambda item:(-abs(item['delta']),item['channel']))
 records.append(record)
report={'scope':'Same C23 grouping in both cases. Individual signed species terms are grouped by C23 before positive total heating/cooling are formed. Do not compare these totals directly with native gross directional sums. Temperature/density/wind are prescribed; none of the column histories is an accepted thermal atmosphere.','channel_precision':'Printed channel fractions are seven decimal places and the saved cooling totals have approximately five significant digits. Channels below the print threshold are not zero: their summed unprinted residual is retained.','Ca_Fe_ion_fraction_limit':'The original input does not save local Ca/Fe stage fractions; their values are not inferred from cooling-channel changes.','samples':records,'input_sha256':{str(d/f):hashlib.sha256((d/f).read_bytes()).hexdigest() for d in [a.original,a.excluded] for f in ['model.heating','model.cooling','model.overview','model.conditions']},'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
a.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps([{'radius':r['radius_Rp'],'largest_cooling_changes':r['cooling_channel_changes'][:3]} for r in records]))
