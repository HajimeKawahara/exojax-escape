"""Separate successful process exit, completed columns and local convergence."""
from pathlib import Path
import json,re,hashlib
root=Path(__file__).parent;records={}
for case in ['smoke_original','smoke_tracking','exclude']:
 path=root/case/'model.out';text=path.read_text(errors='replace');receipt=json.loads((root/case/'execution_receipt.json').read_text())
 ends=[line.strip() for line in text.splitlines() if 'Cloudy ends:' in line]
 assert len(ends)==1 and receipt['returncode']==0
 match=re.search(r'Failures: (\d+) thermal, (\d+) pressure, (\d+) ionization, (\d+) electron density',ends[0]);assert match
 counts=dict(zip(['thermal','pressure','ionization','electron_density'],map(int,match.groups())))
 records[case]={'execution':receipt,'final_summary':ends[0],'local_failure_counts':counts,'all_local_checks_passed':not any(counts.values()),'failure_lines':[line.strip() for line in text.splitlines() if 'PROBLEM  ConvFail' in line],'raw_output_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
report={'scope':'Completed finite-column control only. Exit code 0 does not imply local convergence or convergence of the global column iteration; any local failures are retained here, and successive-column profile differences are reported separately. No thermal root is solved because temperature/density are prescribed.','cases':records}
(root/'reference_convergence_receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({name:row['local_failure_counts'] for name,row in records.items()}))
