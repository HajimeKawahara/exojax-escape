// Diagnostic calls into unmodified Cloudy C23.01. Original functions are
// copyright 1978-2023 Gary J. Ferland and others; see Cloudy license.txt.
#include "cddefines.h"
#include "cddrive.h"
#include <iostream>
#include <iomanip>
extern double H_photo_cs(double,long,long,long);
extern double H_photo_cs_log10(double,long,long,long);
int main(){
 cdInit(); std::cout<<std::setprecision(17);
 const double energy_ev=6.62607015e-27*2.99792458e10*82259.158/1.602176634e-12;
 for(long n=2;n<=25;++n){
  double threshold_ev=13.5984345/(n*n),relative=energy_ev/threshold_ev;
  if(n<=10){
   for(long l=0;l<n;++l)
    std::cout<<n<<" "<<l<<" "<<2*(2*l+1)<<" "<<energy_ev<<" "<<threshold_ev<<" "<<H_photo_cs(relative,n,l,1)<<" "<<H_photo_cs_log10(relative,n,l,1)<<"\n";
  }else{
   double tab=0.,analytic=0.;
   for(long l=0;l<n;++l){
    double fraction=(2.*l+1.)/(n*n);
    tab+=fraction*H_photo_cs(relative,n,l,1);
    analytic+=fraction*H_photo_cs_log10(relative,n,l,1);
   }
   std::cout<<n<<" -1 "<<2*n*n<<" "<<energy_ev<<" "<<threshold_ev<<" "<<tab<<" "<<analytic<<"\n";
  }
 }
}
