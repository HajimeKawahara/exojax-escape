"""Analyze completed controls only; retain the reference's unresolved scope."""
from pathlib import Path
import json,subprocess,sys,os,hashlib,numpy as np
root=Path(__file__).parent
cases=['smoke_original','smoke_tracking','exclude']
for name in cases:
 receipt=json.loads((root/name/'execution_receipt.json').read_text())
 if receipt['returncode']!=0:raise RuntimeError(f'{name}: incomplete/failed execution')
subprocess.run([sys.executable,str(root/'convergence_receipt.py')],check=True)
subprocess.run([sys.executable,str(root/'compare_tracking.py'),str(root/'smoke_original'),str(root/'smoke_tracking'),'--output',str(root/'tracking_identity.json')],check=True)
parser=Path('/tmp/cloudy-continuum-convergence-continuation/extract_iteration_history.py')
compare=parser.with_name('compare_reference_profiles.py')
for case in ['smoke_tracking','exclude']:
 subprocess.run([sys.executable,str(parser),str(root/case)],check=True)
 subprocess.run([sys.executable,str(root/'summarize_ledger.py'),str(root/case),'--output',str(root/('ledger_'+case+'.json'))],check=True)
a,b=[root/c/'derived' for c in ['smoke_tracking','exclude']]
common=set(p.name for p in a.glob('iteration_*'))&set(p.name for p in b.glob('iteration_*'))
if not common:raise RuntimeError('No completed shared column')
iteration=max(common)
subprocess.run([sys.executable,str(compare),str(a/iteration/'cloudy_profiles.npz'),str(b/iteration/'cloudy_profiles.npz'),str(root/'exclude/input_profiles.npz'),str(root/'profile_comparison.json')],check=True)
subprocess.run([sys.executable,str(root/'decompose_channels.py'),str(root/'smoke_tracking'),str(root/'exclude'),'--output',str(root/'channel_comparison.json')],check=True)
# Keep successive-column errors next to the allocation contrast.
for case,d in [('tracking',a),('exclude',b)]:
 names=sorted(p.name for p in d.glob('iteration_*'))
 if len(names)>1:
  subprocess.run([sys.executable,str(compare),str(d/names[-2]/'cloudy_profiles.npz'),str(d/names[-1]/'cloudy_profiles.npz'),str(root/'exclude/input_profiles.npz'),str(root/(case+'_successive_column_difference.json'))],check=True)
repo=Path('/tmp/escape-fe-ots-observer-source'); observer=repo/'examples/cloudy_halpha.py';output=root/'observer'
command=[sys.executable,str(observer),'--case','Original OTS allocation',str(a/iteration/'profiles.npz'),str(a/iteration/'receipt.json'),'--case','Fe overlap excluded from generic OTS',str(b/iteration/'profiles.npz'),str(b/iteration/'receipt.json'),'--cadence','/tmp/escape-observation-processing/cadence_weights.npz','--stellar-surface','/tmp/escape-stellar-sed-data/phoenix10000_surface_flux.npz','--high-n-cross-sections','/tmp/escape-completed-reference-publication/observer_inputs/high_n/halpha_n20_25.npz','--raw-cloudy-profiles','--output',str(output)]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',JAX_PLATFORMS='cpu',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',NUMBA_CACHE_DIR='/tmp/escape-numba-cache',MPLCONFIGDIR='/tmp/escape-matplotlib',PYTHONPATH=str(repo/'src')+':/tmp/exojax-spectrum-upstream/src:'+str(repo/'examples'))
with (root/'observer.log').open('w') as log:
 subprocess.run(['taskset','-c','55',*command],env=env,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
z=dict(np.load(output/'derived_profiles_spectra.npz'));dv=z['case1_processed_contrast']-z['case0_processed_contrast']
scaled=np.interp(z['observed_velocity_kms'],z['output_velocity_kms'],dv)/z['observed_error']
report={'scope':'Conditional fixed-temperature/density allocation contrast using an approximate observation operator. No converged thermal/wind or precision-reference claim.','selected_column':iteration,'maximum_difference_ppm':float(np.max(abs(dv))*1e6),'maximum_difference_over_supplied_observation_error':float(np.max(abs(scaled))),'rms_difference_over_supplied_observation_error':float(np.sqrt(np.mean(scaled**2))),'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),parser,compare,observer]},'original_observer_provenance':str(output/'provenance.json')}
(root/'observer_comparison.json').write_text(json.dumps(report,indent=2)+'\n')
# Derived export intentionally omits all stellar-reference spectral arrays.
kept={k:v for k,v in z.items() if k!='stellar_reference'}
assert not any('surface_flux' in k or k=='stellar_reference' for k in kept)
np.savez_compressed(output/'derived_profiles_spectra_public.npz',**kept)
(root/'public_npz_keys.json').write_text(json.dumps({k:{'shape':list(v.shape),'dtype':str(v.dtype)} for k,v in kept.items()},indent=2)+'\n')
print(json.dumps(report),flush=True)
