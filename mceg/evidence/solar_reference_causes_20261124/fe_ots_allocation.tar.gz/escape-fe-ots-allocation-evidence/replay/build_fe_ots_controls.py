"""Build matched C23 tracking and allocation-only controls; no runtime data copied."""
from pathlib import Path
import hashlib, json, difflib, subprocess
src=Path('/tmp/cloudy-reference-run/c23.01/source')
extra=Path('/tmp/cloudy-continuum-convergence-continuation/diagnostic')
out=Path('/tmp/cloudy-fe-ots-allocation'); out.mkdir(exist_ok=True)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
a=(src/'rt_line_all.cpp').read_text()
anchor='/*RT_line_all do escape and destruction probabilities for all lines in code. */\nvoid RT_line_all_escape'
assert a.count(anchor)==1
a=a.replace(anchor,'''// Diagnostic allocation ledger. Store the increment actually retained by the
// realnum Pdest addition, not the subsequently recomputed Fe rate.
double escape_fe_lya_added_pdest = 0.;

'''+anchor)
old='\t\tiso_sp[ipH_LIKE][ipHYDROGEN].trans(ipH2p,ipH1s).Emis().Pdest() += hydro.dstfe2lya;'
assert a.count(old)==1
a=a.replace(old,'''        const double before_fe = iso_sp[ipH_LIKE][ipHYDROGEN].trans(ipH2p,ipH1s).Emis().Pdest();
'''+old+'''
        escape_fe_lya_added_pdest =
            double(iso_sp[ipH_LIKE][ipHYDROGEN].trans(ipH2p,ipH1s).Emis().Pdest()) - before_fe;''')
# Case-B resets the destruction probability before the ordinary Fe addition.
old='\tif( opac.lgCaseB_no_pdest )\n\t{'
assert a.count(old)==1
a=a.replace(old,old+'\n        escape_fe_lya_added_pdest = 0.;')
# Exceptional no-population / below-plasma resets also erase the old contribution.
anchor='\tRT_line_all(RT_line_one_escape);'
assert a.count(anchor)==1
a=a.replace(anchor,anchor+'''
    const TransitionProxy hydrogen_lya = iso_sp[ipH_LIKE][ipHYDROGEN].trans(ipH2p,ipH1s);
    if (hydrogen_lya.Lo()->Pop() <= SMALLFLOAT ||
        hydrogen_lya.EnergyErg()/EN1RYD <= rfield.plsfrq)
        escape_fe_lya_added_pdest = 0.;''')
(out/'rt_line_all_tracking.cpp').write_text(a)
b=(src/'rt_ots.cpp').read_text()
b=b.replace('#include "cosmology.h"','#include "cosmology.h"\n#include "hydrogenic.h"\n#include "radius.h"\n#include "phycon.h"\nextern double escape_fe_lya_added_pdest;\n#ifndef ESCAPE_EXCLUDE_FE_OTS\n#define ESCAPE_EXCLUDE_FE_OTS 0\n#endif')
# Keep the baseline multiplication expression literally unchanged.
old='''						/* this signifies a fake line */'''
assert b.count(old)==1
b=b.replace(old,'''                        const bool hydrogen_lya_line = ipISO==ipH_LIKE && nelem==ipHYDROGEN && ipHi==ipH2p && ipLo==ipH1s;
                        const double old_pdest = iso_sp[ipISO][nelem].trans(ipHi,ipLo).Emis().Pdest();
                        const double removed_fe_pdest = hydrogen_lya_line ? escape_fe_lya_added_pdest*rfield.lgLyaOTS : 0.;
                        const double continuum_pdest = old_pdest-removed_fe_pdest;
                        const double allocated_pdest = ESCAPE_EXCLUDE_FE_OTS ? continuum_pdest : old_pdest;
                        if (hydrogen_lya_line)
                        {
                            // A negative result indicates a bookkeeping failure; do not clip it.
                            ASSERT(continuum_pdest >= 0.);
                            static FILE* ledger = open_data("fe_ots_ledger.tsv", "w");
                            ASSERT(ledger != NULL);
                            static bool first=true;
                            if (first) { fprintf(ledger,"# iteration zone depth_cm T_K ne_cm3 n1s_cm3 n2p_cm3 A_s Pdest_total Pdest_Fe_added Pdest_Fe_current Pdest_continuum original_photons_cm3_s allocated_photons_cm3_s opacity_cm1 excluded\\n"); first=false; }
                            const double photons = iso_sp[ipISO][nelem].trans(ipHi,ipLo).Emis().Aul()*iso_sp[ipISO][nelem].st[ipHi].Pop();
                            const long frequency_index=iso_sp[ipISO][nelem].trans(ipHi,ipLo).ipCont()-1;
                            fprintf(ledger,"%ld %ld %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %d\\n", iteration,nzone,radius.depth,phycon.te,dense.eden,iso_sp[ipISO][nelem].st[ipH1s].Pop(),iso_sp[ipISO][nelem].st[ipH2p].Pop(),double(iso_sp[ipISO][nelem].trans(ipHi,ipLo).Emis().Aul()),old_pdest,removed_fe_pdest,double(hydro.dstfe2lya),continuum_pdest,photons*old_pdest,photons*allocated_pdest,frequency_index>=0 ? double(opac.opacity_abs[frequency_index]) : 0.,ESCAPE_EXCLUDE_FE_OTS);
                        }
'''+old)
b=b.replace('iso_sp[ipISO][nelem].trans(ipHi,ipLo).Emis().Pdest()<= DEST0','allocated_pdest<= DEST0',1)
old='''							iso_sp[ipISO][nelem].trans(ipHi,ipLo).Emis().Pdest();'''
assert b.count(old)==1
b=b.replace(old,'''#if ESCAPE_EXCLUDE_FE_OTS
                            allocated_pdest;
#else
'''+old+'''
#endif''')
(out/'rt_ots_tracking.cpp').write_text(b)
flags=['g++','-std=c++11','-O2','-fno-pie','-I'+str(src),'-DSYS_CONFIG="'+str(src/'cloudyconfig.h')+'"']
cmds=[]
cmds.append(flags+['-c',str(out/'rt_line_all_tracking.cpp'),'-o',str(out/'rt_line_all_tracking.o')])
for variant,exclude in [('tracking',0),('exclude',1)]:
 cmds.append(flags+['-DESCAPE_EXCLUDE_FE_OTS='+str(exclude),'-c',str(out/'rt_ots_tracking.cpp'),'-o',str(out/('rt_ots_'+variant+'.o'))])
 cmds.append(['g++','-no-pie','-o',str(out/('cloudy_fe_ots_'+variant+'.exe')),str(src/'maincl.o'),str(extra/'cont_ffun.o'),str(extra/'rt_line_one_exact_atomic_sulfur_incident.o'),*[str(extra/(n+'_precision.o')) for n in ['save_special','save_do','heat_save']],str(extra/'radius_next.o'),str(out/'rt_line_all_tracking.o'),str(out/('rt_ots_'+variant+'.o')),str(src/'libcloudy.a')])
for cmd in cmds: subprocess.run(cmd,check=True)
for original,new in [('rt_line_all.cpp','rt_line_all_tracking.cpp'),('rt_ots.cpp','rt_ots_tracking.cpp')]:
 (out/(new+'.patch')).write_text(''.join(difflib.unified_diff((src/original).read_text().splitlines(True),(out/new).read_text().splitlines(True),fromfile='C23.01/'+original,tofile='allocation-control/'+new)))
inputs=[src/'rt_line_all.cpp',src/'rt_ots.cpp',src/'libcloudy.a',src/'maincl.o',extra/'cont_ffun.o',extra/'rt_line_one_exact_atomic_sulfur_incident.o',extra/'radius_next.o',*[extra/(n+'_precision.o') for n in ['save_special','save_do','heat_save']]]
report={'scope':'Two-function causal allocation experiment. Tracking baseline must reproduce original saved outputs before the exclusion experiment is interpreted. No thermal, spatial, or full-column convergence is implied.', 'difference':'Remove only the historically retained Fe addition from H Ly-alpha generic continuum OTS. H Pdest and Fe excitation rates are unchanged directly; their self-consistent response is allowed.', 'source_inputs':{str(p):sha(p) for p in inputs},'generated':{p.name:sha(p) for p in out.iterdir() if p.is_file()},'commands':cmds,'receivers':'Generic otslin feeds SummedCon/occ photon fields; direct CaII excited PI also reads the Ly-alpha otslin cell. No artificial receiver-specific rate changes.'}
(out/'build_receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'compiled':True,'binaries':{p.name:sha(p) for p in out.glob('*.exe')}}))
