"""Audit the H Ly-alpha destruction allocation, not an all-frequency photon budget."""
from pathlib import Path
import argparse,json,hashlib,numpy as np
p=argparse.ArgumentParser();p.add_argument('case',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
raw=(a.case/'fe_ots_ledger.tsv').read_bytes()
rows=[]
for line in raw.decode().splitlines():
 if line.startswith('#'):continue
 try:v=[float(x) for x in line.split()]
 except ValueError:continue
 if len(v)==16:rows.append(v)
last={}
for row in rows:
 if row[1]>0:last[int(row[0]),int(row[1])]=row
radii={};iteration=1;previous=0
for line in (a.case/'history.radius').read_text().splitlines():
 try:v=[float(x) for x in line.split()[:4]]
 except ValueError:continue
 if len(v)!=4:continue
 if int(v[0])<=previous:iteration+=1
 previous=int(v[0]);radii[iteration,previous]=v
record=[]
for key,row in sorted(last.items()):
 if key not in radii:continue
 v=radii[key]
 # Populations may lag between source functions. Only the historically retained
 # Pdest contribution defines the exact allocation subtraction in this experiment.
 h=row[6]*row[7]*row[8];fe=row[6]*row[7]*row[9];current=row[6]*row[7]*row[10];ots=row[13]
 record.append([*key,row[2],v[3],row[3],row[4],row[6],h,fe,current,ots])
z=np.asarray(record);assert z.ndim==2 and z.shape[1]==11 and np.isfinite(z).all()
# RT_OTS_AddLine rounds the per-bin photon flux to realnum (float32).
# This estimates this H contribution before later sources add to the same bin;
# it does not attribute roundoff of the final summed radiation field.
all_rows=np.asarray(rows); source=all_rows[:,13]; opacity=all_rows[:,14]
small=float(np.finfo(np.float32).tiny*100.)
emitted=np.zeros(len(source)); valid_opacity=opacity>0
emitted[valid_opacity]=np.asarray(source[valid_opacity]/opacity[valid_opacity],dtype=np.float32).astype(float)*opacity[valid_opacity]
allocated_probability=np.where(all_rows[:,15]>0,all_rows[:,11],all_rows[:,8])
emitted[(source<=small)|(allocated_probability<=small)]=0.
positive_source=all_rows[:,12]>0
rounding_relative=np.abs(emitted[positive_source]-source[positive_source])/all_rows[positive_source,12]
by_iteration=[]
for it in np.unique(z[:,0]).astype(int):
 v=z[z[:,0]==it];h,fe,current,ots=v[:,7:11].T;positive=h>0
 width=v[:,3];integral=lambda x:float(np.sum(width*x))
 ratio=(fe[positive]+ots[positive]-h[positive])/h[positive]
 before_after=(current[positive]-fe[positive])/h[positive]
 summary={'iteration':int(it),'matched_zone_count':len(v),'last_zone':int(v[-1,1]),'last_radius_Rp':float(3-v[-1,2]/1.358348e10),'integrated_units':'photons cm^-2 s^-1 per unit plane-parallel area; sum(local rate * saved zone width)','H_destruction':integral(h),'Fe_historical_assignment':integral(fe),'generic_continuum_assignment':integral(ots),'assignment_minus_H_destruction':integral(fe+ots-h),'max_abs_local_allocation_defect_relative_to_H_destruction':float(np.max(abs(ratio))) if len(ratio) else None,'max_abs_current_vs_historical_Fe_difference_relative_to_H_destruction':float(np.max(abs(before_after))) if len(before_after) else None,'sampled_radii':[]}
 for r in [1.1,1.3,1.8,2.5]:
  d=(3-r)*1.358348e10
  if not v[0,2]<=d<=v[-1,2]:continue
  j=int(np.argmin(abs(v[:,2]-d))); sample=v[j]
  summary['sampled_radii'].append({'requested_radius_Rp':r,'nearest_radius_Rp':float(3-sample[2]/1.358348e10),'zone':int(sample[1]),'T_K':float(sample[4]),'ne_cm3':float(sample[5]),'H_destruction':float(sample[7]),'Fe_historical_assignment':float(sample[8]),'Fe_current_probability_times_current_n2p_A':float(sample[9]),'generic_continuum_assignment':float(sample[10])})
 by_iteration.append(summary)
receipt_path=a.case/'execution_receipt.json';receipt=json.loads(receipt_path.read_text()) if receipt_path.exists() else None
report={'scope':'Local H Ly-alpha destruction allocation only. Photon multiplication by Fe cascades, Fe fluorescence energy, other lines and continuum photons are not a globally conserved photon-number ledger. Historical Pdest and current Fe rate may lag at this stage of the reference iteration.','execution_complete':receipt is not None and receipt['returncode']==0,'execution_receipt':receipt,'ledger_sha256_at_read':hashlib.sha256(raw).hexdigest(),'ledger_complete_numeric_rows_at_read':len(rows),'allocation_ledger_precision':'Double-precision event rates before generic continuum-bin flux is rounded to float32. This does not assert exact conservation of the final multi-source float32 radiation field.','maximum_H_bin_rounding_error_relative_to_H_destruction':float(np.max(rounding_relative)) if len(rounding_relative) else None,'summarizer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'columns':['iteration','zone','depth_cm','width_cm','temperature_k','electron_cm3','n2p_cm3','H_destruction_photons_cm3_s','Fe_historical_photons_cm3_s','Fe_current_inferred_photons_cm3_s','generic_continuum_photons_cm3_s'],'iterations':by_iteration}
a.output.parent.mkdir(exist_ok=True,parents=True)
a.output.write_text(json.dumps(report,indent=2)+'\n')
np.savez_compressed(a.output.with_suffix('.npz'),allocation_ledger=z)
print(json.dumps({'complete':report['execution_complete'],'iteration_summary':[{k:r[k] for k in ['iteration','last_zone','last_radius_Rp','max_abs_local_allocation_defect_relative_to_H_destruction']} for r in by_iteration]}))
