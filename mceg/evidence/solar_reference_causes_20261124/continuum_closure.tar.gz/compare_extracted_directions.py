"""Resolve direct, forward-diffuse and backward-diffuse H ground PI at fixed C23 state."""
from pathlib import Path
from hashlib import sha256
import argparse,gzip,json,time
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as jnp
import numpy as np
from escape.hydrogen_escape_probability import HydrogenEscapeProbabilityModel,_column_above,_cell_weights
from escape.hydrogen_rates import PLANCK_CGS,LIGHT_SPEED_CGS
from escape.hydrogen_two_photon import two_photon_emissivity
from escape.radiation import solve_slab_transfer

root=Path(__file__).parent
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('case',type=Path);args=parser.parse_args()
source=args.case
derived=source/'derived'
p=dict(np.load(derived/'profile.npz'))
width=np.load(derived/'zone_geometry.npz')['width_cm'][::-1]
m=HydrogenEscapeProbabilityModel(np.r_[0.,np.cumsum(width)],nmax=15,line_optical_depth_scale=2.,shell_collision_model='anderson_lebedev')
T=jnp.asarray(p['temperature_k'][::-1]);bound=jnp.asarray(p['bound_cm3'][::-1]);ne=jnp.asarray(p['electron_cm3'][::-1]);proton=jnp.asarray(p['proton_cm3'][::-1])
nu=m.grid.frequency_hz;pref=2*PLANCK_CGS/LIGHT_SPEED_CGS**2*nu**3
start=time.monotonic()

@jax.jit
def evaluate():
 chi,eta,inverse=m._continuum(T,bound,proton,ne,nu,m._sigma)
 scattering=m.scattering_coefficients_at(bound,ne,nu)
 transport=chi+jnp.log1p(scattering*m.widths_cm[:,None])/m.widths_cm[:,None]
 eta_ground=ne[:,None]*proton[:,None]*inverse[:,0,:]*m._sigma[0]*pref
 eta_two=two_photon_emissivity(nu,m.grid.weight_hz,m.atom.excitation_energy_erg[1]/PLANCK_CGS,bound[:,1])
 sources=jnp.stack((eta_ground,eta-eta_ground,eta_two))
 def solve(emission):
  formal=solve_slab_transfer(m.edges_cm,transport,emission,jnp.zeros_like(nu),jnp.zeros_like(nu),angle_order=m.angle_order,beam_mean_intensity=jnp.zeros_like(nu)).mean_intensity
  forward=m._forward_diffuse(transport,emission)
  kernel=m._photo_kernel[0]/pref
  # C23's outward interacting continuum adds half the isotropic cell
  # luminosity and then attenuates the updated beam. Compare at entry of
  # each cell, where the preceding zone's continuum is held fixed.
  def cloudy_cell(incoming, values):
   tau, source = values
   return (incoming + source) * jnp.exp(-tau), incoming
  entry = jax.lax.scan(cloudy_cell,jnp.zeros_like(nu),
      (transport*m.widths_cm[:,None], emission*m.widths_cm[:,None]*.5),
      reverse=True)[1]
  angular_entry=m.forward_diffuse_at_fraction(transport,emission,0.)
  def exact_cell(incoming, values):
   tau, source = values
   return incoming*jnp.exp(-tau)+source*_cell_weights(tau)[0],incoming
  exact_entry=jax.lax.scan(exact_cell,jnp.zeros_like(nu),
      (transport*m.widths_cm[:,None],emission*m.widths_cm[:,None]*.5),reverse=True)[1]
  return formal@kernel,forward@kernel,entry@kernel,angular_entry@kernel,exact_entry@kernel
 full,forward,entry,angular_entry,exact_entry=jax.vmap(solve)(sources)
 incoming=m.boundary_blackbody(10000.,.025)
 depth=transport*m.widths_cm[:,None]
 direct=incoming*jnp.exp(-_column_above(depth))*_cell_weights(depth)[0]
 entry_direct=incoming*jnp.exp(-_column_above(depth))
 return direct@(m._photo_kernel[0]/pref),full,forward,jnp.max(m._sigma_line[0]),entry,entry_direct@(m._photo_kernel[0]/pref),angular_entry,exact_entry
result=evaluate();direct,full,forward,ots_sigma,entry,entry_direct,angular_entry,exact_entry=[np.asarray(a) for a in result]
report={'scope':'Same frozen C23 populations, T, ne, np, slab edges, and native continuum coefficients. No SE/thermal/wind solve or new C23 run. Continuum direction, emissivity source, and the C23 single-beam source-then-attenuation recurrence are separated; linear transport keeps opacity fixed. The recurrence uses native coefficients and is not an assertion of exact C23 coefficient parity. Current frozen source, not a relabeling of older source controls.','boundary':'Normal blackbody beam J=.025 B_nu(10000 K), both diffuse incoming boundaries dark, double line optical depths; no bottom photosphere.', 'emission_sources':['ground_spontaneous_recombination','other_bound_recombination_and_free_free','two_photon'],'seconds':time.monotonic()-start,'profile_sha256':sha256((derived/'profile.npz').read_bytes()).hexdigest(),'source_snapshot':json.loads((root/'source_snapshot.json').read_text()),'cloudy_control':json.loads((source/'control.json').read_text()),'ground_cross_section_at_every_retained_H_line_max_cm2':float(ots_sigma),'zones':{}}
for zone in [1,3,64,127]:
 k=len(direct)-zone;op=np.load(derived/f'zone{zone:03d}_operators.npz')
 report['zones'][str(zone)]={'C23_saved_ground_photoionization_s':float(op['fb'][0,5]),'C23_ground_effective_RR_escape_factor':float(op['fb'][0,9]),'native_direct_s':float(direct[k]),'native_forward_diffuse_by_source_s':forward[:,k].tolist(),'native_backward_diffuse_by_source_s':(full-forward)[:,k].tolist(),'native_bidirectional_total_s':float(direct[k]+full[:,k].sum()),'native_forward_total_s':float(direct[k]+forward[:,k].sum()),'native_coefficients_cloudy_single_outward_recurrence_diffuse_s':entry[:,k].tolist(),'native_coefficients_entry_direct_s':float(entry_direct[k]),'native_coefficients_cloudy_recurrence_total_s':float(entry_direct[k]+entry[:,k].sum()),'native_angle_integrated_entry_total_s':float(entry_direct[k]+angular_entry[:,k].sum()),'native_exact_uniform_cell_single_beam_entry_total_s':float(entry_direct[k]+exact_entry[:,k].sum())}
(derived/'continuum_direction_comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2),flush=True)
