"""Check the diagnostic under the unmodified binary's documented Makefile flags."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,shutil
root=Path(__file__).parent;source=Path('/tmp/cloudy-reference-run/c23.01/source')
flags=['g++','-std=c++11','-O3','-ftrapping-math','-fno-math-errno','-fasynchronous-unwind-tables','-Wno-deprecated-declarations','-ftree-vectorize','-march=native','-Wall','-W','-g','-no-pie','-fno-pie','-I'+str(source),'-DSYS_CONFIG="'+str(source/'cloudyconfig.h')+'"','-DREVISION=""']
objects=[]
for name,path in [('iso',Path('/tmp/escape-ep-continuation/iso_level_selected.cpp')),('rt',Path('/tmp/escape-ep-prototype/rt_line_one_readout.cpp'))]:
 obj=root/(name+'_original_flags.o');subprocess.run(flags+['-c',str(path),'-o',str(obj)],check=True);objects.append(obj)
binary=root/'cloudy_original_flags_readout.exe';command=['g++','-no-pie','-o',str(binary),str(source/'maincl.o'),*map(str,objects),str(source/'libcloudy.a')];subprocess.run(command,check=True)
(root/'matching_flags_provenance.json').write_text(json.dumps({'scope':'Same public C23 Makefile optimization/configuration flags for readout-only source; not a claim that compiler scheduling is unchanged by diagnostics. Saved-output identity or measured numerical difference is required.','compiler_flags':flags,'link_command':command,'hashes':{str(p):sha256(p.read_bytes()).hexdigest() for p in objects+[binary]}},indent=2)+'\n')
p=root/'continuum_controls/ou2_matching_flags';p.mkdir(exist_ok=False);base=root/'continuum_controls/ou2_unmodified';shutil.copy2(base/'model.in',p/'model.in');d=json.loads((base/'control.json').read_text());d.update(variant='original_line_matching_compile_flags',executable=str(binary),executable_sha256=sha256(binary.read_bytes()).hexdigest());(p/'control.json').write_text(json.dumps(d,indent=2)+'\n')
print(binary)
