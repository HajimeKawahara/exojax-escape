# Matching a hydrogen thermal and radiation operator

This audit separates a change of accounting from a change of physical closure. It does not certify a converged solar atmosphere. The initial reference uses C23.01 equations but additionally refreshes line escape on every local pass; it is not a readout-only or unmodified-C23 binary. The immutable pure-H, fixed-density, fixed-temperature slab is specified in `col21_double_selected_rates/receipt.json`. The same-state native probe uses the frozen source revision in `source_snapshot.json`.

## What must be compared

A signed kinetic-energy power is Q = Gamma - Lambda. There is no unique gross Gamma + Lambda: adding an equal reversible cycle to both leaves Q unchanged. The native solver's positive/negative microscopic-rate sums are useful numerical scales, but they are not automatically C23's reported heating/cooling categories.

| Process | C23.01 accounting | Matching input to the external grouping diagnostic |
| --- | --- | --- |
| Ground photoionization | Separate heating | Ground photoelectron excess-energy power |
| Excited photoionization and spontaneous RR | Net over the iso atom before splitting by sign | Excited photoheating minus spontaneous RR cooling |
| Induced RR | Separate cooling | Induced RR kinetic-energy loss |
| Collisional ionization and three-body recombination | Net before splitting by sign | Three-body heating minus CI cooling |
| Bound-bound collisions | Net over the entire iso atom before splitting by sign | Sum of signed collisional transition powers |

`tools/cloudy_thermal_bookkeeping.py` changes only this grouping. It neither recalculates rates nor solves a radiation field. It preserves Q exactly, up to floating-point summation. Matched populations, transfer closure, temperature, and retained levels are prerequisites. In particular, C23 excludes the highest retained H state from the CI/three-body heat sum, and weights RR cooling by its effective continuum escape factor. Matching those conventions is a separate physical comparison.

The frozen C23 linear-solve operator shows why this distinction matters: the total gross collisional power divided by the absolute net collisional power is 320 at zone 1, 414 at zone 3, 56 at zone 64, and 27 at zone 127. These are accounting identities at a saved operator, not final cooling-stack or atmospheric-convergence certificates. The CI illustration uses an explicitly declared threshold convention; it does not establish exact C23 threshold rounding.

## The continuum closures are different

Let alpha_i be the thin spontaneous RR coefficient into level i, P_i its continuum escape factor, and f_i the fraction of threshold absorption supplied by other absorbers. C23's default outward scheme, OU2, uses

    P_i = E2(tau_face,i),
    beta_i = min[1, P_i + (1 - P_i) f_i],
    alpha_eff,i = alpha_i beta_i.

The source evaluates E2 on its stored threshold-adjacent continuum mesh index. The opacity fraction includes stimulated recombination in the opacity and is updated as 0.75 f_old + 0.25 f_new. Thus beta is an effective net RR factor, not simply a geometrical photon-escape probability.

The local continuum OTS source is proportional to

    n_e n_ion alpha_i (1 - P_i) / kappa_abs,i.

C23's `GammaBn` excludes `otscon` from the first photoionizing frequency cell and includes it above that cell. This eliminates the local self-recombination/self-ionization cycle together with alpha_eff. Adding that local self-PI back to a rate equation already using alpha_eff would double count the eliminated cycle. Other absorbers can still see these photons through the generic radiation ledger.

Escaping RR emission is multiplied by P_i and added to a single outward continuum. For open plane-parallel geometry, the source-cell multiplier is dr/2. The existing source then attenuates this updated beam. The code itself marks the finite-zone ordering as an approximation; this audit preserves it. This is not the native angle-integrated, bidirectional formal solution.

The public `diffuse outward 3` option sets P_i = 1: full RR, no continuum recombination OTS source, and a single outward transported continuum. It leaves line OTS mechanisms enabled. OU3 is therefore a useful matched-direction control, not the standard Cloudy or author configuration. It still differs from a cell-averaged, angle-integrated one-way formal solution in angular and finite-zone treatment. `diffuse OTS` uses a two-boundary escape probability; it does not enable bidirectional formal continuum transfer.

## A causal surface test

At the same C23 populations, electron/proton densities, temperature, cell widths, and native continuum coefficients, the incident-only H ground PI rate is 1.33720 s^-1 at the illuminated surface. The C23 saved rate is 1.34507 s^-1. Native bidirectional transfer adds 0.431677 s^-1 from backward-propagating ground RR continuum; forward ground RR contributes only 0.0000195 s^-1. Other RR and free-free emission contribute less than 3e-8 s^-1, and two-photon emission contributes zero above the ground threshold. Every retained H line also has zero ground PI cross section.

This isolates the surface excess to backward ground RR continuum. It is not evidence for H-line OTS double counting. Deep in the slab, C23's effective ground RR factor falls below 1.3e-7, while the native calculation explicitly transports and reabsorbs ground RR photons. Merely removing backward transport cannot establish deep operator parity: the eliminated local recycling and transported continuum must be matched together.

The active OU2/OU3 pair in `continuum_controls/ou2_active` and `ou3_active` is a new causal experiment with identical binary, incident spectrum, H atom, temperature, density, six full-column iterations, and line settings. Only the public diffuse-continuum option changes. Its result must remain separate from the standard OU2 reference and from the solar thermal/wind acceptance gates.

## Minimal comparison sequence

1. Freeze populations and the supplied radiation ledger. Compare H rate and energy operators under identical effective-RR and OTS conventions. Match the highest-state CI treatment explicitly.
2. Freeze populations and continuum coefficients. Compare direct, outward diffuse, and backward diffuse transport separately. Refine spatial/frequency resolution before interpreting finite-zone differences physically.
3. Re-solve the pure-H slab under matched closures; then add ground He and individual metal atoms. Keep changing-composition controls distinct from missing-process controls.
4. Re-solve the complete thermal/wind system only after the operator and fixed-profile reference controls pass. Reference refinement remains 1%; the native comparison remains 5% for the declared important profiles and separately grouped Gamma/Lambda. Neither a small gross-scaled residual nor a fixed-profile observer bound replaces thermal convergence.

The existing remove-all-He control is not a validation of the native ground-He approximation: it also changes mass density at fixed nH, and it uses an unrefined fixed-temperature atmosphere. Native ground He omits metastable/excited He photoionization, He line cooling, and detailed level-resolved RR energy exchange. Local metal matrix parity similarly does not bound omitted solar elements or prove a converged atmosphere.

## Source locations

- `iso_cool.cpp`: CI/three-body netting (103-177), excited PI/RR netting (255-320), induced RR (326-375), atom-wide collisional exchange (377-587).
- `rt_recom_effic.cpp`: OU2/OU3 continuum escape options.
- `iso_radiative_recomb.cpp:408-449`: effective RR factor.
- `opacity_addtotal.cpp:330-455`: opacity fraction and under-relaxation.
- `rt_ots.cpp:230-240,443-472`: local continuum OTS creation.
- `cont_gammas.cpp:35-195`: threshold-cell exclusion and photoelectron heat.
- `rt_diffuse.cpp` and `rt_continuum.cpp:227-242`: escaped continuum source and outward recurrence.
- `zone_startend.cpp:489-503`: open-geometry dr/2 source factor.
- `parse_commands.cpp:1287-1335`: public diffuse settings.
- Hazy 1 `optdepth.tex:151-180`, Hazy 2 `coninter.tex:26-95`: documented continuum schemes.

The first attempted pair (`ou2`, `ou3`) is retained as an invalid configuration control: an inserted blank line terminated input parsing before the requested option. Their echoed inputs show that both used default OU2. `comparison.json` marks that invalidity explicitly. The corrected active pair requires the expected command in Cloudy's echoed input before analysis.

## Completed OU2/OU3 control and a finite-zone transport cause

The corrected active pair completed all six columns with no reported convergence failures. Explicit OU2 reproduces the original default run's five saved physical tables byte for byte. OU3 has beta_i = 1 in every sampled level, as required. The n3 column changes from 6.82335e13 to 6.13601e12 cm^-2; n2 changes from 8.17806e14 to 9.47082e13 cm^-2. This large change prevents using OU3 as a silent replacement for the standard reference. The adaptive zone counts differ (127 and 1128); named zone numbers are therefore not common cross-run positions.

At the same OU3 populations and native coefficients, the C23-style source-then-attenuation recurrence agrees with C23 ground PI at the four saved operator zones to within 0.59%. The separate diagnostics at OU3 zone 127 are:

| Same-state ground PI calculation | Rate (s^-1) |
| --- | ---: |
| Actual C23 OU3 | 0.002762811 |
| Native angle-integrated one-way, cell average | 0.004884265 |
| Native angle-integrated one-way, cell entry | 0.004823962 |
| Single normal beam, exact uniform-cell source, cell entry | 0.004769736 |
| Single normal beam, C23 source-then-attenuation recurrence | 0.002754484 |

Most of this discrepancy is thus the finite-zone source update, rather than the angular quadrature or evaluation position. This is a direct instance of the approximation marked by the source's existing FIXIT. It is not evidence that default OU2 or the solar atmosphere has the same numerical error.

A fixed-coefficient transport refinement splits each original uniform cell into N identical subcells, keeping all populations, opacities and emissivities unchanged. The geometric series is evaluated analytically, independently of the exact-cell source expression. At zone 127, the recurrence error relative to the exact single-beam limit is -42.25% for N=1, -3.18% for N=16, -0.802% for N=64 and -0.401% for N=128. N=1 reproduces the prior recurrence, and the exact limit reproduces the separate uniform-cell calculation. This establishes a finite-zone cause and its numerical resolution in a frozen operator. A re-solved atmospheric reference still requires its own spatial/local/global/thermal refinement.

## Provenance correction and independent standard-policy pair

A source-level audit found that `cloudy_selected_rates.exe` links `rt_line_one_final.o`, which removes the first-sweep-only guard in five line-escape branches in addition to printing diagnostics. The original pure-H profile and the active OU2/OU3 pair share this numerical policy, so their same-binary causal comparison remains valid. It must not be labeled a standard unmodified-C23 run. The original source-tree differences, replacement-object patches and binary reconstruction are recorded separately.

The independent `ou2_original_readout` / `ou3_original_readout` pair preserves the original cache guard. Its paired `ou2_unmodified` / `ou3_unmodified` executions use the completely unmodified binary, and saved-table identity is required before attributing results to the standard numerical policy. These runs do not overwrite any earlier result.

## Actionable native/reference strategy

Keep the native bidirectional formal continuum solver. For the same extinction, emissivity and one-dimensional boundary conditions, it solves the stated transport equation with emission distributed through each cell and retains diffuse photons moving toward either boundary. That is a better controlled treatment than the finite-zone single-beam source update audited above. It does not prove that the chosen geometry, opacities, line redistribution or boundary conditions are a better description of the actual planet. It also does not establish identical predictions to the paper's Cloudy approximation.

Do not copy C23's source-then-attenuation inconsistency into the native scientific default. The continuous single-beam equation itself has the exact uniform-cell update

    F_out = F_in exp(-Delta_tau) + j_cell Delta_s/2 * phi(Delta_tau),
    phi(t) = (1 - exp(-t))/t, with phi(0) = 1.

Here j_cell is the selected closure's transported isotropic photon emissivity per volume and frequency (`DiffuseEscape`, including P_i in OU2); the factor one-half is the open-geometry outward fraction. In OU3, P_i is one. The existing C23 recurrence instead replaces phi(t) by exp(-t). The frozen subdivision control demonstrates convergence from that recurrence to the exact-cell expression. A separate external numerical reference can implement the exact-cell expression, preserve all physical rate and OTS prescriptions, and then demonstrate agreement with refined unmodified-C23 transport. It must be labeled an independently corrected numerical reference, with the original executions retained. The native continuum angular solution should still not be replaced by this single ray.

The minimum useful optional comparison path is a **Cloudy-continuum-closure diagnostic**. It needs all of the following together, not merely removal of the backward ray:

1. OU2's continuum escape P_i and effective RR beta_i, with the threshold-adjacent mesh and other-opacity conventions explicit.
2. Local continuum OTS allocation, with the self-threshold recycling eliminated in both the ionization equation and kinetic-energy ledger. Line OTS remains governed by the separately matched line model.
3. A single outward diffuse continuum with the exact continuous-equation source integral, normal-beam incident radiation, and the same open boundary. Evaluate and compare operators at a common within-cell position; do not confuse entry values and cell averages.
4. The same level truncation, atomic rates, abundances, density/temperature state and signed heat grouping. Every deliberately unmatched item remains a separate test condition.

This path can validate rate assembly, RR recycling and energy accounting against Cloudy without introducing the finite-zone bias into the default model. A useful implementation order is frozen pure-H operators, a re-solved pure-H slab, then fixed-profile H/He/selected-metals, followed by the complete thermal/wind loop. One same-state source-term match is not a substitute for the re-solved stages.

The reference obligation remains quantitative. The fixed-profile reference first needs successful local solves and stable important profiles under full-column iterations; then local tolerance, spatial placement, continuum sampling and atomic truncation must each be refined within the existing 1% budget. Thermal relaxation and the variable-mu wind add their own independent convergence tests. The native/reference 5% requirement applies to matched physical closures and states, with Gamma and Lambda grouped consistently. The native spatial/angle/frequency/atomic and thermal-root refinements also remain mandatory. Neither an improved transfer formula nor the new diagnostic path removes those gates.

Finally compare the converged native bidirectional model with the matched outward-closure model. This is a physical-approximation sensitivity, not an implementation residual. Apply the declared important-profile and observer budgets to this difference as well. If it exceeds the agreed limits, the bidirectional result cannot be advertised as reproducing the paper's predictions: retain the contradiction, identify the photon channels and emitting layers, and provide an explicitly named paper-closure mode if that is the intended use. Passing the matched diagnostic does not silently waive an unmet default-model equivalence requirement. Conversely, requiring the default model to reproduce a demonstrably unconverged C23 finite-zone result would test the wrong equations.

The immediate external work is therefore finite and directed: finish the unmodified/same-flags readout identity controls; retain the OU2/OU3 causal comparison; complete the fine spatial/local/global controls with unchanged accuracy thresholds and bounded work limits; and, where the source integration itself limits precision, use the exact-cell external numerical control with a demonstrated unmodified-C23 refinement limit. This produces a numerical reference for the stated closure rather than stopping after reporting a difference.

## Canonical standard-C23 readout result

The final `ou2_matching_flags` and `ou3_matching_flags` readout builds preserve the original first-sweep line policy and use the same optimization/configuration flags as the unmodified C23 Makefile. Both complete six-column cases have all five saved physical tables byte-identical to their completely unmodified paired runs. This is the primary source-policy control; the earlier O2 and every-pass controls remain explicitly separate. Changing optimization flags alone changed the adaptive OU3 grid, so a diagnostic source label without compiler/build provenance was insufficient.

The standard pair contains 127 (OU2) and 1181 (OU3) zones. OU3/OU2 integrated populations are 0.11617 for n2 and 0.090287 for n3. In the canonical OU3 zone 127, C23 ground PI is 0.002664322 s^-1, the independently computed C23-style recurrence is 0.002656628 s^-1, and the exact uniform-cell single-beam limit is 0.004685948 s^-1. The recurrence error is -43.306% at the original cell size, -0.8222% with 64 subcells, and -0.4117% with 128. These are the updated standard-policy values; the earlier table describes its separately retained O2/every-pass experiment.

There is an additional finite-zone convention in the incident beam. `zone_startend.cpp:145-213` multiplies the incident flux before the local solve by `tmn`, approximately `phi(1.35 * kappa_old * dr)` for an open normal beam. It uses opacity retained at zone entry, has explicit small/large optical-depth branches, and cancels the factor when ending the zone. The outward interacting diffuse continuum is not multiplied by this same factor. Hazy 2 describes a zone-average attenuation; the implementation adds the documented-in-code 1.35 multiplier. A strict operator comparison must preserve this convention separately from cell-entry and exact cell-average values. It matters for OU2 direct illumination; it does not explain the OU3 deep-zone source discrepancy, where the direct ground PI is about 3e-12 s^-1.
