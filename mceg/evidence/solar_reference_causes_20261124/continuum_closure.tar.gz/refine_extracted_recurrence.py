"""Resolve direct, forward-diffuse and backward-diffuse H ground PI at fixed C23 state."""
from pathlib import Path
from hashlib import sha256
import argparse,gzip,json,time
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as jnp
import numpy as np
from escape.hydrogen_escape_probability import HydrogenEscapeProbabilityModel,_column_above,_cell_weights
from escape.hydrogen_rates import PLANCK_CGS,LIGHT_SPEED_CGS
from escape.hydrogen_two_photon import two_photon_emissivity
from escape.radiation import solve_slab_transfer

root=Path(__file__).parent
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('case',type=Path);args=parser.parse_args()
source=args.case
derived=source/'derived'
p=dict(np.load(derived/'profile.npz'))
width=np.load(derived/'zone_geometry.npz')['width_cm'][::-1]
m=HydrogenEscapeProbabilityModel(np.r_[0.,np.cumsum(width)],nmax=15,line_optical_depth_scale=2.,shell_collision_model='anderson_lebedev')
T=jnp.asarray(p['temperature_k'][::-1]);bound=jnp.asarray(p['bound_cm3'][::-1]);ne=jnp.asarray(p['electron_cm3'][::-1]);proton=jnp.asarray(p['proton_cm3'][::-1])
nu=m.grid.frequency_hz;pref=2*PLANCK_CGS/LIGHT_SPEED_CGS**2*nu**3
start=time.monotonic()

@jax.jit
def evaluate():
 chi,eta,inverse=m._continuum(T,bound,proton,ne,nu,m._sigma)
 scattering=m.scattering_coefficients_at(bound,ne,nu)
 transport=chi+jnp.log1p(scattering*m.widths_cm[:,None])/m.widths_cm[:,None]
 eta=eta+two_photon_emissivity(nu,m.grid.weight_hz,m.atom.excitation_energy_erg[1]/PLANCK_CGS,bound[:,1])
 tau=transport*m.widths_cm[:,None]
 source=eta*m.widths_cm[:,None]*.5
 exact_weight=_cell_weights(tau)[0]
 direct=m.boundary_blackbody(10000.,.025)*jnp.exp(-_column_above(tau))
 def solve(nsplit):
  sub=tau/nsplit
  correction=jnp.exp(-sub)/_cell_weights(sub)[0]
  weight=jnp.where(jnp.isinf(nsplit),exact_weight,exact_weight*correction)
  def step(incoming,values):
   depth,emission=values
   return incoming*jnp.exp(-depth)+emission,incoming
  entry=jax.lax.scan(step,jnp.zeros_like(nu),(tau,source*weight),reverse=True)[1]
  return (direct+entry)@(m._photo_kernel[0]/pref)
 splits=jnp.asarray([1.,2.,4.,8.,16.,32.,64.,128.,256.,jnp.inf])
 return jax.vmap(solve)(splits)
rates=np.asarray(evaluate());report={'scope':'Fixed C23 OU3 populations, native opacity/emissivity, same original cells. Each original uniform cell is split into N identical subcells for the C23 source-then-attenuation outward recurrence, using its closed geometric-series sum. No new Cloudy/SE/energy/wind solve. The exact uniform-cell single-beam solution is the independent analytic transport limit; this is not atmospheric reference convergence.','splits':[1,2,4,8,16,32,64,128,256,'exact'],'zones':{},'profile_sha256':sha256((derived/'profile.npz').read_bytes()).hexdigest(),'source_snapshot':json.loads((root/'source_snapshot.json').read_text()),'cloudy_control':json.loads((source/'control.json').read_text())}
for zone in [1,3,64,127]:
 k=len(p['depth_cm'])-zone
 report['zones'][str(zone)]={'ground_PI_s':rates[:,k].tolist(),'relative_to_exact':(rates[:,k]/rates[-1,k]-1).tolist()}
(derived/'frozen_outward_subdivision.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2),flush=True)
