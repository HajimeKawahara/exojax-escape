"""Compare two heat/cool groupings of exactly the same recorded H operator."""
from pathlib import Path
from hashlib import sha256
import argparse,json,sys
import numpy as np
sys.path.insert(0, str(Path(__file__).parent / "tools"))
from cloudy_thermal_bookkeeping import hydrogen_heat_groups

root=Path(__file__).parent
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('case',type=Path);args=parser.parse_args()
source=args.case/'derived'
KB=1.38064852e-16
report={'scope':'Algebraic grouping of the same frozen C23 H populations/rates. This is not a new atmospheric solve, a measured C23 final cooling-stack match, or a statement that old/native radiative fields agree. No microscopic rates are changed.', 'source':'C23.01 iso_cool.cpp:103-177 and377-587; native hydrogen_escape_probability.py:_thermal_exchange', 'sign':'Positive net = kinetic heating', 'units':'erg cm^-3 s^-1', 'cases':{}}
for zone in [1,3,64,127]:
 path=source/f'zone{zone:03d}_operators.npz'
 op=dict(np.load(path)); ne,corrected,proton=op['header'][[4,5,7]];T=op['header'][3]
 fb=op['fb'];pop=op['solution'];g=fb[:,3];E=fb[:,4]*KB
 heat=cool=0.
 for row in op['bb']:
  u,l=map(int,row[:2]);down=row[5];delta=row[6]*KB
  heat+=pop[u]*down*delta
  cool+=pop[l]*down*g[u]/g[l]*np.exp(-(E[u]-E[l])/(KB*T))*delta
 net=heat-cool
 # The uppermost state is excluded in C23 iso_cool's CI/three-body ledger.
 # Use the declared ground threshold and saved excitation energies; exact C23 threshold rounding is not established.
 chi=13.598434599702*1.602176634e-12-E
 ion=corrected*pop*fb[:,6]*chi
 three=corrected*ne*proton*fb[:,6]*fb[:,7]*chi
 paired=float(np.sum(three[:-1]-ion[:-1]))
 grouped=hydrogen_heat_groups(ground_photo=0.,excited_photo=0.,spontaneous_recombination=0.,induced_recombination=0.,collisional_ionization=ion[:-1].sum(),three_body_recombination=three[:-1].sum(),line_net=net)
 np.testing.assert_allclose(grouped['net'],net+paired,rtol=1e-13)

 report['cases'][str(zone)]={'operator_sha256':sha256(path.read_bytes()).hexdigest(),'line_plus_ci_grouping_net_check':float(grouped['net']),'temperature_k':float(T),'electron_cm3':float(ne),'bound_population_cm3':pop.tolist(),'collisional_lines':{'separate_direction_heating':float(heat),'separate_direction_cooling':float(cool),'net_kinetic_heat':float(net),'C23_atom_group_heating':float(max(net,0)),'C23_atom_group_cooling':float(max(-net,0)),'gross_over_net_absolute':float((heat+cool)/abs(net))},'CI_three_body':{'highest_level_excluded':True,'threshold_note':'Uses saved excitation energies and stated H ground threshold; exact C23 threshold rounding is not inferred from this operator dump. This illustrative CI grouping is not rate-parity evidence.','separate_CI_cooling':float(ion[:-1].sum()),'separate_three_body_heating':float(three[:-1].sum()),'net_kinetic_heat':paired,'C23_group_heating':max(paired,0),'C23_group_cooling':max(-paired,0),'highest_level_native_additional_net':float(three[-1]-ion[-1])}}
(source/'frozen_hydrogen_grouping.json').write_text(json.dumps(report,indent=2)+'\n')
print({z:{'line_gross_over_abs_net':r['collisional_lines']['gross_over_net_absolute'],'line_net':r['collisional_lines']['net_kinetic_heat']} for z,r in report['cases'].items()})
