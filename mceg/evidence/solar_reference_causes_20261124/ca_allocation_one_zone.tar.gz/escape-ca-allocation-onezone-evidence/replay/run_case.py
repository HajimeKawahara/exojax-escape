from pathlib import Path
import argparse, subprocess, time, json, hashlib, os
p=argparse.ArgumentParser();p.add_argument('case');p.add_argument('binary');p.add_argument('cpu');a=p.parse_args()
root=Path(__file__).parent; work=root/a.case; binary=Path(a.binary)
env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
start=time.time()
metadata_path=work/'input_receipt.json'
if not metadata_path.exists(): metadata_path=work/'build_receipt.json'
scope=json.loads(metadata_path.read_text()).get('scope','Diagnostic reference control') if metadata_path.exists() else 'Diagnostic reference control'
with (work/'console.txt').open('w') as log:
 run=subprocess.run(['taskset','-c',a.cpu,str(binary),'-r','model'],cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'returncode':run.returncode,'elapsed_seconds':time.time()-start,'input_sha256':hashlib.sha256((work/'model.in').read_bytes()).hexdigest(),'command':['taskset','-c',a.cpu,str(binary),'-r','model'],'scope':scope}
(work/'execution_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
raise SystemExit(run.returncode)
