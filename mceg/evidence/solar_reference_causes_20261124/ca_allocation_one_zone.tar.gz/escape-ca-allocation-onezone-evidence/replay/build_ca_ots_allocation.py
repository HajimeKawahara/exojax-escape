"""Build isolated, explicitly altered C23 Ly-alpha-bin Ca OTS allocation controls."""
from pathlib import Path
import subprocess,json,hashlib,difflib,shutil
root=Path('/tmp/cloudy-ca-ots-allocation');root.mkdir(exist_ok=True)
src=Path('/tmp/cloudy-reference-run/c23.01/source');original=(src/'rt_ots.cpp').read_text()
s=original.replace('#include "cosmology.h"','#include "cosmology.h"\n#include "ca.h"\n#include "atmdat.h"\n#include "radius.h"\n#include "phycon.h"')
anchor='/* this flag may be used for debugging ots rate changes */'
insert='''/* ALTERED DIAGNOSTIC C23.01: optional Ca receiver allocation only.
 * This does not add Ca opacity to Pdest or broad-band continuum transfer. */
#ifndef ESCAPE_CA_ALLOCATION
#define ESCAPE_CA_ALLOCATION 0
#endif
static double escape_ca_receiver_opacity=0.;
static double escape_lya_ots_source=0.;
static double escape_ca_receiver_candidate()
{
    const long calcium=atmdat.ipSpecIon[ipCALCIUM][1];
    if(calcium<0 || dBaseSpecies[calcium].numLevels_local<5) return 0.;
    const double cross[]={4.8e-18,7.0e-18,8.4e-19,1.7e-18};
    double opacity=0.;
    for(long i=1;i<5;++i) opacity+=dBaseStates[calcium][i].Pop()*cross[i-1];
    ASSERT(opacity>=0.);
    return opacity;
}

'''
assert s.count(anchor)==1;s=s.replace(anchor,insert+anchor)
anchor='\tDEBUG_ENTRY( "RT_OTS()" );'
insert='''
    escape_lya_ots_source=0.;
    escape_ca_receiver_opacity=escape_ca_receiver_candidate();
#if ESCAPE_CA_ALLOCATION
    /* This controlled variant is valid only when the legacy Ca hook is absent. */
    ASSERT(ca.popca2ex==0.);
#endif
'''
s=s.replace(anchor,anchor+insert)
anchor='''	if( opac.opacity_abs[ip-1] > 0. )
	{
		rfield.otslin[ip-1] += (realnum)(ots/opac.opacity_abs[ip-1]);
	}'''
assert s.count(anchor)==1
replace='''    const bool lya_bin=ip==iso_sp[ipH_LIKE][ipHYDROGEN].trans(ipH2p,ipH1s).ipCont();
    if(lya_bin) escape_lya_ots_source+=ots;
#if ESCAPE_CA_ALLOCATION
    const double allocation_opacity=opac.opacity_abs[ip-1] + (lya_bin ? escape_ca_receiver_opacity : 0.);
    if(allocation_opacity>0.)
        rfield.otslin[ip-1]+=(realnum)(ots/allocation_opacity);
#else
'''+anchor+'''
#endif'''
s=s.replace(anchor,replace)
# Preserve the meaning of the existing OTS-source convergence statistic.
anchor='\t\t*SumOTS += (rfield.otscon[i] + rfield.otslin[i])*opac.opacity_abs[i];'
assert s.count(anchor)==1
s=s.replace(anchor,anchor+'''
#if ESCAPE_CA_ALLOCATION
        if(i==iso_sp[ipH_LIKE][ipHYDROGEN].trans(ipH2p,ipH1s).ipCont()-1)
            *SumOTS+=rfield.otslin[i]*escape_ca_receiver_opacity;
#endif''')
anchor='''		(*diatom)->H2_RT_OTS();

	return;'''
assert s.count(anchor)==1
s=s.replace(anchor,'''        (*diatom)->H2_RT_OTS();

    const long calcium=atmdat.ipSpecIon[ipCALCIUM][1];
    if(calcium>=0 && dBaseSpecies[calcium].numLevels_local>=5){
        static FILE* f=open_data("ca_allocation_ledger.tsv","w");
        static bool first=true;
        if(first){fprintf(f,"# iteration zone depth_cm T_K ne_cm3 legacy_excited_cm3 receiver_opacity_cm1 base_opacity_cm1 source_photons_cm3_s flux_photons_cm2_s base_receiver_photons_cm3_s Ca_receiver_photons_cm3_s Ca0_cm3 Ca1_cm3 Ca2_cm3 allocation_enabled\\n");first=false;}
        const long index=iso_sp[ipH_LIKE][ipHYDROGEN].trans(ipH2p,ipH1s).ipCont()-1;
        const double flux=rfield.otslin[index];
        fprintf(f,"%ld %ld %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %d\\n",iteration,nzone,radius.depth,phycon.te,dense.eden,double(ca.popca2ex),escape_ca_receiver_opacity,double(opac.opacity_abs[index]),escape_lya_ots_source,flux,flux*opac.opacity_abs[index],flux*escape_ca_receiver_opacity,dense.xIonDense[ipCALCIUM][0],dense.xIonDense[ipCALCIUM][1],dense.xIonDense[ipCALCIUM][2],ESCAPE_CA_ALLOCATION);
    }
    return;''')
path=root/'rt_ots_ca_allocation.cpp';path.write_text(s)
(root/'allocation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='C23.01/rt_ots.cpp',tofile='allocation_only/rt_ots.cpp')))
commands=[]
for mode in [0,1]:
 name='tracking' if mode==0 else 'allocation';obj=root/f'rt_ots_{name}.o';exe=root/f'cloudy_ca_{name}.exe'
 cmds=[['taskset','-c','53','g++','-std=c++11','-O2','-fno-pie','-I'+str(src),'-DSYS_CONFIG="'+str(src/'cloudyconfig.h')+'"',f'-DESCAPE_CA_ALLOCATION={mode}','-c',str(path),'-o',str(obj)],['taskset','-c','53','g++','-no-pie','-o',str(exe),str(src/'maincl.o'),str(obj),str(src/'libcloudy.a')]]
 for c in cmds:subprocess.run(c,check=True)
 commands+=cmds
 case=root/name;case.mkdir(exist_ok=True)
 shutil.copyfile('/tmp/cloudy-fe-ots-allocation/ca_readout/model.in',case/'model.in')
paths=[src/'rt_ots.cpp',src/'libcloudy.a',src/'maincl.o',src/'ion_photo.cpp',src/'species2.cpp',path,root/'tracking/model.in',root/'cloudy_ca_tracking.exe',root/'cloudy_ca_allocation.exe']
receipt={'scope':'Isolated Ly-alpha-bin OTS allocation control. Retains original H destruction probability, broad-band opacity and all rate coefficients. Only the same four actual excited-Ca receiver opacities enter the OTS denominator; the source-count convergence statistic is updated with that same historical denominator. No full physical correction or atmospheric convergence claim.','commands':commands,'sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}}
(root/'build_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(root)
