"""Build a separate Ly-alpha-bin Ca absorption/OTS closure control."""
from pathlib import Path
import subprocess,hashlib,json,difflib,shutil
root=Path('/tmp/cloudy-ca-coupled-closure-v2');root.mkdir(exist_ok=True);src=Path('/tmp/cloudy-reference-run/c23.01/source')
ots=Path('/tmp/cloudy-ca-ots-allocation/rt_ots_ca_allocation.cpp').read_text().replace('static double escape_ca_receiver_candidate()','double escape_ca_receiver_candidate()')
(root/'rt_ots_ca_coupled.cpp').write_text(ots)
orig=(src/'rt_escprob.cpp').read_text();s=orig.replace('#include "integrate.h"','#include "integrate.h"\n#include "radius.h"\n#include "phycon.h"\n// ALTERED C23.01 diagnostic: same-bin Ca absorption in beta/albedo only.\n#ifndef ESCAPE_CA_COUPLED\n#define ESCAPE_CA_COUPLED 0\n#endif\nextern double escape_ca_receiver_candidate();')
# Only this private function's two H/He-Lya calls use its albedo argument.
needle='''  long ipLine );''';assert s.count(needle)==1;s=s.replace(needle,'''  long ipLine, double line_albedo );''')
needle='''  long ipLine )
{''';assert s.count(needle)==1;s=s.replace(needle,'''  long ipLine, double line_albedo )
{''')
needle='''	conopc = opac.opacity_abs[ t.ipCont()-1 ];
	if (rt.lgElecScatEscape && NEW_PELEC_ESC)''';assert s.count(needle)==1
s=s.replace(needle,'''    const bool ca_lya_bin=t.ipCont()==iso_sp[ipH_LIKE][ipHYDROGEN].trans(ipH2p,ipH1s).ipCont();
    const double ca_candidate=ca_lya_bin ? escape_ca_receiver_candidate() : 0.;
    const double ca_added=ESCAPE_CA_COUPLED ? ca_candidate : 0.;
    const double base_absorption=opac.opacity_abs[t.ipCont()-1];
    const double line_absorption=base_absorption+ca_added;
    double local_albedo=opac.albedo[t.ipCont()-1];
#if ESCAPE_CA_COUPLED
    if(ca_lya_bin){
        const double scattering=opac.opacity_sct[t.ipCont()-1];
        ASSERT(line_absorption+scattering>0.);
        local_albedo=scattering/(scattering+line_absorption);
    }
#endif
    conopc=line_absorption;
	if (rt.lgElecScatEscape && NEW_PELEC_ESC)''')
# Preserve the source's exact old arithmetic when the diagnostic switch is OFF.
needle='''		t.ipCont()-1);''';assert s.count(needle)==2;s=s.replace(needle,'''        t.ipCont()-1, local_albedo);''')
needle='''	*dest = (realnum)( (1. - opac.albedo[ipLine]) * *dest + opac.albedo[ipLine]*DEST0);''';assert s.count(needle)==1;s=s.replace(needle,'''    *dest = (realnum)((1.-line_albedo)* *dest + line_albedo*DEST0);''')
needle='''	ASSERT( escla_v >=0. && *dest>=0. && *esin>=0. );
	return escla_v;''';assert s.count(needle)==1
s=s.replace(needle,'''    ASSERT( escla_v >=0. && *dest>=0. && *esin>=0. );
    if(ca_lya_bin){
        static FILE* f=open_data("ca_lya_probability.tsv","w");static bool first=true;
        if(first){fprintf(f,"# iteration zone depth_cm T_K base_absorption_cm1 candidate_Ca_cm1 added_Ca_cm1 beta_absorption_cm1 scattering_cm1 albedo beta line_mean_opacity_cm1 escape dest new_electron_mode coupled_enabled\\n");first=false;}
        fprintf(f,"%ld %ld %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %d %d\\n",iteration,nzone,radius.depth,phycon.te,base_absorption,ca_candidate,ca_added,line_absorption,double(opac.opacity_sct[t.ipCont()-1]),local_albedo,beta,abund*SQRTPI*t.Emis().opacity()/DopplerWidth,escla_v,*dest,int(NEW_PELEC_ESC),ESCAPE_CA_COUPLED);
    }
    return escla_v;''')
# This new-mode opacity branch is inactive in the original C23.01 build;
# record that fact instead of enabling a different electron escape model.
needle='''		double conopc = opac.opacity_abs[ t.ipCont()-1 ];''';assert s.count(needle)==1
s=s.replace(needle,needle+'''
#if ESCAPE_CA_COUPLED
        if(t.ipCont()==iso_sp[ipH_LIKE][ipHYDROGEN].trans(ipH2p,ipH1s).ipCont())
            conopc+=escape_ca_receiver_candidate();
#endif''')
needle='''		t.Emis().Pelec_esc() = (realnum)opacity_ratio * MAX2(0.f,1.f-t.Emis().Pesc()-t.Emis().Pdest());''';assert s.count(needle)==1
s=s.replace(needle,needle+'''
        if(t.ipCont()==iso_sp[ipH_LIKE][ipHYDROGEN].trans(ipH2p,ipH1s).ipCont() && t.Emis().iRedisFun()==ipLY_A){
            static FILE* f=open_data("ca_electron_escape.tsv","w");static bool first=true;
            if(first){fprintf(f,"# iteration zone depth_cm electron_opacity_cm1 line_opacity_cm1 escape dest electron_escape opacity_ratio new_electron_mode\\n");first=false;}
            fprintf(f,"%ld %ld %.17g %.17g %.17g %.17g %.17g %.17g %.17g %d\\n",iteration,nzone,radius.depth,opac_electron,opac_line,double(t.Emis().Pesc()),double(t.Emis().Pdest()),double(t.Emis().Pelec_esc()),opacity_ratio,int(NEW_PELEC_ESC));
        }''')
p=root/'rt_escprob_ca_coupled.cpp';p.write_text(s)
for source,text in [('rt_escprob.cpp',s),('rt_ots.cpp',ots)]:
 old=(src/source).read_text();(root/(source+'.patch')).write_text(''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile='C23.01/'+source,tofile='coupled_ca/'+source)))
commands=[]
for mode,name in [(0,'tracking'),(1,'coupled')]:
 objects=[]
 for stem in ['rt_ots','rt_escprob']:
  code=root/(stem+'_ca_coupled.cpp');obj=root/(stem+'_'+name+'.o');objects.append(obj)
  cmd=['taskset','-c','52','g++','-std=c++11','-O2','-fno-pie','-I'+str(src),'-DSYS_CONFIG="'+str(src/'cloudyconfig.h')+'"',f'-DESCAPE_CA_ALLOCATION={mode}',f'-DESCAPE_CA_COUPLED={mode}','-c',str(code),'-o',str(obj)];subprocess.run(cmd,check=True);commands.append(cmd)
 exe=root/f'cloudy_ca_{name}.exe';cmd=['taskset','-c','52','g++','-no-pie','-o',str(exe),str(src/'maincl.o'),*[str(p) for p in objects],str(src/'libcloudy.a')];subprocess.run(cmd,check=True);commands.append(cmd)
 case=root/name;case.mkdir(exist_ok=True);shutil.copyfile('/tmp/cloudy-fe-ots-allocation/ca_readout/model.in',case/'model.in');(case/'input_receipt.json').write_text(json.dumps({'scope':'One-zone same-bin Ca beta/albedo/OTS closure control; original electron escape mode remains false; not an atmosphere correction.'},indent=2)+'\n')
paths=[src/'rt_ots.cpp',src/'rt_escprob.cpp',src/'cloudyconfig.h',src/'maincl.o',src/'libcloudy.a',*root.glob('*.cpp'),*root.glob('*.exe')]
(root/'build_receipt.json').write_text(json.dumps({'scope':'Only H Ly-alpha-bin Ca opacity in beta/albedo/OTS. Original electron escape mode unchanged; no broad-band opacity or Fe OTS correction.','commands':commands,'sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}},indent=2)+'\n')
shutil.copyfile('/tmp/cloudy-fe-ots-allocation/run_case.py',root/'run_case.py')
print(root)
