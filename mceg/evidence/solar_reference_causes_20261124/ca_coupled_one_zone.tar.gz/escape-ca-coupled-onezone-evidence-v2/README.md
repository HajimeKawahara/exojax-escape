# Coupled same-bin Ca absorption in a C23.01 one-zone control

This completed blackbody test uses the same prescribed density/temperature/input as the isolated Ca allocation control. It includes the same four-level excited-Ca absorption in the three **executed** places relevant to this test: the Ly-alpha beta ratio, its scattering-albedo suppression, and the line-OTS allocation denominator. The broad-band continuum opacity and the original Fe OTS allocation remain unchanged. This is not a full atmospheric validation or a complete correction of every Ca continuum process.

C23.01 sets NEW_PELEC_ESC=false. Its active old electron-escape expression remains unchanged and receives the updated Pdest. The alternate new electron absorption/scattering split is not enabled. The active albedo, rather than that inactive branch, is the necessary second use of the corrected absorption. The source and readout explicitly distinguish them.

`summary.json` independently reconstructs beta, albedo, the absorption sum, and the original float32 electron-escape expression from all emitted H-specific diagnostics. All four maximum discrepancies are zero for the corrected case. The final Ca opacity sampled by beta and OTS is identical; they use the same four-level function at their own calls, so equality is not artificially imposed across earlier nonlinear iterates. The maximum local bin source/receiver mismatch is 7.552e-8, consistent with the retained float32 OTS field.

In this particular final one-zone state, beta increases by 13.9296 and H continuum destruction probability by 194.006 because the added absorption also changes albedo. The total source for the common Ly-alpha bin rises by only 0.0153%; it includes other lines assigned to the same bin and must not be called H Ly-alpha alone. The bin flux becomes 0.0718008 of its original value. Electron escape is numerically unchanged at float32 precision, and the small Ca density response does not bound a planetary thermal response.

The macro-OFF source has byte-identical saved conditions/cooling tables to the unmodified C23 companion. The first diagnostic version also logged other transitions sharing this continuum bin in its electron table. V2 restricts that readout to the Lya redistribution tag. The retained `diagnostic_filter_parity.json` confirms that this readout-only selection change left both saved physical tables unchanged for both switch values. Only the V2 H-specific table supports the H-electron claims.

## Replay and scope

Obtain the pinned C23.01 source/library; original and altered hashes and exact compile/link commands are in `build_receipt.json`. The patches identify all modifications. Adjust historical local paths in the builder, compile both macro values, and run `-r model` in separate copies of the supplied case directories. `summarize.py` verifies the recorded identities. The builder expects the allocation-only source from the companion Ca allocation evidence archive; that source is also fully present here as `rt_ots_ca_coupled.cpp`, with its helper made externally callable. No binaries, objects, cache, SED/FITS or stellar-flux arrays are distributed.

The tests establish only this explicit source/receiver coupling and the stated one-zone behavior. They do not certify numerical convergence of a multi-layer atmosphere, agreement with a native model, the author's exact physical configuration, or any pending PHX-column experiment. Original Cloudy credit and license are preserved in `Cloudy_LICENSE.txt`.

## Metadata correction

The initial archive incorrectly described the original stored albedo as float32 in its summary. C23 opacity.h declares opacity_abs, opacity_sct and albedo as vector<double>; both tested switches preserve that precision. Pesc/Pdest/Pelec and the OTS field are realnum float32. `source_precision.json` pins those declarations. No executed source, input, binary, readout or numerical result was changed for this correction.
