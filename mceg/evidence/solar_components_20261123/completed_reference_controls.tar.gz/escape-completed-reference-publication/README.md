# Completed fixed-profile solar controls — intermediate evidence

These files document four completed Cloudy C23.01 **prescribed-temperature,
prescribed-density** columns and their conditional H-alpha predictions. They are
neither a thermal/wind equilibrium, a fit, a native-solar validation, nor an exact
reproduction of Zhang et al. (2026, arXiv:2606.23899v1). Work continues separately.
All four cases use Cloudy's default local convergence tolerances; a subsequent
local-tolerance discrepancy remains unresolved. Do not treat these outputs as a
numerically certified atmosphere. The later tolerance campaign is intentionally
excluded from this immutable intermediate archive.

## What the controls establish

| Comparison | Completed conditional result |
| --- | --- |
| Fe II 80 -> 716 levels on the same union continuum mesh | Heating increases by factors 2.87, 8.32, 3.76, 3.66 at 1.1, 1.3, 1.8, 2.5 Rp. This effect survives controlling stellar-line sampling. |
| Fe II 716, exact incident atomic-line sampling at background R=6000 vs union mesh | Heating ratios are 0.99995, 0.99946, 0.99847, 0.99829 at those radii. |
| Exact sampling R=12000 vs union mesh | Heating ratios are 1.00429, 0.99989, 0.99982, 0.99993. This checks this approximation in this column, not all states. |
| Same observer, Fe II 80 -> 716 | Maximum processed difference 5.8754 ppm, 0.02763 supplied-error units. |
| Same observer, exact-sampling R=6000 vs union | Maximum processed difference 1.24384 ppm, 0.005124 supplied-error units. |

A small fixed-temperature spectral difference does **not** bound the potentially
large thermal feedback of metal heating. Full tables and hashes are in
`numerical_controls/Fe716_matched_controls.json` and
`figures/observer_controls.json`. The figures contain the Zenodo observations and
preserve the atmospheric profile figure. The predictions are not fitted (roughly
2.22 supplied-error units RMS from the data).

## Declared model and numerical changes

The input is a 48-node 1–3 Rp temperature/density/velocity profile, with 4500 K at
the base and approximately 8000 K aloft. It is common to all cases. Cloudy uses
`default.abn`, full chemistry, H I 10 resolved + 15 collapsed levels with its
default topoff, a top-incident normal beam, doubled optical depths, and Fe II 80
or 716 levels. The supplied stellar proxy is PHOENIX Teff=10000 K, log g=4, solar
composition; incident flux is 0.1 times its surface flux, with zero outside its
500 Angstrom–5.5 micron coverage. This omits any independently specified XUV
component. Radiation is static; wind does not Doppler-shift the pumping field.
The authors' exact input configuration is unavailable.

`numerical_patches/` contains changes to private C23 source copies:

- A binary interval search preserves the original tabulated-spectrum interpolation;
  independent tie/end-point tests and complete-output identity are retained.
- Reporting precision changes only printed numeric precision.
- The density-law step selector limits its nominal density change to 2.5% instead
  of 10%; the remaining growth limits and convergence guards remain enabled.
- The optional exact atomic incident-pumping prototype samples the unchanged
  stellar interpolant at each selected atomic transition. It corrects only the
  incident occupation; the main-mesh attenuation, diffuse field, shielding, rate
  data, and guards are unchanged. It is restricted to one constant beam and the
  explicitly selected species/energy ranges in the patch. The common union-mesh
  calculation provides an independent comparison. No molecular pumping change
  is included. This is an experimental numerical approximation, not a new
  atomic coefficient or a general Cloudy replacement.

## Contents and exclusions

`reference_controls/` retains original input text, final output logs, populations,
heating/cooling and state tables, original input profiles, and parsed raw/projected
profiles. `cases.json` maps each case to its mesh and driver. `replay/` includes
the exact run driver sources and numerical patches/build instructions. The
intermediate union driver was reconstructed from the later commit by reverting
only local-tolerance/reporting additions; its full SHA256 exactly matches the
original run receipts. Figure source is exojax-escape commit
`d9e8577ddcd8a588adfc50d2e36848ab4e4fa108`, with ExoJAX
`38cb2e44f153ad6d729e3253e235702de52920cf`; file hashes are retained in the original
figure-generation provenance. No active run, intermediate thermal trajectory,
compiled executable/object, JAX cache/StableHLO, PHOENIX FITS, full stellar NPZ,
incident SED, or `stellar_reference` array is distributed.

`figures/derived_profiles_spectra_public.npz` is a separately named redacted copy.
Its retained arrays are unchanged; `figures/redaction.json` records removed keys
and both hashes. The original figure-generation provenance refers to the private
unredacted NPZ and is preserved verbatim. It must not be mistaken for the hash of
the public file.

## Replay

1. Obtain and build the unmodified C23.01 archive from
   https://data.nublado.org/cloudy_releases/c23/c23.01.tar.gz (SHA256
   `a9ad2dc037e88f552389de0e483d68f54310976dee32154ed13830882aedae0b`).
   The original compiler was g++ 11.4.0. `provenance/cloudy_source.json` retains the
   original build provenance; the bundled Cloudy license files apply to patches.
2. Run `python replay/build_reference.py /path/to/c23.01/source /new/private/build`.
   This copies and patches only six translation units, then links the original
   library. The build directory must be new. Generated source and binary hashes
   are saved; the original case binary hashes remain in their receipts.
3. Retrieve the stellar input locally with `python replay/fetch_phoenix.py
   --output /private/stellar`. Copy `replay/original_build_helpers/inspect_phoenix.py`
   into that directory and execute it there to construct the local surface-flux
   NPZ. This preserves original arrays and units; its expected NPZ SHA256 is
   `df612b67bfe28f63a87e7c774d0e949aed1b0aa3a1c247f9e06de20a8e32f98c`.
   Then use the archived driver's `write_sed(output_directory, stellar_npz, 0.1)`
   to create the private `SED/incident.sed`. Its expected SHA256 is
   `5df331940067d4524223f0a108dbf6fe865b7945fedfdbe5b7cce458296f8615`.
   The original literal `model.in` is authoritative; its `nuF(nu)` normalization
   must remain unchanged. The PHOENIX retrieval metadata gives URLs, units and
   citations; it does not grant redistribution of the spectra.
4. For each fresh run directory, copy its archived `model.in`, its mapped
   `continuum_mesh.ini`, and the locally constructed `SED/incident.sed`. Set
   `CLOUDY_DATA_PATH=.:/path/to/c23.01/data` and execute the mapped binary with
   `-r model`. Keep output separate from this immutable archive. Default local
   convergence is part of these controls, not an endorsement of its adequacy.
5. The figure command and full settings are in
   `figures/figure_generation_provenance.json`: raw Cloudy zones with documented
   endpoint stubs, 128 transfer layers, 48×24 disk cells, 601 frequencies, 5 phases,
   and the archived cadence proxy. Run the original example at the pinned commit,
   remapping input paths to this archive/local stellar input. The observational
   operator is an explicit proxy, not a recovered publication reduction. Its
   weights, phases and controls are retained under `observer_inputs/`.

Validate file integrity with `sha256sum -c SHA256SUMS`. The archive source manifest
and original copy mapping are under `provenance/`. Actual temperature/wind
convergence and refined local radiative/ionization convergence require separate
future evidence; this archive cannot satisfy those requirements.

## Attribution

- Zhang et al. (2026): https://arxiv.org/abs/2606.23899v1 .
- Observations: https://doi.org/10.5281/zenodo.20707255 , CC BY 4.0;
  https://creativecommons.org/licenses/by/4.0/ . Derived cadence weights and the
  displayed observational table are attributed to that deposit.
- Cloudy C23.01: https://www.nublado.org/ ; original source/data and licenses are
  identified above. No source atomic rate tables are duplicated here.
- PHOENIX: Husser et al. (2013), https://doi.org/10.1051/0004-6361/201219058 ;
  https://phoenix.astro.physik.uni-goettingen.de/ . Stellar numerical inputs are
  fetched separately.
- The external thermal driver records the public sunbather equation/workflow;
  no thermal/wind convergence is claimed for the fixed-profile controls here.
