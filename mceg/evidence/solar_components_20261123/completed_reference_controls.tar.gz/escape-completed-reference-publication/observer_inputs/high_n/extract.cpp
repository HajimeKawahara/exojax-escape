#include "cddefines.h"
#include "cddrive.h"
#include <cmath>
#include <fstream>
#include <iomanip>

extern double H_photo_cs_log10(double, long, long, long);

int main(int argc, char** argv) {
    if (argc != 2) return 2;
    cdInit();
    std::ofstream out(argv[1]);
    out << std::setprecision(17);
    const double h = 6.62607015e-27;
    const double ev = 1.602176634e-12;
    const double center_hz = 15233.146 * 2.99792458e10;
    for (int i = 0; i < 601; ++i) {
        double velocity = -120. + 240.*i/600.;
        double frequency = center_hz * std::exp(velocity/299792.458);
        out << frequency;
        for (long n = 20; n <= 25; ++n) {
            double threshold = 13.5984345*ev/(n*n);
            double relative_energy = h*frequency/threshold;
            double cross_section = 0.;
            for (long ell = 0; ell < n; ++ell)
                cross_section += (2.*ell+1.)/(n*n)
                    * H_photo_cs_log10(relative_energy, n, ell, 1);
            out << " " << cross_section;
        }
        out << "\n";
    }
    return 0;
}
