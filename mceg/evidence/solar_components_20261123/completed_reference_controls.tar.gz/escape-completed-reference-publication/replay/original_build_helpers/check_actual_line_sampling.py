"""Export actual continuum cells addressed by C23 transitions in a point mesh."""
from pathlib import Path
import subprocess
root=Path('/tmp/cloudy-continuum-convergence-continuation/diagnostic')
source=Path('/tmp/cloudy-reference-run/c23.01/source')
s=(root/'prt_line_centers.cpp').read_text()
s=s.replace('#include "radius.h"','#include "radius.h"\n#include "rfield.h"')
s=s.replace('actual_line_centers.tsv','actual_line_samples.tsv')
s=s.replace(r'Aul_s\n',r'Aul_s\tcell_energy_ryd\tcell_width_ryd\n')
s=s.replace(r'%.17g\t%.17g\t%.17g\n',r'%.17g\t%.17g\t%.17g\t%.17g\t%.17g\n')
s=s.replace('(double)tr->Emis().Aul());','(double)tr->Emis().Aul(),rfield.anu(tr->ipCont()-1),rfield.widflx(tr->ipCont()-1));')
p=root/'prt_line_samples.cpp';p.write_text(s)
flags=['g++','-std=c++11','-O2','-fno-pie','-I'+str(source),'-DSYS_CONFIG="'+str(source/'cloudyconfig.h')+'"']
subprocess.run(flags+['-c',str(p),'-o',str(root/'prt_line_samples.o')],check=True)
subprocess.run(['g++','-no-pie','-o',str(root/'cloudy_line_samples.exe'),str(source/'maincl.o'),str(root/'cont_ffun.o'),str(root/'prt_line_samples.o'),str(source/'libcloudy.a')],check=True)
work=root.parent/'actual_point_samples_6000';work.mkdir(exist_ok=False)
base=Path('/tmp/escape-continuation-actual-centered-R6000/iteration_000')
(work/'model.in').write_text((base/'model.in').read_text().replace('iterate to convergence','iterate 2').rstrip()+'\nstop zone 1\n')
(work/'SED').symlink_to(base/'SED',target_is_directory=True)
(work/'continuum_mesh.ini').symlink_to(base/'continuum_mesh.ini')
with (work/'console.txt').open('w') as f:
 subprocess.run([str(root/'cloudy_line_samples.exe'),'-r','model'],cwd=work,stdout=f,stderr=subprocess.STDOUT,check=True)
print(work)
