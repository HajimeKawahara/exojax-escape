"""Inspect a public PHOENIX input without modifying its surface-flux normalization."""
from pathlib import Path
from hashlib import sha256
import json
import numpy as np
from astropy.io import fits

ROOT=Path(__file__).resolve().parent
h,c,k=6.62607015e-27,2.99792458e10,1.380649e-16
w=np.asarray(fits.getdata(ROOT/'wavelength.fits'),dtype=float)
f=np.asarray(fits.getdata(ROOT/'phoenix10000.fits'),dtype=float)
header=fits.getheader(ROOT/'phoenix10000.fits')
assert w.shape==f.shape and np.all(np.diff(w)>0) and np.all(np.isfinite(f)&(f>=0))
lam=w*1e-8
frequency=c/lam
flux_nu=f*lam**2/c
np.savez_compressed(ROOT/'phoenix10000_surface_flux.npz',frequency_hz=frequency[::-1],surface_flux_nu=flux_nu[::-1])
def bb(x):
    x=np.asarray(x)*1e-8
    return np.pi*2*h*c*c/x**5/np.expm1(h*c/(x*k*1e4))
points={}
for label,center in [('Lya',1215.6698984551463),('Lyb',1025.7220860452012),('Halpha',6564.6)]:
    points[label]={'center_vacuum_angstrom':center,'offset_velocity_ratios':{}}
    for velocity in [0,30,100,300,1000]:
        x=center*(1+np.array([-velocity,velocity])/299792.458)
        points[label]['offset_velocity_ratios'][str(velocity)]=(np.interp(x,w,f)/bb(x)).tolist()
    inside=abs(w/center-1)*299792.458<100
    points[label]['native_spacing_angstrom']=float(np.median(np.diff(w[inside])))
    points[label]['native_minmax_ratio_within100kms']=[float(np.min(f[inside]/bb(w[inside]))),float(np.max(f[inside]/bb(w[inside])))]
integrals={}
for label,edge in [('Lyman',911.7534701),('Balmer',3647.0)]:
    inside=w<edge
    # Include the exact edge by linear interpolation on the tabulation.
    x=np.r_[w[inside],edge];y=np.r_[f[inside],np.interp(edge,w,f)]
    integrals[label]={'covered_surface_flux':float(np.trapezoid(y,x*1e-8)),
        'covered_incident_equivalent_flux_W0p025':float(.1*np.trapezoid(y,x*1e-8)),
        'covered_blackbody_incident_equivalent_flux_W0p025':float(.1*np.trapezoid(bb(x),x*1e-8))}
report={'scope':'Public PHOENIX proxy for a 10000K/logg4 solar star, not an observed stellar spectrum or exact Zhang input.',
    'urls':{'wavelength':'https://ftp.gwdg.de/pub/misc/phoenix/v2.0/HiResFITS/WAVE_PHOENIX-ACES-AGSS-COND-2011.fits',
    'flux':'https://ftp.gwdg.de/pub/misc/phoenix/v2.0/HiResFITS/PHOENIX-ACES-AGSS-COND-2011/Z-0.0/lte10000-4.00-0.0.PHOENIX-ACES-AGSS-COND-2011-HiRes.fits'},
    'documentation':{'homepage':'https://phoenix.astro.physik.uni-goettingen.de/',
    'files':'https://phoenix.astro.physik.uni-goettingen.de/spectra/',
    'publication':'https://doi.org/10.1051/0004-6361/201219058'},
    'license_note':'Official public library requests citation to Husser et al. (2013); no explicit data-redistribution license was found on the inspected homepage/spectra pages. Keep raw and derived numerical tables local; distribute fetch instructions and analysis outputs rather than assume CC licensing.',
    'header':{key:header.get(key) for key in ['BUNIT','PHXTEFF','PHXLOGG','PHXM_H','PHXALPHA','PHXVER','PHXEOS','PHXXI_L','PHXXI_N']},
    'units':{'wavelength':'vacuum Angstrom, per Husser et al. (2013)','raw_flux':'surface F_lambda erg s^-1 cm^-2 cm^-1','derived_flux':'surface F_nu erg s^-1 cm^-2 Hz^-1'},
    'conversion':'F_nu = F_lambda(per cm) * lambda_cm**2 / c; J_nu = W * F_nu / pi under the same uniform-disk dilution convention as J=W B; occupation = c**2*J_nu/(2*h*nu**3). No radius/distance or bolometric renormalization is applied to the stored surface flux.',
    'range_angstrom':[float(w.min()),float(w.max())],'count':len(w),'finite_nonnegative':True,
    'surface_integrated_flux':float(np.trapezoid(f,lam)),
    'sigma_Teff4':5.670374419e-5*1e16,
    'bolometric_ratio':float(np.trapezoid(f,lam)/(5.670374419e-5*1e16)),
    'covered_integrals':integrals,'line_diagnostics':points,
    'tail_policy':'Unspecified in this data file. Caller must provide explicit extrapolation/completion and sensitivity checks. Do not endpoint-clamp.',
    'sha256':{p.name:sha256(p.read_bytes()).hexdigest() for p in [ROOT/'wavelength.fits',ROOT/'phoenix10000.fits',ROOT/'phoenix10000_surface_flux.npz']}}
(ROOT/'metadata.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:report[key]for key in ['range_angstrom','bolometric_ratio','covered_integrals','line_diagnostics','sha256']},indent=2))
