"""Read exact Cloudy transition centers without changing any coefficient."""
from pathlib import Path
import subprocess,shutil
source=Path('/tmp/cloudy-reference-run/c23.01/source');root=Path('/tmp/cloudy-continuum-convergence-continuation/diagnostic')
text=(source/'prt_lines_general.cpp').read_text()
text=text.replace('#include "lines_service.h"','#include "lines_service.h"\n#include "radius.h"')
anchor='\t// cooling due to database species\n'
assert text.count(anchor)==1
block=r'''
    static bool centers_exported=false;
    if (LineSave.ipass==1 && nzone==1 && !centers_exported) {
        FILE* out=open_data("actual_line_centers.tsv","w");
        ASSERT(out!=NULL);
        fprintf(out,"kind\tZ\tstage\tlower\tupper\twavenumber_cm\tenergy_ryd\tAul_s\n");
        for(long species=0;species<nSpecies;++species) {
            const int z=dBaseStates[species][0].nelem();
            const int stage=dBaseStates[species][0].IonStg();
            if (stage>3 || (z!=6 && z!=7 && z!=8 && z!=12 && z!=13 && z!=14 && z!=20 && z!=25 && z!=26))continue;
            for(auto tr=dBaseTrans[species].begin();tr!=dBaseTrans[species].end();++tr) {
                if(tr->ipCont()<=0 || tr->EnergyRyd()<=.016 || tr->EnergyRyd()>=1.83)continue;
                fprintf(out,"database\t%d\t%d\t%d\t%d\t%.17g\t%.17g\t%.17g\n",z,stage,tr->ipLo(),tr->ipHi(),(double)tr->EnergyWN(),tr->EnergyRyd(),(double)tr->Emis().Aul());
            }
        }
        for(int seq=0;seq<2;++seq)for(int element=seq;element<2;++element) {
            for(auto tr=iso_sp[seq][element].tr->begin();tr!=iso_sp[seq][element].tr->end();++tr) {
                if(tr->ipCont()<=0 || tr->EnergyRyd()<=.016 || tr->EnergyRyd()>=1.83)continue;
                fprintf(out,"iso\t%d\t%d\t%d\t%d\t%.17g\t%.17g\t%.17g\n",element+1,element-seq+1,tr->ipLo(),tr->ipHi(),(double)tr->EnergyWN(),tr->EnergyRyd(),(double)tr->Emis().Aul());
            }
        }
        fclose(out);centers_exported=true;
    }
'''
(root/'prt_line_centers.cpp').write_text(text.replace(anchor,block+anchor))
flags=['g++','-std=c++11','-O2','-fno-pie','-I'+str(source),'-DSYS_CONFIG="'+str(source/'cloudyconfig.h')+'"']
subprocess.run(flags+['-c',str(root/'prt_line_centers.cpp'),'-o',str(root/'prt_line_centers.o')],check=True)
subprocess.run(['g++','-no-pie','-o',str(root/'cloudy_line_centers.exe'),str(source/'maincl.o'),str(root/'cont_ffun.o'),str(root/'prt_line_centers.o'),str(source/'libcloudy.a')],check=True)
work=root.parent/'actual_line_export';work.mkdir(exist_ok=False)
base=Path('/tmp/escape-solar-default-atom-control/iteration_000')
(work/'model.in').write_text((base/'model.in').read_text().replace('iterate to convergence','iterate 2').rstrip()+'\nstop zone 1\n')
(work/'SED').symlink_to(base/'SED',target_is_directory=True)
print('Reporting-only exact line-center exporter ready.')
