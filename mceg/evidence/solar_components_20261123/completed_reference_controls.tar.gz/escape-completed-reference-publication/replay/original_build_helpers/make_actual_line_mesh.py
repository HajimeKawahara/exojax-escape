"""Anchor C23 continuum samples to declared metal lines without changing the SED.

This is a numerical reference control, not an atomic-data or radiation model.
The independent globally refined reference remains the comparison target.
"""
from hashlib import sha256
from pathlib import Path
import json
import numpy as np

ROOT=Path('/tmp/cloudy-continuum-convergence-continuation')
TABLE=ROOT/'actual_line_export/actual_line_centers.tsv'
MAJOR=np.array([.249865,.999466,.999907,1.807139])
raw=np.genfromtxt(TABLE, delimiter='\t', names=True, dtype=None, encoding='utf8')
centers=np.unique(raw['energy_ryd'])
metadata={'scope':'Numerical sampling at actual C23 radiative transition frequencies. No changed SED, rate, abundance, continuum guard, or radiative-transfer closure.',
          'table_sha256':sha256(TABLE.read_bytes()).hexdigest(), 'line_count':len(raw), 'unique_centers':len(centers),
          'transition_energy':'Actual C23 EnergyRyd exported from initialized transition objects; includes radiative wavelengths, not inferred level differences.',
          'half_width_relative':1e-8, 'meshes':{}}
for resolving in (6000,12000,24000):
 selected=centers[(centers<1.0007)|(centers>1.0013)]
 # C23 merges nearby user edges with major ionization edges. Keep point cells
 # away from that merging neighborhood instead of perturbing a guard/edge.
 keep=np.all(abs(selected[:,None]/MAJOR[None,:]-1)>2/resolving,axis=1)
 selected=selected[keep]
 eps=1e-8
 groups=[]
 for center in selected:
  lo,hi=center*(1-eps),center*(1+eps)
  if groups and lo<groups[-1][1]:groups[-1][1]=max(groups[-1][1],hi)
  else:groups.append([lo,hi])
 # Explicit boundaries around the one retained O I threshold cell prevent
 # unrelated high-energy mesh phase changes in its width-sensitivity control.
 entries=[(.016,300.),(1.0007,float(resolving)),(1.0013,1000.),(1.002,float(resolving)),(1.83,float(resolving))]
 entries.extend((float(edge),float(resolving)) for edge in MAJOR)
 max_offset=0.
 for lo,hi in groups:
  entries.extend([(lo,float(resolving)),(hi,0.5/np.log(hi/lo))])
  inside=selected[(selected>=lo)&(selected<=hi)]
  max_offset=max(max_offset,float(np.max(abs((hi+lo)/(2*inside)-1))))
 entries.sort()
 text=['10 08 08','# Unchanged stellar SED; actual C23 line-centered continuum sampling.']
 text.extend(f'{edge:.17g} {power:.17g}' for edge,power in entries)
 old=Path('/tmp/cloudy-continuum-mesh-controls/continuum_mesh_R60000_oi.ini').read_text().splitlines()
 start=next(i for i,line in enumerate(old) if line.startswith('50.'))
 text.extend(old[start:])
 path=ROOT/f'continuum_mesh_actual_centered_R{resolving}.ini'
 path.write_text('\n'.join(text)+'\n')
 metadata['meshes'][str(resolving)]={'path':str(path),'sha256':sha256(path.read_bytes()).hexdigest(),'retained_unique_centers':len(selected),'point_cells':len(groups),'maximum_relative_center_offset':max_offset,'excluded_near_major_edges':int((~keep).sum())}
(ROOT/'actual_line_mesh_provenance.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata,indent=2))
