"""Anchor C23 continuum samples to declared metal lines without changing the SED.

This is a numerical reference control, not an atomic-data or radiation model.
The independent globally refined reference remains the comparison target.
"""
from hashlib import sha256
from pathlib import Path
import json
import numpy as np

ROOT=Path('/tmp/cloudy-continuum-convergence-continuation')
ATOMS=Path('/tmp/escape-coupled-atmosphere/src/escape/data/metal_atoms.npz')
DATA=Path('/tmp/cloudy-reference-run/c23.01/source/physconst_template.h')
# C23.01 CODATA2018 Rydberg in reciprocal cm (physconst_template.h).
RYD_INF=109737.31568160
MAJOR=np.array([.249865,.999466,.999907,1.807139])
raw=np.load(ATOMS)
lines=[]
for species in sorted({key.split('__')[0] for key in raw.files}):
 energy=raw[species+'__energy_wavenumber'];a=raw[species+'__spontaneous']
 hi,lo=np.where(a>0)
 # C23 TransitionProxy stores EnergyWN as realnum (float32 in this build).
 wn=np.asarray(energy[hi]-energy[lo],dtype=np.float32).astype(float)
 for lower,upper,value in zip(lo,hi,wn/RYD_INF):
  if .016<value<1.83:lines.append((species,int(lower),int(upper),float(value)))
centers=np.unique([row[-1] for row in lines])
metadata={'scope':'Numerical line-center sampling control. No changed SED, rate, abundance, continuum guard, or radiative-transfer closure.',
          'atomic_grid_sha256':sha256(ATOMS.read_bytes()).hexdigest(),'C23_transition_energy':'float32(upper_wn-lower_wn)/RYD_INF; validated separately against printed C23 line samples',
          'species':sorted({row[0] for row in lines}), 'line_count':len(lines), 'unique_centers':len(centers),'half_width_relative':1e-8,'meshes':{}}
np.savez(ROOT/'declared_metal_line_centers.npz',species=np.array([r[0] for r in lines]),lower=np.array([r[1] for r in lines]),upper=np.array([r[2] for r in lines]),energy_ryd=np.array([r[3] for r in lines]))
for resolving in (6000,12000,24000):
 selected=centers[(centers<1.0007)|(centers>1.0013)]
 # C23 merges nearby user edges with major ionization edges. Keep point cells
 # away from that merging neighborhood instead of perturbing a guard/edge.
 keep=np.all(abs(selected[:,None]/MAJOR[None,:]-1)>2/resolving,axis=1)
 selected=selected[keep]
 eps=1e-8
 groups=[]
 for center in selected:
  lo,hi=center*(1-eps),center*(1+eps)
  if groups and lo<groups[-1][1]:groups[-1][1]=max(groups[-1][1],hi)
  else:groups.append([lo,hi])
 # Explicit boundaries around the one retained O I threshold cell prevent
 # unrelated high-energy mesh phase changes in its width-sensitivity control.
 entries=[(.016,300.),(1.0007,float(resolving)),(1.0013,1000.),(1.002,float(resolving)),(1.83,float(resolving))]
 entries.extend((float(edge),float(resolving)) for edge in MAJOR)
 max_offset=0.
 for lo,hi in groups:
  entries.extend([(lo,float(resolving)),(hi,0.5/np.log(hi/lo))])
  inside=selected[(selected>=lo)&(selected<=hi)]
  max_offset=max(max_offset,float(np.max(abs((hi+lo)/(2*inside)-1))))
 entries.sort()
 text=['10 08 08','# Unchanged stellar SED; declared C23 metal line-centered continuum sampling.']
 text.extend(f'{edge:.17g} {power:.17g}' for edge,power in entries)
 old=Path('/tmp/cloudy-continuum-mesh-controls/continuum_mesh_R60000_oi.ini').read_text().splitlines()
 start=next(i for i,line in enumerate(old) if line.startswith('50.'))
 text.extend(old[start:])
 path=ROOT/f'continuum_mesh_metal_centered_R{resolving}.ini'
 path.write_text('\n'.join(text)+'\n')
 metadata['meshes'][str(resolving)]={'path':str(path),'sha256':sha256(path.read_bytes()).hexdigest(),'retained_unique_centers':len(selected),'point_cells':len(groups),'maximum_relative_center_offset':max_offset,'excluded_near_major_edges':int((~keep).sum())}
(ROOT/'line_mesh_provenance.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata,indent=2))
