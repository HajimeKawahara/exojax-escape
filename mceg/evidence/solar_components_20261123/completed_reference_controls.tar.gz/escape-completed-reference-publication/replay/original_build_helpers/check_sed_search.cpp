// Independent interval checks for the numerical C23 TABLE SED search patch.
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <limits>
#include <random>
#include <stdexcept>
#include <vector>
using Table=std::vector<double>;
long linear(const Table& a,double q) {
    for(long i=1;i<(long)a.size();++i) if(q<a[i]) return i;
    return a.size();
}
long binary(const Table& a,double q) {
    long left=1,right=a.size();
    while(left<right) {
        const long middle=left+(right-left)/2;
        if(q<a[middle])right=middle;else left=middle+1;
    }
    return left;
}
void require(bool yes) {if(!yes)throw std::runtime_error("interval mismatch");}
int main(int argc,char** argv) {
    if(argc!=2)return 2;
    std::ifstream in(argv[1],std::ios::binary|std::ios::ate);
    const auto bytes=in.tellg();in.seekg(0);
    Table a(bytes/sizeof(double));in.read(reinterpret_cast<char*>(a.data()),bytes);
    require(a.size()>2 && std::is_sorted(a.begin(),a.end()));
    // Exhaustively test every real SED knot, equality tie, and adjacent floats.
    // Oracle is an independent single forward traversal of ordered queries.
    long cursor=1;size_t knot_checks=0;
    for(double center:a) {
        for(double q:{std::nextafter(center,-INFINITY),center,std::nextafter(center,INFINITY)}) {
            while(cursor<(long)a.size() && !(q<a[cursor]))++cursor;
            require(binary(a,q)==cursor);++knot_checks;
        }
    }
    // Literal original loop on non-monotonic queries, ties and all boundaries.
    std::mt19937_64 random(260623899);
    std::uniform_real_distribution<double> uniform(std::log(a.front())-1,std::log(a.back())+1);
    size_t original_checks=0;
    for(int i=0;i<2000;++i) {
        const double q= i%3==0?a[random()%a.size()]:std::exp(uniform(random));
        require(binary(a,q)==linear(a,q));++original_checks;
    }
    for(double q:{-double(INFINITY),double(INFINITY),double(NAN),0.,a.front(),a.back(),a.front()*1.000001}) {
        require(binary(a,q)==linear(a,q));++original_checks;
    }
    // Tiny tables exercise every interval and tie, independently of real sampling.
    for(long n=2;n<100;++n) {
        Table small(n);for(long i=0;i<n;++i)small[i]=std::exp(i*.3);
        for(long i=0;i<n;++i)for(double q:{std::nextafter(small[i],-INFINITY),small[i],std::nextafter(small[i],INFINITY)}) {
            require(binary(small,q)==linear(small,q));++original_checks;
        }
    }
    std::printf("{\"passed\":true,\"sed_points\":%zu,\"all_knot_tie_adjacent_checks\":%zu,\"literal_original_loop_checks\":%zu}\n",a.size(),knot_checks,original_checks);
}
