"""Build the two numerical C23 controls from an already compiled C23.01 tree.

Only private copies are changed. This script does not download or alter rates,
remove guards, or alter the incident spectrum. Compiler output is not evidence of
scientific convergence; retain the original reference limitations.
"""
from pathlib import Path
from hashlib import sha256
import argparse
import json
import shutil
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('cloudy_source', type=Path, help='C23.01/source with maincl.o and libcloudy.a')
parser.add_argument('output', type=Path, help='New private build directory')
args = parser.parse_args()
source, output = args.cloudy_source.resolve(), args.output.resolve()
output.mkdir(parents=True, exist_ok=False)
archive = Path(__file__).resolve().parents[1]
names = ['cont_ffun', 'radius_next', 'save_special', 'save_do', 'heat_save', 'rt_line_one']
for name in names:
    shutil.copy2(source / (name + '.cpp'), output / (name + '.cpp'))
for patch in ['sed_search.patch', 'spatial_refinement.patch', 'reporting_precision.patch', 'exact_atomic_incident_pump.patch']:
    subprocess.run(['patch', '--batch', '--fuzz=0', '-p1', '-i', str(archive / 'numerical_patches' / patch)], cwd=output, check=True)
for name in names:
    subprocess.run(['g++', '-std=c++11', '-O3' if name == 'cont_ffun' else '-O2',
                    '-fno-pie', '-I' + str(source), '-DSYS_CONFIG="' + str(source / 'cloudyconfig.h') + '"',
                    '-c', str(output / (name + '.cpp')), '-o', str(output / (name + '.o'))], check=True)
common = ['cont_ffun', 'save_special', 'save_do', 'heat_save', 'radius_next']
for binary, objects in [('cloudy_union.exe', common), ('cloudy_exact_atomic.exe', common + ['rt_line_one'])]:
    subprocess.run(['g++', '-no-pie', '-o', str(output / binary), str(source / 'maincl.o'),
                    *[str(output / (name + '.o')) for name in objects], str(source / 'libcloudy.a')], check=True)
files = [source / 'libcloudy.a', *[source / (n + '.cpp') for n in names],
         *[output / (n + '.cpp') for n in names], *output.glob('*.exe')]
(output / 'build_provenance.json').write_text(json.dumps({
    'compiler': subprocess.check_output(['g++', '--version'], text=True).splitlines()[0],
    'hashes': {str(p): sha256(p.read_bytes()).hexdigest() for p in files}}, indent=2) + '\n')
