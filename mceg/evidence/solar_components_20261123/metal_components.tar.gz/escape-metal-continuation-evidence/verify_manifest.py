"""Verify archive integrity and explicitly reject unapproved NPZ content."""
from pathlib import Path
import hashlib,json
import numpy as np
root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
for row in manifest['files']:
 p=root/row['path']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['path']
 if p.suffix=='.npz':
  with np.load(p,allow_pickle=False) as a:
   assert set(a.files)==set(row['arrays'])
   for name in a.files:
    assert not any(x in name.lower() for x in ['stellar','surface_flux','intensity']),name
    assert name != 'sed' and not name.startswith('sed_'),name
    assert not a[name].dtype.hasobject
    assert list(a[name].shape)==row['arrays'][name]['shape']
    assert a[name].dtype.str==row['arrays'][name]['dtype']
assert not any(p.suffix in ['.pyc','.so','.exe','.fits'] or '__pycache__' in p.parts for p in root.rglob('*'))
print(f"Verified {len(manifest['files'])} files and {sum('arrays' in r for r in manifest['files'])} explicit NPZ inventories.")
