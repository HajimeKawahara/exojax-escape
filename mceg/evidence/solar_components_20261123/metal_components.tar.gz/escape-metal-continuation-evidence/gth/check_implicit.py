from pathlib import Path
import time,json,ast,hashlib
import jax,jax.numpy as jnp,numpy as np
from implicit_se import solve
from escape.metal_atom import populations
jax.config.update('jax_enable_x64',True)
cases=[('three',np.array([[0.,3.,.2],[2.,0.,4.],[1.,5.,0.]])),('stiff',np.array([[0.,1e-12,1e6],[1e-14,0.,1e-20],[1e9,1e-20,0.]]))]
report=[]
for label,base in cases:
 rate=jnp.asarray(base);perturb=jnp.array(np.random.default_rng(1).normal(size=base.shape))*rate;weight=jnp.arange(len(rate))+.17
 old=lambda value:populations(rate*jnp.exp(value*perturb/jnp.where(rate>0,rate,1.)),jnp.exp(.2*value))
 new=lambda value:solve(rate*jnp.exp(value*perturb/jnp.where(rate>0,rate,1.)),jnp.exp(.2*value))
 value,derivative=jax.jvp(new,(0.,),(1.,));reference=jax.jvp(old,(0.,),(1.,))[1]
 reverse=jax.jit(jax.grad(lambda x:jnp.dot(new(x),weight)))(0.)
 print(label,np.asarray(value),np.asarray(derivative),np.asarray(reference),float(reverse),flush=True)
 np.testing.assert_allclose(value,old(0.),rtol=1e-14,atol=1e-30)
 np.testing.assert_allclose(derivative,reference,rtol=1e-10,atol=1e-20)
 np.testing.assert_allclose(reverse,reference@weight,rtol=1e-10,atol=1e-20)
 report.append({'case':label,'derivative_relative_error':float(jnp.linalg.norm(derivative-reference)/jnp.linalg.norm(reference))})
Path('/tmp/escape-large-fe-validation/implicit_small.json').write_text(json.dumps(report,indent=2)+'\n')
