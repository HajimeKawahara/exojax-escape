"""Prototype only: stable GTH implicit stationary-population derivatives."""
import jax
import jax.numpy as jnp


def factors(rate):
    count=rate.shape[0];index=jnp.arange(count)
    def step(k,state):
        reduced,inverse=state; current=count-1-k;active=index<current
        reciprocal=1/jnp.sum(jnp.where(active,reduced[current],0.))
        increment=reduced[:,current,None]*reduced[current,None,:]*reciprocal
        return reduced+jnp.where(active[:,None]&active[None,:],increment,0.),inverse.at[current].set(reciprocal)
    return jax.lax.fori_loop(0,count-1,step,(rate,jnp.ones(count)))


def normalized(reduced,inverse):
    index=jnp.arange(len(inverse))
    def step(k,p):return p.at[k].set(inverse[k]*jnp.sum(jnp.where(index<k,p*reduced[:,k],0.)))
    p=jax.lax.fori_loop(1,len(index),step,jnp.zeros(len(index)).at[0].set(1.))
    return p/p.sum()


@jax.custom_jvp
def solve(rate,density):
    off=rate-jnp.diag(jnp.diag(rate))
    return density*normalized(*factors(off))


@solve.defjvp
def tangent(primals,tangents):
    rate,density=primals;change,ddensity=tangents
    off=rate-jnp.diag(jnp.diag(rate));change=change-jnp.diag(jnp.diag(change))
    probability=solve(rate,1.)
    anchor=jnp.argmax(probability);order=jnp.arange(len(probability)).at[0].set(anchor).at[anchor].set(0)
    reduced,inverse=factors(off[order[:,None],order[None,:]])
    # Q^T dp = -dQ^T p. Eliminate the signed forcing with the positive
    # GTH Schur coefficients, avoiding differences of large diagonal sums.
    rhs=probability*jnp.sum(change,axis=1)-probability@change
    rhs=rhs[order];index=jnp.arange(len(order));count=len(index)
    def eliminate(k,b):
        current=count-1-k
        return b+jnp.where(index<current,reduced[current]*inverse[current]*b[current],0.)
    b=jax.lax.fori_loop(0,count-1,eliminate,rhs)
    def substitute(k,x):
        incoming=jnp.sum(jnp.where(index<k,x*reduced[:,k],0.))
        return x.at[k].set(inverse[k]*(incoming-b[k]))
    particular=jax.lax.fori_loop(1,count,substitute,jnp.zeros(count))[order]
    derivative=particular-probability*particular.sum()
    return density*probability,density*derivative+ddensity*probability
