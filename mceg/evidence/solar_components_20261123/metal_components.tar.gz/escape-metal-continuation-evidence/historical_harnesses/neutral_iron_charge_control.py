"""Conditional Saha electron response to the omitted neutral-Fe partition."""
from pathlib import Path
import json
import numpy as np
from scipy.optimize import brentq
from escape.metal_atom import load_metal_atom
from escape.metal_rates import load_metal_rates
from escape.metal_network import ATOMS,ELEMENTS
from escape.solar import SOLAR_ABUNDANCE
from escape.hydrogen_atom import make_hydrogen_atom
h,k,me,c=6.62607015e-27,1.380649e-16,9.1093837015e-28,2.99792458e10
v=(h*h/(2*np.pi*me*k))**1.5;vh=(h*h/(2*np.pi*9.1093837139e-28*k))**1.5
r=Path('/tmp/escape-large-fe-validation');nr=[]
for line in Path('/tmp/cloudy-causal-rates/data/stout/fe/fe_1/fe_1.nrg').read_text().splitlines()[1:]:
 if line.startswith('*'):break
 f=line.split();nr.append([float(f[1]),float(f[2])])
nr=np.array(nr);d=load_metal_rates();H=make_hydrogen_atom(15)
atoms={(z,q):load_metal_atom(label,levels=716 if label=='Fe II' else None) for label,z,q in ATOMS}
results=[]
for t in [4500.,6500.]:
 partitions={(z,q):np.sum(np.array(a.weight)*np.exp(-h*c*np.array(a.energy_wavenumber)/(k*t))) for (z,q),a in atoms.items()}
 FeI=np.sum(nr[:,1]*np.exp(-h*c*nr[:,0]/(k*t)))
 S=np.array(H.statistical_weights)/2*vh/t**1.5*np.exp(np.array(H.ionization_energy_erg)/(k*t))
 for nh in [4.9e14,1e15,4e16]:
  outcomes=[]
  for corrected in [False,True]:
   part=dict(partitions)
   if corrected:part[26,0]=FeI
   ionic=[]
   for z,mass in [(2,4.)]+list(ELEMENTS):
    coeff=[]
    for q in range(2):
     w=d['ground_weight'][z,q];fit=d['photo'][z,q];threshold=float(fit.threshold_ev[int(fit.outer_shell)-1])*1.602176634e-12
     coeff.append(2*t**1.5/v*part.get((z,q+1),w[1])/part.get((z,q),w[0])*np.exp(-threshold/(k*t)))
    ionic.append((z,np.array(coeff)))
   def charge(logne,ret=False):
    ne=np.exp(logne);p=nh/(1+ne*S.sum());ions={}
    for z,a in ionic:
     f=np.array([1.,a[0]/ne,np.prod(a)/ne**2]);f/=f.sum();ions[z]=nh*(.1 if z==2 else SOLAR_ABUNDANCE[z])*f
    total=p+sum(a@[0.,1.,2.] for a in ions.values())
    return (ne,p,ions) if ret else (ne-total)/nh
   root=brentq(charge,np.log(1e-20),np.log(3*nh),xtol=1e-13);ne,p,ions=charge(root,True)
   outcomes.append({'electron_cm3':ne,'FeI_fraction':ions[26][0]/ions[26].sum(),'Hminus_LTE_proxy':ne*(nh-p)})
  results.append({'temperature_k':t,'nH_cm3':nh,'ground_only_FeI':outcomes[0],'partition_FeI':outcomes[1],'electron_relative_change':outcomes[1]['electron_cm3']/outcomes[0]['electron_cm3']-1,'Hminus_LTE_proxy_relative_change':outcomes[1]['Hminus_LTE_proxy']/outcomes[0]['Hminus_LTE_proxy']-1})
report={'scope':'Scalar LTE charge closure with all nine retained elements, H15 and ground He, no molecules; changing only neutral-Fe partition. No atmosphere or thermal/wind response.', 'results':results}
(r/'neutral_iron_charge_control.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
