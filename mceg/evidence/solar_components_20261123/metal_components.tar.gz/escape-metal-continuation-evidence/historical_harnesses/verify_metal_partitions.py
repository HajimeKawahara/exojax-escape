"""Independent scalar sum over original source files, not the extraction parser."""
import jax
jax.config.update('jax_enable_x64',True)
from escape.metal_rates import load_metal_partitions,log_metal_partition
import numpy as np,json,math,hashlib
from pathlib import Path
repo=Path('/tmp/escape-coupled-atmosphere');meta=json.loads((repo/'src/escape/data/metal_provenance.json').read_text());data=load_metal_partitions();rows=[]
for item in meta['partition_stages']:
 text=(Path('/tmp/cloudy-causal-rates')/item['source']).read_text().splitlines();pairs=[]
 for line in text:
  if line.startswith('*'):break
  fields=line.split()
  if len(fields)<3 or not fields[0].isdigit() or fields[:3]==['17','09','05']:continue
  if item['source'].endswith('.elvlc'):
   energy,weight=float(line[40:55]),float(line[37:40])
   if energy<=0 and int(fields[0])!=1:continue
  else:energy,weight=float(fields[1]),float(fields[2])
  if energy<item['ionization_wavenumber']:pairs.append((energy,weight))
 for t in [4000.,4500.,8000.,14000.]:
  expected=math.fsum(g*math.exp(-6.62607015e-27*2.99792458e10*e/(1.380649e-16*t)) for e,g in pairs)
  value=float(np.exp(log_metal_partition(t,item['atomic_number'],item['charge'],data)))
  rows.append(dict(z=item['atomic_number'],q=item['charge'],temperature_k=t,reference=expected,actual=value,relative_error=value/expected-1))
print([x for x in rows if x['z'] in [26,14,13] and x['q']==0 and x['temperature_k']==4500.])
report={'scope':'Independent scalar math.fsum of original C23 bound-level source tables versus packaged JAX log-partition; finite-bound-level numerical verification only.','cases':rows,'max_relative_error':max(abs(x['relative_error']) for x in rows),'data_sha256':hashlib.sha256((repo/'src/escape/data/metal_partitions.npz').read_bytes()).hexdigest()}
assert report['max_relative_error']<2e-14
Path('/tmp/escape-large-fe-validation/metal_partition_verification.json').write_text(json.dumps(report,indent=2)+'\n');print('max relative error',report['max_relative_error'])
