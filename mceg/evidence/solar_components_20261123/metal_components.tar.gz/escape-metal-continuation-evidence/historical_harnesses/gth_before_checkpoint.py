import jax
import jax.numpy as jnp

def populations(total_rate, species_density):
    """Solve closed local SE by positive GTH elimination, rates [from,to].

    Grassmann, Taksar & Heyman (1985), Operations Research 33, 1107;
    the same rearrangement is used in C23.01 atom_leveln.cpp:gthsolve.
    This JAX implementation avoids subtracting large outgoing sums in a
    nearly singular normalized rate matrix. Irreducible nonnegative rates
    are required; externally supplied ionization sources/sinks are excluded.
    """
    rate = total_rate - jnp.diag(jnp.diag(total_rate))
    size = rate.shape[0]
    indices = jnp.arange(size)

    def eliminate(step, state):
        reduced, inverse = state
        current = size - 1 - step
        active = indices < current
        reciprocal = 1 / jnp.sum(jnp.where(active, reduced[current, :], 0.0))
        update = reduced[:, current, None] * reduced[current, None, :] * reciprocal
        reduced = reduced + jnp.where(active[:, None] & active[None, :], update, 0.0)
        return reduced, inverse.at[current].set(reciprocal)

    reduced, inverse = jax.lax.fori_loop(0, size - 1, eliminate, (rate, jnp.ones(size)))

    def substitute(current, values):
        incoming = jnp.sum(
            jnp.where(indices < current, values * reduced[:, current], 0.0)
        )
        return values.at[current].set(inverse[current] * incoming)

    relative = jax.lax.fori_loop(1, size, substitute, jnp.zeros(size).at[0].set(1.0))
    return species_density * relative / relative.sum()
