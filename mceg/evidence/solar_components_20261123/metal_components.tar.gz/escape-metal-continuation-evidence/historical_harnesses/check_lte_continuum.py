"""Quantify C23-style heavy ground-continuum departures from Kirchhoff in LTE."""
import jax
jax.config.update('jax_enable_x64',True)
from escape.metal_rates import *
from escape.metal_atom import load_metal_atom
from escape.metal_network import ATOMS
from escape.hydrogen_continuum import planck_intensity_hz
from pathlib import Path
import json,numpy as np,hashlib
rates=load_metal_rates();part=load_metal_partitions()
atoms={(z,q):load_metal_atom(label,levels=716 if label=='Fe II' else None) for label,z,q in ATOMS}
rows=[]
for t in [4500.,6500.]:
 def U(z,q):
  if (z,q) in atoms:
   a=atoms[z,q];return float(jnp.sum(a.weight*jnp.exp(-PLANCK*C*a.energy_wavenumber/(KB*t))))
  return float(jnp.exp(log_metal_partition(t,z,q,part)))
 for z,q in [(26,0),(26,1),(14,0),(13,0),(12,0),(20,0)]:
  fit=rates['photo'][z,q];energy=float(fit.threshold_ev[fit.outer_shell-1])*EV_ERG;nu=jnp.array([1.05*energy/PLANCK]);g=rates['ground_weight'][z,q]
  thermal=(PLANCK*PLANCK/(2*np.pi*ME*KB*t))**1.5
  ne=1e11;nq=1e8;nnext=nq*2/thermal*U(z,q+1)/U(z,q)*np.exp(-energy/(KB*t))/ne
  cross=photoionization_cross_sections(fit,PLANCK*nu/EV_ERG)[:,fit.outer_shell-1]
  eta=ground_recombination_continuum(fit,g[0]/g[1],t,ne,nnext,nu)
  ratio=float((eta/(nq*cross*planck_intensity_hz(nu,t)))[0])
  expected=g[0]/g[1]*U(z,q+1)/U(z,q)*(1-np.exp(-PLANCK*float(nu[0])/(KB*t)))
  np.testing.assert_allclose(ratio,expected,rtol=1e-13)
  rows.append(dict(z=z,q=q,temperature_k=t,eta_over_kappa_B=ratio,expected=expected))
root=Path('/tmp/escape-coupled-atmosphere');out={'scope':'Isolated ground valence-continuum component at partition-Saha populations, nu=1.05 times threshold; excludes extra excited PI, RR pseudo lines and other species. This diagnoses a shared C23 continuum approximation, not an observer or atmosphere effect.','cases':rows,'source_sha256':hashlib.sha256((root/'src/escape/metal_rates.py').read_bytes()).hexdigest()}
Path('/tmp/escape-large-fe-validation/lte_continuum_audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(rows,indent=2))
