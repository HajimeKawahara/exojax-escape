"""Independent scalar charge-neutral Saha review of the selected LTE boundary."""
from pathlib import Path
import hashlib
import json
import numpy as np
from scipy.optimize import brentq
import jax
import jax.numpy as jnp
from escape.solar import SolarCompositionModel

jax.config.update('jax_enable_x64',True)
h,k,me,c = 6.62607015e-27,1.380649e-16,9.1093837015e-28,2.99792458e10
volume=(h*h/(2*np.pi*me*k))**1.5
hydrogen_volume=(h*h/(2*np.pi*9.1093837139e-28*k))**1.5
model=SolarCompositionModel(np.array([1.,1.01,1.02])*1e10,nmax=3,
    quadrature_order=1,angle_order=1,atoms=(('Fe II',26,1),('Fe III',26,2)),
    iron_levels=716,oxygen_overlap=False)
temperatures=np.array([4500.,6500.]);densities=np.array([1e15,1e14])
state=np.array(model.initialize(jnp.asarray(densities),jnp.asarray(temperatures)))
reports=[]
fe1=[]
for line in Path('/tmp/cloudy-causal-rates/data/stout/fe/fe_1/fe_1.nrg').read_text().splitlines()[1:]:
    if line.startswith('*'):break
    fields=line.split()
    if len(fields)>2 and fields[0].isdigit():fe1.append([float(fields[1]),float(fields[2])])
fe1=np.asarray(fe1)
for cell,(t,nh) in enumerate(zip(temperatures,densities)):
    atom=model.hydrogen.atom
    S=np.array(atom.statistical_weights)/2*hydrogen_volume/t**1.5*np.exp(np.array(atom.ionization_energy_erg)/(k*t))
    neutral_partition=np.sum(fe1[:,1]*np.exp(-h*c*fe1[:,0]/(k*t)))
    partition=np.array([neutral_partition,sum(np.array(model.metal.atoms[0].weight)*np.exp(-h*c*np.array(model.metal.atoms[0].energy_wavenumber)/(k*t))),sum(np.array(model.metal.atoms[1].weight)*np.exp(-h*c*np.array(model.metal.atoms[1].energy_wavenumber)/(k*t)))])
    metal_saha=2*t**1.5/volume*partition[1:]/partition[:-1]*np.exp(-np.array(model.metal.threshold_erg[0,:2])/(k*t))
    helium_saha=2*t**1.5/volume*np.array([2.,.5])*np.exp(-np.array(model.helium.threshold)/(k*t))
    molecule_ratio=np.exp(np.array([-17.,-18.,-10.,-15.]))
    def charge(logne,return_state=False):
        ne=np.exp(logne)
        proton=nh/(1+ne*S.sum()+molecule_ratio.sum())
        mf=np.array([1.,metal_saha[0]/ne,np.prod(metal_saha)/ne**2]);mf/=mf.sum()
        hf=np.array([1.,helium_saha[0]/ne,np.prod(helium_saha)/ne**2]);hf/=hf.sum()
        metal=nh*float(model.abundance[0])*mf
        helium=.1*nh*hf
        molecules=proton*molecule_ratio/np.array([1.,2.,2.,2.])
        calculated=proton+metal@[0.,1.,2.]+helium@[0.,1.,2.]+molecules[1]-molecules[0]
        if return_state:return ne,proton,metal,helium,molecules
        return (ne-calculated)/nh
    logne=brentq(charge,np.log(1e-20),np.log(3*nh),xtol=1e-13)
    ne,proton,metal,helium,molecules=charge(logne,True)
    state[cell,:model.hydrogen_size]=np.log(ne*S)
    state[cell,model.hydrogen_size:model.hydrogen_size+4]=np.log(molecule_ratio)
    state[cell,model.helium_slice]=np.log(helium[1:]/helium[0])
    ms=state[cell,model.metal_slice]
    ms[:2]=np.log([metal[0]/metal[1],metal[2]/metal[1]])
    for at,block in zip(model.metal.atoms,model.metal.excitation_slices):
        ms[block]=np.log(np.array(at.weight[1:])/float(at.weight[0]))-h*c*np.array(at.energy_wavenumber[1:])/(k*t)
    reports.append({'temperature_k':t,'n_h_cm3':nh,'electron_cm3':ne,'Fe_ion_density_cm3':metal.tolist(),'He_ion_density_cm3':helium.tolist(),'charge_residual_over_nH':charge(logne)})
actual=np.array(model.lte_atomic_target(jnp.asarray(state),densities,temperatures))
physical=model.unpack(jnp.asarray(state),densities)
error=float(np.max(abs(actual-state)))
np.testing.assert_allclose(actual,state,rtol=0,atol=1e-12)
np.testing.assert_allclose(physical['electron_cm3'],[r['electron_cm3'] for r in reports],rtol=3e-14)
np.testing.assert_allclose(physical['metal_ion_cm3'][:,0,:],[r['Fe_ion_density_cm3'] for r in reports],rtol=3e-14)
result={'scope':'Independent scalar Saha charge equation, two dense cells, Fe716+FeIII70 and full bound FeI partition/ground He; molecules have prescribed coordinate ratios, not solved chemical equilibrium. This verifies signs, retained partition factors and charge conservation, not the dense-patch physical prescription.','constant_convention':'Hydrogen electron mass9.1093837139e-28; C23-derived metal Saha constant uses9.1093837015e-28. Commonmass trial differed by2.04e-9 in log H ratios only.', 'max_log_state_error':error,'samples':reports,'solar_source_sha256':hashlib.sha256(Path('/tmp/escape-coupled-atmosphere/src/escape/solar.py').read_bytes()).hexdigest()}
Path('/tmp/escape-large-fe-validation/lte_boundary_partition_review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
