from pathlib import Path
import hashlib,json,subprocess
root=Path('/tmp/escape-recombination-audit');source=Path('/tmp/cloudy-reference-run/c23.01/source')
s=(source/'rt_diffuse.cpp').read_text().replace('#include "heavy.h"','#include "heavy.h"\n#include "ionbal.h"')
anchor='\t\t\t\t/* this is ground state continuum from stored opacities */'
assert s.count(anchor)==1
s=s.replace(anchor,'\t\t\t\tdouble diagnostic_photons = 0., diagnostic_energy = 0.;\n'+anchor)
anchor='\t\t\t\t\t\t/* add heavy rec to ground in active beam,*/'
assert s.count(anchor)==1
s=s.replace(anchor,'\t\t\t\t\t\tdiagnostic_photons += (realnum)photon*EdenAbund;\n\t\t\t\t\t\tdiagnostic_energy += (realnum)photon*EdenAbund*rfield.anu(nu)*EN1RYD;\n'+anchor)
anchor='\t\t\t\trfield.outlin_noplot[ipla] += (realnum)(difflya*radius.dVolOutwrd*opac.tmn[ipla]*opac.ExpmTau[ipla]);'
assert s.count(anchor)==2
pos=s.index(anchor,s.index(anchor)+len(anchor))+len(anchor)
readout=r'''
                // Reporting only: preserve the actual C23 source photon ledger.
                const double diagnostic_radius = 3. - radius.depth_mid_zone/1.358348e10;
                if (ion < 2 && (nelem==5 || nelem==6 || nelem==7 || nelem==11 || nelem==12 || nelem==13 || nelem==19 || nelem==24 || nelem==25)
                    && (fabs(diagnostic_radius-1.1)<.001 || fabs(diagnostic_radius-1.3)<.001 || fabs(diagnostic_radius-1.8)<.006 || fabs(diagnostic_radius-2.5)<.06)) {
                    char file[256];snprintf(file,sizeof(file),"recombination_%ld_%ld_zone%05ld.txt",nelem+1,ion,nzone);
                    FILE* diagnostic = open_data(file,"w");
                    if(diagnostic) {
                        fprintf(diagnostic,"# radius_rp T ne parent_ion RR DR ground_photons ground_energy pseudo_events IP_erg\n");
                        fprintf(diagnostic,"%.17e %.17e %.17e %.17e %.17e %.17e %.17e %.17e %.17e %.17e\n",diagnostic_radius,phycon.te,dense.eden,(double)dense.xIonDense[nelem][ion+1],ionbal.RR_rate_coef_used[nelem][ion],ionbal.DR_Badnell_rate_coef[nelem][ion],diagnostic_photons,diagnostic_energy,difflya,Heavy.Valence_IP_Ryd[nelem][ion]*EN1RYD);
                        fclose(diagnostic);
                    }
                }
'''
s=s[:pos]+readout+s[pos:];(root/'rt_diffuse.cpp').write_text(s)
flags=['g++','-std=c++11','-O2','-fno-pie','-I'+str(source),'-DSYS_CONFIG="'+str(source/'cloudyconfig.h')+'"']
subprocess.run(flags+['-c',str(root/'rt_diffuse.cpp'),'-o',str(root/'rt_diffuse.o')],check=True)
subprocess.run(['g++','-no-pie','-o',str(root/'cloudy_recombination.exe'),str(source/'maincl.o'),str(root/'rt_diffuse.o'),str(source/'libcloudy.a')],check=True)
receipt={'scope':'Reporting-only instrumentation of original C23.01; no physical coefficient or source term modified.','original_source_sha256':hashlib.sha256((source/'rt_diffuse.cpp').read_bytes()).hexdigest(),'diagnostic_source_sha256':hashlib.sha256((root/'rt_diffuse.cpp').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256((root/'cloudy_recombination.exe').read_bytes()).hexdigest()}
(root/'build.json').write_text(json.dumps(receipt,indent=2)+'\n')
