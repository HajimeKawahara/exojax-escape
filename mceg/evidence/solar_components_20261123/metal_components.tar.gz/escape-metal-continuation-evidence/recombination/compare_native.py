import json,numpy as np,jax,jax.numpy as jnp
from pathlib import Path
from escape.metal_rates import load_metal_rates,ground_recombination_continuum,oxygen_ground_valence_cross_section,EV_ERG
from escape.metal_atom import PLANCK
jax.config.update('jax_enable_x64',True)
root=Path('/tmp/escape-recombination-audit');report=json.loads((root/'summary.json').read_text());data=load_metal_rates();results=[]
for z in (6,7,8,12,13,14,20,25,26):
 for q in (0,1):
  rows=[r for r in report['samples'] if r['Z']==z and r['recombined_charge']==q];fit=data['photo'][z,q];threshold=float(fit.threshold_ev[fit.outer_shell-1]);energy=threshold+np.r_[0,np.geomspace(1e-8,200,6000)];nu=jnp.asarray(energy*EV_ERG/PLANCK)
  t=jnp.array([r['T'] for r in rows]);ne=jnp.array([r['ne'] for r in rows]);parent=jnp.ones(4)
  ratio=data['ground_weight'][z,q][0]/data['ground_weight'][z,q][1]
  sigma=oxygen_ground_valence_cross_section(jnp.asarray(energy)) if (z,q)==(8,0) else None
  emission=ground_recombination_continuum(fit,ratio,t,ne,parent,nu,valence_cross_section_cm2=sigma)
  alpha=np.trapezoid(np.asarray(4*jnp.pi*emission/(PLANCK*nu)),np.asarray(nu),axis=1)/np.asarray(ne)
  for row,native in zip(rows,alpha):
   source=row['ground_fraction_of_total_RR_DR']*(row['RR_cm3_s']+row['DR_cm3_s']);results.append({'Z':z,'q':q,'radius_rp':row['target_radius_rp'],'native_ground_coefficient_cm3_s':float(native),'C23_ground_coefficient_cm3_s':source,'relative':float(native/source-1),'ground_statistical_weight_ratio':float(ratio)})
(root/'native_comparison.json').write_text(json.dumps({'scope':'Native fine-grid Milne integration vs actual C23 emitted ground continuum, with different continuum quadrature; this is not exact mesh parity.','cases':results},indent=2)+'\n')
for z in (6,7,8,12,13,14,20,25,26):print(z,[(r['q'],r['radius_rp'],round(r['relative']*100,3)) for r in results if r['Z']==z])
