"""Replay archived numerical assertions; never run Cloudy or read a stellar SED."""
from pathlib import Path
import argparse, hashlib, importlib.util, json
import numpy as np
ROOT=Path(__file__).resolve().parent

def read(name): return json.loads((ROOT/name).read_text())

def controls():
    results={}
    for name in ['atomic_rr','helium','fe_lyalpha','oi_ca']:
        with np.load(ROOT/f'controls/{name}_derived.npz',allow_pickle=False) as a:
            pairs=[(int(k[4:k.index('_')]),0) for k in a.files
                   if k.endswith('_processed_contrast') and k!='case0_processed_contrast']
            if name=='atomic_rr':pairs.append((2,1))
            for changed,base in pairs:
                delta=a[f'case{changed}_processed_contrast']-a[f'case{base}_processed_contrast']
                normalized=np.interp(a['observed_velocity_kms'],a['output_velocity_kms'],delta)/a['observed_error']
                results[f'{name}:{changed}-{base}']={'max_change_ppm':float(abs(delta).max()*1e6),
                    'max_observation_error_units':float(abs(normalized).max()),
                    'rms_observation_error_units':float(np.sqrt(np.mean(normalized**2)))}
    for name,path in [('helium','controls/helium/observer_response.json'),('fe_lyalpha','controls/fe_lyalpha/observer_response.json')]:
        expected=read(path)
        for k,v in results[f'{name}:1-0'].items():np.testing.assert_allclose(v,expected[k],rtol=2e-14)
    expected=read('controls/atomic_rr_observer_response.json')
    for i,row in enumerate(expected['cases'],1):
        for k,v in results[f'atomic_rr:{i}-0'].items():np.testing.assert_allclose(v,row[k],rtol=2e-14)
    for k,v in results['atomic_rr:2-1'].items():np.testing.assert_allclose(v,expected['Fe716_vs371'][k],rtol=2e-14)
    return results

def partitions():
    from escape.metal_rates import load_metal_partitions,log_metal_partition
    data=load_metal_partitions();errors=[]
    for row in read('partitions/metal_partition_verification.json')['cases']:
        value=float(np.exp(log_metal_partition(row['temperature_k'],row['z'],row['q'],data)))
        errors.append(abs(value/row['reference']-1))
    assert max(errors)<2e-14
    return {'cases':len(errors),'max_relative_error':max(errors)}

def atoms():
    import jax.numpy as jnp
    from escape.metal_atom import (load_metal_atom,load_metal_colliders,
        electron_collision_coefficients,tabulated_collision_coefficients,populations,kinetic_line_heating)
    errors=[]
    with np.load(ROOT/'atoms/conditional_rates.npz',allow_pickle=False) as a:
        for r in read('atoms/conditional_rates.json')['cases']:
            levels=r['levels'] if r['species']=='Fe II' else None
            atom=load_metal_atom(r['species'],levels=levels)
            ne=r['electron']+1.7e-4*r['collider_densities_cm3']['H I']
            collision=ne*electron_collision_coefficients(atom,r['temperature'])
            for name,table in load_metal_colliders(r['species'],levels=levels).items():
                names={'H':'H I','PROTON':'H II','HE':'He I','HE+':'He II'}
                if name in names:
                    collision+=r['collider_densities_cm3'][names[name]]*tabulated_collision_coefficients(atom,table,r['temperature'])
            key=r['key'];p=populations(a[key+'__radiative']+collision,r['abundance'])
            heat=float(kinetic_line_heating(p,collision,atom.energy_wavenumber))
            l1=lambda x,y:float(np.sum(abs(np.asarray(x)-y))/np.sum(abs(y)))
            row={'key':key,'collision_l1':l1(collision,a[key+'__collision']),
                 'population_l1':l1(p,a[key+'__population']),'heat_relative':abs(heat/(-r['cooling'])-1)}
            np.testing.assert_array_equal(np.asarray(atom.spontaneous)>0,a[key+'__radiative_mask'])
            assert row['collision_l1']<2e-6 and row['population_l1']<1e-6 and row['heat_relative']<2e-5
            errors.append(row)
    return {'cases':len(errors),'maxima':{k:max(r[k] for r in errors) for k in ['collision_l1','population_l1','heat_relative']}}

def gth():
    import jax,jax.numpy as jnp
    from escape.metal_atom import populations
    spec=importlib.util.spec_from_file_location('old_gth',ROOT/'historical_harnesses/gth_before_checkpoint.py')
    old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
    record=next(r for r in read('atoms/conditional_rates.json')['cases'] if r['levels']==716)
    with np.load(ROOT/'atoms/conditional_rates.npz',allow_pickle=False) as a:
        r=jnp.asarray(a[record['key']+'__radiative']);c=jnp.asarray(a[record['key']+'__collision'])
    weight=jnp.asarray(np.random.default_rng(42).normal(size=716))
    reference=lambda x:old.populations(r+jnp.exp(x)*c,record['abundance'])
    current=lambda x:populations(r+jnp.exp(x)*c,record['abundance'])
    a,da=jax.jit(lambda x:jax.jvp(reference,(x,),(jnp.ones_like(x),)))(0.)
    b,db=jax.jit(lambda x:jax.jvp(current,(x,),(jnp.ones_like(x),)))(0.)
    reverse=jax.jit(jax.grad(lambda x:current(x)@weight)).lower(0.).compile()
    tangent=float(reverse(0.));fd=(reference(1e-4)-reference(-1e-4))/2e-4
    result={'primal_relative_l1':float(jnp.sum(abs(a-b))/record['abundance']),
            'JVP_relative_l2':float(jnp.linalg.norm(da-db)/jnp.linalg.norm(da)),
            'VJP_JVP_relative':abs(tangent/float(db@weight)-1),
            'finite_difference_relative_l2':float(jnp.linalg.norm(db-fd)/jnp.linalg.norm(fd)),
            'reverse_temporary_bytes':reverse.memory_analysis().temp_size_in_bytes}
    assert result['primal_relative_l1']<1e-13 and result['JVP_relative_l2']<1e-11
    assert result['VJP_JVP_relative']<1e-10 and result['finite_difference_relative_l2']<1e-7
    return result

def rr():
    rows=read('recombination/summary.json')['samples']
    for r in rows:
        np.testing.assert_allclose(r['ground_photons_cm3_s']/r['expected_total_RR_DR_cm3_s'],r['ground_fraction_of_total_RR_DR'],rtol=2e-14)
    return {'cases':len(rows),'ground_exceeds_total_capture_cases':sum(r['ground_fraction_of_total_RR_DR']>1 for r in rows),
        'maximum_ground_over_total_capture':max(r['ground_fraction_of_total_RR_DR'] for r in rows)}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('components',nargs='*',choices=['controls','partitions','atoms','gth','rr'])
    args=parser.parse_args()
    import jax
    jax.config.update('jax_enable_x64',True)
    result={}
    for name in args.components or ['controls','partitions','rr']:
        result[name]=globals()[name]()
        print(json.dumps({name:result[name]}),flush=True)
