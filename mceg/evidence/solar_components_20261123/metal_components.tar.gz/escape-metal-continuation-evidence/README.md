# Metal continuation evidence

This bundle records component verification and scientific counterexamples for
`exojax-escape`. It does **not** establish a converged solar atmosphere, agreement
with the Yapeng model, or NUTS readiness. Component commits are `5e4546d`
(source-defined radiative masks), `34c176a` (GTH checkpoints), and `d22f7de`
(bound-level partitions). Source hashes and historical scopes are retained in
the original receipts. Later lower-boundary/Kirchhoff changes are outside this
bundle's executed tests.

## What is retained

| Component | Evidence | What it establishes |
|---|---|---|
| Ionic/PI primitives | `rates/` | Source-backed low-charge coefficients, ground cross sections, and the O I special cross section; supplied-radiation scope. |
| Metal excitation | `atoms/conditional_rates.*` | 66 final-iteration cases (11 atoms, six cells), plus two independent BB Fe371/716 cells. C23 supplies radiation and total ion density. |
| Differentiation | `gth/` | Stable GTH values/JVP, Fe716 FD and VJP agreement, and 3.33 GB to 107 MB reverse temporary-memory reduction. |
| Partitions/LTE algebra | `partitions/` | 27 finite bound-level tables, 108 independent sums, actual-electron Saha charge reviews, and the old continuum inconsistency. |
| Recombination source | `recombination/` | Actual C23 ground-continuum and total RR/DR pseudo-line ledger, reporting perturbation, and the half-cascade sensitivity. |
| Conditional observables | `controls/` | Fixed-temperature/density Fe-size, He-removal, and line-overlap switches, processed through a declared reduction proxy. |

`components.json` maps these results to scoped MCEG use/claim candidates.
`manifest.json` lists every file, its hash, and every NPZ array's shape/dtype.
`origins.json` records original artifact hashes and all observer-NPZ exclusions.
The 716-level **conditional rate matrix** is retained to replay the derivative
benchmark; it is neither a raw atomic database nor a stellar-flux array.

## Negative findings that remain important

* Fe80 is inadequate for the selected irradiation/heating calculation. The
  coarse Fe371-to-716 comparison still changes heating by more than 5% in some
  layers. Atomic convergence and the full atmospheric/observable response are
  not established by the conditional matrix agreement.
* Fe80's zero Lyalpha-switch response did not exercise any accessible overlap
  lines. With Fe716, turning off the C23 Lyalpha pump changes lower n3 by about
  -13%, and cooling near 1.3 Rp by +17%; the fixed-structure processed spectrum
  changes by 8.336 ppm (0.0351 supplied-error units). Thermal/wind readjustment
  remains unbounded. `atoms/fe_lyalpha_source_audit.json` identifies the paired
  Fe excitation/H destruction hooks and the OTS accounting concern.
* The local implicit-SE derivative prototype failed the stiff fixture. It was
  rejected; checkpointed positive GTH is the accepted implementation. The
  failure script/log is deliberately retained, not counted as a passing test.
* C23 emits a ground Milne continuum and independently assigns total RR+DR to
  both approximate cascade photons. Actual source readout gives ground capture
  larger than total RR+DR for some N/O stages. Subtracting ground capture would
  therefore give negative cascade rates. This is a shared reference-model
  approximation, not evidence that the native radiation/energy closure is
  physically complete.
* The recombination reporting binary was **not byte-identical** to the original
  physical output. `output_differences.json` quantifies the small differences;
  the source inspection and readout are not presented as an exact-output proof.
* Ground-only neutral-Fe partitions omit a factor about 2.90 at 4500 K. The
  added partition data resolve that finite-level omission, but do not include
  continuum lowering or prove the dense-boundary prescription.
* Partition-Saha populations with the original C23-style total-ion ground
  opacity/Milne source violate Kirchhoff: at 4500 K, isolated edge ratios
  eta/(kappa B) are approximately Fe I 1.424, Fe II 0.594, Si I 0.305, Al I 0.341.
  Later dense-mask-only source corrections require separate evidence.
* Neither selected C23 STOUT Fe II nor the native counterpart includes
  level-resolved excited Fe II photoionization. Agreement shares this unbounded
  approximation. Helium removal and omitted-coolant budgets are conditional
  diagnostics, not proof that all omitted processes are negligible.

Earlier messages mentioned 99 local excitation cases. The hash-pinned final
artifact actually contains **66**, after selecting the final iteration. This
bundle preserves the correct count and does not combine intermediate iterations.

## Replay without Cloudy or a stellar SED

Use a checkout of `exojax-escape` at `d22f7de` (or inspect later changes), with
its declared ExoJAX dependency and JAX x64 support. No full atomic table is
copied here because those compact licensed tables are already in the repository.
Set `PYTHONPATH` to that checkout's `src` if it is not installed.

```sh
export PYTHONDONTWRITEBYTECODE=1
python verify_manifest.py
python replay.py controls partitions rr
python replay.py atoms gth
```

The first commands recompute the observable differences, partition anchors,
and source-ledger ratios. `atoms` independently rebuilds collision rates and
local populations from the packaged coefficients, using the archived C23
radiation and abundances. `gth` repeats the actual Fe716 value/JVP/VJP/FD check.
The memory measurement depends on JAX/XLA version and hardware; the original
measurements and JUnit results remain separately recorded.

`replay_results.jsonl` records the archive's own verification run. The original
absolute-path harnesses in `historical_harnesses/` are provenance, not portable
entrypoints. The preserved `solar_partition_review.py` was reconstructed from
`12dbf5a` plus the partition-only wiring and its full hash exactly matches the
executed LTE-review receipt. Original ground-only LTE review uses `12dbf5a`.
These reviews predate the later H-minus/Kirchhoff lower-boundary prescription.

To demonstrate the **expected rejected** derivative failure separately:

```sh
python gth/check_implicit.py
```

It exits with an assertion failure on the stiff case. It is not used by runtime.

## Re-running the external reference experiments

Obtain Cloudy C23.01 and its distributed data separately. `inputs/fe371.in` and
`inputs/fe716.in` are complete small blackbody cases. Apply the corresponding
reporting patch in `patches/` to a separate diagnostic source tree, build it,
and preserve an unmodified binary for the output-identity control. The archive
contains source hashes and patches, not compiled binaries or a source-tree copy.

The solar inputs additionally require the original user-supplied stellar SED
and the reference setup identified in each receipt. No SED/FITS, full stellar
flux, `stellar_reference`, cache, HLO, or runtime atomic database is distributed
in this bundle. The observer NPZ files were rebuilt with explicit allowlists;
all dropped keys are recorded. Consequently the archive replays **derived
observable comparisons**, not a new PHX atmosphere or the original publication's
complete reduction. The default local Cloudy convergence criteria in these controls
have not been shown adequate for precision calibration; stricter local-criterion
experiments belong to the separate reference campaign. Full model reproduction needs the external stellar source,
C23 data, the source-pinned reference/observer tools, cadence weights and high-n
cross-section fixtures identified by the receipts.

The observation values used for error normalization originate from
https://doi.org/10.5281/zenodo.20707255, licensed CC BY 4.0. The numerical model
outputs and rate readouts have their scopes recorded above. Cloudy-derived
source patches retain `Cloudy_LICENSE.txt`; atomic data references remain in
the repository's provenance and acknowledgment files.
