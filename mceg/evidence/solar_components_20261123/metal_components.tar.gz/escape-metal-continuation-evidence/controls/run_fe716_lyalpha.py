"""Disable only C23 Fe II pumping by hydrogen Lyalpha in a fixed profile."""
from pathlib import Path
import hashlib
import json
import subprocess
import time
root=Path('/tmp/escape-overlap-controls/fe716/iron_lyalpha_off')
directory=root/'iteration_000'
directory.mkdir(parents=True,exist_ok=True)
baseline=Path('/tmp/escape-overlap-controls/fe716/baseline/iteration_000')
source=(baseline/'model.in').read_text()
source=source.replace('species "Fe+" levels=716','species "Fe+" levels=716\nno FeII')
assert 'no FeII' in source
(directory/'model.in').write_text(source)
(directory/'input_profiles.npz').write_bytes((baseline/'input_profiles.npz').read_bytes())
sed=directory/'SED'
if not sed.exists():sed.symlink_to(baseline/'SED',target_is_directory=True)
binary=Path('/tmp/cloudy-reference-run/cloudy_unmodified.exe')
report={'scope':'Built-in no FeII disables H Lyalpha pumping of the full716 FeII atom at fixed prescribed T/nH. Same full chemistry/H25 PHX coarse reference. No thermal/wind reconvergence or line-center mesh convergence.','baseline_input_sha256':hashlib.sha256((baseline/'model.in').read_bytes()).hexdigest(),'input_sha256':hashlib.sha256((directory/'model.in').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'source':'parse_dont.cpp:122-125 sets hydro.lgLyaFeIIPumpOn=false; species2.cpp:1105-1106 returns before extra bound-bound rates.'}
start=time.time()
with (directory/'console.txt').open('w') as output:
 result=subprocess.run([str(binary),'-r','model'],cwd=directory,stdout=output,stderr=subprocess.STDOUT)
report.update(exit_code=result.returncode,wall_time_s=time.time()-start)
(root/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2),flush=True)
