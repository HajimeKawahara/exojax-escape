from pathlib import Path
import time,subprocess,hashlib,json
root=Path('/tmp/escape-helium-control');directory=root/'iteration_000';directory.mkdir(exist_ok=True);baseline=Path('/tmp/escape-overlap-controls/fe716/baseline/iteration_000')
source=(baseline/'model.in').read_text();source=source.replace('abundances "default.abn"','abundances "default.abn"\nelement helium off')
(directory/'model.in').write_text(source);(directory/'input_profiles.npz').write_bytes((baseline/'input_profiles.npz').read_bytes());sed=directory/'SED'
if not sed.exists():sed.symlink_to(baseline/'SED',target_is_directory=True)
binary=Path('/tmp/cloudy-reference-run/cloudy_unmodified.exe');r={'scope':'Remove all He microphysics at fixed prescribed H nuclei density/T and fixed observer velocity, using Fe716/full-H25. Mass density changes because He is removed. No thermal/wind re-equilibration, strict error bound, or final reference-mesh accuracy is claimed.','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'baseline_input_sha256':hashlib.sha256((baseline/'model.in').read_bytes()).hexdigest(),'input_sha256':hashlib.sha256((directory/'model.in').read_bytes()).hexdigest()};start=time.time()
with (directory/'console.txt').open('w') as f:out=subprocess.run([str(binary),'-r','model'],cwd=directory,stdout=f,stderr=subprocess.STDOUT)
r.update(exit_code=out.returncode,wall_time_s=time.time()-start);(root/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
