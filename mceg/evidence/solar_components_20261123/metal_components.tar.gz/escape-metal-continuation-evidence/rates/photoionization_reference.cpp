/* Reporting harness; original C23.01 method bodies follow. See Cloudy-license.txt. */

#include <algorithm>
#include <cassert>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
using namespace std;
#define DEBUG_ENTRY(x) ((void)0)
#define ASSERT(x) assert(x)
#define POW2(x) ((x)*(x))
enum { PHFIT_UNDEF, PHFIT95, PHFIT96 };
const int ipARGON=17,ipCALCIUM=19,ipSCANDIUM=20,ipTITANIUM=21,ipMANGANESE=24,ipIRON=25;
const double EVRYD=13.605693122994;
struct { double potential[30][30]; double getIonPot(int z,int q){return potential[z][q];} } atmdat;
struct t_ADfA {
    int version=PHFIT96; long L[7],NINN[30],NTOT[30];
    float PH1[7][30][30][6]={}, PH2[30][30][7]={};
    long set_vshell_index(long ne,long Z) const;
    double getEthresh(long nshell,long nel,long Z) const;
    double phfit(long nz,long ne,long is,double e);
};
bool row(ifstream &file,string &s) {
    while(getline(file,s)) { s=s.substr(0,s.find('#')); if(s.find_first_not_of(" \t\r")==string::npos) continue; return true; }
    return false;
}
inline long t_ADfA::set_vshell_index( long nelec, long Z ) const
{
	long nout = NTOT[nelec-1];

	// NB NB
	// 4th row elements start filling 4s (shell 7) before completely
	// filling 3d (shell 6) -- true for all neutrals, and some singly
	// ionized elements, see below
	//
	// The indices below are on C scale, i.e., they start at 0 for H,
	// hence the +1
	//
	if( Z == nelec && Z > ipARGON+1 )
		nout = 7;
	else if( Z == (nelec + 1)
		 && ( Z == ipCALCIUM+1
			|| Z == ipSCANDIUM+1
			|| Z == ipTITANIUM+1
			|| Z == ipMANGANESE+1
			|| Z == ipIRON+1 ) )
		nout = 7;
	return nout;
}

double t_ADfA::getEthresh( long int nshell, long int nelec, long int Z ) const
{
	long nout = set_vshell_index( nelec, Z );
	if( nshell == nout )
		return atmdat.getIonPot(Z-1, Z-nelec) * EVRYD;
	else
		return double(PH1[nshell-1][nelec-1][Z-1][0]);
}

double t_ADfA::phfit(long int nz, 
		     long int ne,
		     long int is, 
		     double e)
{
	long int nint, 
	  nout;
	double a, 
	  b, 
	  crs, 
	  einn, 
	  p1, 
	  q, 
	  x, 
	  y, 
	  z;

	DEBUG_ENTRY( "phfit()" );

	/*** Version 3. October 8, 1996.
	 *** Written by D. A. Verner, verner@pa.uky.edu
	 *** Inner-shell ionization energies of some low-ionized species are slightly
	 *** improved to fit smoothly the experimental inner-shell ionization energies 
	 *** of neutral atoms.
	 ******************************************************************************
	 *** This subroutine calculates partial photoionization cross sections
	 *** for all ionization stages of all atoms from H to Zn (Z=30) by use of
	 *** the following fit parameters:
	 *** Outer shells of the Opacity Project (OP) elements:
	 *** >>refer	all	photo_cs	Verner, D. A., Ferland, G. J., Korista, K. T., & Yakovlev, D. G. 1996, ApJ, 465, 487.
	 *** Inner shells of all elements, and outer shells of the non-OP elements:
	 ***  Verner and Yakovlev, 1995, A&AS, 109, 125
	 *** Input parameters:  nz - atomic number from 1 to 30 (integer) 
	 ***          ne - number of electrons from 1 to iz (integer)
	 ***          is - shell number (integer)
	 ***          e - photon energy, eV 
	 ***          version - enum, PHFIT96 (default): calculates 
	 ***                 new cross sections, PHFIT95: calculates
	 ***                 only old Hartree-Slater cross sections
	 *** Output parameter:  photoionization cross section, Mb
	 *** Shell numbers:
	 *** 1 - 1s, 2 - 2s, 3 - 2p, 4 - 3s, 5 - 3p, 6 - 3d, 7 - 4s. 
	 *** If a species in the ground state has no electrons on the given shell,
	 *** the subroutine returns 0.
	 ****************************************************************************** */

	crs = 0.0;
	if( nz < 1 || nz > 30 )
	{ 
		return crs;
	}

	if( ne < 1 || ne > nz )
	{ 
		return crs;
	}

	nout = set_vshell_index( ne, nz );

	if( is > nout )
	{ 
		return crs;
	}

	if( (is == 6 && (nz == 20 || nz == 19)) && ne >= 19 )
	{ 
		return crs;
	}

	ASSERT( is >= 1 && is <= 7 );

	double ethres = getEthresh( is, ne, nz );

	if( e < ethres )
	{
		return crs;
	}

	nint = NINN[ne-1];
	if( ((nz == 15 || nz == 17) || nz == 19) || (nz > 20 && nz != 26) )
	{
		einn = 0.0;
	}
	else
	{
		if( ne < 3 )
		{
			einn = 1.0e30;
		}
		else
		{
			if( nint == nout )
				einn = ethres;
			else
				einn = double(PH1[nint-1][ne-1][nz-1][0]);
		}
	}

	if( (is <= nint || e >= einn) || version == PHFIT95 )
	{
		p1 = -PH1[is-1][ne-1][nz-1][4];
		y = e/PH1[is-1][ne-1][nz-1][1];
		q = -0.5*p1 - L[is-1] - 5.5;
		a = PH1[is-1][ne-1][nz-1][2]*(POW2(y - 1.0) + 
			POW2(PH1[is-1][ne-1][nz-1][5]));
		b = sqrt(y/PH1[is-1][ne-1][nz-1][3]) + 1.0;
		crs = a*pow(y,q)*pow(b,p1);
	}
	else
	{
		if( (is < nout && is > nint) && e < einn )
		{ 
			return crs;
		}
		p1 = -PH2[ne-1][nz-1][3];
		q = -0.5*p1 - 5.5;
		x = e/PH2[ne-1][nz-1][0] - PH2[ne-1][nz-1][5];
		z = sqrt(x*x+POW2(PH2[ne-1][nz-1][6]));
		a = PH2[ne-1][nz-1][1]*(POW2(x - 1.0) + 
			POW2(PH2[ne-1][nz-1][4]));
		b = 1.0 + sqrt(z/PH2[ne-1][nz-1][2]);
		crs = a*pow(z,q)*pow(b,p1);
	}
	return crs;
}


int main(int argc,char**argv) {
    t_ADfA model; string line; ifstream table(string(argv[1])+"/phfit.dat"); row(table,line);
    row(table,line); {istringstream r(line);for(int i=0;i<7;++i)r>>model.L[i];}
    row(table,line); {istringstream r(line);for(int i=0;i<30;++i)r>>model.NINN[i];}
    row(table,line); {istringstream r(line);for(int i=0;i<30;++i)r>>model.NTOT[i];}
    while(row(table,line)) {istringstream r(line); int s,n,z;r>>s>>n>>z;if(s<0)break;for(int i=0;i<6;++i)r>>model.PH1[s][n][z][i];}
    while(row(table,line)) {istringstream r(line); int n,z;r>>n>>z;if(n<0)break;for(int i=0;i<7;++i)r>>model.PH2[n][z][i];}
    ifstream potentials(string(argv[1])+"/ionization_potentials.dat");row(potentials,line);
    while(row(potentials,line)) {istringstream r(line);int z,q;double wn;if(!(r>>z>>q>>wn))continue;if(z>30)break;atmdat.potential[z-1][q]=wn*(6.62607015e-27*2.99792458e10/1.602176634e-12)/EVRYD;}
    int z,q,s; double e;cout<<setprecision(17);
    while(cin>>z>>q>>s>>e)cout<<model.phfit(z,z-q,s,e)*1e-18<<"\n";
}
