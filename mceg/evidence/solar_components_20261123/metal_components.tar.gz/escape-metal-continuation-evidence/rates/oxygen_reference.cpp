#include <cmath>
#include <iostream>
#include <iomanip>
#include <cassert>
#define STATIC static
#define DEBUG_ENTRY(x)
#define ASSERT(x) assert(x)
#define POW2(x) ((x)*(x))
using realnum=float;
STATIC void ofit(double e, 
	  realnum opart[])
{
	static const double y[7][5] = {
		{8.915,3995.,3.242,10.44,0.0},
		{11.31,1498.,5.27,7.319,0.0},
		{10.5,1.059e05,1.263,13.04,0.0},
		{19.49,48.47,8.806,5.983,0.0},
		{50.,4.244e04,0.1913,7.012,4.454e-02},
		{110.5,0.1588,148.3,-3.38,3.589e-02},
		{177.4,32.37,381.2,1.083,0.0}
	};
	static const double eth[7]={13.62,16.94,18.79,28.48,50.,110.5,538.};
	static const long l[7]={1,1,1,0,1,1,0};

	DEBUG_ENTRY( "ofit()" );
	/*compute cross sections for all shells of atomic oxygen
	 * Photoionization of OI
	 * Input parameter:   e - photon energy, eV
	 * Output parameters: otot - total photoionization cross section, Mb
	 *  opart(1) - 2p-shell photoionization, goes to 4So
	 *  opart(2) - 2p-shell photoionization, goes to 2Do
	 *  opart(3) - 2p-shell photoionization, goes to 2Po
	 *  opart(4) - 2s-shell photoionization
	 *  opart(5) - double photoionization, goes to O++
	 *  opart(6) - triple photoionization, goes to O+++
	 *  opart(7) - 1s-shell photoionization */

	for( int i=0; i < 7; i++ )
	{
		opart[i] = 0.0;
	}

	for( int i=0; i < 7; i++ )
	{
		if( e >= eth[i] )
		{
			// this assert is trivially true, but it helps PGCC
			ASSERT( i < 7 );
			double q = 5.5 - 0.5*y[i][3] + l[i];

			double x = e/y[i][0];

			opart[i] = (realnum)(y[i][1]*(POW2(x - 1.0) + POW2(y[i][4]))/
			  pow(x,q)/pow(1.0 + sqrt(x/y[i][2]),y[i][3]));

		}
	}
	return;
}
int main(){double e;while(std::cin>>e){realnum cross[7];ofit(e,cross);double sum=0;for(int i=0;i<6;++i)sum+=cross[i];std::cout<<std::setprecision(17)<<sum*1e-18<<"\n";}}
