from pathlib import Path
import ast,hashlib,json
import jax
import numpy as np
from escape.metal_rates import *
jax.config.update('jax_enable_x64',True)
p=Path('/tmp/escape-metal-prototype/validate.py');tree=ast.parse(p.read_text());exec(compile(ast.Module(body=[next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='parse')],type_ignores=[]),str(p),'exec'))
root=Path('/tmp/escape-metal-coolants');records=[parse(p) for p in (root/'solar-column').glob('metal_atom_*.txt')]
iteration=max(r['iteration'] for r in records);records=[r for r in records if r['iteration']==iteration]
data=load_metal_rates();out=[]
for z in (7,8,25):
 cand=[r for r in records if r['element']==z]
 for radius in (1.1,1.3,1.8,2.5):
  r=min(cand,key=lambda r:abs(r['radius_rp']-radius));t,ne=r['temperature'],r['electron']
  for q in (1,2,3):
   ref=r['charge_rates'][str(q-1)];ct=charge_exchange(t,z,q,data)
   vals={'RR':float(radiative_recombination(t,z,q,data)), 'DR':float(raw_dielectronic_recombination(t,z,q,data)*dielectronic_suppression(t,ne,z,q)),
    'Hion':float(ct[0]),'Hrec':float(ct[1]),'Heion':float(ct[2]),'Herec':float(ct[3])}
   keys=['RR_rate_coef_used_cm3_s','DR_Badnell_rate_coef_cm3_s','H_CharExcIonOf_cm3_s','H_CharExcRecTo_cm3_s','He_CharExcIonOf_cm3_s','He_CharExcRecTo_cm3_s']
   reference={key:ref[rkey] for key,rkey in zip(vals,keys)}
   rel={key:abs(val-reference[key])/max(abs(reference[key]),1e-99) for key,val in vals.items()}
   out.append(dict(z=z,q=q,radius_rp=r['radius_rp'],temperature=t,ne=ne,native=vals,reference=reference,relative_errors=rel,source=r['path'],sha256=r['source_sha256']))
(root/'extended_rates_check.json').write_text(json.dumps(out,indent=2)+'\n')
for z in (7,8,25):
 for key in ('RR','DR','Hion','Hrec','Heion','Herec'):
  row=max([r for r in out if r['z']==z],key=lambda r:r['relative_errors'][key]);print(z,key,row['relative_errors'][key],row['native'][key],row['reference'][key],row['q'])

extra=[]
for r in records:
 lines=Path(r['path']).read_text().splitlines()
 for line in lines:
  row=line.split()
  if row[0]=='GROUND_CI':
   z=int(row[1])
   actual=[float(collisional_ionization(r['temperature'],z,q,data)) for q in range(3)]
   ref=list(map(float,row[2:]))
   extra.append(dict(kind='collisional_ionization',z=z,temperature=r['temperature'],native=actual,reference=ref,source=r['path'],sha256=r['source_sha256']))
  elif row[0]=='HELIUM_GROUND':
   actual=[float(collisional_ionization(r['temperature'],2,q,data)) for q in range(2)]
   actual += [float(x) for q in (1,2) for x in charge_exchange(r['temperature'],2,q,data)[:2]]
   extra.append(dict(kind='helium_ground',z=2,temperature=r['temperature'],native=actual,reference=list(map(float,row[1:])),source=r['path'],sha256=r['source_sha256']))
(root/'extended_ci_helium_check.json').write_text(json.dumps(extra,indent=2)+'\n')
worst=max((abs(a-b)/max(abs(b),1e-99),row['kind'],row['z'],a,b) for row in extra for a,b in zip(row['native'],row['reference']))
print('CI/helium worst',worst)
