import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as jnp
import numpy as np,json,gzip
from pathlib import Path
from escape.hydrogen_escape_probability import HydrogenEscapeProbabilityModel,_column_above,_cell_weights
p=Path('/tmp/escape-ep-continuation');r=np.load(p/'col21_double_selected_rates/profile.npz');rows={}
for s in gzip.open(p/'col21_double_selected_rates/model.out.gz','rt'):
 if s.startswith('EPSTATE '):
  a=np.array(list(map(float,s.split()[1:])));rows[int(a[1])]=a
widths=np.array([rows[i+1][20] for i in range(len(r["depth_cm"]))]);m=HydrogenEscapeProbabilityModel(np.r_[0,np.cumsum(widths[::-1])],nmax=15,line_optical_depth_scale=2.)
bound=jnp.asarray(r['bound_cm3'][::-1]);ne=jnp.asarray(r['electron_cm3'][::-1]);inc=m.boundary_blackbody(10000.,.025)
s=jax.jit(m.population_state)(jnp.full(len(widths),8000.),bound,ne,ne,inc)
nu=m.grid.frequency_hz;pref=2*6.62607015e-27/(2.99792458e10)**2*nu**3;d=s['transport_extinction_cm1']*m.widths_cm[:,None]
direct=inc*jnp.exp(-_column_above(d))*_cell_weights(d)[0];diffuse=s['mean_intensity']-direct
out={}
for name,J in [('unattenuated',inc),('direct',direct),('diffuse',diffuse)]:
 a=np.asarray(J/pref@m._photo_kernel.T)
 out[name]=a.tolist() if a.ndim==1 else {str(z):a[-z,:6].tolist() for z in [1,3,64,127]}
print(json.dumps(out,indent=2));(p/'ground_photo_parts.json').write_text(json.dumps(out,indent=2)+'\n')
