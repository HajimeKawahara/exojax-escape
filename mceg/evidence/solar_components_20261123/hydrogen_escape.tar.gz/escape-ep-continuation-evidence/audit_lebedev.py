from pathlib import Path
import json,sys
import jax
jax.config.update('jax_enable_x64',True)
import numpy as np
sys.path.insert(0,'/tmp/escape-coupled-atmosphere/tools')
from cloudy_rates_diagnosis import rate_blocks,solve_frozen
from escape.hydrogen_atom import make_hydrogen_atom,atom_collision_rates
from escape.hydrogen_mixing import mixing_bound_bound_cm3_s
p=Path('/tmp/escape-ep-continuation');atom=make_hydrogen_atom(15);report={}
for zone in (1,3,64,127):
 z=np.load(p/f'double_zone{zone:03d}_operators.npz');expected=rate_blocks(z);ne=float(z['header'][4]);base=solve_frozen(expected,1e12,electron=ne);cases={}
 for model in ('anderson_n45','anderson_lebedev'):
  q=np.array(atom_collision_rates(atom,8000.,shell_collision_model=model)[0]);q[1,2]=q[2,1]=0.;q+=np.asarray(mixing_bound_bound_cm3_s(atom,8000.,ne))
  swap=dict(expected);swap['electron_bound_bound_cm3_s']=q;result=solve_frozen(swap,1e12,electron=ne)
  cases[model]={'n2_ratio':result['n2_cm3']/base['n2_cm3'],'n3_ratio':result['n3_cm3']/base['n3_cm3']}
 report[zone]=cases
print(json.dumps(report,indent=2));(p/'lebedev_frozen_swaps.json').write_text(json.dumps(report,indent=2)+'\n')
