"""Force Cloudy global iterations, retaining the exact input and all diagnostics."""
from pathlib import Path
import argparse,json,hashlib,sys
sys.path.insert(0,'/tmp/escape-coupled-atmosphere/tools')
import verify_atmosphere_reference as reference
p=argparse.ArgumentParser();p.add_argument('--iterations',type=int,default=12);p.add_argument('--column',type=float,default=1e21);p.add_argument('--record',type=Path,required=True);p.add_argument('--zones',type=int,default=0);p.add_argument('--double',action='store_true');p.add_argument('--executable',default='/tmp/escape-ep-prototype/cloudy_final.exe');a=p.parse_args()
original=reference.slab_input
reference.slab_input=lambda c:original(c).replace('iterate to convergence',f'iterate {a.iterations}')+('double optical depths\n' if a.double else '')
config=dict(nmax=15,temperature_k=8000.,density_cm3=1e12,radiation_temperature_k=10000.,dilution=.025,column_cm2=a.column,zones=a.zones,resolution=.05,illumination='beam')
r=reference.run(a.executable,a.record,config,timeout=1800.)
r['double_optical_depths']=a.double
r['global_iteration_policy']=f'Forced {a.iterations} iterations, not stopping at automatic convergence.'
r['generator_script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
(a.record/'generator.py').write_bytes(Path(__file__).read_bytes())
(a.record/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(r['status'],r.get('error'),flush=True)
