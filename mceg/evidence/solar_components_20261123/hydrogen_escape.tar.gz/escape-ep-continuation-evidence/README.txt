Controlled hydrogen line/radiation campaign; not a solar-atmosphere equivalence claim.

Both successful references: Cloudy C23.01, T=8000 K, nH=1e12 cm^-3,
blackbody10000 K, dilution0.025, normal incident beam, H nmax15 with
resolved n<=3 and collapsed n=4..15, topoff off, 6 global iterations,
explicit double optical depths. Columns1e18 and1e21 cm^-2 use47 and127
adaptive zones. Exact inputs and original gzip outputs are retained.

Native roots use anderson_lebedev with the same cells and line-column scale.
Native continuum is two-sided formal transport; C23 uses its outward/OTS
recombination approximation. Native first-surface ground photoionization
includes returning recombination photons absent from C23's surface field.
The remaining boundary differences are retained, not counted as agreement.
The failed open-back12-iteration Cloudy case is a failure, not a reference.

Kernel/AD/LTE/photon-budget tests do not establish atom truncation, solar
composition, moving-medium transfer, or complete atmospheric adequacy.
All other runtime sources are available at the recorded repository commit.
No executables, object files, raw stellar SED or redundant checkpoints included.
