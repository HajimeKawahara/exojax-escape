"""Compare final zone-wise C23 coefficients with native frozen-population rates."""
from pathlib import Path
import sys,gzip,json
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as jnp
import numpy as np
sys.path.insert(0,'/tmp/escape-coupled-atmosphere/tools')
from cloudy_rates_diagnosis import rate_blocks,solve_frozen,RATE_KEYS
from escape.hydrogen_escape_probability import HydrogenEscapeProbabilityModel
p=Path(__file__).parent
text=gzip.open(p/'col21_double_selected_rates/model.out.gz','rt').read()
blocks={}
for segment in text.split('MCEG_BEGIN ')[1:]:
 if 'MCEG_END' not in segment: continue
 lines=segment.split('MCEG_END')[0].splitlines();header=list(map(float,lines[0].split()))
 block={'header':header,'fb':[],'bb':[],'matrix':[],'two_photon':[]}
 for line in lines[1:]:
  parts=line.split();tag=parts[0] if parts else ''
  if tag in ('MCEG_FB','MCEG_BB','MCEG_2PH'):block[{'MCEG_FB':'fb','MCEG_BB':'bb','MCEG_2PH':'two_photon'}[tag]].append(list(map(float,parts[1:])))
  elif tag=='MCEG_MATRIX':block['matrix'].append(list(map(float,parts[2:])))
  elif tag=='MCEG_SOLUTION':block['solution']=list(map(float,parts[1:]))
 blocks[int(header[1])]=block
ref=np.load(p/'col21_double_selected_rates/profile.npz')
C=len(ref['depth_cm']);rows={}
for line in text.splitlines():
 if line.startswith('EPSTATE '):
  row=np.array(list(map(float,line.split()[1:])));rows[int(row[1])]=row
widths=np.array([rows[i+1][20] for i in range(C)])
m=HydrogenEscapeProbabilityModel(np.r_[0.,np.cumsum(widths[::-1])],nmax=15,line_optical_depth_scale=2.)
bound=jnp.asarray(ref['bound_cm3'][::-1]);ne=jnp.asarray(ref['electron_cm3'][::-1])
r=jax.jit(m.population_state)(jnp.full(C,8000.),bound,ne,ne,m.boundary_blackbody(10000.,.025))
report={}; arrays={k:np.asarray(v) for k,v in r['rates']._asdict().items()}
np.savez_compressed(p/'double_surface_native_rates.npz',**arrays)
for zone,op in sorted(blocks.items()):
 expected=rate_blocks(op);actual={k:np.asarray(v)[C-zone] for k,v in arrays.items()}; electron=op['header'][4]
 baseline=solve_frozen(expected,1e12,electron=electron)
 cases={}
 for key in RATE_KEYS:
  swapped=dict(expected);swapped[key]=actual[key]
  v=solve_frozen(swapped,1e12,electron=electron)
  cases[key]={'n2_ratio':v['n2_cm3']/baseline['n2_cm3'],'n3_ratio':v['n3_cm3']/baseline['n3_cm3']}
 both=dict(expected)
 both.update({k:actual[k] for k in RATE_KEYS[2:]})
 v=solve_frozen(both,1e12,electron=electron)
 cases['all_bf']={'n2_ratio':v['n2_cm3']/baseline['n2_cm3'],'n3_ratio':v['n3_cm3']/baseline['n3_cm3']}
 report[zone]={'baseline':baseline,'swaps':cases,'two_photon':op['two_photon']}
 np.savez_compressed(p/f'double_zone{zone:03d}_operators.npz',**{k:np.asarray(v) for k,v in op.items()})
(p/'double_surface_frozen_swaps.json').write_text(json.dumps(report,indent=2)+'\n')
for z in (1,3,64,127):print(z,report[z]['swaps'],flush=True)
