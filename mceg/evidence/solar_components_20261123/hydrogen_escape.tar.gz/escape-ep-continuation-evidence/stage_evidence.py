"""Publish only canonical controlled inputs, outputs and causal diagnostics."""
from pathlib import Path
import shutil,gzip,json,hashlib,subprocess
src=Path('/tmp/escape-ep-continuation');dst=Path('/tmp/escape-ep-continuation-evidence')
if dst.exists():
 if (dst/'manifest.json').exists():raise SystemExit('Refuse to overwrite completed evidence')
 shutil.rmtree(dst)
dst.mkdir();records={}
def copy(relative,subdir=None):
 p=src/relative;q=dst/(subdir or relative);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
for folder in ['col18_double_adaptive_6iter','col21_double_selected_rates']:
 for name in ['model.in','model.out.gz','model.conditions','model.levels','profile.npz','receipt.json','generator.py']:
  copy(f'{folder}/{name}')
for folder in ['core18_double_lebedev','core21_double_lebedev_reduced_mass']:
 for name in ['configuration_0.json','source_0.json','steps.jsonl','solution.npz']:
  copy(f'{folder}/{name}')
for name in ['checkpoint_root.py','ground_photo_parts.py','ground_photo_parts.json','audit_double_surface.py','double_surface_frozen_swaps.json','double_surface_native_rates.npz','audit_lebedev.py','lebedev_frozen_swaps.json','lebedev_root_comparison.json','lebedev_root_col18_comparison.json','double_adaptive_root_comparison.json','iso_level_selected.cpp','iso_level_readout.cpp','sample_lebedev.cpp','stage_evidence.py']:
 copy(name)
for zone in (1,3,64,127):copy(f'double_zone{zone:03d}_operators.npz')
for name in ['lebedev_tests','lebedev_legacy_tests','overlap_energy_tests','overlap_integrated_tests']:
 for suffix in ['xml','log']:copy(name+'.'+suffix,'tests/'+name+'.'+suffix)
failed='col21_adaptive_12iter'
for name in ['model.in','receipt.json','generator.py']:copy(f'{failed}/{name}')
original=src/failed/'model.out.gz';target=dst/failed/'model.scientific_output.txt.gz'
with gzip.open(original,'rt') as inp,gzip.open(target,'wt') as out:
 for line in inp:
  if not line.startswith('EPSTATE '):out.write(line)
(dst/failed/'extraction.json').write_text(json.dumps({'original_gzip_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'selection':'All original lines except repeated EPSTATE instrumented line-operator rows; full original remains in the local campaign. C23 scientific output and failure diagnostics retained.'},indent=2)+'\n')
repo=Path('/tmp/escape-coupled-atmosphere');sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
# Newton backtracking was an explicit worktree update during these solves.
q=dst/'runtime_source';q.mkdir();shutil.copyfile(repo/'src/escape/nonlinear.py',q/'nonlinear.py')
(dst/'README.txt').write_text('''Controlled hydrogen line/radiation campaign; not a solar-atmosphere equivalence claim.

Both successful references: Cloudy C23.01, T=8000 K, nH=1e12 cm^-3,
blackbody10000 K, dilution0.025, normal incident beam, H nmax15 with
resolved n<=3 and collapsed n=4..15, topoff off, 6 global iterations,
explicit double optical depths. Columns1e18 and1e21 cm^-2 use47 and127
adaptive zones. Exact inputs and original gzip outputs are retained.

Native roots use anderson_lebedev with the same cells and line-column scale.
Native continuum is two-sided formal transport; C23 uses its outward/OTS
recombination approximation. Native first-surface ground photoionization
includes returning recombination photons absent from C23's surface field.
The remaining boundary differences are retained, not counted as agreement.
The failed open-back12-iteration Cloudy case is a failure, not a reference.

Kernel/AD/LTE/photon-budget tests do not establish atom truncation, solar
composition, moving-medium transfer, or complete atmospheric adequacy.
All other runtime sources are available at the recorded repository commit.
No executables, object files, raw stellar SED or redundant checkpoints included.
''')
for p in sorted(dst.rglob('*')):
 if p.is_file():records[str(p.relative_to(dst))]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
(dst/'manifest.json').write_text(json.dumps({'repository':'HajimeKawahara/exojax-escape','commit':sha,'files':records},indent=2)+'\n')
print(dst,len(records),sum(r['bytes'] for r in records.values()))
