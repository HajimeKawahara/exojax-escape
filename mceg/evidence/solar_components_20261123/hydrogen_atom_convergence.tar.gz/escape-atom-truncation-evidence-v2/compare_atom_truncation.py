"""Compare conditional pure-H atom truncations; integrate each native cell grid."""
from pathlib import Path
import json,hashlib
import numpy as np
p=Path(__file__).parent
c15=np.load(p/'col21_double_adaptive_6iter/profile.npz');c25=np.load(p/'col21_double_default_atom/profile.npz')
n15=np.load(p/'core21_double_lebedev_reduced_mass/solution.npz');n20=np.load(p/'core21_double_lebedev_n20/solution.npz')
width15=np.diff(n15['edges_cm'])[::-1]

def report(ref,other,widthref,widthother,depthref,depthother):
 ratio=np.interp(depthref,depthother,other)/ref-1
 return dict(column_fraction=float(other@widthother/(ref@widthref)-1),surface_fraction=float(ratio[0]),base_fraction=float(ratio[-1]),max_abs_fraction=float(abs(ratio).max()))

def values(d,kind,native=False):
 if kind=='electron':return d['electron_cm3'][::-1] if native else d['electron_cm3']
 n=int(kind[1:]);v=(d['bound_cm3'][:,1:3].sum(1) if n==2 else d['bound_cm3'][:,3:6].sum(1))
 return v[::-1] if native else v
r=dict(scope='Fixed T=8000 K, nH=1e12 cm-3, NH=1e21 cm-2, blackbody10000 K diluted .025, normal beam, double line optical depths. Conditional pure-H control, not Solar/PHX adequacy.',cloudy15_atom='resolved3 + collapsed12; topoff off',cloudy25_atom='C23 default resolved10 + collapsed15; topoff on',native_atoms='resolved n<=3 plus principal-shell collapsed n4..15 or20; Anderson n4/5 and Lebedev n>5')
for name,ref,other,wr,wo,dr,do,native in [('cloudy_default25_vs_matched15',c15,c25,width15,c25['zone_width_cm'],c15['depth_cm'],c25['depth_cm'],False)]:
 r[name]={k:report(values(ref,k),values(other,k),wr,wo,dr,do) for k in ['n2','n3','electron']}
for name,n in [('native15_vs_cloudy_default25',n15),('native20_vs_cloudy_default25',n20)]:
 r[name]={k:report(values(c25,k),values(n,k,True),c25['zone_width_cm'],np.diff(n['edges_cm'])[::-1],c25['depth_cm'],c15['depth_cm']) for k in ['n2','n3','electron']}
r['sources']={str(q.relative_to(p)):hashlib.sha256(q.read_bytes()).hexdigest() for q in [p/'col21_double_adaptive_6iter/profile.npz',p/'col21_double_default_atom/profile.npz',p/'core21_double_lebedev_reduced_mass/solution.npz',p/'core21_double_lebedev_n20/solution.npz']}
(p/'atom_truncation_comparison.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
