"""Conditional pure-H control for C23's default resolved10+collapsed15 atom."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
sys.path.insert(0,'/tmp/escape-coupled-atmosphere/tools')
import verify_atmosphere_reference as reference
original=reference.slab_input

def text(config):
 s=original(config).replace('resolved 3 element hydrogen','resolved 10 element hydrogen').replace('collapsed 22 element hydrogen','collapsed 15 element hydrogen').replace('database H-like topoff off\n','').replace('iterate to convergence','iterate 6')
 return s+'double optical depths\nsave radius "model.radius" last\n'
reference.slab_input=text

def parse(directory,nmax):
 d=Path(directory);out=reference.artifact_bytes(d/'model.out').decode(errors='replace')
 if 'Cloudy exited OK' not in out:raise ValueError('Cloudy did not complete')
 levels=reference._rows(d/'model.levels');conditions=reference._rows(d/'model.conditions');ne=reference._rows(d/'model.electrons');np_=reference._rows(d/'model.protons');radius=reference._rows(d/'model.radius')
 if levels.shape[1]<71 or np.any(levels[:,71:]!=0):raise ValueError('Unexpected default atom dimension')
 columns=[levels[:,1:7]];index=7
 for n in range(4,11):columns.append(levels[:,index:index+n].sum(1,keepdims=True));index+=n
 columns.append(levels[:,index:index+15]);bound=np.concatenate(columns,axis=1)
 if bound.shape[1]!=28 or radius.shape[0]!=len(bound):raise ValueError('Profile dimensions differ')
 return dict(depth_cm=levels[:,0],bound_cm3=bound,temperature_k=conditions[:,1],n_h_cm3=conditions[:,2],electron_cm3=ne[:,1],proton_cm3=np_[:,1],n2_cm3=bound[:,1:3].sum(1),n3_cm3=bound[:,3:6].sum(1),zone_width_cm=radius[:,3])
reference.parse_profile=parse
config=dict(nmax=25,temperature_k=8000.,density_cm3=1e12,radiation_temperature_k=10000.,dilution=.025,column_cm2=1e21,zones=0,resolution=.05,illumination='beam')
destination=Path('/tmp/escape-ep-continuation/col21_double_default_atom')
r=reference.run('/tmp/cloudy-reference-run/cloudy_unmodified.exe',destination,config,timeout=1800.)
r['atomic_model']='C23 default H resolved10 collapsed15, topoff default on; nmax25, packed n4..25 shell sums'
r['generator_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();r['scope']='Controlled fixed T/density pure-H blackbody slab, not solar/PHX atmosphere adequacy.'
(destination/'generator.py').write_bytes(Path(__file__).read_bytes());(destination/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(r['status'],r.get('error'),flush=True)
