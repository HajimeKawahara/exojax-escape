"""Checkpointed exact-JVP Newton/GMRES on the packaged H residual."""
from pathlib import Path
import argparse,gzip,json,time,hashlib
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as jnp
import numpy as np
from escape.hydrogen_escape_probability import HydrogenEscapeProbabilityModel
from escape.hydrogen_nlte import _bound_ratios
from escape.hydrogen_atom import atom_saha_factors
from escape.nonlinear import newton_krylov_step
from escape.hydrogen_two_photon import two_photon_emissivity
from escape.hydrogen_rates import PLANCK_CGS
p=argparse.ArgumentParser();p.add_argument('--reference',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--steps',type=int,default=12);p.add_argument('--scale',type=float,default=1.);p.add_argument('--restart',type=int,default=128);p.add_argument('--krylov-iterations',type=int,default=20);p.add_argument('--linear-rtol',type=float,default=.01);p.add_argument('--inner-source-extension',action='store_true');p.add_argument('--seed',type=Path);p.add_argument('--coincident',action='store_true');p.add_argument('--shell-collisions',default='anderson_n45');p.add_argument('--nmax',type=int,default=15);a=p.parse_args()
r=np.load(a.reference/'profile.npz');C=len(r['depth_cm']);rows={}
for line in gzip.open(a.reference/'model.out.gz','rt'):
 if line.startswith('EPSTATE '):
  q=np.array(list(map(float,line.split()[1:])));rows[int(q[1])]=q
widths=np.array([rows[i+1][20] for i in range(C)]);edges=np.r_[0,np.cumsum(widths[::-1])]
m=HydrogenEscapeProbabilityModel(edges,nmax=a.nmax,line_optical_depth_scale=a.scale,line_overlap_model="coincident" if a.coincident else "resolved",shell_collision_model=a.shell_collisions)
b=jnp.asarray(r['bound_cm3'][::-1]);e=jnp.asarray(r['electron_cm3'][::-1]);t=jnp.full(C,8000.);incoming=m.boundary_blackbody(10000.,.025)
a.output.mkdir(exist_ok=True,parents=True)
if (a.output/'checkpoint.npz').exists():
 old=np.load(a.output/'checkpoint.npz');state=jnp.asarray(old['state']);start_iteration=int(old['iteration']);print('resume',start_iteration,flush=True)
elif a.seed is not None:state=jnp.asarray(np.load(a.seed)["state"]).ravel();start_iteration=0
else:state=jnp.log(b/e[:,None]).ravel();start_iteration=0
rows_state=state.reshape(C,-1)
if rows_state.shape[1]<len(m.atom.principal_n):
 seed_e=jnp.asarray(np.load(a.seed)['electron_cm3']) if a.seed else e
 tail=jnp.log(seed_e[:,None]*atom_saha_factors(m.atom,8000.)[None,rows_state.shape[1]:])
 state=jnp.concatenate((rows_state,tail),axis=1).ravel()
(a.output/f'configuration_{start_iteration}.json').write_text(json.dumps({k:str(v) if isinstance(v,Path) else v for k,v in vars(a).items()},indent=2)+'\n')
sources={name:hashlib.sha256(Path('/tmp/escape-coupled-atmosphere/src/escape',name).read_bytes()).hexdigest() for name in ('hydrogen_escape_probability.py','line_escape_probability.py','hydrogen_two_photon.py','nonlinear.py','hydrogen_atom.py','hydrogen_collisions.py')}
(a.output/f'source_{start_iteration}.json').write_text(json.dumps(sources,indent=2)+'\n')
@jax.jit
def residual(x):
 ratio=x.reshape(C,-1);f=jax.nn.softmax(jnp.column_stack((ratio,jnp.zeros(C))),axis=1);b=1e12*f[:,:-1];e=1e12*f[:,-1]
 inner=0.
 if a.inner_source_extension:
  chi,emission,_=m._continuum(t,b,e,e,m.grid.frequency_hz,m._sigma)
  emission=emission+two_photon_emissivity(m.grid.frequency_hz,m.grid.weight_hz,m.atom.excitation_energy_erg[1]/PLANCK_CGS,b[:,1])
  chi=chi+jnp.log1p(m.scattering_coefficients_at(b,e,m.grid.frequency_hz)*m.widths_cm[:,None])/m.widths_cm[:,None]
  inner=emission[0]/jnp.where(chi[0]>0,chi[0],1.)
 s=m.population_state(t,b,e,e,incoming,inner_intensity=inner)
 return (ratio-jnp.log(jax.vmap(_bound_ratios)(e,s['rates']))).ravel()
step=jax.jit(lambda x:newton_krylov_step(residual,x,restart=a.restart,krylov_iterations=a.krylov_iterations,linear_rtol=a.linear_rtol))
for iteration in range(start_iteration,start_iteration+a.steps):
 begin=time.time();v=step(state);state=v.value;norm=float(jnp.max(jnp.abs(v.residual)))
 np.savez_compressed(a.output/'checkpoint.npz',state=np.asarray(state),iteration=iteration+1,norm=norm,edges_cm=edges)
 record={'iteration':iteration+1,'residual':norm,'linear_residual':float(v.linear_residual_norm),'accepted':bool(v.accepted),'seconds':time.time()-begin,'linear_rtol':a.linear_rtol,'restart':a.restart,'krylov_iterations':a.krylov_iterations}
 with (a.output/'steps.jsonl').open('a') as stream:stream.write(json.dumps(record)+'\n')
 print(record,flush=True)
 if norm<1e-8 or not bool(v.accepted):break
frac=np.asarray(jax.nn.softmax(jnp.column_stack((state.reshape(C,-1),jnp.zeros(C))),axis=1));bound=1e12*frac[:,:-1];ne=1e12*frac[:,-1]
np.savez_compressed(a.output/'solution.npz',state=np.asarray(state).reshape(C,-1),bound_cm3=bound,electron_cm3=ne,residual_norm=norm,converged=norm<1e-8,edges_cm=edges)
print('final',norm,flush=True)
