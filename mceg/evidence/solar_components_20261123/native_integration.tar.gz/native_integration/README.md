# Scoped native integration and authoring checks

The complete Fe716, nmax15, H/O overlap fixed-temperature two-cell root has
2062 unknowns and maximum residual 3.6771e-13. Its analytic boundary is a
10000 K blackbody with W=.025; T=[8000,8200] K, nH=[1e12,9e11] cm^-3,
and edges=[0,5e5,1e6] cm. This is not a thermal/wind equilibrium, a resolved
planet atmosphere, or a fit. `source_current_overlap/manifest.json` pins the
source at 287ce45; retrieve that repository revision for replay, use its src
on PYTHONPATH, and run `solve_current_column.py --output OUTPUT`.

The later dark-UV, observer-boundary, dense-LTE and lower-continuum tests
exercise separate changes (fd79469, 287ce45, 12dbf5a and 5700a3c). Their XML
receipts are scoped regression results, not whole-atmosphere support. Build
and final model-document checks use the committed continuation source.
The MCEG reports retain unknown full-use support and open inventory reviews.
Do not combine these different source scopes into a claim of full validation.

No PHOENIX stellar arrays or compiler cache is included. This archive is a
completed snapshot; ongoing planetary/gradient controls are separate.
