# Independently switched Fe and Ca Ly-alpha allocation corrections

These are local Cloudy C23.01 source-control experiments, not an accepted
planetary atmosphere or a complete radiation/thermal-equilibrium proof.
The two corrections act on different ledgers and must not be conflated:

1. Fe overlap already removes H Ly-alpha photons through direct Fe excitation.
   Remove only the *historically retained* Fe addition from the generic
   continuum OTS source. Preserve H total loss, direct Fe excitation and the
   original population/escape update sequence.
2. Add actual excited Ca II absorption (four supplied Ly-alpha cross sections)
   to the H destruction beta, scattering albedo and the same OTS bin's allocation
   denominator. Preserve the original electron-escape prescription and broadband
   continuum; no broadband cross section is invented.

Four switches are run with identical inputs: neither correction, Fe only,
Ca only, and both. Unmodified C23 and the prior Ca-only binary are independent
companions. Their saved physical tables are byte-identical to the corresponding
tracking/newly composed modes.

The one-zone BB case is a useful inactive limit: Fe overlap never activates,
so it does not verify the Fe correction. The three-zone BB column uses the same
10000-K/W=.025 irradiation, 6707-K gas and nH=10^11.358 cm^-3, with Fe716/S72,
three 1e10-cm zones and three finite iterations. Fe then activates beyond the
illuminated face. Its historic and current net excitation probabilities are
recorded separately; no inactive mechanism is presented as tested feedback.
The inherited input title still says one-zone, but the executed `stop zone 3`
and final Cloudy report establish the three-zone scope.

`blackbody_column_summary.json` shows the two distinct budgets. With both
corrections, H loss equals generic OTS plus historical direct Fe allocation to
2.23e-16 relative error; all line photons assigned to the Ly-alpha continuum bin
equal Ca plus other absorption events to 4.47e-7. The latter includes other line
sources and uses Cloudy's float32 OTS accumulation. It is not the H source alone.
The beta/albedo/original electron expressions agree exactly with their executed
inputs. All cases have no reported local convergence failure; this does not
certify a globally refined atmosphere or a thermal root.

For replay, obtain the original C23.01 source/data. The build receipt lists
compiler flags and original object/library/source hashes. The generation script
composes the separately verified source inputs included under `replay/inputs`;
its paths document the original execution layout. Run the blackbody drivers
with each executable's `-r model` arguments, then `summarize_blackbody.py` with
and without `--column`. An original unmodified companion and the independently
compiled prior Ca-only companion are required for the byte-identity checks.
No binaries, caches, original stellar SED/FITS, or unfinished PHX reference
results are included. The separate refined PHX candidate remains subject to
local, whole-column, spatial and continuum convergence requirements.
