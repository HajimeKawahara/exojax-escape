"""Freeze local combined-closure evidence; omit binaries and unfinished PHX data."""
from pathlib import Path
import hashlib,json,shutil,tarfile
root=Path(__file__).parent;out=Path('/tmp/escape-combined-fe-ca-closure-evidence')
assert not out.exists()
summary=json.loads((root/'blackbody_column_summary.json').read_text());assert summary['Fe_mechanism_exercised']
out.mkdir()
def add(source,name):
 source=Path(source);assert source.is_file() and source.suffix not in ('.o','.exe','.pyc','.npz','.fits')
 target=out/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
for name in ['rt_ots_combined.cpp','rt_line_all_tracking.cpp','rt_escprob_ca_coupled.cpp',
 'rt_ots.cpp.patch','rt_line_all.cpp.patch','rt_escprob.cpp.patch','build_receipt.json',
 'run_blackbody_controls.py','run_blackbody_column_controls.py','summarize_blackbody.py',
 'blackbody_summary.json','blackbody_column_summary.json','package_local_evidence.py']:
 add(root/name,name)
add('/tmp/build_combined_fe_ca_ots.py','replay/build_combined_fe_ca_ots.py')
add('/tmp/escape-ca-coupled-onezone-evidence-v2/Cloudy_LICENSE.txt','Cloudy_LICENSE.txt')
# The exact individually verified source inputs are needed to replay composition.
for directory,files in [('/tmp/cloudy-fe-ots-allocation',['rt_ots_tracking.cpp','rt_line_all_tracking.cpp']),
 ('/tmp/cloudy-ca-coupled-closure-v2',['rt_ots_ca_coupled.cpp','rt_escprob_ca_coupled.cpp'])]:
 for name in files:add(Path(directory)/name,'replay/inputs/'+Path(directory).name+'/'+name)
for prefix in ['bb_fe716_','bb_fe716_column_']:
 for variant in ['original','tracking','old_ca','ca_only','fe_only','combined']:
  source=root/(prefix+variant)
  assert json.loads((source/'execution_receipt.json').read_text())['returncode']==0
  for name in ['model.in','model.out','model.conditions','model.cooling','execution_receipt.json',
   'fe_ots_ledger.tsv','ca_allocation_ledger.tsv','ca_lya_probability.tsv','ca_electron_escape.tsv']:
   if (source/name).exists():add(source/name,'cases/'+source.name+'/'+name)
readme='''# Independently switched Fe and Ca Ly-alpha allocation corrections

These are local Cloudy C23.01 source-control experiments, not an accepted
planetary atmosphere or a complete radiation/thermal-equilibrium proof.
The two corrections act on different ledgers and must not be conflated:

1. Fe overlap already removes H Ly-alpha photons through direct Fe excitation.
   Remove only the *historically retained* Fe addition from the generic
   continuum OTS source. Preserve H total loss, direct Fe excitation and the
   original population/escape update sequence.
2. Add actual excited Ca II absorption (four supplied Ly-alpha cross sections)
   to the H destruction beta, scattering albedo and the same OTS bin's allocation
   denominator. Preserve the original electron-escape prescription and broadband
   continuum; no broadband cross section is invented.

Four switches are run with identical inputs: neither correction, Fe only,
Ca only, and both. Unmodified C23 and the prior Ca-only binary are independent
companions. Their saved physical tables are byte-identical to the corresponding
tracking/newly composed modes.

The one-zone BB case is a useful inactive limit: Fe overlap never activates,
so it does not verify the Fe correction. The three-zone BB column uses the same
10000-K/W=.025 irradiation, 6707-K gas and nH=10^11.358 cm^-3, with Fe716/S72,
three 1e10-cm zones and three finite iterations. Fe then activates beyond the
illuminated face. Its historic and current net excitation probabilities are
recorded separately; no inactive mechanism is presented as tested feedback.
The inherited input title still says one-zone, but the executed `stop zone 3`
and final Cloudy report establish the three-zone scope.

`blackbody_column_summary.json` shows the two distinct budgets. With both
corrections, H loss equals generic OTS plus historical direct Fe allocation to
2.23e-16 relative error; all line photons assigned to the Ly-alpha continuum bin
equal Ca plus other absorption events to 4.47e-7. The latter includes other line
sources and uses Cloudy's float32 OTS accumulation. It is not the H source alone.
The beta/albedo/original electron expressions agree exactly with their executed
inputs. All cases have no reported local convergence failure; this does not
certify a globally refined atmosphere or a thermal root.

For replay, obtain the original C23.01 source/data. The build receipt lists
compiler flags and original object/library/source hashes. The generation script
composes the separately verified source inputs included under `replay/inputs`;
its paths document the original execution layout. Run the blackbody drivers
with each executable's `-r model` arguments, then `summarize_blackbody.py` with
and without `--column`. An original unmodified companion and the independently
compiled prior Ca-only companion are required for the byte-identity checks.
No binaries, caches, original stellar SED/FITS, or unfinished PHX reference
results are included. The separate refined PHX candidate remains subject to
local, whole-column, spatial and continuum convergence requirements.
'''
(out/'README.md').write_text(readme)
files={str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()}
(out/'manifest.json').write_text(json.dumps({'scope':'Completed local controls only; active and inactive mechanism tests are separated.','files':files},indent=2)+'\n')
archive=out.with_suffix('.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as stream:stream.add(out,arcname=out.name)
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files)+1}))
