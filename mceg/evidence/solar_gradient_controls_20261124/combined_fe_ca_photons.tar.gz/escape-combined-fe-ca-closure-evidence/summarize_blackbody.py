"""Verify both separate photon ledgers; never identify their different source budgets."""
from pathlib import Path
import hashlib,json,re
import numpy as np
root=Path(__file__).parent
import argparse
p=argparse.ArgumentParser();p.add_argument('--column',action='store_true');a=p.parse_args()
labels=['original','tracking','old_ca','ca_only','fe_only','combined']
paths={name:root/(('bb_fe716_column_' if a.column else 'bb_fe716_')+name) for name in labels}
for name,path in paths.items():
 assert json.loads((path/'execution_receipt.json').read_text())['returncode']==0,name
inputs={hashlib.sha256((path/'model.in').read_bytes()).hexdigest() for path in paths.values()}
assert len(inputs)==1
pairs={}
for old,new in [('original','tracking'),('old_ca','ca_only')]:
 files={file:(paths[old]/file).read_bytes()==(paths[new]/file).read_bytes()
        for file in ['model.conditions','model.cooling']}
 assert all(files.values()),(old,new,files)
 pairs[f'{old}_versus_{new}']={'saved_physical_tables_byte_identical':files}
records={}
for name in labels:
 path=paths[name];out=(path/'model.out').read_text(errors='replace')
 ending=[line.strip() for line in out.splitlines() if 'Cloudy ends:' in line]
 assert len(ending)==1
 record={'execution':json.loads((path/'execution_receipt.json').read_text()),'final_summary':ending[0],
 'reported_local_failures':[line.strip() for line in out.splitlines() if 'PROBLEM  ConvFail' in line]}
 if name in ('tracking','ca_only','fe_only','combined'):
  f=np.loadtxt(path/'fe_ots_ledger.tsv');c=np.loadtxt(path/'ca_allocation_ledger.tsv')
  h=np.loadtxt(path/'ca_lya_probability.tsv');e=np.loadtxt(path/'ca_electron_escape.tsv')
  assert all(np.isfinite(x).all() for x in [f,c,h,e])
  active=f[:,12]>0;fe_events=f[:,6]*f[:,7]*f[:,9]
  fdef=(f[active,13]+fe_events[active])/f[active,12]-1
  cactive=c[:,8]>0;cdef=(c[cactive,10]+c[cactive,11])/c[cactive,8]-1
  valid=h[:,11]>0;beta=h[valid,7]/(h[valid,7]+h[valid,11]);albedo=h[:,8]/(h[:,8]+h[:,7])
  ep=np.float32(e[:,8])*np.maximum(np.float32(0),np.float32(1)-np.float32(e[:,5])-np.float32(e[:,6]))
  last_fe_by_zone={int(row[1]):row for row in f if int(row[0])==int(np.max(f[:,0])) and row[1]>0}
  last_fe=np.asarray(list(last_fe_by_zone.values()));active_last=last_fe[:,9]>0
  lag=float(np.max(abs(last_fe[active_last,10]/last_fe[active_last,9]-1))) if np.any(active_last) else None
  record.update({
   'Fe_historical_added_probability_max':float(np.max(f[:,9])),
   'Fe_historical_added_probability_final':float(f[-1,9]),
   'last_column_current_Fe_rate_vs_retained_probability_max_relative_difference':lag,
   'Fe_historical_added_probability_last_column_max':float(np.max(f[(f[:,0]==np.max(f[:,0])) & (f[:,1]>0),9])),
   'Fe_H_loss_equals_generic_OTS_plus_direct_Fe_max_relative_defect':float(np.max(abs(fdef))),
   'Ca_common_bin_source_equals_all_absorbers_max_relative_defect':float(np.max(abs(cdef))),
   'Ca_beta_formula_max_relative_error':float(np.max(abs(h[valid,10]/beta-1))),
   'Ca_albedo_formula_max_absolute_error':float(np.max(abs(h[:,9]-albedo))),
   'original_float32_electron_formula_max_absolute_error':float(np.max(abs(e[:,7]-ep))),
   'original_electron_mode_retained':bool(np.all(h[:,14]==0) and np.all(e[:,9]==0)),
   'final_Ca_H_probability_and_OTS_opacity_relative_difference':float(h[-1,5]/c[-1,6]-1),
   'final':{'H_total_destruction_photons_cm3_s':float(f[-1,12]),
    'direct_Fe_photons_cm3_s':float(fe_events[-1]),
    'current_net_Fe_excitation_photons_cm3_s':float(f[-1,6]*f[-1,7]*f[-1,10]),
    'H_generic_OTS_photons_cm3_s':float(f[-1,13]),
    'all_lines_in_Lya_bin_source_photons_cm3_s':float(c[-1,8]),
    'Ca_receiver_photons_cm3_s':float(c[-1,11]),
    'other_receivers_photons_cm3_s':float(c[-1,10]),
    'CaII_fraction_first_three_stages':float(c[-1,13]/c[-1,12:15].sum())},
  })
  if name in ('fe_only','combined'):
   assert record['Fe_H_loss_equals_generic_OTS_plus_direct_Fe_max_relative_defect']<1e-12
  if name in ('ca_only','combined'):
   assert record['Ca_common_bin_source_equals_all_absorbers_max_relative_defect']<1e-6
  assert record['Ca_beta_formula_max_relative_error']<1e-12
  assert record['Ca_albedo_formula_max_absolute_error']<1e-12
  assert record['original_float32_electron_formula_max_absolute_error']==0
 records[name]=record
report={
 'scope':'Same-input prescribed blackbody/T/density control with Fe716/S72; zone count is reported separately. The two independent switches are verified through distinct budgets: H Ly-alpha destruction allocation, and all line sources assigned to the Ly-alpha continuum bin. Their source totals must not be identified. Not a converged planetary atmosphere or complete photon/energy conservation proof.',
 'readout_parity':pairs,'same_input_sha256':next(iter(inputs)),
 'zone_width_cm':1e10 if a.column else 1e8, 'zones_requested':3 if a.column else 1,
 'Fe_mechanism_exercised':all(records[name]['Fe_historical_added_probability_last_column_max']>0 for name in ('tracking','ca_only','fe_only','combined')),
 'cases':records,
 'source_sha256':{str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in [Path(__file__),root/'rt_ots_combined.cpp',root/'rt_line_all_tracking.cpp',root/'rt_escprob_ca_coupled.cpp']},
}
(root/('blackbody_column_summary.json' if a.column else 'blackbody_summary.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'parity':pairs,'Fe_mechanism_exercised':report['Fe_mechanism_exercised'],
 'cases':{name:{key:value for key,value in record.items() if key not in ('execution','final_summary','reported_local_failures')} for name,record in records.items()}},indent=2))
