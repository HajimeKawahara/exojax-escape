"""Compose the separately tested Fe-OTS and coupled-Ca controls, without changing their arithmetic."""
from pathlib import Path
import hashlib,json,difflib,subprocess,shutil
src=Path('/tmp/cloudy-reference-run/c23.01/source')
fe=Path('/tmp/cloudy-fe-ots-allocation')
ca=Path('/tmp/cloudy-ca-coupled-closure-v2')
root=Path('/tmp/cloudy-combined-fe-ca-ots');root.mkdir(exist_ok=True)
old_fe=(fe/'rt_ots_tracking.cpp').read_text()
code=(ca/'rt_ots_ca_coupled.cpp').read_text()
code=code.replace('#include "phycon.h"','#include "phycon.h"\n#include "hydrogenic.h"\nextern double escape_fe_lya_added_pdest;\n#ifndef ESCAPE_EXCLUDE_FE_OTS\n#define ESCAPE_EXCLUDE_FE_OTS 0\n#endif')
anchor='\t\t\t\t\t\t/* this signifies a fake line */'
start=old_fe.index('                        const bool hydrogen_lya_line =')
end=old_fe.index(anchor,start)
assert code.count(anchor)==1
code=code.replace(anchor,old_fe[start:end]+anchor)
needle='iso_sp[ipISO][nelem].trans(ipHi,ipLo).Emis().Pdest()<= DEST0'
assert code.count(needle)==1
code=code.replace(needle,'allocated_pdest<= DEST0',1)
needle='\t\t\t\t\t\t\tiso_sp[ipISO][nelem].trans(ipHi,ipLo).Emis().Pdest();'
assert code.count(needle)==1
replacement='#if ESCAPE_EXCLUDE_FE_OTS\n                            allocated_pdest;\n#else\n'+needle+'\n#endif'
assert replacement in old_fe
code=code.replace(needle,replacement)
code=code.replace('/* ALTERED DIAGNOSTIC C23.01: optional Ca receiver allocation only.\n * This does not add Ca opacity to Pdest or broad-band continuum transfer. */',
 '/* ALTERED DIAGNOSTIC C23.01: independently switched Ca allocation and Fe OTS.\n * The paired rt_escprob source supplies coupled Ca beta/albedo; broad-band\n * continuum transfer is unchanged. Fe uses the historically retained Pdest. */')
(root/'rt_ots_combined.cpp').write_text(code)
for source,target in [(fe/'rt_line_all_tracking.cpp',root/'rt_line_all_tracking.cpp'),
 (ca/'rt_escprob_ca_coupled.cpp',root/'rt_escprob_ca_coupled.cpp')]:shutil.copyfile(source,target)
for base,changed in [('rt_ots.cpp','rt_ots_combined.cpp'),('rt_line_all.cpp','rt_line_all_tracking.cpp'),('rt_escprob.cpp','rt_escprob_ca_coupled.cpp')]:
 (root/(base+'.patch')).write_text(''.join(difflib.unified_diff((src/base).read_text().splitlines(True),(root/changed).read_text().splitlines(True),fromfile='C23.01/'+base,tofile='combined-fe-ca/'+changed)))
flags=['taskset','-c','52','g++','-std=c++11','-O2','-fno-pie','-I'+str(src),'-DSYS_CONFIG="'+str(src/'cloudyconfig.h')+'"']
commands=[]
def run(cmd):commands.append(cmd);subprocess.run(cmd,check=True)
run(flags+['-c',str(root/'rt_line_all_tracking.cpp'),'-o',str(root/'rt_line_all_tracking.o')])
for calcium in (0,1):
 run(flags+[f'-DESCAPE_CA_COUPLED={calcium}','-c',str(root/'rt_escprob_ca_coupled.cpp'),'-o',str(root/f'rt_escprob_ca{calcium}.o')])
for name,iron,calcium in [('tracking',0,0),('fe_only',1,0),('ca_only',0,1),('combined',1,1)]:
 obj=root/f'rt_ots_{name}.o'
 run(flags+[f'-DESCAPE_CA_ALLOCATION={calcium}',f'-DESCAPE_EXCLUDE_FE_OTS={iron}','-c',str(root/'rt_ots_combined.cpp'),'-o',str(obj)])
 run(['taskset','-c','52','g++','-no-pie','-o',str(root/f'cloudy_{name}.exe'),str(src/'maincl.o'),str(root/'rt_line_all_tracking.o'),str(root/f'rt_escprob_ca{calcium}.o'),str(obj),str(src/'libcloudy.a')])
paths=[src/'libcloudy.a',src/'maincl.o',fe/'rt_line_all_tracking.cpp',fe/'rt_ots_tracking.cpp',ca/'rt_ots_ca_coupled.cpp',ca/'rt_escprob_ca_coupled.cpp',Path(__file__)]
paths += list(root.glob('*.cpp'))+list(root.glob('*.o'))+list(root.glob('*.exe'))
report={'scope':'Composed diagnostic controls. Fe historical Pdest is removed only from generic continuum OTS; total H loss and Fe excitation remain. Coupled Ca uses the same four-level absorption in beta, albedo and the Ly-alpha-bin OTS denominator. Original electron mode and broad-band continuum are retained. Compilation alone is not verification.','switches':{'tracking':[0,0],'fe_only':[1,0],'ca_only':[0,1],'combined':[1,1]},'switch_order':['exclude_Fe_from_generic_OTS','coupled_Ca_and_allocation'],'commands':commands,'sha256':{str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}}
(root/'build_receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'built':True,'directory':str(root)}),flush=True)
