"""Exercise independent Fe/Ca switches with the same explicitly large Fe atom."""
from pathlib import Path
import hashlib,json,subprocess,time
root=Path(__file__).parent
original=Path('/tmp/cloudy-fe-ots-allocation/ca_readout/cloudy_unmodified_companion.exe')
old_ca=Path('/tmp/cloudy-ca-coupled-closure-v2/cloudy_ca_coupled.exe')
base=(Path('/tmp/cloudy-ca-coupled-closure-v2/coupled/model.in')).read_text()
text=base.replace('title Read-only Ca excited-opacity hook; not an atmosphere',
 'title Combined Fe OTS and Ca coupling; prescribed one-zone blackbody')
text=text.replace('blackbody 10000 K dilution 0.025',
 'species "Fe+" levels=716\nspecies "S+" levels=72\nblackbody 10000 K dilution 0.025')
variants={'original':original,'tracking':root/'cloudy_tracking.exe','old_ca':old_ca,
 'ca_only':root/'cloudy_ca_only.exe','fe_only':root/'cloudy_fe_only.exe',
 'combined':root/'cloudy_combined.exe'}
for name,binary in variants.items():
 case=root/('bb_fe716_'+name);case.mkdir(exist_ok=False);(case/'model.in').write_text(text)
 command=['taskset','-c','52',str(binary),'-r','model'];start=time.monotonic()
 with (case/'console.txt').open('w') as log:
  result=subprocess.run(command,cwd=case,stdout=log,stderr=subprocess.STDOUT)
 receipt={'command':command,'returncode':result.returncode,'elapsed_seconds':time.monotonic()-start,
  'input_sha256':hashlib.sha256((case/'model.in').read_bytes()).hexdigest(),
  'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
  'scope':'One-zone prescribed blackbody/T/density control with Fe716 and S72, so the Fe overlap can be exercised. Process success alone is not a ledger or physical-adequacy certificate.'}
 (case/'execution_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({'variant':name,**receipt}),flush=True)
 if result.returncode:raise RuntimeError(f'{name} failed; retain its diagnostics.')
