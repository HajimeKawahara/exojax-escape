"""Check the selected actual spectrum using exact JAX products and host roots.

The blend is a runtime argument so the same kernels can check a subsequently
converged thermal state. A fixed-temperature result never supports that case.
"""
from pathlib import Path
from unittest.mock import patch
import argparse
import hashlib
import json
import resource
import threading
import time

import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd
from scipy.sparse.linalg import LinearOperator, gmres

from escape.solar import SolarAtmosphereModel

jax.config.update('jax_enable_x64', True)
jax.config.update('jax_compilation_cache_dir', '/tmp/escape-jax-cache')
# Read existing entries, but avoid the extra executable materialization used to
# serialize new large entries. No numerical model or solve setting changes.
jax.config.update('jax_persistent_cache_min_compile_time_secs', 1e9)
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--state', type=Path, required=True)
parser.add_argument('--preconditioner', type=Path, required=True)
parser.add_argument('--blend', type=float, required=True)
parser.add_argument('--step', type=float, default=1e-3)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--expected-spectrum', type=Path)
args = parser.parse_args()
args.output.mkdir(exist_ok=False)
scratch = Path('/tmp/escape-solar-molecular-continuation')
config_path = scratch/'current5_flow_gradient/configuration.json'
config = json.loads(config_path.read_text())
source = scratch/'source_current_flow_gradient'
manifest = json.loads((source/'manifest.json').read_text())
digest = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name, expected in manifest['files'].items():
    assert digest(source/name) == expected, name
sed_path = Path('/tmp/escape-stellar-sed-data/phoenix10000_surface_flux.npz')
assert digest(sed_path) == config['raw_sed_sha256']
sed = np.load(sed_path)
nist = json.loads(Path('/tmp/escape-five-cell-root-evidence/nist_row.json').read_text())['row']
with patch('exojax.database.nist.api.fetch_nist_lines',
           lambda *a, **kw: (pd.DataFrame(nist), [])):
    model = SolarAtmosphereModel(
        config['edges_rp'], nmax=config['nmax'], iron_levels=config['iron_levels'],
        sulfur_levels=config['sulfur_levels'], iron_lyalpha=True,
        shielding_model='continuous_core', core_escape_model='continuous',
        newton_merit='correction', quadrature_order=2, angle_order=2,
        dense_lower_cells=2, lower_temperature_k=4500., line_sampling='average',
        line_quadrature_order=4, wind_ngrid=config['wind_ngrid'],
        tidal_coefficient_s2=3*(2*np.pi/(1.48*86400))**2,
        extra_frequency_edges=sed['frequency_hz'][[0, -1]],
        observer_options=dict(nlon=2, nlat=2, nnu=101))
boundary = model.stellar_boundary(sed['frequency_hz'], sed['surface_flux_nu'],
                                  incident_flux_ratio=.1, outside_zero=True)
reference = jnp.asarray(config['temperature_reference_k'])
initial = np.load(args.state)['state'].ravel()
preconditioner = np.load(args.preconditioner)
left, right = preconditioner['inverse_left'], preconditioner['inverse_right']
blend = jnp.asarray(args.blend)
start, phase = time.time(), 'constructed'
history = []


def heartbeat():
    while True:
        time.sleep(25)
        print(dict(phase=phase, elapsed=time.time()-start, maxrss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss, memory_maps=len(Path('/proc/self/maps').read_text().splitlines())), flush=True)


threading.Thread(target=heartbeat, daemon=True).start()


def evaluate(state, log_mass, thermal_blend):
    return model.evaluate_atmosphere(
        state, reference, config['mass_loss_g_s']*jnp.exp(log_mass),
        boundary['incident_mean_intensity'],
        hydrogen_line_intensity=boundary['hydrogen_line_intensity'],
        metal_line_intensity=boundary['metal_line_intensity'],
        overlap_intensity=boundary['overlap_intensity'], thermal_blend=thermal_blend)


def residual(state, log_mass, thermal_blend):
    return evaluate(state, log_mass, thermal_blend)[0]


@jax.jit
def diagnostic(state, log_mass, thermal_blend):
    f, physical = evaluate(state, log_mass, thermal_blend)
    return (jnp.max(jnp.abs(f)), physical['valid'], physical['reference_domain_valid'],
            physical['wind_info']['converged'],
            physical['iron_lyalpha_exchange']['selection_distance'])


@jax.jit
def spectrum(state, log_mass, thermal_blend):
    # The observable depends on the supplied populations and wind, not a
    # repeated statistical-equilibrium evaluation. All base/FD roots are
    # independently checked with the original complete equations below.
    del thermal_blend
    values = state.reshape((model.cells, model.state_size+1))
    temperature = reference*jnp.exp(values[:, 0])
    wind, _ = model._wind(values[:, 1:], temperature,
                          config['mass_loss_g_s']*jnp.exp(log_mass))
    physical = model.unpack(values[:, 1:], wind.density_g_cm3/model.mass_per_h)
    physical.update(temperature_k=temperature, radial_velocity_kms=wind.velocity_kms,
                    atomic_lte_mask=model.atomic_lte_mask,
                    converged=True, reference_domain_valid=True)
    return model.spectrum_from_solution(physical)


function = jax.jit(residual)
product = jax.jit(lambda state, mass, b, tangent:
    jax.jvp(lambda x: residual(x, mass, b), (state,), (tangent,))[1])
parameter_product = jax.jit(lambda state, mass, b:
    jax.jvp(lambda q: residual(state, q, b), (mass,), (jnp.ones_like(mass),))[1])
observer_product = jax.jit(lambda state, mass, b, tangent:
    jax.jvp(lambda x, q: spectrum(x, q, b), (state, mass),
            (tangent, jnp.ones_like(mass)))[1])


def linear_solve(state, mass, rhs, label, tolerance=1e-7):
    operator = LinearOperator((state.size, state.size), dtype=float,
        matvec=lambda v: np.array(product(state, jnp.asarray(mass), blend, v), copy=True))
    inverse = LinearOperator(operator.shape, dtype=float,
        matvec=lambda v: v+left@(right@v))
    trace = []
    def callback(error):
        trace.append(float(error))
        if len(trace) % 5 == 0:
            print(label, len(trace), float(error), time.time()-start, flush=True)
    solution, status = gmres(operator, rhs, M=inverse, rtol=tolerance, atol=0.,
                             restart=80, maxiter=4, callback=callback, callback_type='pr_norm')
    error = np.linalg.norm(operator@solution-rhs)/np.linalg.norm(rhs)
    row = dict(label=label, true_relative_error=float(error), iterations=len(trace),
               gmres_info=int(status), passed=bool(np.isfinite(error) and error < 5*tolerance))
    history.append(row)
    (args.output/'history.json').write_text(json.dumps(history, indent=2)+'\n')
    if not row['passed']:
        raise RuntimeError('Failed checked linear solve: '+str(row))
    return solution


def check_state(state, mass):
    values = diagnostic(state, jnp.asarray(mass), blend)
    row = dict(residual=float(values[0]), physical_valid=bool(values[1]),
               reference_domain_valid=bool(values[2]), wind_converged=bool(values[3]),
               iron_selection_distance=np.asarray(values[4]).tolist())
    assert row['residual'] < 1e-9 and all(row[k] for k in (
        'physical_valid', 'reference_domain_valid', 'wind_converged')), row
    return row


phase = 'base root diagnostic'
base = check_state(initial, 0.)
(args.output/'base.json').write_text(json.dumps(base, indent=2)+'\n')
phase = 'parameter JVP compilation'
rhs = -np.asarray(parameter_product(initial, jnp.asarray(0.), blend))
phase = 'state JVP / checked implicit solve'
tangent = linear_solve(initial, 0., rhs, 'implicit')
np.savez_compressed(args.output/'implicit_state.npz', state=initial, tangent=tangent, rhs=rhs)
phase = 'actual observer JVP'
automatic = np.asarray(observer_product(initial, jnp.asarray(0.), blend, tangent))
baseline = np.asarray(spectrum(initial, jnp.asarray(0.), blend))
assert np.isfinite(automatic).all() and np.isfinite(baseline).all()
if args.expected_spectrum is not None:
    np.testing.assert_allclose(baseline, np.load(args.expected_spectrum)['contrast'], rtol=1e-10, atol=1e-14)
np.savez_compressed(args.output/'implicit_spectrum.npz', contrast=baseline,
                    derivative=automatic, wavenumber_cm=np.asarray(model.observer.wavenumber_cm))

finite_spectra, finite_states = [], []
for mass in (-args.step, args.step):
    phase = 'independent finite-difference root '+str(mass)
    value = initial.copy()
    for iteration in range(8):
        f = np.asarray(function(value, jnp.asarray(mass), blend))
        norm = float(np.max(abs(f)))
        print(dict(finite_difference_log_mass=mass, iteration=iteration, residual=norm), flush=True)
        if norm < 1e-10:
            break
        step = linear_solve(value, mass, -f, f'fd{mass}_newton{iteration}')
        accepted = False
        for backtrack in range(16):
            trial = value+(2.**-backtrack)*step
            trial_norm = float(np.max(abs(np.asarray(function(trial, jnp.asarray(mass), blend)))))
            if np.isfinite(trial_norm) and trial_norm < norm:
                value, accepted = trial, True
                break
        if not accepted:
            raise RuntimeError('No finite decreasing finite-difference Newton trial')
    checked = check_state(value, mass)
    finite_states.append(dict(log_mass=mass, **checked))
    contrast = np.asarray(spectrum(value, jnp.asarray(mass), blend))
    assert np.isfinite(contrast).all()
    finite_spectra.append(contrast)
    np.savez_compressed(args.output/f'finite_{mass:+.6f}.npz', state=value, contrast=contrast)

finite = (finite_spectra[1]-finite_spectra[0])/(2*args.step)
error = float(np.max(abs(automatic-finite))/np.max(abs(finite)))
receipt = dict(source_revision=manifest['revision'],
    driver_sha256=digest(__file__), configuration_sha256=digest(config_path),
    base_state_sha256=digest(args.state), preconditioner_sha256=digest(args.preconditioner),
    source_manifest_sha256=digest(source/'manifest.json'), blend=args.blend,
    finite_difference_step=args.step, base=base, finite_roots=finite_states,
    maximum_derivative_relative_error=error, required_relative_error=1e-4,
    passed=bool(error < 1e-4), elapsed_s=time.time()-start,
    observer_factoring='Use the same unpack/wind/continuum/production observer at an independently checked root; avoid a redundant SE evaluation inside the partial observable.',
    expected_spectrum_sha256=None if args.expected_spectrum is None else digest(args.expected_spectrum),
    new_cache_writes_disabled=True,
    scope='Exact JAX products and checked host GMRES, followed by independent centered-difference roots. The actual coarse observer is used. This is not the production implicit primitive, spatial/observer adequacy, or a global NUTS-domain proof; blend=0 fixes temperature.')
(args.output/'summary.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(receipt, flush=True)
assert receipt['passed']
