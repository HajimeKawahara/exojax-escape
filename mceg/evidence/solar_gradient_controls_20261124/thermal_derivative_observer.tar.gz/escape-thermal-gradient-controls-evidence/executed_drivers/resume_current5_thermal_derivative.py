"""Continue interrupted thermal finite differences with per-step checkpoints."""
from pathlib import Path
import sys

resume_driver = Path(__file__)
bootstrap = resume_driver.with_name('audit_current5_implicit_refinement.py')
scratch_root = resume_driver.parent
previous = scratch_root/'current5_thermal_derivative'
sys.argv = [str(bootstrap),'--state',str(scratch_root/'current5_flow_gradient/stage_1.0000.npz'),
    '--preconditioner',str(scratch_root/'current5_flow_gradient/blend_1.0000_step_05/krylov.npz'),
    '--blend','1','--linear-tolerance','1e-10','--step','.00025',
    '--output',str(scratch_root/'current5_thermal_derivative_resumed')]
exec(compile(bootstrap.read_text().split("phase = 'base root diagnostic'")[0],
             str(bootstrap),'exec'),globals())


@jax.jit
def value_and_product(state,mass,b,tangent):
    # One compiled graph supplies both the primal and its exact JVP. A zero
    # direction obtains F without compiling a second large residual graph.
    return jax.jvp(lambda x: residual(x,mass,b),(state,),(tangent,))


def function(state,mass,b):
    return value_and_product(state,mass,b,jnp.zeros_like(state))[0]


def product(state,mass,b,tangent):
    return value_and_product(state,mass,b,tangent)[1]


phase = 'verify saved thermal root and implicit products'
base = check_state(initial,0.)
saved = np.load(previous/'implicit_state.npz')
np.testing.assert_array_equal(saved['state'],initial)
tangent,rhs = saved['tangent'],saved['rhs']
linear_error = float(np.linalg.norm(np.asarray(product(initial,jnp.asarray(0.),blend,tangent))-rhs)/np.linalg.norm(rhs))
assert linear_error<5e-10,linear_error
automatic = np.asarray(observer_product(initial,jnp.asarray(0.),blend,tangent))
baseline = np.asarray(spectrum(initial,jnp.asarray(0.),blend))
original = np.load(previous/'implicit_spectrum.npz')
np.testing.assert_allclose(automatic,original['derivative'],rtol=1e-12,atol=1e-15)
np.testing.assert_allclose(baseline,original['contrast'],rtol=1e-12,atol=1e-15)
(args.output/'reused_product_check.json').write_text(json.dumps(dict(
    base=base,true_linear_residual=linear_error,
    original_implicit_state_sha256=digest(previous/'implicit_state.npz'),
    original_spectrum_sha256=digest(previous/'implicit_spectrum.npz'),
    observer_replay_passed=True),indent=2)+'\n')
finite_spectra,finite_states = [],[]
for mass in (-args.step,args.step):
    phase = 're-solve finite-difference root '+str(mass)
    # The saved sensitivity predicts a seed, not an accepted root. Each
    # perturbed state must independently pass the original full equations.
    value = initial+mass*tangent
    for iteration in range(8):
        f = np.asarray(function(value,jnp.asarray(mass),blend))
        norm = float(np.max(abs(f)))
        np.savez_compressed(args.output/f'checkpoint_{mass:+.6f}_{iteration:02d}.npz',
                            state=value,residual=f,log_mass=mass)
        print(dict(log_mass=mass,iteration=iteration,residual=norm),flush=True)
        if norm<1e-11:
            break
        step = linear_solve(value,mass,-f,f'fd{mass}_newton{iteration}',tolerance=1e-6)
        for backtrack in range(16):
            trial = value+(2.**-backtrack)*step
            trial_norm = float(np.max(abs(np.asarray(function(trial,jnp.asarray(mass),blend)))))
            if np.isfinite(trial_norm) and trial_norm<norm:
                value = trial
                break
        else:
            raise RuntimeError('No finite decreasing perturbed-root trial')
    checked = check_state(value,mass)
    assert checked['residual']<1e-11
    finite_states.append(dict(log_mass=mass,**checked))
    contrast = np.asarray(spectrum(value,jnp.asarray(mass),blend))
    assert np.isfinite(contrast).all()
    finite_spectra.append(contrast)
    np.savez_compressed(args.output/f'finite_{mass:+.6f}.npz',state=value,contrast=contrast)
finite = (finite_spectra[1]-finite_spectra[0])/(2*args.step)
error = float(np.max(abs(automatic-finite))/np.max(abs(finite)))
receipt = dict(source_revision=manifest['revision'],driver_sha256=digest(resume_driver),
    bootstrap_sha256=digest(bootstrap),configuration_sha256=digest(config_path),
    base_state_sha256=digest(args.state),preconditioner_sha256=digest(args.preconditioner),
    interrupted_exit_code=143,interruption_reason='No numerical exception was recorded; termination cause was not established.',
    preserved_run=str(previous),preserved_log_sha256=digest(scratch_root/'current5_thermal_derivative.log'),
    blend=1.,base=base,finite_roots=finite_states,finite_difference_step=args.step,
    sensitivity_true_linear_residual=linear_error,primal_linear_rtol=1e-6,
    perturbed_root_stopping_residual=1e-11,required_relative_error=1e-4,
    maximum_derivative_relative_error=error,passed=bool(error<1e-4),
    elapsed_s=time.time()-start,
    scope='Full thermal/radiation/composition/wind implicit JVP checked against re-solved perturbed roots and the actual coarse observer. The IFT predictor is only an initial guess; full original root/domain checks determine acceptance. No production cold-start, radial resolution or NUTS-envelope claim.')
(args.output/'summary.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(receipt,flush=True)
assert receipt['passed'],receipt
