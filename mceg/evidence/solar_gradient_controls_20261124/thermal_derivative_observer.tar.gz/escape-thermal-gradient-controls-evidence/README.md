# Full thermal sensitivity and fixed-atmosphere observer refinement

The original fixed-temperature derivative failed the unchanged 1e-4
observable criterion. Tightening only its implicit linear solve from 1e-7
to 1e-10, while retaining the original independently re-solved finite
differences, reduces the error from 2.5951e-4 to 1.3832e-6. A separate
smaller finite step gives 7.7412e-7. This is a conditioned-observable
accuracy control, not a claim of global smoothness across all rate guards.

At the full five-cell thermal/radiation/composition/wind root, the exact
implicit spectral JVP agrees with two independently re-solved perturbed
roots to 2.3939e-6. The true sensitivity equation residual is 4.6131e-11;
both finite-difference roots satisfy F-infinity below 2.02e-12. A saved
implicit tangent initializes those solves but does not determine their
acceptance. The original process terminated with exit 143 and no recorded
numerical exception; its cause is unknown. Its products and log are kept
alongside the resumed calculation and its independently checked products.

These are host-orchestrated exact JAX-product controls at one mass-loss
point, not a completed production reverse-mode or NUTS-domain test.
The coarse actual observer used for the derivative has 101 frequencies
and 2 by 2 surface nodes. Its fast evaluation is bitwise identical in
spectrum and directional derivative to the original complete evaluation.

Separate longitude, latitude, frequency and phase refinements and their
joint refinement all pass 0.1 supplied observation errors at the unchanged
full thermal root. Their largest change is 1.0225 ppm, 0.00547 supplied
errors. This does not test radial, atomic or radiation-grid convergence,
nor establish the exact unpublished observational reduction.

The included arrays and receipts are from executed controls. The packaging
script recomputes their reported finite-difference and observer errors;
it does not rerun the atmosphere equations. Original drivers retain their
executed paths. For a new physical replay restore the exact source manifest,
the root/input metadata in evidence/solar-thermal-root-20261124 and the
retrieved PHOENIX input with its recorded SHA256. Restore ExoJAX revision
38cb2e44f153ad6d729e3253e235702de52920cf. Preconditioner factors were
numerical accelerators and are not redistributed: regenerate a checked
inverse approximation or solve the original residual equations directly.
No private stellar samples, compiler caches, binaries or duplicate atomic
tables are included. The observed data are attributed under CC BY 4.0 in
observer/ORIGINAL_OBSERVATION_NOTICE.txt. No extra plots duplicate the
existing thermal observer figure archive.
