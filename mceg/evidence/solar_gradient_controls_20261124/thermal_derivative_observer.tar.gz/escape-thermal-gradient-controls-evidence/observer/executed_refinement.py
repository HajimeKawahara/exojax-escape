"""Run independent observer refinements after the fixed-temperature audit."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

import numpy as np

scratch = Path('/tmp/escape-solar-molecular-continuation')
release = scratch/'current5_fixed_derivative_refinement/summary.json'
print('Waiting for fixed-temperature derivative run to release CPUs 56--59.',flush=True)
while not release.exists():
    time.sleep(25)
time.sleep(5)
root = Path('/tmp/escape-native-thermal-observer-refinements')
root.mkdir(exist_ok=False)
env = dict(os.environ,JAX_PLATFORMS='cpu',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
           NUMBA_CACHE_DIR='/tmp/escape-numba-cache',MPLCONFIGDIR='/tmp/escape-matplotlib',
           PYTHONPATH=str(scratch/'source_current_flow_gradient')+
           ':/tmp/exojax-spectrum-upstream/src:/tmp/escape-coupled-atmosphere/examples')
baseline = np.load('/tmp/escape-native-current5-thermal-observer/derived_spectrum.npz')
observed_velocity = baseline['observed_velocity_kms']
prediction = np.interp(observed_velocity,baseline['output_velocity_kms'],baseline['processed'])
errors = baseline['supplied_error']
records = []
for label,grids in (
    ('longitude',(96,24,1201,9)),
    ('latitude',(48,48,1201,9)),
    ('frequency',(48,24,2401,9)),
    ('phase',(48,24,1201,17)),
    ('joint',(96,48,2401,17)),
):
    print('Running',label,grids,flush=True)
    command = ['taskset','-c','56-59','/home/kawahara/miniconda3/bin/python','-u',
        '/tmp/observe_native_solar_root.py',
        '--case','/tmp/escape-current-five-cell-thermal-root-evidence',
        '--cadence','/tmp/escape-observation-processing/cadence_weights.npz',
        '--stellar-surface','/tmp/escape-stellar-sed-data/phoenix10000_surface_flux.npz',
        '--output',str(root/label)]
    for name,value in zip(('nlon','nlat','nnu','nphase'),grids):
        command.extend(['--'+name,str(value)])
    with (root/(label+'.log')).open('w') as log:
        result = subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
    row = dict(label=label,grids=grids,exit_code=result.returncode)
    if result.returncode == 0:
        data = np.load(root/label/'derived_spectrum.npz')
        refined = np.interp(observed_velocity,data['output_velocity_kms'],data['processed'])
        difference = refined-prediction
        row.update(maximum_difference_ppm=float(np.max(abs(difference))*1e6),
            maximum_difference_over_supplied_error=float(np.max(abs(difference)/errors)),
            rms_difference_over_supplied_error=float(np.sqrt(np.mean((difference/errors)**2))),
            spectrum_sha256=hashlib.sha256((root/label/'derived_spectrum.npz').read_bytes()).hexdigest(),
            passed=bool(np.max(abs(difference)/errors)<.1))
    else:
        row['passed'] = False
    records.append(row)
    receipt = dict(required_maximum_difference_over_supplied_error=.1,controls=records,
        baseline='/tmp/escape-native-current5-thermal-observer/derived_spectrum.npz',
        baseline_sha256=hashlib.sha256(Path('/tmp/escape-native-current5-thermal-observer/derived_spectrum.npz').read_bytes()).hexdigest(),
        scope='Independent and joint observer refinements at one unchanged five-cell thermal root. No atmospheric radial/atomic/transfer convergence or exact observational-reduction claim.',
        driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (root/'summary.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(row,flush=True)
assert all(row['passed'] for row in records),records
