"""Local radiation-channel diagnostics; no physical transport is inferred."""

from pathlib import Path
import hashlib
import json
import os

os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:2])

import jax
import jax.numpy as jnp
import numpy as np
from exojax.database.core.broadening import doppler_sigma
from exojax.database.core_atom.io import load_atomicdata
from exojax.opacity.lpf.lpf import vvoigt
from escape.hydrogen_atom import (
    make_hydrogen_atom, solve_atom_populations, atom_rate_coefficients,
    atom_natural_width_hz,
)
from escape.hydrogen_rates import (
    PLANCK_CGS, EV_CGS, BOLTZMANN_CGS, LIGHT_SPEED_CGS, planck_occupation,
)
from escape.nlte_forward import halpha_coefficients

jax.config.update("jax_enable_x64", True)
OUT = Path(__file__).parent
atom = make_hydrogen_atom(15)
thresholds = np.asarray(atom.ionization_energy_erg) / PLANCK_CGS
edges = np.unique(np.r_[thresholds, 100 * EV_CGS / PLANCK_CGS])
nodes, weights = np.polynomial.legendre.leggauss(48)
width = np.diff(np.log(edges))[:, None]
freq = jnp.asarray((edges[:-1, None] * np.exp(width * (nodes + 1) / 2)).ravel())
weight = jnp.asarray((np.asarray(freq).reshape(-1, 48) * width * weights / 2).ravel())
line = planck_occupation(atom.line_frequency_hz, 10000.0, 0.025)
cont = planck_occupation(freq, 10000.0, 0.025)
low, up = np.asarray(atom.line_lower), np.asarray(atom.line_upper)
principal = np.asarray(atom.principal_n)
center_cm = 15233.146
mass = float(load_atomicdata().set_index("ielem").loc[1, "mass"])
line_centers = jnp.full((3,), center_cm)
gamma = atom_natural_width_hz(atom)[2:5] / LIGHT_SPEED_CGS

inputs = [
    Path("/tmp/exojax-escape-nlte-spectrum/results/nlte_asymmetry/candidate_arrays.npz"),
    Path("/tmp/escape-physics-diagnosis/results/physics_diagnosis/hybrid_arrays.npz"),
]
candidate, hybrid = [{key: value for key, value in np.load(path).items()} for path in inputs]
cases = [
    ("baseline", candidate, "baseline_", "baseline_radius_rp"),
    ("manual", candidate, "manual_", "manual_radius_rp"),
    ("current_fit", hybrid, "current_fit_", "radius_rp"),
]


def variants():
    """Perturb occupations only; spontaneous rates and material state stay physical."""
    yield "full_field", line, cont
    masks = {
        "Halpha": (principal[up] == 3) & (principal[low] == 2),
        "Lya": (low == 0) & (principal[up] == 2),
        "Lyb": (low == 0) & (principal[up] == 3),
        "higher_Lyman": (low == 0) & (principal[up] >= 3),
        "all_Lyman": low == 0,
    }
    for name, mask in masks.items():
        factors = (0.1,) if name in ("Halpha", "Lya") else (0.1, 0.01, 0.0)
        for factor in factors:
            yield f"{name}_x{factor:g}", line * jnp.where(mask, factor, 1), cont
    yield "Lyman_continuum_x0.1", line, cont * jnp.where(
        freq * PLANCK_CGS >= 13.5984345 * EV_CGS, 0.1, 1)
    yield "Balmer_continuum_only_x0.1", line, cont * jnp.where(
        (freq * PLANCK_CGS >= 13.5984345 / 4 * EV_CGS)
        & (freq * PLANCK_CGS < 13.5984345 * EV_CGS), 0.1, 1)


def shell_budget(bound, ne, proton, rates, shell):
    """Gross shell ingress and loss; intra-shell transitions cancel exactly."""
    radiative, collision, photoion, recomb, collion, threebody = map(np.asarray, rates)
    selected = np.flatnonzero(principal == shell)
    others = {
        "ground": np.flatnonzero(principal == 1),
        "n2" if shell == 3 else "n3": np.flatnonzero(principal == (2 if shell == 3 else 3)),
        "higher": np.flatnonzero(principal >= 4),
    }
    incoming, outgoing = {}, {}
    for group, indices in others.items():
        for mechanism, coefficient in [("radiative", radiative), ("collisional", ne * collision)]:
            incoming[group + "_" + mechanism] = float(np.sum(
                bound[indices, None] * coefficient[np.ix_(indices, selected)]))
            outgoing[group + "_" + mechanism] = float(np.sum(
                bound[selected, None] * coefficient[np.ix_(selected, indices)]))
    incoming["radiative_recombination"] = float(ne * proton * recomb[selected].sum())
    incoming["threebody_recombination"] = float(ne**2 * proton * threebody[selected].sum())
    outgoing["photoionization"] = float(np.sum(bound[selected] * photoion[selected]))
    outgoing["collisional_ionization"] = float(np.sum(bound[selected] * ne * collion[selected]))
    total = sum(incoming.values())
    return {
        "ingress_cm3_s": incoming, "loss_cm3_s": outgoing,
        "ingress_fraction": {key: value / total for key, value in incoming.items()},
        "fractional_balance_error": (total - sum(outgoing.values())) / total,
    }


report_path = OUT / "local_rate_budget.json"
rows = json.loads(report_path.read_text())["rows"] if report_path.exists() else []
for case, arrays, prefix, radius_key in cases:
    for radius in [1.3, 1.8]:
        index = int(np.argmin(abs(arrays[radius_key] - radius)))
        if sum(row["case"] == case and row["radius_rp"] == float(arrays[radius_key][index])
               for row in rows) == 14:
            continue
        temperature = float(arrays[prefix + "temperature_k"][index])
        density = float(arrays[prefix + "n_h_cm3"][index])
        profile = vvoigt(jnp.zeros((3, 1)), doppler_sigma(line_centers, temperature, mass), gamma)[:, 0]
        for name, occupation, continuum in variants():
            result = solve_atom_populations(density, atom, temperature, occupation, continuum, freq, weight)
            bound = np.asarray(result.bound_cm3)
            ne, proton = float(result.electron_cm3), float(result.proton_cm3)
            rates = atom_rate_coefficients(atom, temperature, occupation, continuum, freq, weight, electron_cm3=ne)
            alpha, emission = halpha_coefficients(bound, center_cm, sum_branches=False)
            source = float(jnp.sum(emission * profile) / jnp.sum(alpha * profile))
            source_tex = PLANCK_CGS * LIGHT_SPEED_CGS * center_cm / BOLTZMANN_CGS / np.log1p(
                2 * PLANCK_CGS * LIGHT_SPEED_CGS**2 * center_cm**3 / source)
            row = {
                "case": case, "radius_rp": float(arrays[radius_key][index]), "variant": name,
                "temperature_k": temperature, "n_h_cm3": density, "electron_cm3": ne,
                "n2_cm3": float(bound[1:3].sum()), "n3_cm3": float(bound[3:6].sum()),
                "n3_over_n2": float(bound[3:6].sum() / bound[1:3].sum()),
                "ionized_fraction": float(result.ionized_fraction), "bound_cm3": bound.tolist(),
                "halpha_rest_center_source": source, "halpha_rest_center_source_tex_k": float(source_tex),
                "halpha_rest_center_extinction_cm_inv": float(jnp.sum(alpha * profile)),
                "population_inversion_at_rest_center": bool(jnp.sum(alpha * profile) <= 0),
                "halpha_branch_emissivity_fraction": np.asarray(emission * profile / jnp.sum(emission * profile)).tolist(),
                "valid": bool(result.valid), "converged": bool(result.converged),
                "rate_residual_norm": float(result.rate_residual_norm),
                "charge_residual_norm": float(result.residual_norm),
                "n2_budget": shell_budget(bound, ne, proton, rates, 2),
                "n3_budget": shell_budget(bound, ne, proton, rates, 3),
            }
            if name == "full_field":
                row["n2_fractional_difference_from_saved"] = float(bound[1:3].sum() / arrays[prefix + "n2_cm3"][index] - 1)
                row["n3_fractional_difference_from_saved"] = float(bound[3:6].sum() / arrays[prefix + "n3_cm3"][index] - 1)
            rows.append(row)
        print(case, radius, [(r["variant"], round(r["halpha_rest_center_source_tex_k"]), round(r["n3_over_n2"], 5)) for r in rows[-14:]], flush=True)
        report = {
            "scope": "Fixed nH,T local rate diagnostics and prescribed-field occupation ablations. These are causal diagnostics, not a radiation-transfer solution or a fitted atmosphere.",
            "rate_budget_scope": "Gross ingress/loss rates count repeated resonance absorption and decay. Fractions do not represent net escaping Halpha photon creation.",
            "source_definition": "Actual summed Halpha j/alpha at rest center with branch-specific full-lifetime Voigt profiles, converted to equivalent Planck temperature; no statistical substate ratio is imposed. Negative source temperatures flag population inversion and are not positive Planck brightness temperatures.",
            "fixed": {"nmax": 15, "continuum_points_per_interval": 48, "radiation_temperature_k": 10000.0, "radiation_dilution": 0.025, "center_cm_inv": center_cm, "hydrogen_mass_amu": mass},
            "input_sha256": {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs},
            "jax_version": jax.__version__, "jax_x64": bool(jax.config.jax_enable_x64), "rows": rows,
        }
        (OUT / "local_rate_budget.json").write_text(json.dumps(report, indent=2) + "\n")
