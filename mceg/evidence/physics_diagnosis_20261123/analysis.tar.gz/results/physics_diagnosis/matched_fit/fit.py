"""Controlled freedom comparison; prescribed-field fits are not physical inference."""
from __future__ import annotations
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import time
from unittest.mock import patch

import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd
from scipy.optimize import least_squares

from escape.nlte_forward import HydrogenNLTEForwardModel
from escape.hydrogen_forward import SYNCHRONOUS_ROTATION_KMS
from generate_spectra import load_observations
from verify_nlte_spectrum import NIST_ROW

jax.config.update('jax_enable_x64', True)
parser = argparse.ArgumentParser()
parser.add_argument('--mode', choices=['nonisothermal','isothermal'], required=True)
args = parser.parse_args()
out = Path('/tmp/escape-matched-fit') / args.mode
out.mkdir(parents=True, exist_ok=True)
tidal = 3 * (2*np.pi/(1.48*86400))**2 if args.mode == 'nonisothermal' else 0.0
mu = .5 if args.mode == 'nonisothermal' else 2/3
with patch('exojax.database.nist.api.fetch_nist_lines',lambda *a, **kw:(pd.DataFrame(NIST_ROW),[])):
    model = HydrogenNLTEForwardModel(nlayer=128,nlon=12,nlat=6,nnu=601,
                wind_model=args.mode,tidal_coefficient_s2=tidal)
velocity, observed, error = map(jnp.asarray,load_observations(model.line_center_cm))

def keywords(p):
    return dict(mass_loss_g_s=1e13*jnp.exp(p[0]),temperature_top_k=1e4*p[1],
        zonal_kms=10*p[2],rotation_kms=SYNCHRONOUS_ROTATION_KMS,
        mean_molecular_weight=mu,
        wind_temperature_k=1e4*p[3] if args.mode == 'isothermal' else 1e4,
        radiation_dilution=.025,radiation_temperature_k=1e4)

@jax.jit
def spectrum(p):
    return model.spectrum(**keywords(p))

@jax.jit
def prediction(p):
    return jnp.interp(velocity,model.velocity_kms[::-1],spectrum(p)[::-1])

@jax.jit
def residual(p):
    signal = prediction(p)
    baseline = jnp.sum((observed-signal)/error**2)/jnp.sum(1/error**2)
    return (signal+baseline-observed)/error
jacobian=jax.jit(jax.jacfwd(residual))
lo=[np.log(.01),.6,0.]
hi=[np.log(1000),1.4,3.]
starts=[(2.0918598638957434e14,6105.231332735623,11.6,10000),
        (1e15,13900,17.,18000),(9e15,12000,5.,14000)]
if args.mode == 'isothermal':
    lo.append(.6);hi.append(3.)
records=[]
summary=dict(scope='Controlled exploratory local least squares; no observational reduction or physical validity claimed.',
    mode=args.mode,kinetic_domain_note='Ttop cannot exceed14000K: atom data domain restriction retained, not extrapolated.',
    free_parameters=['ln(Mdot/1e13)','Ttop/1e4','zonal/10']+(['Twind/1e4'] if args.mode=='isothermal' else [])+['analytically profiled constant baseline'],
    lower_bounds=lo,upper_bounds=hi,
    fixed=dict(nmax=15,nlayer=128,nlon=12,nlat=6,nnu=601,temperature_base_k=6000,
        mu=mu,tidal_coefficient_s2=tidal,radiation_dilution=.025,radiation_temperature_k=10000,
        rotation_kms=SYNCHRONOUS_ROTATION_KMS,phase=.375),
    trials=records,source_sha256={str(p):sha256(p.read_bytes()).hexdigest() for p in [
        Path('/tmp/exojax-escape-nlte-spectrum/src/escape/nlte_forward.py'),
        Path('/tmp/exojax-escape-nlte-spectrum/src/escape/hydrogen_atom.py'),
        Path('/tmp/exojax-escape-nlte-spectrum/src/escape/hydrogen_forward.py'),
        Path(__file__)]})
for index,(mass,top,zonal,wind) in enumerate(starts):
    p0=np.array([np.log(mass/1e13),top/1e4,zonal/10]+([wind/1e4] if args.mode=='isothermal' else []))
    t0=time.monotonic()
    record=dict(trial=index,initial=p0.tolist())
    try:
        rr=np.asarray(residual(p0));jj=np.asarray(jacobian(p0))
        record['initial_residual_finite']=bool(np.isfinite(rr).all())
        record['initial_jacobian_finite']=bool(np.isfinite(jj).all())
        print(json.dumps({'start':index,'mode':args.mode,'initial_rms':float(np.sqrt(np.mean(rr**2))),'elapsed':time.monotonic()-t0}),flush=True)
        result=least_squares(lambda p:np.asarray(residual(p)),p0,jac=lambda p:np.asarray(jacobian(p)),
            bounds=(lo,hi),x_scale='jac',max_nfev=100,ftol=1e-7,xtol=1e-7,gtol=1e-7)
        pred=np.asarray(prediction(result.x));spec=np.asarray(spectrum(result.x))
        baseline=float(np.average(np.asarray(observed)-pred,weights=np.asarray(error)**-2))
        kw=keywords(result.x);popkw={k:v for k,v in kw.items() if k not in ['zonal_kms','rotation_kms']}
        prof={k:np.asarray(v) for k,v in model.population_profiles(**popkw).items()}
        record.update(coordinates=result.x.tolist(),parameters={k:float(v) for k,v in kw.items()},
            baseline=baseline,rms=float(np.sqrt(np.mean(result.fun**2))),success=bool(result.success),
            message=result.message,nfev=int(result.nfev),active_bounds=result.active_mask.tolist(),
            optimality=float(result.optimality),all_roots_converged=bool(np.all(prof['converged'])),
            all_roots_valid=bool(np.all(prof['valid'])),max_rate_residual=float(np.max(prof['rate_residual_norm'])),
            n2_column_cm2=float(np.sum(prof['n2_cm3']*np.asarray(model.thickness_cm))),
            n3_column_cm2=float(np.sum(prof['n3_cm3']*np.asarray(model.thickness_cm))),
            elapsed_s=time.monotonic()-t0)
        np.savez_compressed(out/f'trial_{index}.npz',velocity_kms=np.asarray(model.velocity_kms),spectrum=spec,
            prediction=pred,baseline=baseline,observed=np.asarray(observed),error=np.asarray(error),
            observation_velocity=np.asarray(velocity),radius_rp=np.asarray(model.radius_rp),
            thickness_cm=np.asarray(model.thickness_cm),**prof)
    except Exception as exc:
        record.update(success=False,error=repr(exc),elapsed_s=time.monotonic()-t0)
    records.append(record)
    (out/'fits.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
    print(json.dumps(record,allow_nan=False),flush=True)
