"""Check new optimization directions and refinement at selected fitted points."""
from __future__ import annotations
import argparse
from hashlib import sha256
import json
from pathlib import Path
from unittest.mock import patch

import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd
from escape.nlte_forward import HydrogenNLTEForwardModel
from generate_spectra import load_observations
from verify_nlte_spectrum import NIST_ROW

jax.config.update('jax_enable_x64', True)
parser=argparse.ArgumentParser();parser.add_argument('--mode',required=True);args=parser.parse_args()
root=Path('/tmp/escape-matched-fit')/args.mode
fits=json.loads((root/'fits.json').read_text())
valid=[r for r in fits['trials'] if r.get('success') and r.get('all_roots_converged') and r.get('all_roots_valid')]
if not valid: raise RuntimeError('No successful valid fit')
best=min(valid,key=lambda r:r['rms']);p=jnp.asarray(best['coordinates']);kw=best['parameters']
fixed=fits['fixed']
def make(nlayer=128,nmax=15):
    with patch('exojax.database.nist.api.fetch_nist_lines',lambda *a, **kw:(pd.DataFrame(NIST_ROW),[])):
        return HydrogenNLTEForwardModel(nlayer=nlayer,nmax=nmax,nlon=12,nlat=6,nnu=601,
            wind_model=args.mode,tidal_coefficient_s2=fixed['tidal_coefficient_s2'])
model=make()
vel,obs,err=map(jnp.asarray,load_observations(model.line_center_cm))
def keywords(p):
    return dict(mass_loss_g_s=1e13*jnp.exp(p[0]),temperature_top_k=1e4*p[1],zonal_kms=10*p[2],
        rotation_kms=fixed['rotation_kms'],mean_molecular_weight=fixed['mu'],
        wind_temperature_k=1e4*p[3] if args.mode=='isothermal' else 1e4,
        radiation_dilution=.025,radiation_temperature_k=1e4)
@jax.jit
def prediction(p):
    s=model.spectrum(**keywords(p))
    return jnp.interp(vel,model.velocity_kms[::-1],s[::-1])
@jax.jit
def residual(p):
    signal=prediction(p);baseline=jnp.sum((obs-signal)/err**2)/jnp.sum(1/err**2)
    return (signal+baseline-obs)/err
actual=np.asarray(jax.jacfwd(residual)(p));step=1e-4
fd=np.stack([np.asarray((residual(p+jnp.eye(len(p))[i]*step)-residual(p-jnp.eye(len(p))[i]*step))/(2*step)) for i in range(len(p))],axis=-1)
allowed=1e-7+.003*np.maximum(np.abs(actual),np.abs(fd))
report={'scope':'Sampled checks at selected local minima, not a global fit or domain-wide numerical guarantee.',
    'best_trial':best['trial'],'best':best,
    'gradient':{'step':step,'rtol':.003,'atol':1e-7,'finite':bool(np.isfinite(actual).all() and np.isfinite(fd).all()),
                'max_error_over_tolerance':float(np.max(np.abs(actual-fd)/allowed)),
                'passed':bool(np.isfinite(actual).all() and np.isfinite(fd).all() and np.all(np.abs(actual-fd)<=allowed))},
    'refinements':{}}
base=np.asarray(prediction(p))
for label,grid in [('layers128to256',{'nlayer':256}),('nmax15to20',{'nmax':20})]:
    finer=make(**grid);spec=finer.spectrum(**kw)
    signal=np.asarray(jnp.interp(vel,finer.velocity_kms[::-1],spec[::-1]))
    d=np.abs(signal-base)/np.asarray(err)
    report['refinements'][label]={'max_over_supplied_sigma':float(np.max(d)),
        'passed_existing_numerical_0p1_sigma':bool(np.isfinite(d).all() and np.max(d)<.1),
        'baseline':'Held fixed; cancels in refined-minus-base difference.'}
    print(json.dumps({label:report['refinements'][label]}),flush=True)
report['fit_input_sha256']=sha256((root/'fits.json').read_bytes()).hexdigest()
(root/'checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2),flush=True)
