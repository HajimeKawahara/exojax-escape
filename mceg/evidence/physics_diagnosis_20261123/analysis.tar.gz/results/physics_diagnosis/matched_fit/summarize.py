"""Summarize sampled fits and the integrated-coefficient source temperature."""
from pathlib import Path
import json
import numpy as np

root=Path('/tmp/escape-matched-fit')
h,c,k,wn=6.62607015e-27,2.99792458e10,1.380649e-16,15233.146
report={'scope':'Exploratory local least-squares minima; no global optimum, physical inference or exact observational reduction claim.',
 'temperature_domain':'Gas kinetic Ttop retained at6000..14000K; legacy M3 fitted22149K is outside this atom domain.',
 'source_temperature_definition':'Solve B_wavenumber(Tex)=sum_branch(j_integral)/sum_branch(alpha_integral). This is a frequency-integrated coefficient ratio, not the frequency-dependent branch mixture at each pixel.',
 'baseline_note':'Unbounded analytically profiled constant, matching PR9, more permissive than legacy +/-0.0005.',
 'fits':{}}
for mode in ['nonisothermal','isothermal','isothermal_lowmass']:
 fits=json.loads((root/mode/'fits.json').read_text())
 valid=[r for r in fits['trials'] if r.get('success') and r.get('all_roots_converged') and r.get('all_roots_valid')]
 best=min(valid,key=lambda r:r['rms'])
 data=np.load(root/mode/f"trial_{best['trial']}.npz")
 source=np.squeeze(data['halpha_emissivity_integral'])/np.squeeze(data['halpha_extinction_integral'])
 tex=h*c*wn/k/np.log1p(2*h*c*c*wn**3/source)
 samples=[]
 for radius in [1.1,1.3,1.5,1.8,2.5]:
  i=np.argmin(abs(data['radius_rp']-radius))
  samples.append({'radius_rp':float(data['radius_rp'][i]),'n2_cm3':float(data['n2_cm3'][i]),
   'n3_over_n2':float(data['ratio'][i]),'integrated_source_tex_k':float(tex[i]),
   'kinetic_temperature_k':float(data['temperature_k'][i]),'radial_velocity_kms':float(data['radial_velocity_kms'][i])})
 report['fits'][mode]={'best':best,'all_trial_rms':[r.get('rms') for r in fits['trials']],
  'all_trials_successful':len(valid)==len(fits['trials']),'samples':samples}
 check=root/mode/'checks.json'
 if check.exists():report['fits'][mode]['checks']=json.loads(check.read_text())
(root/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({m:{'best_rms':r['best']['rms'],'all_trial_rms':r['all_trial_rms'],'checks':r.get('checks',{}).get('refinements')} for m,r in report['fits'].items()},indent=2))
