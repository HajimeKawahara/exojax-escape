"""Local exploratory fits; processed data are not a validated likelihood."""
from pathlib import Path
from unittest.mock import patch
import json
import time
import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd
from scipy.optimize import least_squares
from escape.nlte_forward import HydrogenNLTEForwardModel
from escape.hydrogen_forward import SYNCHRONOUS_ROTATION_KMS
from generate_spectra import load_observations
from verify_nlte_spectrum import NIST_ROW

jax.config.update('jax_enable_x64', True)
out = Path('/tmp/exojax-escape-nlte-spectrum/results/nlte_asymmetry')
out.mkdir(parents=True, exist_ok=True)
tidal = 3 * (2 * np.pi / (1.48 * 86400)) ** 2
with patch('exojax.database.nist.api.fetch_nist_lines',
           lambda *a, **kw: (pd.DataFrame(NIST_ROW), [])):
    model = HydrogenNLTEForwardModel(nlayer=128, nlon=12, nlat=6, nnu=601,
                                    tidal_coefficient_s2=tidal)
velocity, observed, error = map(jnp.asarray, load_observations(model.line_center_cm))

@jax.jit
def spectrum(p, horizontal):
    return model.spectrum(mass_loss_g_s=1e13*jnp.exp(p[0]),
                          temperature_top_k=1e4*p[1],
                          rotation_kms=horizontal*SYNCHRONOUS_ROTATION_KMS,
                          zonal_kms=horizontal*11.6)

@jax.jit
def prediction(p, horizontal):
    return jnp.interp(velocity, model.velocity_kms[::-1], spectrum(p, horizontal)[::-1])

@jax.jit
def residual(p, horizontal):
    signal = prediction(p, horizontal)
    baseline = jnp.sum((observed-signal)/error**2)/jnp.sum(1/error**2)
    return (signal+baseline-observed)/error

jacobian = jax.jit(jax.jacfwd(residual, argnums=0))
records = []
for horizontal in [0., 1.]:
    for mass, top in [(1e14, 10000.), (1e15, 14000.), (1e14, 14000.)]:
        t0 = time.monotonic()
        initial = np.array([np.log(mass/1e13),top/1e4])
        result = least_squares(
            lambda p: np.asarray(residual(p, horizontal)), initial,
            jac=lambda p: np.asarray(jacobian(p, horizontal)),
            bounds=([np.log(.01),.6],[np.log(100),1.4]),
            x_scale='jac', max_nfev=50, ftol=1e-7, xtol=1e-7, gtol=1e-7,
        )
        pred = np.asarray(prediction(result.x, horizontal))
        record = dict(horizontal=horizontal, initial_mass_loss=mass, initial_top=top,
                      coordinates=result.x.tolist(), mass_loss_g_s=float(1e13*np.exp(result.x[0])),
                      temperature_top_k=float(1e4*result.x[1]),
                      baseline=float(np.average(np.asarray(observed)-pred,weights=np.asarray(error)**-2)),
                      rms=float(np.sqrt(np.mean(result.fun**2))), success=bool(result.success),
                      message=result.message, nfev=int(result.nfev), active_bounds=result.active_mask.tolist(),
                      optimality=float(result.optimality), elapsed_s=time.monotonic()-t0)
        records.append(record)
        (out/'fits.json').write_text(json.dumps(records, indent=2)+'\n')
        print(json.dumps(record),flush=True)
