"""Inspect retained fits and profiles; no new physical model or fitting run."""
from hashlib import sha256
from pathlib import Path
import json
import numpy as np

OLD = Path('/home/kawahara/exojax-escape/results/three_models')
NEW = Path('/tmp/exojax-escape-nlte-spectrum')
OUT = Path('/tmp/escape-model-audit')
h,c,k,Rp = 6.62607015e-27,2.99792458e10,1.380649e-16,1.9*7.1492e9
nu = 15233.146
prefactor, energy = 2*h*c*c*nu**3, h*c*nu/k
legacy=json.loads((OLD/'parameters.json').read_text())
old_profiles=np.genfromtxt(OLD/'profiles.csv',delimiter=',',names=True)
old_spectra=np.genfromtxt(OLD/'spectra.csv',delimiter=',',names=True)
new_profiles=np.load(NEW/'results/nlte_asymmetry/candidate_arrays.npz')
new_fits=json.loads((NEW/'results/nlte_asymmetry/fits.json').read_text())
wavelength,obs,err=np.loadtxt(NEW/'data/zenodo_20707255/KELT9b_w6565_avg_p0.30-0.45.dat',unpack=True)
vobs=c/1e5*(wavelength/(1e8/nu)-1)
radii=[1.1,1.3,1.5,1.8,2.,2.5]

def profile_summary(radius,n2,n3,source,temperature,velocity):
    dr=2/len(radius)
    interpolate=lambda values,r:float(np.interp(r,radius[::-1],values[::-1]))
    column=float(n2.sum()*dr*Rp)
    return {'n2_column_cm2':column,'n2_column_above_cm2':{
        str(r):float(np.sum(n2*np.maximum(0,np.minimum(dr,radius+dr/2-r)))*Rp) for r in [1.3,1.5,1.8,2.]},
        'samples':[{'radius_rp':r,'n2_cm3':interpolate(n2,r),'n3_cm3':interpolate(n3,r),
                    'n3_over_n2':interpolate(n3/n2,r),'source_rest_center':interpolate(source,r),
                    'source_brightness_temperature_k':energy/np.log1p(prefactor/interpolate(source,r)),
                    'kinetic_temperature_k':interpolate(temperature,r),'radial_velocity_kms':interpolate(velocity,r)} for r in radii]}

models={}
for m in [1,2,3]:
    tag=str(m);prefix=f'model{m}_';ratio=old_profiles[prefix+'ratio']
    source=prefactor/(2.25/ratio-1)
    pred=np.interp(vobs,old_spectra['velocity_kms'][::-1],old_spectra[f'model{m}'][::-1])
    best=legacy['models'][tag]['best']
    models[f'legacy_model{m}']={'fit':best,'rms_recomputed_from_saved_spectrum':float(np.sqrt(np.mean(((pred-obs)/err)**2))),
        'profiles':profile_summary(old_profiles['radius_rp'],old_profiles[prefix+'n2_cm3'],
            old_profiles[prefix+'n3_cm3'],source,old_profiles[prefix+'temperature_k'],old_profiles[prefix+'radial_velocity_kms'])}
for tag in ['baseline','manual']:
    models[f'nlte_{tag}']={'profiles':profile_summary(*(new_profiles[tag+'_'+name] for name in
        ['radius_rp','n2_cm3','n3_cm3','rest_center_source','temperature_k','radial_velocity_kms']))}
occ=.025/np.expm1(energy/10000)
paths=[OLD/'parameters.json',OLD/'profiles.csv',OLD/'spectra.csv',NEW/'results/nlte_asymmetry/candidate_arrays.npz',
       NEW/'results/nlte_asymmetry/fits.json',NEW/'src/escape/hydrogen_forward.py',NEW/'src/escape/hydrogen_populations.py',
       NEW/'src/escape/nlte_forward.py',NEW/'examples/fit_three_models.py',NEW/'results/nlte_asymmetry/fit.py']
report={
    'scope':'Read-only comparison of retained exploratory fits and prescribed atmospheres. Source brightness temperature is an equivalent Planck intensity, not a statement of LTE or gas temperature. Current NLTE samples are baseline/manual atmospheres, not the best-fit profiles.',
    'input_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in paths},
    'same_observation_sha256':sha256((NEW/'data/zenodo_20707255/KELT9b_w6565_avg_p0.30-0.45.dat').read_bytes()).hexdigest(),
    'source_convention':{'frequency_wavenumber_cm':nu,'formula':'S=(2 h c^2 nu_tilde^3)/(g3/g2/R-1), g3/g2=18/8, for the legacy unresolved line; current uses saved frequency-dependent branch-summed rest-center source. Tex=(h c nu_tilde/k)/log(1+2 h c^2 nu_tilde^3/S).',
        'column_convention':'Piecewise-constant layer midpoint n2 over 1..3 Rp; partial boundary cell included for tail columns.'},
    'legacy_two_level_radiative_limit':{'occupation':float(occ),'n3_over_n2':float(2.25*occ/(1+occ)),'brightness_temperature_k':float(energy/np.log1p(1/occ))},
    'legacy_fit_setup':{key:value for key,value in legacy.items() if key!='models'},
    'new_fits':new_fits,'models':models,
    'comparison_cautions':[
        'Legacy fits have six fitted coordinates; new exploratory fits have mass loss and kinetic top temperature plus one profiled constant baseline.',
        'Legacy models fit the N2 column independently; even rate Model 3 derives a freely adjustable neutral excited fraction from that column.',
        'Legacy effective isothermal Parker temperature is independent of kinetic T; new nonisothermal wind uses kinetic T, different fixed molecular weight, and tides.',
        'Legacy fitted Ttop is 14182/13177/22149 K under bounds6000..30000; new atomic model restricts T to5802..14000 and fits top6000..14000 with base6000.',
        'Both omit atmospheric continuum, feedback from internal radiation, limb halo, full observational processing, and pressure broadening.',
        'Legacy uses isolated-transition natural broadening and statistical shell populations; current uses resolved low sublevels and full upper/lower lifetimes.',
        'Current baseline is unbounded and profiled; legacy baseline is bounded +/-500 ppm. No formal likelihood or model-selection claim follows from these RMS values.',
        'Current baseline/manual total N2 columns are much larger yet more concentrated at the base. The source remains much brighter in outer layers; swaps at a common transfer setup are needed for causal attribution.',
    ]}
(OUT/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'out':str(OUT/'audit.json'),'old_rms':{k:v['rms_recomputed_from_saved_spectrum'] for k,v in models.items() if k.startswith('legacy')}},indent=2))
