"""Controlled opacity/source substitutions, not a statistical-equilibrium model."""
from pathlib import Path
from unittest.mock import patch
import hashlib
import json
import time

import jax
import jax.numpy as jnp
import matplotlib
import numpy as np
import pandas as pd
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from escape.hydrogen_forward import HydrogenForwardModel, SYNCHRONOUS_ROTATION_KMS
from escape.nlte_forward import HydrogenNLTEForwardModel, halpha_coefficients
from escape.hydrogen_rates import PLANCK_CGS, LIGHT_SPEED_CGS
from exojax.opacity.lpf.line_coefficients import line_coefficients
from exojax.utils.constants import hcperk
from fit_three_models import inputs, profiles as legacy_profiles
from generate_spectra import load_observations
from verify_nlte_spectrum import NIST_ROW

jax.config.update('jax_enable_x64', True)
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
LEGACY=Path('/home/kawahara/exojax-escape/results/three_models/parameters.json')
OLD=json.loads(LEGACY.read_text())
TIDE=3*(2*np.pi/(1.48*86400))**2
CONFIG=dict(nlayer=128,nlon=12,nlat=6,nnu=601)

def construct(cls, **extra):
    with patch('exojax.database.nist.api.fetch_nist_lines', lambda *a,**k:(pd.DataFrame(NIST_ROW),[])):
        return cls(**(CONFIG|extra))

legacy=construct(HydrogenForwardModel)
model=construct(HydrogenNLTEForwardModel,tidal_coefficient_s2=TIDE)
radius=np.asarray(model.radius_rp)
velocity=np.asarray(model.velocity_kms)
obs_v, observed,error=map(np.asarray,load_observations(model.line_center_cm))
C=2*PLANCK_CGS*LIGHT_SPEED_CGS**2*model.line_center_cm**3

def tex(source):
    return hcperk*model.line_center_cm/np.log1p(C/np.asarray(source))

def score(f):
    f=np.asarray(f)
    assert np.isfinite(f).all()
    at_data=np.interp(obs_v,velocity[::-1],f[::-1])
    offset=float(np.average(observed-at_data,weights=error**-2))
    return dict(rms=float(np.sqrt(np.mean(((at_data+offset-observed)/error)**2))),
                baseline=offset,center_ppm=float((f[np.argmin(abs(velocity))]+offset)*1e6),
                max_intrinsic=float(np.max(f)))

transfer=jax.jit(model._transfer_line_coefficients)
legacy_transfer=jax.jit(legacy._transfer)
arrays={'radius_rp':radius,'velocity_kms':velocity,'observation_velocity_kms':obs_v,
        'observed':observed,'error':error}
report={'scope':'Diagnostic substitutions of source and opacity on frozen profiles; no SE/wind solution or physical adequacy is inferred.',
        'grid':CONFIG,'legacy_parameters_sha256':hashlib.sha256(LEGACY.read_bytes()).hexdigest(),
        'baseline':'One constant profiled independently for each spectrum, no amplitude/slope/velocity shift fit.',
        'cases':{},'checks':{},'profiles':{}}

def save():
    (OUT/'hybrid_metrics.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    np.savez_compressed(OUT/'hybrid_arrays.npz',**arrays)

def record(name,f,extra=None):
    arrays[name]=np.asarray(f)
    report['cases'][name]=score(f)|(extra or {})
    print(name,json.dumps(report['cases'][name]),flush=True)
    save()

legacy_p={}
for ident in [1,2,3]:
    p=jnp.asarray(OLD['models'][str(ident)]['best']['coordinates'])
    pr=legacy_profiles(legacy,ident,p)
    t=legacy.temperature_profile(p[2]*1e4)
    f=legacy_transfer(pr['n2_cm3'],pr['ratio'],pr['radial_velocity_kms'],SYNCHRONOUS_ROTATION_KMS,p[4]*10,t)
    record(f'legacy{ident}',f,{'saved_rms':OLD['models'][str(ident)]['best']['residual_rms']})
    a,j=line_coefficients(jnp.ones((1,1)),legacy.adb.nu_lines,legacy.adb.A,legacy.adb.glower,legacy.adb.gupper,
                          pr['n2_cm3'][:,None],pr['n3_cm3'][:,None])
    legacy_p[ident]=dict(pr)|{'temperature_k':t,'alpha':a,'source':j/a,'zonal':p[4]*10}
    for k in ['n2_cm3','n3_cm3','ratio','radial_velocity_kms']:
        arrays[f'legacy{ident}_{k}']=np.asarray(pr[k])
    arrays[f'legacy{ident}_temperature_k']=np.asarray(t)
    arrays[f'legacy{ident}_source_tex']=tex(j/a)[:,0]
    # Compare natural-lifetime branch profiles with statistical shell populations.
    bound=jnp.zeros((len(radius),6)).at[:,1].set(pr['n2_cm3']/4).at[:,2].set(3*pr['n2_cm3']/4)
    bound=bound.at[:,3].set(pr['n3_cm3']/9).at[:,4].set(pr['n3_cm3']/3).at[:,5].set(5*pr['n3_cm3']/9)
    ab,jb=halpha_coefficients(bound,model.line_center_cm,sum_branches=False)
    f_branch=transfer(ab,jb,pr['radial_velocity_kms'],SYNCHRONOUS_ROTATION_KMS,p[4]*10,t)
    record(f'legacy{ident}_full_lifetimes',f_branch,{'control':'Statistical substates, three full-lifetime branches; no population refit.'})

for base,top,mass,zonal in [('current_fit',6105.231332735623,209185986389574.34,11.6),
                            ('current_manual',14000.,1e15,0.)]:
    t0=time.monotonic()
    pr=model.population_profiles(temperature_top_k=top,mass_loss_g_s=mass)
    assert bool(jnp.all(pr['converged']))
    alpha=pr['halpha_branch_extinction_integral']
    emis=pr['halpha_branch_emissivity_integral']
    v,t=pr['radial_velocity_kms'],pr['temperature_k']
    rotation=SYNCHRONOUS_ROTATION_KMS if base=='current_fit' else 0.
    f=transfer(alpha,emis,v,rotation,zonal,t)
    record(base,f,{'mass_loss_g_s':mass,'temperature_top_k':top,'rotation_kms':float(rotation),'zonal_kms':zonal,
                  'max_rate_residual':float(jnp.max(pr['rate_residual_norm']))})
    phi=jax.vmap(model._line_profiles)(t,jnp.zeros_like(v))[:,:,len(velocity)//2]
    source=jnp.sum(emis*phi,axis=1)/jnp.sum(alpha*phi,axis=1)
    for k in ['n_h_cm3','n2_cm3','n3_cm3','ratio','radial_velocity_kms','temperature_k','ionized_fraction']:
        arrays[f'{base}_{k}']=np.asarray(pr[k])
    arrays[f'{base}_source_tex']=tex(source)
    report['profiles'][base]={'N2_cm2':float(jnp.sum(pr['n2_cm3']*model.thickness_cm)),
                             'elapsed_s':time.monotonic()-t0}
    target=legacy_p[2]
    source_factor=target['source'][:,0]/source
    alpha_factor=target['alpha'][:,0]/jnp.sum(alpha,axis=1)
    # Preserve source frequency dependence from original branch populations.
    # Only the rest-center source is exactly replaced; integrated extinction is exact.
    shape_factor=alpha_factor*jnp.sum(jnp.sum(alpha,axis=1)*model.thickness_cm)/jnp.sum(target['alpha'][:,0]*model.thickness_cm)
    for label,af,sf,vel,temp,rot,zon in [
        ('source_only',jnp.ones_like(v),source_factor,v,t,rotation,zonal),
        ('opacity_only',alpha_factor,jnp.ones_like(v),v,t,rotation,zonal),
        ('opacity_shape_only',shape_factor,jnp.ones_like(v),v,t,rotation,zonal),
        ('source_and_opacity',alpha_factor,source_factor,v,t,rotation,zonal),
        ('velocity_only',jnp.ones_like(v),jnp.ones_like(v),target['radial_velocity_kms'],t,SYNCHRONOUS_ROTATION_KMS,target['zonal']),
        ('temperature_only',jnp.ones_like(v),jnp.ones_like(v),v,target['temperature_k'],rotation,zonal),
        ('source_opacity_temperature',alpha_factor,source_factor,v,target['temperature_k'],rotation,zonal),
        ('source_opacity_velocity',alpha_factor,source_factor,target['radial_velocity_kms'],t,SYNCHRONOUS_ROTATION_KMS,target['zonal']),
        ('legacy_opacity_temperature_velocity',alpha_factor,jnp.ones_like(v),target['radial_velocity_kms'],target['temperature_k'],SYNCHRONOUS_ROTATION_KMS,target['zonal']),
        ('legacy_source_temperature_velocity',jnp.ones_like(v),source_factor,target['radial_velocity_kms'],target['temperature_k'],SYNCHRONOUS_ROTATION_KMS,target['zonal']),
        ('all_profiles',alpha_factor,source_factor,target['radial_velocity_kms'],target['temperature_k'],SYNCHRONOUS_ROTATION_KMS,target['zonal']),
    ]:
        candidate=transfer(alpha*af[:,None],emis*(af*sf)[:,None],vel,rot,zon,temp)
        record(base+'_'+label,candidate,{'target':'Legacy Model2 fitted profile','not_equilibrium':True})
    assert np.allclose(np.sum(np.asarray(alpha*alpha_factor[:,None]),axis=1),np.asarray(target['alpha'][:,0]),rtol=2e-14)
    report['checks'][base+'_opacity_substitution']=True
    newsource=jnp.sum(emis*source_factor[:,None]*phi,axis=1)/jnp.sum(alpha*phi,axis=1)
    assert np.allclose(newsource,np.asarray(target['source'][:,0]),rtol=2e-14)
    report['checks'][base+'_source_substitution']=True
    save()

fig,axs=plt.subplots(2,3,figsize=(14,8),constrained_layout=True)
for ident,color in [(1,'C0'),(2,'C1'),(3,'C3')]:
    name=f'legacy{ident}'
    axs[0,0].plot(velocity,100*(arrays[name]+report['cases'][name]['baseline']),color=color,label=f'Model {ident}: RMS {report["cases"][name]["rms"]:.3f}')
    for axis,key in [(axs[0,1],'source_tex'),(axs[0,2],'n2_cm3'),(axs[1,1],'temperature_k'),(axs[1,2],'radial_velocity_kms')]:
        axis.plot(radius,arrays[f'{name}_{key}'],color=color,label=f'Model {ident}')
name='current_fit'
axs[0,0].plot(velocity,100*(arrays[name]+report['cases'][name]['baseline']),color='k',label=f'Current fit: RMS {report["cases"][name]["rms"]:.3f}')
for axis,key in [(axs[0,1],'source_tex'),(axs[0,2],'n2_cm3'),(axs[1,1],'temperature_k'),(axs[1,2],'radial_velocity_kms')]:
    axis.plot(radius,arrays[f'{name}_{key}'],color='k',label='Current fit')
axs[0,0].errorbar(obs_v,100*observed,yerr=100*error,fmt='.',color='.6',markersize=3,label='Zenodo observation')
for name,color,style in [('legacy2','C1','-'),('legacy2_full_lifetimes','C1','--'),('legacy3','C3','-'),('legacy3_full_lifetimes','C3','--')]:
    axs[1,0].plot(velocity,100*(arrays[name]+report['cases'][name]['baseline']),color=color,ls=style,label=name.replace('_',' '))
axs[1,0].errorbar(obs_v,100*observed,yerr=100*error,fmt='.',color='.6',markersize=3)
for ax in [axs[0,0],axs[1,0]]:ax.set(xlim=(-100,100),xlabel='Velocity [km/s]',ylabel='Contrast [%]')
axs[0,0].set_title('Old and current fits: different freedoms')
axs[1,0].set_title('Keep old populations; update natural widths')
axs[0,1].set(title='Rest-center source brightness temperature',ylabel='Source T [K]',xlabel='Radius / Rp',xlim=(1,2.3))
axs[0,1].axhline(4500,color='.6',ls=':',label='4500 K lower boundary')
axs[0,2].set(title='Where the n=2 absorbers are',yscale='log',ylabel='n2 [cm$^{-3}$]',xlabel='Radius / Rp',xlim=(1,2.3))
axs[1,1].set(title='Kinetic temperature',ylabel='T [K]',xlabel='Radius / Rp',xlim=(1,2.3))
axs[1,2].set(title='Radial velocity',ylabel='v [km/s]',xlabel='Radius / Rp',xlim=(1,2.3))
for ax in axs.flat:ax.legend(fontsize=7)
fig.suptitle('Successful free models provide a dark upper absorber; the current local NLTE closure does not\nAll plotted at phase 0.375; single-phase comparison, constant offsets, no reduction operator')
fig.supxlabel('Data: Y. Zhang (2026), doi:10.5281/zenodo.20707255, CC BY 4.0. Full branch sources used for current NLTE.',fontsize=8)
fig.savefig(OUT/'profile_comparison.png',dpi=150)
plt.close(fig)

fig,axs=plt.subplots(1,2,figsize=(13,5),constrained_layout=True)
for ax,base in zip(axs,['current_fit','current_manual']):
    ax.errorbar(obs_v,100*observed,yerr=100*error,fmt='.',color='.6',markersize=3,label='Zenodo observation')
    for label,color,style in [('', 'k','-'),('_source_only','C0','-'),('_opacity_only','C1','-'),('_source_and_opacity','C2','-'),('_all_profiles','C3','--')]:
        name=base+label
        ax.plot(velocity,100*(arrays[name]+report['cases'][name]['baseline']),color=color,ls=style,
                label=(label[1:].replace('_',' ') or 'unchanged')+f' ({report["cases"][name]["rms"]:.2f})')
    ax.set(title=base.replace('_',' '),xlim=(-90,90),ylim=(-.12,.3),xlabel='Velocity [km/s]',ylabel='Contrast [%]')
    ax.legend(fontsize=8)
fig.suptitle('Counterfactual substitutions from fitted Model 2; labels include residual RMS\nThese spectra are diagnostics, not new statistical-equilibrium or wind solutions')
fig.supxlabel('Each curve profiles one constant offset; populations/opacity/source substitutions are explicit. Data: Zenodo 20707255, CC BY 4.0.',fontsize=8)
fig.savefig(OUT/'hybrid_controls.png',dpi=150)
plt.close(fig)
save()
