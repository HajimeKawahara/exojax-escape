"""Compare the adopted blackbody UV shape with a published PHOENIX budget."""

from pathlib import Path
import json
import numpy as np
from scipy.integrate import quad

h, k, c, ev = 6.62607015e-27, 1.380649e-16, 2.99792458e10, 1.602176634e-12
temperature, dilution = 10000.0, 0.025
prefactor = 8 * np.pi * dilution * (k * temperature)**4 / (h**3 * c**2)
flux = {}
for name, threshold_ev in [("Balmer", 13.5984345 / 4), ("Lyman", 13.5984345)]:
    xmin = threshold_ev * ev / (k * temperature)
    flux[name] = prefactor * quad(lambda x: x**3 / np.expm1(x), xmin, 200)[0]
report = {
    "scope": "Spectral-shape diagnostic, not a comparison to the unavailable exact stellar input of Zhang et al. (2026).",
    "definition": "F_equivalent = 4 pi integral J_nu dnu, where J_nu = W B_nu(T). This is the incident-flux convention for a distant collimated source, not the radial flux of an isotropic blackbody radiation bath.",
    "blackbody": {"temperature_k": temperature, "dilution": dilution,
                  "equivalent_flux_erg_cm2_s": flux,
                  "Balmer_to_Lyman": flux["Balmer"] / flux["Lyman"]},
    "published_reference": {
        "source": "Garcia Munoz & Schneider (2019), Stellar irradiation appendix; PHOENIX Teff=10200 K",
        "url": "https://arxiv.org/html/1910.00267v1",
        "lyman_continuum_flux_erg_cm2_s_at_0p035au": 3100.0,
        "balmer_to_lyman_flux_ratio": 7.5e6,
        "normalization_caution": "Stellar parameters, exact atmosphere, and dilution differ from the current prescribed-field model. This comparison identifies an orders-of-magnitude UV-shape mismatch rather than an exact factor for the 2026 model.",
    },
    "blackbody_to_reference_Lyman_flux": flux["Lyman"] / 3100,
}
(Path(__file__).parent / "blackbody_uv_budget.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
