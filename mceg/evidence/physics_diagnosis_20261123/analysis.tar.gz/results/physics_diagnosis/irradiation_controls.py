"""Prescribed-frequency ablations: a causal diagnostic, not an RT solution."""
from pathlib import Path
from unittest.mock import patch
import json
import hashlib
import time
import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from escape.nlte_forward import HydrogenNLTEForwardModel,halpha_coefficients
from escape.hydrogen_atom import solve_atom_populations
from escape.hydrogen_forward import SYNCHRONOUS_ROTATION_KMS
from escape.hydrogen_rates import planck_occupation,PLANCK_CGS,LIGHT_SPEED_CGS
from exojax.utils.constants import hcperk
from generate_spectra import load_observations
from verify_nlte_spectrum import NIST_ROW,uncertainty_scaled_difference
jax.config.update('jax_enable_x64',True)
OUT=Path(__file__).resolve().parent
TIDE=3*(2*np.pi/(1.48*86400))**2
CASES={'fit':dict(temperature_top_k=6105.231332735623,mass_loss_g_s=209185986389574.34,rotation=SYNCHRONOUS_ROTATION_KMS,zonal=11.6),
       'manual':dict(temperature_top_k=14000.,mass_loss_g_s=1e15,rotation=0.,zonal=0.)}
VARIANTS={'full':(1.,1.,1.),'Halpha_x0.1':(1.,1.,.1),'higher_Lyman_x0.1':(1.,.1,1.),
          'higher_Lyman_x0.01':(1.,.01,1.),'all_Lyman_x0.1':(.1,.1,1.)}
report={'scope':'Prescribed incident-occupation interventions at fixed nH,T,velocities; re-solve all populations and charge. No depth-dependent transfer, diffuse radiation, energy solve or new fit.',
        'cases':{},'refinements':{},'variants':{k:list(v) for k,v in VARIANTS.items()},
        'variant_coordinates':['Lyalpha factor','higher Lyman factor','Halpha factor'],
        'baseline':'Same observation pixels, independent error weights and one profiled constant offset per spectrum.'}
arrays={}

def construct(**extra):
    with patch('exojax.database.nist.api.fetch_nist_lines',lambda *a,**kw:(pd.DataFrame(NIST_ROW),[])):
        return HydrogenNLTEForwardModel(**(dict(nlayer=128,nlon=12,nlat=6,nnu=601,tidal_coefficient_s2=TIDE)|extra))

def prepare(model):
    atom=model.atom
    low,up,n=atom.line_lower,atom.line_upper,atom.principal_n
    base_line=planck_occupation(atom.line_frequency_hz,10000.,.025)
    continuum=planck_occupation(model.continuum_frequency_hz,10000.,.025)
    @jax.jit
    def calculate(nh,t,v,rotation,zonal,factors):
        line=base_line*jnp.where((low==0)&(n[up]==2),factors[0],1.)
        line=line*jnp.where((low==0)&(n[up]>=3),factors[1],1.)
        line=line*jnp.where((n[low]==2)&(n[up]==3),factors[2],1.)
        sol=jax.vmap(lambda a,b:solve_atom_populations(a,atom,b,line,continuum,model.continuum_frequency_hz,model.continuum_weight_hz))(nh,t)
        alpha,emis=halpha_coefficients(sol.bound_cm3,model.line_center_cm,sum_branches=False)
        spectrum=model._transfer_line_coefficients(alpha,emis,v,rotation,zonal,t)
        phi=jax.vmap(model._line_profiles)(t,jnp.zeros_like(v))[:,:,len(model.velocity_kms)//2]
        source=jnp.sum(emis*phi,axis=1)/jnp.sum(alpha*phi,axis=1)
        return spectrum,sol,source
    return calculate

model=construct();calculate=prepare(model)
velocity=np.asarray(model.velocity_kms);radius=np.asarray(model.radius_rp)
obs_v,observed,error=map(np.asarray,load_observations(model.line_center_cm))
arrays.update(velocity=velocity,radius_rp=radius,observation_velocity_kms=obs_v,observed=observed,error=error)
C=2*PLANCK_CGS*LIGHT_SPEED_CGS**2*model.line_center_cm**3

def score(spectrum):
    f=np.asarray(spectrum)
    if not np.isfinite(f).all():return dict(valid_spectrum=False)
    sample=np.interp(obs_v,velocity[::-1],f[::-1])
    baseline=float(np.average(observed-sample,weights=error**-2))
    return dict(valid_spectrum=True,rms=float(np.sqrt(np.mean(((sample+baseline-observed)/error)**2))),baseline=baseline,
                center_ppm=float((f[np.argmin(abs(velocity))]+baseline)*1e6))

def save():
    (OUT/'irradiation_metrics.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    np.savez_compressed(OUT/'irradiation_arrays.npz',**arrays)

for name,p in CASES.items():
    profiles=model.population_profiles(temperature_top_k=p['temperature_top_k'],mass_loss_g_s=p['mass_loss_g_s'])
    report['cases'][name]={'parameters':p,'variants':{}}
    for label,factors in VARIANTS.items():
        start=time.monotonic()
        f,sol,source=calculate(profiles['n_h_cm3'],profiles['temperature_k'],profiles['radial_velocity_kms'],p['rotation'],p['zonal'],jnp.array(factors))
        n2=np.asarray(sol.bound_cm3[:,1:3].sum(axis=1));n3=np.asarray(sol.bound_cm3[:,3:6].sum(axis=1))
        rec=score(f)|{'converged':bool(jnp.all(sol.converged)),'valid':bool(jnp.all(sol.valid)),
                      'rate_residual':float(jnp.max(sol.rate_residual_norm)),
                      'N2_cm2':float(np.sum(n2*np.asarray(model.thickness_cm))),'elapsed_s':time.monotonic()-start}
        assert rec['converged'] and rec['valid'] and rec['valid_spectrum'],rec
        prefix=f'{name}_{label}'
        arrays[prefix]=np.asarray(f)
        arrays[prefix+'_source_tex']=hcperk*model.line_center_cm/np.log1p(C/np.asarray(source))
        arrays[prefix+'_n2']=n2;arrays[prefix+'_ratio']=n3/n2
        rec['samples']={str(r):{key:float(np.interp(r,radius[::-1],arrays[prefix+'_'+key][::-1])) for key in ['source_tex','n2','ratio']} for r in [1.3,1.8]}
        if label=='full':
            control=model.spectrum(temperature_top_k=p['temperature_top_k'],mass_loss_g_s=p['mass_loss_g_s'],rotation_kms=p['rotation'],zonal_kms=p['zonal'])
            rec['public_path_max_difference']=float(jnp.max(jnp.abs(f-control)))
            assert rec['public_path_max_difference']<1e-12
        report['cases'][name]['variants'][label]=rec
        print(name,label,json.dumps(rec),flush=True);save()

# The new spectral comparison is retained at the manual case for an independent
# spatial and atom-size control, using the original fixed numerical error scale.
p=CASES['manual']; label='higher_Lyman_x0.1'
for key,extra in [('layers256',{'nlayer':256}),('nmax20',{'nmax':20})]:
    fine=construct(**extra);evaluate=prepare(fine)
    profiles=fine.population_profiles(temperature_top_k=p['temperature_top_k'],mass_loss_g_s=p['mass_loss_g_s'])
    f,sol,source=evaluate(profiles['n_h_cm3'],profiles['temperature_k'],profiles['radial_velocity_kms'],p['rotation'],p['zonal'],jnp.array(VARIANTS[label]))
    assert bool(jnp.all(sol.converged))
    reference=np.interp(obs_v,velocity[::-1],arrays['manual_'+label][::-1])
    candidate=np.interp(obs_v,np.asarray(fine.velocity_kms)[::-1],np.asarray(f)[::-1])
    comparison=uncertainty_scaled_difference(reference,candidate,error)
    report['refinements'][key]=comparison
    arrays['refinement_'+key]=np.asarray(f)
    print(key,json.dumps(comparison),flush=True);save()

fig,axs=plt.subplots(2,2,figsize=(13,8),constrained_layout=True)
colors={'full':'k','Halpha_x0.1':'.6','higher_Lyman_x0.1':'C0','higher_Lyman_x0.01':'C1','all_Lyman_x0.1':'C3'}
labels={'full':'Unchanged blackbody','Halpha_x0.1':'H-alpha occupation x0.1','higher_Lyman_x0.1':'Ly-beta and higher x0.1','higher_Lyman_x0.01':'Ly-beta and higher x0.01','all_Lyman_x0.1':'All Lyman lines x0.1'}
for col,name in enumerate(CASES):
    axs[0,col].errorbar(obs_v,100*observed,yerr=100*error,fmt='.',markersize=3,color='.65',label='Zenodo observation')
    for label,color in colors.items():
        prefix=name+'_'+label;rec=report['cases'][name]['variants'][label]
        axs[0,col].plot(velocity,100*(arrays[prefix]+rec['baseline']),color=color,label=labels[label]+f' ({rec["rms"]:.2f})')
        axs[1,col].plot(radius,arrays[prefix+'_source_tex'],color=color,label=labels[label])
    axs[0,col].set(title=('Current fitted atmosphere' if name=='fit' else 'Manual hot atmosphere'),xlim=(-100,100),xlabel='Velocity [km/s]',ylabel='Contrast [%]')
    axs[1,col].set(xlim=(1,2.4),xlabel='Radius / Rp',ylabel='Rest-center source brightness T [K]')
    axs[1,col].axhline(4500,color='.6',ls=':',label='Lower boundary4500K')
    axs[0,col].legend(fontsize=7);axs[1,col].legend(fontsize=7)
fig.suptitle('Which incident photons keep the upper atmosphere bright?\nFixed density/temperature/velocity; populations and charge re-solved; prescribed-field diagnostics only')
fig.supxlabel('Labels include normalized residual RMS after a constant offset. No physical fit or depth-dependent radiation transport. Data: Zenodo 20707255, CC BY 4.0.',fontsize=8)
fig.savefig(OUT/'irradiation_controls.png',dpi=150);plt.close(fig)
