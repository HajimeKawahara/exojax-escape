"""Net atomic rate and local relaxation diagnostics on retained profiles.

No internal radiation is solved. Positive channel net rates populate the
selected state/shell; negative rates deplete it. Two-level epsilon values are
illustrations, not closures for this multilevel atom.
"""
from __future__ import annotations

from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from unittest.mock import patch

import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd
from scipy.special import voigt_profile

from escape.hydrogen_atom import atom_rate_coefficients, solve_atom_populations, atom_natural_width_hz
from escape.hydrogen_rates import PLANCK_CGS as H, LIGHT_SPEED_CGS as C, BOLTZMANN_CGS as K, planck_occupation
from escape.hydrogen_forward import PLANET_RADIUS_CM
from escape.nlte_forward import HydrogenNLTEForwardModel
from stellar_halpha import load_surface, occupation_fields
from verify_nlte_spectrum import NIST_ROW

jax.config.update('jax_enable_x64',True)
OUT=Path(__file__).parent
INPUT=Path('/tmp/escape-stellar-spectrum/results/stellar_halpha/arrays.npz')
payload=INPUT.read_bytes()
with np.load(BytesIO(payload)) as f:
    arrays={k:f[k] for k in f.files}
with patch('exojax.database.nist.api.fetch_nist_lines',lambda *a,**k:(pd.DataFrame(NIST_ROW),[])):
    model=HydrogenNLTEForwardModel(nlayer=128,nmax=15,nlon=12,nlat=6,nnu=601,
        tidal_coefficient_s2=3*(2*np.pi/(1.48*86400))**2)
atom=model.atom
principal=np.asarray(atom.principal_n);g=np.asarray(atom.statistical_weights)
energy=np.asarray(atom.excitation_energy_erg)
lower,upper=np.asarray(atom.line_lower),np.asarray(atom.line_upper)
freq=np.asarray(atom.line_frequency_hz);A=np.asarray(atom.einstein_a_s)
surface=load_surface(Path('/tmp/escape-stellar-sed-data/wavelength.fits'),Path('/tmp/escape-stellar-sed-data/phoenix10000.fits'))
fields={'PHOENIX':occupation_fields(model,surface),'blackbody':dict(
    line_occupation=planck_occupation(atom.line_frequency_hz,10000.,.025),
    continuum_occupation=planck_occupation(model.continuum_frequency_hz,10000.,.025))}
names=['1s','2s','2p','3s','3p','3d']+[f'n{n}' for n in range(4,16)]

@jax.jit
def solve(nh,t,line,cont):
    sol=solve_atom_populations(nh,atom,t,line,cont,model.continuum_frequency_hz,model.continuum_weight_hz)
    rates=atom_rate_coefficients(atom,t,line,cont,model.continuum_frequency_hz,model.continuum_weight_hz,electron_cm3=sol.electron_cm3)
    return sol,rates

def rhs(bound,nh,t,line,cont):
    ne=nh-jnp.sum(bound)
    r=atom_rate_coefficients(atom,t,line,cont,model.continuum_frequency_hz,model.continuum_weight_hz,electron_cm3=ne)
    transition=r.radiative_bound_bound_s+ne*r.electron_bound_bound_cm3_s
    ion=r.photoionization_s+ne*r.electron_ionization_cm3_s
    rec=ne**2*r.radiative_recombination_cm3_s+ne**3*r.three_body_recombination_cm6_s
    return transition.T@bound-bound*jnp.sum(transition,axis=1)+rec-bound*ion
jacobian=jax.jit(jax.jacfwd(rhs,argnums=0))

def budget(bound,ne,rates,selected):
    rad,col,photo,rec,ion,three=map(np.asarray,rates)
    selected=np.asarray(selected);outside=np.setdiff1d(np.arange(len(bound)),selected)
    groups={'ground':np.flatnonzero(principal==1),'n2':np.flatnonzero(principal==2),
            'n3':np.flatnonzero(principal==3),'higher':np.flatnonzero(principal>=4)}
    channels={}
    for label,members in groups.items():
        members=np.intersect1d(members,outside)
        if not len(members):continue
        for mechanism,q in [('radiative',rad),('collisional',ne*col)]:
            incoming=float(np.sum(bound[members,None]*q[np.ix_(members,selected)]))
            outgoing=float(np.sum(bound[selected,None]*q[np.ix_(selected,members)]))
            channels[label+'_'+mechanism]={'in':incoming,'out':outgoing,'net':incoming-outgoing}
    for name,incoming,outgoing in [
        ('bound_free_radiative',ne**2*rec[selected].sum(),np.sum(bound[selected]*photo[selected])),
        ('bound_free_collisional',ne**3*three[selected].sum(),np.sum(bound[selected]*ne*ion[selected]))]:
        channels[name]={'in':float(incoming),'out':float(outgoing),'net':float(incoming-outgoing)}
    turnover=sum(v['in'] for v in channels.values())
    residual=sum(v['net'] for v in channels.values())
    return {'channels_cm3_s':channels,'total_in_cm3_s':turnover,'relative_balance':float(residual/turnover)}

def line_depths(prefix):
    bound=arrays[prefix+'_bound_cm3'];t=arrays[prefix+'_temperature_k']
    dr=np.asarray(model.thickness_cm)
    sigma=freq[None,:]/C*np.sqrt(K*t[:,None]/1.6735575e-24)
    phi=voigt_profile(0.,sigma,np.asarray(atom_natural_width_hz(atom))[None,:])
    extinction=C*C/(8*np.pi*freq[None,:]**2)*A[None,:]*(g[upper]/g[lower]*bound[:,lower]-bound[:,upper])*phi
    tau=np.cumsum(extinction*dr[:,None],axis=0)-.5*extinction*dr[:,None]
    return tau

rows=[]
report={'scope':__doc__,'input_sha256':sha256(payload).hexdigest(),'rows':rows,
    'timescale_scope':'Eigenvalues are of fixed-prescribed-field local charge/population kinetics only; photon diffusion and nonlocal radiation response are absent.',
    'epsilon_scope':'For each isolated two-level branch, epsilon=C_ul*(1-exp(-hnu/kT))/(A_ul+C_ul*(1-exp(-hnu/kT))). Competing branches, cascades, continua and mixing invalidate using this as the full multilevel source.',
    'source_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),Path('/tmp/escape-stellar-spectrum/src/escape/hydrogen_atom.py'),Path('/tmp/escape-stellar-spectrum/src/escape/hydrogen_rates.py')]}}
for case in ['previous_fit','hot_manual']:
    for field_name,field in fields.items():
        prefix=case+'_'+field_name;tau=line_depths(prefix)
        for r in [1.1,1.3,1.8,2.5]:
            i=int(np.argmin(abs(arrays['radius_rp']-r)))
            nh=float(arrays[prefix+'_n_h_cm3'][i]);t=float(arrays[prefix+'_temperature_k'][i])
            sol,rates=solve(nh,t,field['line_occupation'],field['continuum_occupation'])
            assert bool(sol.valid&sol.converged)
            bound=np.asarray(sol.bound_cm3);ne=float(sol.electron_cm3)
            match=float(np.max(abs(bound/arrays[prefix+'_bound_cm3'][i]-1)))
            assert match<1e-10,match
            n2=bound[1:3].sum();n3=bound[3:6].sum()
            ratio_lte=2.25*np.exp(-(np.average(energy[3:6],weights=g[3:6])-np.average(energy[1:3],weights=g[1:3]))/(K*t))
            row={'case':case,'field':field_name,'radius_rp':float(arrays['radius_rp'][i]),'temperature_k':t,'nH_cm3':nh,
                 'electron_cm3':ne,'ionized_fraction':float(sol.ionized_fraction),'saved_population_max_rel_error':match,
                 'source_brightness_k':float(arrays[prefix+'_source_temperature'][i]),'n3_over_n2':float(n3/n2),
                 'b3_over_b2_shell':float(n3/n2/ratio_lte),'n2_over_n1':float(n2/bound[0]),
                 'n2_over_n1_relative_boltzmann':float(n2/bound[0]/(4*np.exp(-np.average(energy[1:3],weights=g[1:3])/(K*t)))),
                 'n2':budget(bound,ne,rates,[1,2]),'n3':budget(bound,ne,rates,[3,4,5]),
                 'states':{names[k]:budget(bound,ne,rates,[k]) for k in range(1,6)},'lines':{}}
            rad,col,photo,rec,ion,three=map(np.asarray,rates)
            for li,label in enumerate(['Lya','Lyb','Halpha_3s2p','Halpha_3p2s','Halpha_3d2p']):
                u,l=upper[li],lower[li]
                up=bound[l]*rad[l,u];down=bound[u]*rad[u,l]
                cup=bound[l]*ne*col[l,u];cdown=bound[u]*ne*col[u,l]
                c_ul=ne*col[u,l];factor=1-np.exp(-H*freq[li]/(K*t));eps=c_ul*factor/(A[li]+c_ul*factor)
                sourceocc=bound[u]/(g[u]/g[l]*bound[l]-bound[u])
                row['lines'][label]={'radiative_in':float(up),'radiative_out':float(down),'radiative_net_up':float(up-down),
                    'collisional_in':float(cup),'collisional_out':float(cdown),'collisional_net_up':float(cup-cdown),
                    'radiative_bracket_1_J_over_S':float(1-float(field['line_occupation'][li])/sourceocc),
                    'C_ul_over_A':float(c_ul/A[li]),'isolated_two_level_epsilon':float(eps),
                    'critical_electron_density_cm3':float(A[li]/col[u,l]),'line_center_tau_above':float(tau[i,li]),
                    'tau_sqrt_epsilon':float(tau[i,li]*np.sqrt(eps)),
                    'photoionization_rate_upper_s':float(photo[u]),'photoionization_rate_lower_s':float(photo[l]),
                    'source_occupation':float(sourceocc),'incident_occupation':float(field['line_occupation'][li])}
            jac=np.asarray(jacobian(jnp.asarray(bound),nh,t,field['line_occupation'],field['continuum_occupation']))
            eig=np.linalg.eigvals(jac)
            slow=float(np.max(eig.real));fast=float(np.min(eig.real))
            radius=arrays['radius_rp'][i]*PLANET_RADIUS_CM;v=arrays[prefix+'_radial_velocity_kms'][i]*1e5
            row['local_relaxation']={'max_real_eigenvalue_s1':slow,'min_real_eigenvalue_s1':fast,'slowest_time_s':-1/slow if slow<0 else None,
                'flow_r_over_v_s':float(radius/v),'bound_system_stable':bool(slow<0)}
            rows.append(row)
            (OUT/'net_rates.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
            print(case,field_name,r,'Tsource',row['source_brightness_k'],'b32',row['b3_over_b2_shell'], 'maxbalance',max(abs(row[k]['relative_balance']) for k in ['n2','n3']),flush=True)
