"""Local net-radiative-bracket limiting experiment; not a transfer solution.

For selected bound-bound transitions replace both radiative directions by
beta times their prescribed-field values. This is algebraically the local
closure J=(1-beta)*S+beta*J_external, preserving Einstein ratios. beta=0 is
the perfectly trapped net-rate limit, not a computed escape probability.
Collision, photoionization, recombination, two-photon emission and unselected
lines are retained. No emergent spectrum or physical population prediction
is claimed. Optical depths cannot be used as beta without transport closure.
"""
from pathlib import Path

LIMIT_SCOPE=__doc__
common=Path('/tmp/escape-darkening-rates/net_rates.py').read_text().split('rows=[]')[0]
exec(common)
from escape.hydrogen_nlte import _solve_equilibrium_with_rates
from escape.nlte_forward import halpha_coefficients

@jax.jit
def solve_scaled(nh,t,line,cont,scale):
    def rates_at(ne):
        rates=atom_rate_coefficients(atom,t,line,cont,model.continuum_frequency_hz,
                                    model.continuum_weight_hz,electron_cm3=ne)
        return rates._replace(radiative_bound_bound_s=rates.radiative_bound_bound_s*scale)
    sol=_solve_equilibrium_with_rates(nh,rates_at)
    return sol,rates_at(sol.electron_cm3)

def make_scale(selection,beta):
    mask=np.ones((len(g),len(g)))
    for k in selection:
        l,u=lower[k],upper[k]
        mask[l,u]=mask[u,l]=beta
    return jnp.asarray(mask)

line_indices={
    'baseline':[], 'Lya_closed':[0], 'Lyb_closed':[1],
    'all_Lyman_closed':np.flatnonzero(lower==0),
    'Halpha_closed':[2,3,4],
    'Lyman_Halpha_closed':np.flatnonzero((lower==0)|((principal[lower]==2)&(principal[upper]==3))),
    'all_bound_bound_closed':np.arange(len(lower)),
}
rows=[]
report={'scope':LIMIT_SCOPE,'source':str(Path(__file__)),'rows':rows}
for case in ['previous_fit','hot_manual']:
    prefix=case+'_PHOENIX';field=fields['PHOENIX']
    for radius in [1.1,1.3,1.8,2.5]:
        i=int(np.argmin(abs(arrays['radius_rp']-radius)))
        nh=float(arrays[prefix+'_n_h_cm3'][i]);t=float(arrays[prefix+'_temperature_k'][i])
        for label,indices in line_indices.items():
            sol,rates=solve_scaled(nh,t,field['line_occupation'],field['continuum_occupation'],make_scale(indices,0.))
            assert bool(sol.valid&sol.converged),(case,radius,label,sol)
            bound=np.asarray(sol.bound_cm3)
            alpha,emis=halpha_coefficients(bound,model.line_center_cm,sum_branches=False)
            phi=model._line_profiles(t,0.)[:,300]
            source=float(jnp.sum(emis*phi)/jnp.sum(alpha*phi))
            tex=float(H*C*model.line_center_cm/K/np.log1p(2*H*C*C*model.line_center_cm**3/source))
            row={'case':case,'radius_rp':float(arrays['radius_rp'][i]),'temperature_k':t,'experiment':label,
                 'electron_cm3':float(sol.electron_cm3),'n2_cm3':float(bound[1:3].sum()),'n3_cm3':float(bound[3:6].sum()),
                 'source_brightness_k':tex,'rate_residual':float(sol.rate_residual_norm),
                 'ionized_fraction':float(sol.ionized_fraction),
                 'n2_n1_relative_boltzmann':float(bound[1:3].sum()/bound[0]/(4*np.exp(-np.average(energy[1:3],weights=g[1:3])/(K*t)))),
                 'n2':budget(bound,float(sol.electron_cm3),rates,[1,2]),'n3':budget(bound,float(sol.electron_cm3),rates,[3,4,5])}
            rows.append(row)
            (OUT/'trapping_limits.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
            print(case,radius,label,'Ts',round(tex),'n2',f'{row["n2_cm3"]:.4g}','ion',f'{row["ionized_fraction"]:.4g}',flush=True)
