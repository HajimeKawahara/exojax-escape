# Atomic net-rate diagnosis

These are diagnostics of the retained PHOENIX and blackbody profiles from
`/tmp/escape-stellar-spectrum/results/stellar_halpha/arrays.npz`, not a
replacement atmosphere or a fit. Rates have units cm^-3 s^-1. Positive net
rates populate the selected shell; negative rates remove atoms from it.

## Main result

Changing the illuminating stellar spectrum is insufficient to establish the
required lower-bright, upper-dark source structure. The current rate solve
contains prescribed external radiation but does not feed internally emitted
Ly-alpha, Ly-beta or H-alpha photons back into the populations. In the hot
PHOENIX example, Ly-alpha emission removes almost all newly collisionally
excited n=2 atoms, despite the enormous frozen-profile line optical depth.
The missing n=2 reservoir is a more direct problem than continued Ly-beta
attenuation. H-alpha radiation feedback is a separate issue controlling
n3/n2 and the source brightness.

At 1.305 Rp, T=13368 K, ne=3.552e10 cm^-3:

| Quantity | Hot PHOENIX prescribed-field result |
|---|---:|
| n2/n1 divided by its Boltzmann value | 8.145e-6 |
| (n3/n2)/(n3/n2)_Boltzmann | 0.08896 |
| H-alpha source brightness temperature | 5370 K |
| Net ground collision into n=2 | +5.698e10 |
| Net ground radiation into n=2, almost entirely Ly-alpha | -5.977e10 |
| Net ground collision into n=3 | +3.467e9 |
| Net Ly-beta into n=3 | -1.709e9 |
| Net n2 collision into n=3 | +3.447e6 |
| Net H-alpha into n=3 | -2.280e9 |
| Net higher-state radiative cascade into n=3 | +4.766e8 |

Ly-beta is already a net loss in this hot example. Its gross upward rate is
not a photon-production fraction and cannot alone identify the mechanism
maintaining n=3. At 1.805 Rp in the previous blackbody fit, the earlier 87.1%
gross ground-radiative ingress corresponds to 69.4% of positive net supply.
For the hot PHOENIX model at the same radius the ground-radiative channel is
negative, although its gross upward rate is still substantial.

## Radiative trapping and collisional competition

For an isolated two-level line, the source can be written
S=(1-epsilon)J+epsilon*B with
epsilon=C_ul*(1-exp(-h*nu/(k*T)))/(A_ul+C_ul*(1-exp(-h*nu/(k*T)))).
This expression is illustrative here: the actual atom has other branches,
orbital mixing, continua and cascades. In particular 3p also decays through
Ly-beta, so its H-alpha branch epsilon is not the atom's thermalization rate.

| H-alpha branch at 1.305 Rp | C_ul/A_ul | ne_crit=A_ul/q_ul [cm^-3] | 1-J_external/S |
|---|---:|---:|---:|
| 3s -> 2p | 4.677e-4 | 7.596e13 | 0.9795 |
| 3p -> 2s | 6.443e-5 | 5.513e14 | 0.8963 |
| 3d -> 2p | 8.019e-5 | 4.430e14 | 0.9559 |

The true net downward radiative rate is n_u*A_ul*(1-J/S), not n_u*A_ul
alone. Photon trapping can reduce that bracket even when C/A is small.
Current frozen radial line-center optical depths to the outer boundary are
6.44e7 for Ly-alpha and 1.03e7 for Ly-beta at this point. These are static
line-center depths, not angle/frequency-dependent escape probabilities.

## Controlled limiting experiment

For selected lines, multiply BOTH prescribed-field radiative directions by
beta. Algebraically this is the local closure
J=(1-beta)*S+beta*J_external. beta=0 suppresses the net radiative transition;
it does not suppress A in one direction only. Collisions, continua, the
2s two-photon transition and all unselected lines remain. Charge is solved
again. These are sensitivity limits, not a computed beta(r) or RT solution.

| Closed net radiative channels, hot profile at 1.305 Rp | n2 [cm^-3] | H-alpha source brightness [K] | Ionized fraction |
|---|---:|---:|---:|
| None | 1.624e3 | 5370 | 0.09245 |
| Ly-alpha alone | 1.670e6 | 2965 | 0.7269 |
| Ly-beta alone | 1.642e3 | 6167 | 0.0930 |
| All Lyman lines | 2.495e6 | 3318 | 0.9630 |
| H-alpha alone | 1.606e3 | 7028 | 0.0930 |
| All Lyman lines and H-alpha | 1.245e6 | 7534 | 0.9681 |

Closing Ly-alpha alone increases n2 by about 1028 times, while reducing
n3/n2 and therefore the H-alpha source. With all Lyman lines closed, the
net n2-to-n3 collisional excitation is 6.35e10 cm^-3 s^-1, compared with
1.47e9 from ground-state collisions. Thus n2 collisional feeding can emerge
once the n2 reservoir is retained. H-alpha closure then raises the source.
The large ionization changes also demonstrate why a one-factor source
correction is not a physical replacement for coupled population and RT
solutions. None of these limits proves that a self-consistent fit exists.

## Checks and limitations

The baseline script samples four radii (1.102, 1.305, 1.805, 2.508 Rp), two
atmospheres and two incident fields. It reconstructs the local populations,
checks their agreement with saved arrays, and records resolved-state and
shell net budgets. The closure experiment solves 56 local equilibria.
All roots pass the existing validity and convergence diagnostics.

The fixed-prescribed-field local kinetic relaxation time is 48.6 s at the
hot 1.305 Rp point, compared with r/v=44954 s. Across all four hot PHOENIX
points it is 21--263 s versus r/v=14842--124621 s. These eigenvalues omit
nonlocal photon diffusion and are not proof that advection is negligible
after adding radiation feedback. They do not identify advection as the
first repair of the current fixed-field model.

Raw outputs: `net_rates.json`, `trapping_limits.json`. Reproduction scripts:
`net_rates.py`, `trapping_limits.py`. Sources read without modification:
`hydrogen_atom.py`, `hydrogen_nlte.py`, `nlte_forward.py`, and
`examples/stellar_halpha.py` in `/tmp/escape-stellar-spectrum`.
