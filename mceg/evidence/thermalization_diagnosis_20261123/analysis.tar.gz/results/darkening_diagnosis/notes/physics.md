# Why the upper H-alpha atmosphere can be dark

The leading hypothesis is a missing transition from deep thermalization to upper radiative decoupling. The connected observer pipeline uses local statistical equilibrium with a prescribed external radiation field and no return of internally generated photons to the populations. The observer formal solver still transports H-alpha radiation. Spontaneous decay is present in SE: newly emitted photons are effectively lost from population feedback, not absent from the observer calculation. A separate CoupledHydrogenModel already exists, but is not connected to this pipeline. Thus it can fail to keep the lower atmosphere bright when a realistic stellar spectrum suppresses pumping everywhere.

## Minimal explanation (not a replacement atom)

For an isolated two-level transition with complete redistribution, electron collisions obeying detailed balance, and x = h nu / k T:

    S = (1 - epsilon) Jbar + epsilon Bnu(T)
    epsilon = Cul (1 - exp(-x)) / [Aul + Cul (1 - exp(-x))]

The stimulated-emission factor is retained. In the illustrative one-zone closure Jbar = (1 - beta) S + beta Jext:

    S = [epsilon B + (1 - epsilon) beta Jext]
        / [epsilon + (1 - epsilon) beta]

Deep trapping (beta << epsilon) permits S approximately B. Escape faster than collisional restoration (beta >> epsilon) instead permits S approximately Jext, which can be much dimmer than B. This explains how the lower layer can remain bright under the same weak external radiation. Full transport must determine J; decreasing A by hand is not equivalent in the actual multilevel atmosphere.

For departure coefficients b = n / nLTE:

    S / B = [exp(x) - 1] / [(bl / bu) exp(x) - 1]

The familiar S/B approximately bu/bl is a Wien approximation. With resolved orbital substates this relation applies to each allowed H-alpha branch; shell n3/n2 alone is insufficient without orbital equilibrium.

## Ranked physical interpretation

1. **Differential trapping and thermalization:** Ly-alpha can support the n=2 reservoir while H-alpha photons can escape and n3/n2 becomes smaller. Deep collisions and trapping can maintain the emitting layers. This is more fundamental than finding another absorber to dim the upper layers alone.
2. **Thermal and density structure:** This is a distinct material gap, not solved by excitation trapping alone. An energy-balanced inversion and wind density place the thermal-to-radiative transition. The current prescribed temperature rises monotonically toward its upper asymptote; it cannot turn downward through adiabatic expansion as in the published model. The fitted observer path also uses a fixed wind molecular weight. An energy equation with radiative heating/cooling, adiabatic work and ionization energy, plus pressure feedback from composition, is needed to test the actual temperature and density profile. Expansion cooling can reinforce a source decline but is not required for S to fall below the local Planck function.
3. **Multilevel interlocking and continuum balance:** Lyman pumping, Balmer photoionization, recombination cascades, and l mixing affect n2 and n3 differently. The local atom already includes the corresponding microscopic processes. What is absent from the connected path is the spatially transported radiation field, including diffuse recombination continua and local attenuation. These continua alter ionization, electron density, heating and the n2 destruction rate, so line trapping alone is not a closed physical model. Stronger diffuse ionization can reduce neutral hydrogen while increasing recombination; its effect on H-alpha contrast has no predetermined sign. A large gross Ly-beta inflow does not identify the net mechanism controlling the H-alpha source function.
4. **Advection and geometry:** Test relaxation against flow times and angular radiation transfer after the static coupled problem. Neither advection nor geometric dilution guarantees darkening; they may increase upper excitation or modify opacity instead.

The PHOENIX experiment dimmed both layers and reduced the excited column by roughly 80--200 times. This is consistent with loss of the n2 reservoir in the local closure; it does not by itself demonstrate that transport will restore the observed profile. Coupled transport can also illuminate upper layers, so the sign and magnitude remain to be measured.

## Decisive diagnostics

- Compare the prescribed-atmosphere local and internally coupled SE/transfer solutions, holding density, temperature, atomic data, and stellar boundary spectrum fixed.
- Record branch populations, H-alpha source/Planck ratio, n2 column, and the optical-depth-unity formation radii.
- Record the **net** radiative bracket for every important transition: Rnet = nu Aul (1 - Jbar/S). Gross up and down transitions can be huge while their difference is small.
- Separate direct collisional/radiative balance from indirect multilevel contributions using an equivalent-two-level or rate-path decomposition. Do not treat gross incoming percentages as fractions of escaping H-alpha photons.
- Require the lower emitting source and the upper absorbing opacity/source contrast simultaneously, rather than considering outer brightness alone a success.

## Sources and scope

- Zhang et al. 2026, Section V: https://arxiv.org/html/2606.23899v1#S5 . The paper explicitly attributes lower thermal behavior to extensive scattering and collisional destruction, and upper decline to weak collisions/radiative control, reinforced by expansion cooling. Its published explanation does not establish every individual rate contribution for our model.
- Rutten 2017, especially pp. 9--11 and Figures 2/6: https://robrutten.nl/rrweb/rjr-pubs/2017IAUS..327....1R.pdf . Solar static models illustrate Ly-alpha support of n2 and H-alpha source decline through photon losses. This is an analogous mechanism, not a quantitative KELT-9b result. The CRD Doppler-core thermalization depth scales approximately as 1/epsilon in that discussion; 1/sqrt(epsilon) must not be stated as a universal spectral-line law.
- Krikova and Pereira 2024, Equations 6--14, 21--22 and Discussion: https://arxiv.org/html/2407.00384v1 . The multilevel source contains scattering, thermal, and interlocking terms. Their solar calculation finds substantial Ly-beta interlocking with Ly-alpha/H-alpha. S approximately J alone does not prove isolated two-level scattering dominance.
- Garcia Munoz and Schneider 2019: https://arxiv.org/pdf/1910.00267 . A KELT-9b model couples hydrogen, radiation, and hydrodynamics; excited hydrogen absorbs NUV and drives heating. Its restricted bound-bound transport only includes Ly-alpha, so it is not an H-alpha emission benchmark.

No repository source files were changed for this research.


## Direction of stellar irradiation

The external stellar beam enters the dayside atmosphere from above. Its direct intensity along a ray is Istar exp(-tau_star), with tau_star measured from the irradiated outer boundary. Increasing atmospheric absorption therefore suppresses direct pumping more strongly deeper in the incident column; it is not a mechanism that preferentially shields the top while leaving the bottom irradiated. Scattered and internally generated radiation can change this result, but then their transfer must be solved. Replacing the stellar spectrum by PHOENIX changes the outer boundary for every layer and is likewise not a selective upper-layer dimmer. Thus realistic irradiation is necessary input, but does not supply the missing vertical thermalization structure by itself.

## Independent audit of the rate experiments

Files audited read-only: /tmp/escape-darkening-rates/net_rates.py, trapping_limits.py and both JSON outputs. The source atom and local equilibrium implementation were also checked.

The net-rate bookkeeping is correct. Shell budgets exclude internal shell transitions; state budgets retain them. The bound-free terms use ne=np and retain radiative and three-body recombination. All sampled net radiative brackets were independently checked against upward/downward rate differences. The largest shell equilibrium residual in the JSON is 8.68e-15 relative to incoming turnover.

At the retained hot-PHOENIX layer r/Rp=1.3046875:

| Quantity | Value |
|---|---:|
| Gas temperature | 13368.477 K |
| H-alpha line-center source brightness temperature | 5369.917 K |
| n2/n1 | 4.65686556e-9 |
| Exact Boltzmann shell ratio at the local temperature | 5.71749349e-4 |
| Actual / Boltzmann ratio | 8.14494249e-6 |
| n2 | 1623.958 cm^-3 |
| n3 | 63.0842 cm^-3 |
| Net Ly-beta rate into n3 | -1.70890291e9 cm^-3 s^-1 |
| Net H-alpha rate into n3, summed branches | -2.28011230e9 cm^-3 s^-1 |
| Net ground-state collisional rate into n3 | +3.46693508e9 cm^-3 s^-1 |

The energy-averaged Boltzmann expression used by the script differs from the exact sum over the retained n=2 orbital levels by only 4.73e-11 relative at this layer. The reported value is a departure of the excitation ratio n2/n1, not an absolute Saha-Boltzmann departure coefficient b2. Likewise b3/b2_shell summarizes shell ratios and does not replace the resolved-branch source functions used for the reported brightness temperature.

The trapping experiment multiplies both radiative matrix directions by beta. For one transition, setting D=(gu/gl) nl-nu and etaS=nu/D gives

    net downward = A [nu - D eta]
    eta = (1-beta) etaS + beta eta_ext
    net downward = beta A [nu - D eta_ext].

Therefore its effective rate matrix gives exactly the net SE term of that local closure, including stimulated emission. It is not merely deleting pumping alone. At beta=0, real upward/downward radiative events would still occur and cancel; the effective matrix records zero for both. Modified gross event counts must consequently not be interpreted as physical photon budgets or branching histories.

Competing unselected lines, collisions, density-dependent orbital mixing, photoionization, recombination, and 2s two-photon decay are retained. Even all_bound_bound_closed leaves the 2s two-photon channel, which is not in the selected allowed-line list. Natural profile widths are correctly not modified by this net-rate closure.

A further physical limitation is that assigning independent closures to overlapping H-alpha branches need not correspond to a single realizable radiation field Jnu. The simultaneous beta=0 test is an extreme rate-balance counterfactual, not proof that transport can produce its populations. In the hot layer, all-Lyman closure raises n2 to 2.50e6 cm^-3 but lowers the source to 3318 K; adding H-alpha closure raises the source to 7534 K while n2 is 1.25e6 cm^-3. These opposite responses specifically show that obtaining both opacity and emission is a coupled problem. Neither limiting result is a synthesized or fitted spectrum.

The reported optical depths are static individual-branch, line-center radial depths, with the half-cell term included. Radius is stored outermost first, so cumulative integration has the correct direction. They are not the total blended opacity seen by a moving observer or a computed escape probability. The tau_sqrt_epsilon field is not a universal thermalization criterion for a redistributed spectral line and should not be used to claim LTE.

The eigenvalue relaxation times are for fixed prescribed radiation and charge-conserving local kinetics. They omit photon diffusion and the response of the nonlocal radiation field. Comparing r/v is illustrative; an actual advection criterion should use the local gradient time and the coupled system. Fast local rates do not establish that advection is negligible after trapping is included.

## Strength of the conclusion

Supported by direct code inspection: deep thermalization through internally generated radiation is missing from the **connected prescribed-field population pipeline**, although separate coupled atom/transfer machinery exists. Supported by the retained numerical case: even the hot deep sample is strongly sub-Boltzmann in n2/n1 and has a much cooler H-alpha source, while Ly-beta is a net radiative sink rather than a net source there.

These are strong reasons to test restoration of the n2 reservoir and depth-dependent thermalization before adding new absorbers. They do not prove that missing trapping alone explains the real planet or guarantees the observed double peak. The correct temperature/density profile, diffuse continuum, overlap/redistribution, irradiation geometry and observer formation radii still have to be verified together.
