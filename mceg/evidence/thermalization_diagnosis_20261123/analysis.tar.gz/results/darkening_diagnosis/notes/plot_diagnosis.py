"""Plot the retained local-source diagnosis and limiting net-rate controls."""
from pathlib import Path
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).parent
data = np.load("/tmp/escape-stellar-spectrum/results/stellar_halpha/arrays.npz")
limits = json.loads(Path("/tmp/escape-darkening-rates/trapping_limits.json").read_text())["rows"]
fig, axes = plt.subplots(2, 2, figsize=(11, 8.5), layout="constrained")
radius = data["radius_rp"]
for ax, case, title in zip(axes[0], ["previous_fit", "hot_manual"],
                           ["Previous fitted atmosphere", "Hot manual atmosphere"]):
    ax.plot(radius, data[case + "_PHOENIX_temperature_k"], "k--", label="Gas temperature")
    for field, color, label in [("blackbody", "#0072B2", "Blackbody stellar field"),
                                ("PHOENIX", "#D55E00", "PHOENIX stellar field")]:
        ax.plot(radius, data[f"{case}_{field}_source_temperature"], color=color, label=label)
    ax.set(title=title, ylabel="H-alpha source brightness temperature (K)", xlim=(1, 3))
    ax.legend(fontsize=8, loc="upper right")
for label, color, title in [("baseline", "#D55E00", "Prescribed external field"),
                             ("Lya_closed", "#009E73", "Close net Ly-alpha losses"),
                             ("Lyman_Halpha_closed", "#CC79A7", "Close net Lyman + H-alpha losses")]:
    selected = [r for r in limits if r["case"] == "hot_manual" and r["experiment"] == label]
    r = [v["radius_rp"] for v in selected]
    axes[1, 0].semilogy(r, [v["n2_cm3"] for v in selected], "o-", color=color, label=title)
    axes[1, 1].plot(r, [v["source_brightness_k"] for v in selected], "o-", color=color, label=title)
axes[1, 0].set(title="Hot PHOENIX: n=2 reservoir", ylabel=r"$n_2$ (cm$^{-3}$)", xlim=(1, 3))
axes[1, 0].legend(fontsize=8)
axes[1, 1].set(title="Hot PHOENIX: H-alpha source", ylabel="Source brightness temperature (K)", xlim=(1, 3))
for ax in axes.flat:
    ax.set_xlabel("Radius / Rp")
    ax.grid(alpha=.2)
fig.suptitle("Deep emission is also missing after changing the stellar field", fontsize=14)
fig.supxlabel("Bottom panels: limiting net-rate experiments, not transport solutions or repaired spectra", fontsize=10)
fig.savefig(ROOT / "deep_source_diagnosis.png", dpi=170)
