"""Frozen-opacity, isolated H-alpha 3d--2p scattering diagnostic.

This is not a hydrogen statistical-equilibrium solution. It keeps the real
forward-model density, temperature, electron density and branch opacity,
but closes this one branch as a two-level atom with complete redistribution.
It tests whether scattering/photon loss can make a source decrease outward
without changing the incident stellar spectrum. It omits multilevel
interlocking, velocity gradients, spherical dilution, and continuum opacity.
"""
from __future__ import annotations

import json
from pathlib import Path

import jax
jax.config.update("jax_enable_x64", True)
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.special import voigt_profile

from escape.hydrogen_atom import make_hydrogen_atom, atom_collision_rates, atom_natural_width_hz
from escape.hydrogen_rates import BOLTZMANN_CGS as K, PLANCK_CGS as H, LIGHT_SPEED_CGS as C

OUT = Path(__file__).parent
INPUT = Path("/tmp/escape-stellar-spectrum/results/stellar_halpha/arrays.npz")
RP = 13583480000.
MH = 1.6735575e-24


def planck(nu, temperature):
    return 2 * H * nu**3 / C**2 / np.expm1(H * nu / (K * temperature))


def brightness(nu, intensity):
    return H * nu / K / np.log1p(2 * H * nu**3 / C**2 / intensity)


def transfer_operator(tau_cell, phi_weight, top_intensity, bottom_intensity, angles=8):
    """Exact cell-average formal solution for piecewise-constant sources.

    tau_cell and phi_weight have shape (cell, frequency), ordered top-down.
    Return profile-averaged J = Lambda @ S + boundary. Gauss quadrature
    integrates both hemispheres; no Eddington or escape-probability closure.
    """
    n, nf = tau_cell.shape
    mu, weight = leggauss(angles)
    mu, weight = (mu + 1) / 2, weight / 2
    lam = np.zeros((n, n))
    boundary = np.zeros(n)
    escape = np.zeros(n)
    eye = np.eye(n)
    for k in range(nf):
        monochromatic = np.zeros_like(lam)
        bd = np.zeros(n)
        esc = np.zeros(n)
        for cosine, w in zip(mu, weight):
            dt = tau_cell[:, k] / cosine
            left = np.r_[0., np.cumsum(dt)[:-1]]
            right = left + dt
            g = np.ones(n)
            np.divide(-np.expm1(-dt), dt, out=g, where=dt > 0)
            factor = -np.expm1(-dt)
            gaps_down = left[:, None] - right[None, :]
            gaps_up = left[None, :] - right[:, None]
            down = np.tril(np.exp(-np.maximum(gaps_down, 0.)), -1)
            up = np.triu(np.exp(-np.maximum(gaps_up, 0.)), 1)
            monochromatic += .5 * w * (
                g[:, None] * factor[None, :] * (down + up)
                + 2 * eye * (1 - g)[:, None]
            )
            top = g * np.exp(-left)
            bottom = g * np.exp(-(right[-1] - right))
            bd += .5 * w * (top * top_intensity[k] + bottom * bottom_intensity[k])
            esc += .5 * w * (top + bottom)
        lam += phi_weight[:, k, None] * monochromatic
        boundary += phi_weight[:, k] * bd
        escape += phi_weight[:, k] * esc
    return lam, boundary, escape


def solve(lam, boundary, epsilon, thermal):
    matrix = np.eye(len(epsilon)) - (1 - epsilon[:, None]) * lam
    source = np.linalg.solve(matrix, (1 - epsilon) * boundary + epsilon * thermal)
    residual = source - (1 - epsilon) * (lam @ source + boundary) - epsilon * thermal
    return source, float(np.max(abs(residual)) / np.max(source))


def checks():
    # Unit illumination on both sides must reproduce unit J and S for every
    # cell, including optically thick cells and zero opacity.
    tau = np.array([0., .001, .1, 1., 10., 100.])[:, None]
    lam, bd, esc = transfer_operator(tau, np.ones_like(tau), np.ones(1), np.ones(1))
    partition = float(np.max(abs(lam.sum(axis=1) + esc - 1)))
    equilibrium = []
    for eps in [0., 1e-6, .1, 1.]:
        source, residual = solve(lam, bd, np.full(6, eps), np.ones(6))
        equilibrium.append(float(np.max(abs(source - 1))))
    # In transparent material, J is the average of the incident hemispheres.
    lam0, bd0, _ = transfer_operator(np.zeros((4, 1)), np.ones((4, 1)), np.array([2.]), np.array([4.]))
    transparent = float(max(np.max(abs(lam0)), np.max(abs(bd0 - 3))))
    assert partition < 2e-12 and max(equilibrium) < 2e-10 and transparent < 2e-12
    return dict(partition_of_unity_error=partition, thermodynamic_equilibrium_errors=equilibrium,
                transparent_limit_error=transparent)


def experiment(atom, data, key, *, resolution=1, angles=8, frequency_resolution=1):
    # 3d -> 2p, a genuine single H-alpha branch (no arbitrary shell average).
    line = 4
    u, l = int(atom.line_upper[line]), int(atom.line_lower[line])
    nu, a = float(atom.line_frequency_hz[line]), float(atom.einstein_a_s[line])
    gu, gl = float(atom.statistical_weights[u]), float(atom.statistical_weights[l])
    gamma = float(atom_natural_width_hz(atom)[line])
    radius = data["radius_rp"]
    temperature = data[key + "_temperature_k"]
    bound = data[key + "_bound_cm3"]
    electron = data[key + "_n_h_cm3"] - bound.sum(axis=1)
    collision = np.asarray(jax.vmap(lambda t: atom_collision_rates(atom, t)[0][u, l])(temperature)) * electron
    delta = -np.expm1(-H * nu / (K * temperature))
    epsilon = collision * delta / (a + collision * delta)
    opacity_weight = C**2 / (8 * np.pi * nu**2) * a * (gu / gl * bound[:, l] - bound[:, u])
    actual_source = (2 * H * nu**3 / C**2) / (gu * bound[:, l] / (gl * bound[:, u]) - 1)
    # Refine each original uniform cell without changing its material state.
    dz = 2 * RP / len(radius) / resolution
    radius = np.repeat(radius, resolution) + np.tile((np.arange(resolution)[::-1] - (resolution - 1) / 2) * dz / RP, len(radius))
    temperature, epsilon, opacity_weight, actual_source, electron = [
        np.repeat(v, resolution) for v in (temperature, epsilon, opacity_weight, actual_source, electron)]
    # Resolve the Doppler core and extend the damping wings to 10000 km/s.
    positive = np.r_[np.linspace(0, 100, 200 * frequency_resolution + 1),
                     np.geomspace(100 + 1 / frequency_resolution, 10000, 120 * frequency_resolution + 1)]
    velocity = np.r_[-positive[:0:-1], positive]
    freq = nu * (1 + velocity * 1e5 / C)
    df = np.r_[np.diff(freq)[0] / 2, (freq[2:] - freq[:-2]) / 2, np.diff(freq)[-1] / 2]
    sigma = nu / C * np.sqrt(K * temperature / MH)
    phi = voigt_profile(freq[None, :] - nu, sigma[:, None], gamma)
    phi_weight = phi * df
    coverage = phi_weight.sum(axis=1)
    # No renormalization: record and bound the omitted tails and quadrature.
    assert np.max(abs(coverage - 1)) < 2e-4
    optical = opacity_weight[:, None] * phi * dz
    if "PHOENIX" in key:
        stellar = np.load("/tmp/escape-stellar-sed-data/phoenix10000_surface_flux.npz")
        # Mean intensity W F_nu/pi in vacuum, supplied through one hemisphere.
        top = .05 * np.interp(freq, stellar["frequency_hz"], stellar["surface_flux_nu"]) / np.pi
    else:
        top = .05 * planck(freq, 10000.)
    bottom = planck(freq, 4500.)
    lam, boundary, escape = transfer_operator(optical, phi_weight, top, bottom, angles)
    thermal = planck(nu, temperature)
    source, residual = solve(lam, boundary, epsilon, thermal)
    # Same external stellar continuum, uniform throughout, with no internal
    # radiation coupling. Bottom illumination is omitted in this comparator,
    # matching the current rate calculation's external-only prescription.
    uniform_stellar = phi_weight @ (top / 2)
    local_source = (1 - epsilon) * uniform_stellar + epsilon * thermal
    pure_scattering, _ = solve(lam, boundary, np.zeros_like(epsilon), thermal)
    rows = []
    core = len(freq) // 2
    tau_core = np.cumsum(optical[:, core]) - optical[:, core] / 2
    for rr in [1.05, 1.3, 1.8, 2.9]:
        i = int(np.argmin(abs(radius - rr)))
        rows.append(dict(radius_rp=float(radius[i]), temperature_k=float(temperature[i]),
                         electron_cm3=float(electron[i]), epsilon=float(epsilon[i]),
                         tau_core_to_top=float(tau_core[i]), local_uniform_stellar_brightness_k=float(brightness(nu, local_source[i])),
                         scattering_brightness_k=float(brightness(nu, source[i])),
                         pure_scattering_brightness_k=float(brightness(nu, pure_scattering[i])),
                         full_atom_frozen_brightness_k=float(brightness(nu, actual_source[i])),
                         source_over_planck=float(source[i] / thermal[i])))
    stats = dict(branch="3d -> 2p", model="isolated two-level CRD, frozen opacity, static slab",
                 layers=len(radius), frequency_points=len(freq), angles_per_hemisphere=angles,
                 profile_integral_min=float(min(coverage)), profile_integral_max=float(max(coverage)),
                 closure_residual=residual, total_line_center_tau=float(optical[:, core].sum()),
                 depth_samples=rows)
    arrays = dict(radius_rp=radius, temperature_k=temperature, epsilon=epsilon,
                  source_brightness_k=brightness(nu, source), local_brightness_k=brightness(nu, local_source),
                  full_atom_brightness_k=brightness(nu, actual_source), tau_core=tau_core,
                  pure_scattering_brightness_k=brightness(nu, pure_scattering))
    return stats, arrays


def main():
    atom = make_hydrogen_atom(15)
    data = np.load(INPUT)
    report = dict(checks=checks(), experiments={})
    arrays = {}
    for key in ["previous_fit_blackbody", "previous_fit_PHOENIX", "hot_manual_blackbody", "hot_manual_PHOENIX"]:
        stats, result = experiment(atom, data, key)
        report["experiments"][key] = stats
        arrays.update({key + "_" + name: value for name, value in result.items()})
        print(key, json.dumps(stats), flush=True)
    refinements = [
        ("angle16", "previous_fit_PHOENIX", dict(angles=16)),
        ("depth2", "previous_fit_PHOENIX", dict(resolution=2)),
        ("blackbody_frequency2", "previous_fit_blackbody", dict(frequency_resolution=2)),
        ("blackbody_depth2", "previous_fit_blackbody", dict(resolution=2)),
    ]
    for label, key, options in refinements:
        stats, result = experiment(atom, data, key, **options)
        original = arrays[key + "_source_brightness_k"]
        refined = result["source_brightness_k"]
        if options.get("resolution") == 2:
            refined = refined.reshape(-1, 2).mean(axis=1)
        report["checks"][label + "_maximum_brightness_change_k"] = float(max(abs(refined - original)))
        report["checks"][label + "_closure_residual"] = stats["closure_residual"]
        report["checks"][label + "_frequency_points"] = stats["frequency_points"]
        report["checks"][label + "_depth_samples"] = stats["depth_samples"]
    (OUT / "metrics.json").write_text(json.dumps(report, indent=2))
    np.savez(OUT / "arrays.npz", **arrays)
    fig, axes = plt.subplots(2, 2, figsize=(11, 8), constrained_layout=True)
    for ax, (key, stats) in zip(axes.flat, report["experiments"].items()):
        r = arrays[key + "_radius_rp"]
        ax.plot(r, arrays[key + "_temperature_k"], color="black", label="Gas temperature")
        ax.plot(r, arrays[key + "_source_brightness_k"], label="Isolated branch + transfer")
        ax.plot(r, arrays[key + "_pure_scattering_brightness_k"], ":", label="Pure scattering control")
        ax.plot(r, arrays[key + "_local_brightness_k"], "--", label="Isolated branch, external J only")
        ax.plot(r, arrays[key + "_full_atom_brightness_k"], color="gray", alpha=.8, label="Full atom, external J only")
        ax.set(title=key.replace("_", " "), xlabel="Radius / Rp",
               ylabel=r"H$\alpha$ 3d $\rightarrow$ 2p source brightness (K)")
        ax.grid(alpha=.2)
    axes[0, 0].legend(fontsize=8)
    fig.suptitle("Controlled frozen-opacity line experiment; not a multilevel atmosphere solution")
    fig.savefig(OUT / "thermalization_diagnostic.png", dpi=160)


if __name__ == "__main__":
    main()
