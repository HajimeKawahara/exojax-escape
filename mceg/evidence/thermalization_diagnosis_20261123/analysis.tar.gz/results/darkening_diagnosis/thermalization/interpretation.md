# Frozen-opacity scattering experiment

This diagnostic demonstrates a possible mechanism for a bright lower line source and a dark upper source **without reducing the incident stellar radiation**: collisions create photons in dense material, repeated scattering helps the deep radiation field approach the local thermal field, and escape through the surface lowers the mean radiation field higher up. It also produces an important negative result: with the current PHOENIX-derived populations held fixed, the H-alpha opacity and collisional coupling are too small to make the lower layer bright in this isolated-line calculation.

The plotted quantity is the brightness temperature of the **3d -> 2p branch source**, not the kinetic temperature, a disk-integrated spectrum, or the source of all three overlapping H-alpha branches. The gray curve is the corresponding branch source from the existing multilevel calculation. Comparing gray and blue changes both transport and atomic closure; it is not a pure transfer-feedback ablation.

## Definition

The experiment holds the saved atmospheric temperature, electron density, and physical 3d--2p line extinction fixed. Only this branch's source is recomputed as an isolated two-level atom with complete frequency redistribution:

$$
S_i=(1-\epsilon_i)\overline J_i+\epsilon_i B_{\nu_0}(T_i),
\qquad
\epsilon_i=\frac{C_{ul,i}(1-e^{-h\nu_0/kT_i})}
 {A_{ul}+C_{ul,i}(1-e^{-h\nu_0/kT_i})},
\qquad C_{ul,i}=n_{e,i}q_{ul}(T_i).
$$

The same atomic collision coefficients, Einstein A value, lifetime width, and frozen branch populations as the current forward model determine epsilon and opacity. There is no fitted escape probability or artificial beta factor. The slab transfer equation is solved at each frequency, with an exact cell-averaged formal solution for piecewise-constant sources and Gauss--Legendre angle quadrature. Profile integration gives

$$
\overline{\boldsymbol J}=\boldsymbol\Lambda\boldsymbol S+\boldsymbol b,
\qquad
[\boldsymbol I-\operatorname{diag}(1-\epsilon)\boldsymbol\Lambda]
\boldsymbol S=(1-\epsilon)\boldsymbol b+\epsilon\boldsymbol B.
$$

The 128 cells span 1--3 planet radii, but transport is in a **static plane-parallel slab**. The stellar input is supplied as isotropic incoming intensity over the upper hemisphere,

$$
I_\nu^{\rm top}=2J_{\nu,\star}=2W F_{\nu,\star}/\pi,
\qquad W=0.025,
\qquad I_\nu^{\rm bottom}=B_\nu(4500\,{\rm K}).
$$

This convention reproduces the current stellar mean intensity in an otherwise empty slab when the lower illumination is removed; it is not an exact stellar beam or planet irradiation geometry. In blackbody cases, use $F_{\nu,\star}=\pi B_\nu(10000\,{\rm K})$. The PHOENIX cases use the saved stellar surface flux over the line. The boundary spectrum is unchanged when transfer is introduced. UV transfer is not solved; the UV-dependent populations remain frozen at their original values.

The orange control sets epsilon to zero, with identical opacity and incoming boundaries. The dashed green control uses the same isolated-branch epsilon but the spatially uniform stellar mean intensity and no internally generated or lower-boundary radiation; it resembles the external-only rate prescription. The blue-minus-orange difference isolates collisional photon creation in this particular frozen atmosphere.

## Results

| Frozen atmosphere | Total 3d--2p line-center optical depth | Source brightness at 1.055 Rp | Source brightness at 1.805 Rp |
|---|---:|---:|---:|
| Previous fit, blackbody | 19,012 | 6,013 K | 4,472 K |
| Previous fit, PHOENIX | 95.7 | 4,328 K | 3,627 K |
| Hot manual, blackbody | 1,024 | 8,094 K | 5,110 K |
| Hot manual, PHOENIX | 10.5 | 4,233 K | 3,807 K |

For the blackbody previous-fit case, the gas remains near 6,040--6,105 K while the isolated-line source decreases outward. The lower source reaches 98.4% of the local Planck intensity at 1.055 Rp. The surface escape mechanism can therefore produce a bright-deep/dark-upper structure even without an outward decrease of kinetic temperature.

For the PHOENIX previous-fit case, epsilon is only $3.78\times10^{-4}$ at 1.055 Rp and $1.29\times10^{-5}$ at 1.805 Rp. The lower source reaches only 23.3% of the local Planck intensity. In the hot PHOENIX case, it reaches only 6.0% at 1.055 Rp despite a gas temperature of 8,928 K. The frozen PHOENIX atom does **not** produce a thermally bright lower layer here. Increasing temperature alone is insufficient when photon creation and trapping are weak.

The familiar $1/\sqrt\epsilon$ thermalization-depth estimate is not assumed: line redistribution permits frequency-dependent escape, so a monochromatic/grey estimate does not settle this question.

## Scope and limitations

This is a controlled line calculation, not a proposed correction to the forward model and not a prediction for the measured spectrum. An actual hydrogen calculation must solve Lyman transfer, n=2 opacity, ionization, recombination/cascades, orbital mixing, and the Balmer radiation field together. The isolated 3d--2p closure omits those interlocking channels. It also omits the other H-alpha branches, continuum opacity/emission, spherical geometric dilution, stellar beam geometry, velocity gradients, and partial frequency redistribution. The lower-boundary Planck intensity is prescribed. Frozen opacity is not updated when the source changes.

The result supports testing self-consistent multilevel transfer; it does not establish that adding transfer will by itself reproduce the observed peaks. In particular, the PHOENIX negative result means that Ly-alpha trapping and other population feedback cannot be skipped by merely imposing a declining H-alpha source.

## Checks and reproducibility

`metrics.json` records exact-unit-field, transparent-limit, source-equation residual, angle, depth, and frequency checks. The base run uses 643 frequency nodes and 8 angles per hemisphere. The frequency grid resolves the core and extends to +/-10,000 km/s; the integrated Voigt profile is 0.999997869, without renormalization. The thermodynamic-equilibrium test uses a constant unit boundary field and thermal source, testing epsilon=0, 1e-6, 0.1, and 1. The largest equilibrium error is 5.6e-14; all physical-case source-equation residuals are below 5e-16. These test numerical consistency within the stated closure, not its physical adequacy.

For previous-fit PHOENIX, doubling the angle count changes source brightness by at most 0.12 K and splitting each cell in two changes its averaged brightness by at most 26.65 K. For previous-fit blackbody, increasing 643 to 1,283 frequency nodes changes brightness by at most 0.031 K, and splitting cells changes averaged brightness by at most 37.43 K. The sampled 6,013 K -> 4,472 K contrast is consequently much larger than these numerical changes. Cell splitting holds the material state piecewise constant; it tests the line-transport discretization, not the original atmosphere's spatial resolution.

Source checkout: `/tmp/escape-stellar-spectrum`, commit `1e4ad8456ef0876a4c377df7cf37e82ca7e3e050`. ExoJAX source is `/tmp/exojax-spectrum-upstream/src`, commit `38cb2e44f153ad6d729e3253e235702de52920cf`. Python 3.12.2, JAX/jaxlib 0.10.0, NumPy 2.1.0, SciPy 1.17.1, Matplotlib 3.10.1; x64 enabled.

Input SHA-256:

- Saved full-atom atmospheres, `stellar_halpha/arrays.npz`: `0333197463b309e58eefca7fbc3ed3abb75249a91d0c13bb8fa0a1ac0f2004c0`.
- Stellar flux, `phoenix10000_surface_flux.npz`: `df612b67bfe28f63a87e7c774d0e949aed1b0aa3a1c247f9e06de20a8e32f98c`.

Run `line_scattering.py` with the saved inputs at the paths specified in the script and `PYTHONPATH=/tmp/escape-stellar-spectrum/src:/tmp/exojax-spectrum-upstream/src`. Figures and metrics are research artifacts only; no runtime repository files were changed.

## References

- [Hummer (1964), The mean number of scatterings by a resonance-line photon](https://adsabs.harvard.edu/pdf/1964ApJ...140..276H): complete redistribution gives different photon-escape behavior for Doppler, Voigt, and Lorentz profiles. The present code independently constructs the finite-slab formal operator; it is not a reproduction of a published benchmark table.
- [Leenaarts, Carlsson & Rouppe van der Voort (2012), The formation of the H-alpha line in the solar chromosphere](https://arxiv.org/html/1202.1926v1): low H-alpha photon-destruction probability makes the source depend on the nonlocal radiation field; Lyman redistribution affects n=2 and hence H-alpha opacity. Their solar numerical results are an analogy, not parameters transferable to this planet.
- [Krikova & Pereira (2024), A Markovian description of the multi-level source function and its application to the Lyman series in the Sun](https://arxiv.org/html/2407.00384v1): separates scattering, thermal creation, and multilevel interlocking; provides a warning against interpreting gross excitation fractions as emergent photon-production fractions.
