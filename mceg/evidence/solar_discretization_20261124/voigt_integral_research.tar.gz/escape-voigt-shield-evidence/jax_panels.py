"""Streaming fixed-panel prototype; not a production radiation closure."""
from functools import partial
import jax
import jax.numpy as jnp
import numpy as np
from exojax.special.faddeeva import rewofz,asymptotic_wofz
jax.config.update('jax_enable_x64',True)
def profile_scalar(x,a):
 # Differentiate each actual approximation. The asymptotic derivative avoids
 # cancellation in the exact differential identity at very large |x+ia|.
 core=x*x+a*a<111.
 xx=jnp.where(core,x,1.);aa=jnp.where(core,a,1.)
 farx=jnp.where(core,12.,x);fara=jnp.where(core,1.,a)
 return jnp.where(core,rewofz(xx,aa),jnp.real(asymptotic_wofz(farx,fara)))
@partial(jax.jit,static_argnames=('order',))
def shielding(tau,a,*,order=12):
 tau,a=jnp.broadcast_arrays(tau,a);shape=tau.shape;tau=tau.ravel();a=a.ravel()
 positive=jax.nn.softplus(tau);center=jnp.sqrt(1+jnp.log1p(positive/(1+a)))
 edges=jnp.stack([jnp.zeros_like(center),center-1,center,center+1,2*center+2])*(1+a)
 scale=1+a+jnp.sqrt(a*positive)
 node,weight=np.polynomial.legendre.leggauss(order);node=jnp.asarray(node);weight=jnp.asarray(weight)
 tail,tw=np.polynomial.legendre.leggauss(2*order);tail=jnp.asarray((tail+1)/2);tw=jnp.asarray(tw/2)
 def step(i,total):
  panel=jnp.minimum(i//order,3);k=i%order;half=(edges[panel+1]-edges[panel])/2
  xcore=(edges[panel+1]+edges[panel])/2+half*node[k];wcore=half*weight[k]
  kt=jnp.clip(i-4*order,0,2*order-1);y=tail[kt]
  xtail=edges[-1]+scale*y/(1-y);wtail=scale/(1-y)**2*tw[kt]
  x=jnp.where(i<4*order,xcore,xtail);w=jnp.where(i<4*order,wcore,wtail)
  h=jax.vmap(profile_scalar)(x,a)
  return total+2/jnp.sqrt(jnp.pi)*w*h*jnp.exp(-tau*h)
 return jax.lax.fori_loop(0,6*order,jax.checkpoint(step),jnp.zeros_like(tau)).reshape(shape)
