from pathlib import Path
import json,time,numpy as np,jax,jax.numpy as jnp
from jax_panels import shielding
root=Path(__file__).parent;n=171518;t=jnp.geomspace(1e-8,1e12,n);a=jnp.geomspace(1e-8,1e2,n)
fn=jax.jit(jax.grad(lambda t,a:jnp.sum(jnp.log(shielding(t,a,order=12))),argnums=(0,1)))
start=time.time();compiled=fn.lower(t,a).compile();compile_seconds=time.time()-start
start=time.time();values=compiled(t,a);jax.block_until_ready(values);first=time.time()-start
start=time.time();values=compiled(t,a);jax.block_until_ready(values);elapsed=time.time()-start
memory=compiled.memory_analysis();report=dict(lines=n,order=12,compile_seconds=compile_seconds,first_seconds=first,steady_seconds=elapsed,temporary_bytes=memory.temp_size_in_bytes,argument_bytes=memory.argument_size_in_bytes,output_bytes=memory.output_size_in_bytes,finite=bool(all(np.isfinite(v).all() for v in values)),scope='Reverse derivative of sum log shielding, point kernel only; no outer-root inference proof.')
(root/'reverse_benchmark.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
