from pathlib import Path
import json,numpy as np
from scipy.special import wofz
from scipy.integrate import quad
# Avoid importing the executable comparison script.
import ast
p=Path(__file__).parent/'fixed_panels.py';tree=ast.parse(p.read_text());fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='nodes');exec(compile(ast.Module(body=[fn],type_ignores=[]),str(p),'exec'))
root=p.parent;cases=[(t,a) for t in np.r_[-29.,-10.,-1.,0.,np.geomspace(1e-6,1e14,30)] for a in np.geomspace(1e-20,1e6,20)];rows=[]
for tau,a in cases:
 positive=np.logaddexp(tau,0);scale=1+a+np.sqrt(np.log1p(positive))+np.sqrt(a*positive)
 def f(y):
  x=scale*y/(1-y);h=wofz(x+1j*a).real
  return 2/np.sqrt(np.pi)*h*np.exp(-tau*h)*scale/(1-y)**2
 exact,error=quad(f,0,1,epsabs=1e-150,epsrel=2e-9,limit=500,points=[.1,.3,.5,.7,.9])
 result={}
 for n in (12,24):
  x,w=nodes(tau,a,n);h=wofz(x+1j*a).real;result[n]=float(2/np.sqrt(np.pi)*np.dot(w,h*np.exp(-tau*h))/exact-1)
 rows.append(dict(tau=float(tau),damping=float(a),exact=exact,estimated_reference_error=error,relative_error=result))
report=dict(count=len(rows),scope='Independent SciPy point integral and fixed-panel numerical refinement; not source/paper equivalence.',cases=rows)
(root/'expanded_grid.json').write_text(json.dumps(report,indent=2)+'\n')
for n in [12,24]:
 worst=max(rows,key=lambda x:abs(x['relative_error'][n]));print(n,worst,flush=True)
