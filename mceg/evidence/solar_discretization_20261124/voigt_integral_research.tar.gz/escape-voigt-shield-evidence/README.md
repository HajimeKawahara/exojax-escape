# Direct Voigt shielding investigation

The independently defined point operator is

`Phi(tau,a) = (2/sqrt(pi)) integral_0^infinity H(a,x) exp(-tau H(a,x)) dx`.

It has analytic normalization Phi(0,a)=1. No numerical-profile renormalization is used. This is a scalar operator investigation, not a solar atmosphere or production implementation.

`source_kernel.cpp` includes the unchanged C23.01 source with a reporting main appended. It calls the actual `conpmp_romb(tau*sqrt(pi),a)`. The raw integral amplifies for negative tau; the actual C23 integral-option wrapper applies `min(1,value)` and therefore suppresses that amplification. Both quantities are retained. The default C23 Federman option is a different approximation.

`comparison.json` compares 50 original-C23 values with independent SciPy integration. The largest positive-tau difference is 0.077%; raw negative-tau differences reach 1.97% near a=0.1,tau=-29. C23 uses its FastVoigtH approximation at a<=0.1. The discrepancy is consistent with amplification of that profile approximation in raw gain; an exact causal profile-replacement control was not run. Both capped negative-tau values are one. This is not evidence that the default Federman approximation reproduces the exact integral.

`jax_panels.py` is an executable prototype with four smooth-moving finite panels and one rationally mapped tail, streaming/rematerializing quadrature points. It uses the existing ExoJAX Voigt approximations, differentiating their actual expressions. `expanded_grid.json` covers 680 independent SciPy cases with tau up to 1e14 and a from 1e-20 to 1e6: 72-point quadrature differs by up to 0.166%, and 144 points by 3.1e-6. The narrower 50-point JAX control has finite AD/FD derivatives with maximum absolute discrepancy below 9e-9. These finite domains are not universal error bounds.

Measured on CPU52-55, one 171,518-line cell at 72 points takes 0.874 s for the primal (16.5 MB compiler temporary memory) and 8.97 s for reverse differentiation of sum(log(Phi)) (223.7 MB temporary memory). These are scalar-operator timings, not full atmosphere timings or NUTS readiness. A cell-average of the original piecewise fit, split at its moving branch joins, may be much cheaper and preserves the reference point approximation; that separate proposal is not implemented here.

## Replay

With JAX, NumPy, SciPy, and the pinned ExoJAX provider available:

```sh
python expanded_grid.py
python verify_jax.py
python benchmark_reverse.py
```

The retained C23 values can be checked without an executable. To regenerate them, compile `source_kernel.cpp` against the unchanged local C23.01 source headers and libcloudy.a, then run `compare_integrals.py`. The sources are identified in `source_pins.json`; no executable or original stellar spectrum is redistributed. No runtime escape code was changed for this experiment.
