"""Static-count smooth-moving panels for the normalized Voigt integral."""
from pathlib import Path
import json,numpy as np
from scipy.special import wofz
root=Path(__file__).parent;reference=json.loads((root/'comparison.json').read_text())
def nodes(tau,a,n):
 positive=np.logaddexp(tau,0.)
 center=np.sqrt(1+np.log1p(positive/(1+a)))
 boundary=(1+a)*np.array([0.,center-1,center,center+1,2*center+2])
 x,w=np.polynomial.legendre.leggauss(n);points=(boundary[1:,None]+boundary[:-1,None])/2+(boundary[1:]-boundary[:-1])[:,None]*x/2
 weight=(boundary[1:]-boundary[:-1])[:,None]*w/2
 y,v=np.polynomial.legendre.leggauss(2*n);y=(y+1)/2;v=v/2
 scale=1+a+np.sqrt(a*positive)
 tail=boundary[-1]+scale*y/(1-y);tailweight=scale/(1-y)**2*v
 return np.r_[points.ravel(),tail],np.r_[weight.ravel(),tailweight]
rows=[]
for r in reference['cases']:
 tau,a=r['tau'],r['damping'];orders={}
 for n in [8,12,16,24,32]:
  x,w=nodes(tau,a,n);h=wofz(x+1j*a).real;value=2/np.sqrt(np.pi)*np.dot(w,h*np.exp(-tau*h));orders[n]=dict(value=float(value),relative_error=float(value/r['scipy_raw']-1),points=len(x))
 rows.append(dict(tau=tau,damping=a,orders=orders))
for n in [8,12,16,24,32]:
 worst=max(rows,key=lambda r:abs(r['orders'][n]['relative_error']));print(n,worst,flush=True)
(root/'fixed_panels.json').write_text(json.dumps(dict(scope='Independent SciPy Voigt kernel in proposed fixed-count panels; JAX/time/AD not yet assessed.',cases=rows),indent=2)+'\n')
