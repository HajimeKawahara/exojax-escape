from pathlib import Path
import json,time,numpy as np,jax,jax.numpy as jnp
from jax_panels import shielding
root=Path(__file__).parent;ref=json.loads((root/'comparison.json').read_text())['cases']
t=jnp.array([x['tau'] for x in ref]);a=jnp.array([x['damping'] for x in ref]);expected=np.array([x['scipy_raw'] for x in ref]);reports=[]
for n in (12,24):
 actual=np.asarray(shielding(t,a,order=n));error=actual/expected-1
 fn=lambda shift: jnp.log(shielding(t+jnp.asarray(shift[0]),a*jnp.exp(shift[1]),order=n))
 point=jnp.zeros(2);deriv=np.asarray(jax.jacfwd(fn)(point));fd=np.column_stack([np.asarray((fn(point+jnp.eye(2)[i]*1e-4)-fn(point-jnp.eye(2)[i]*1e-4))/2e-4) for i in range(2)])
 reports.append(dict(order=n,points=6*n,maximum_value_relative_error=float(max(abs(error))),worst_case=int(np.argmax(abs(error))),maximum_derivative_absolute_error=float(np.max(abs(deriv-fd))),derivatives_finite=bool(np.isfinite(deriv).all())))
 print(reports[-1],flush=True)
# One 171,518-line cell; report measured latency and compiled memory, not a
# full-atmosphere speed prediction. No Q-by-line tensor is retained.
size=171518;t=jnp.geomspace(1e-8,1e12,size);a=jnp.geomspace(1e-8,1e2,size)
f=jax.jit(lambda t,a:shielding(t,a,order=12));start=time.time();compiled=f.lower(t,a).compile();compile_seconds=time.time()-start
start=time.time();value=compiled(t,a).block_until_ready();first=time.time()-start
start=time.time();compiled(t,a).block_until_ready();runtime=time.time()-start
memory=compiled.memory_analysis();benchmark=dict(lines=size,order=12,compile_seconds=compile_seconds,first_seconds=first,steady_seconds=runtime,temporary_bytes=memory.temp_size_in_bytes,argument_bytes=memory.argument_size_in_bytes,output_bytes=memory.output_size_in_bytes,finite=bool(np.isfinite(value).all()))
print(benchmark,flush=True);(root/'jax_verification.json').write_text(json.dumps(dict(cases=reports,benchmark=benchmark,scope='Prototype scalar shielding quadrature only; no production integration or full-atmosphere derivative claim.'),indent=2)+'\n')
