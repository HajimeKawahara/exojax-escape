"""Compare untouched C23 Romberg and independent normalized Voigt integrals."""
from pathlib import Path
import hashlib,json,subprocess,time
import numpy as np
from scipy.special import wofz
from scipy.integrate import quad
root=Path(__file__).parent
cases=[(t,a) for a in (1e-9,1e-4,.1,1.,1e3) for t in (-29.,-1.,0.,1e-6,2.,10.,100.,1e4,1e8,1e14)]
(root/'source_input.txt').write_text(''.join(f'{t:.17g} {a:.17g}\n' for t,a in cases))
start=time.time();r=subprocess.run([str(root/'source_kernel')],input=(root/'source_input.txt').read_text(),text=True,capture_output=True,timeout=150);(root/'source_output.txt').write_text(r.stdout);(root/'source_stderr.txt').write_text(r.stderr);assert r.returncode==0,r.stderr
reference=np.loadtxt(root/'source_output.txt');rows=[]
for (tau,a),record in zip(cases,reference):
 scale=1+a+np.sqrt(np.log1p(np.logaddexp(tau,0)))+np.sqrt(a*np.logaddexp(tau,0))
 def f(y):
  x=scale*y/(1-y);h=wofz(x+1j*a).real
  return 2/np.sqrt(np.pi)*h*np.exp(-tau*h)*scale/(1-y)**2
 precise,error=quad(f,0.,1.,epsabs=1e-150,epsrel=3e-10,limit=500,points=[.1,.3,.5,.7,.9])
 fixed={}
 for order in (32,64,128,256):
  x,w=np.polynomial.legendre.leggauss(order);value=np.dot(w/2,f((x+1)/2));fixed[str(order)]=dict(value=float(value),relative_error=float(value/precise-1))
 row=dict(tau=tau,damping=a,c23_raw=float(record[2]),c23_capped=float(record[3]),scipy_raw=precise,c23_relative_error=float(record[2]/precise-1),scipy_estimated_error=error,fixed=fixed);rows.append(row);print(tau,a,row['c23_relative_error'],{n:d['relative_error'] for n,d in fixed.items()},flush=True)
report=dict(definition='2/sqrt(pi) integral_0^infinity H(a,x) exp(-tau H(a,x)) dx; no profile renormalization',scope='Point shielding only; negative raw amplification is distinct from C23 integral-wrapper min(1,value). No atmosphere or timing adequacy.',elapsed=time.time()-start,cases=rows,source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),root/'source_kernel.cpp',Path('/tmp/cloudy-reference-run/c23.01/source/rt_continuum_shield_fcn.cpp')]})
(root/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
