"""Independent full-table excitation control; no supplied Cloudy rate matrices."""
from pathlib import Path
from unittest.mock import patch
import json,numpy as np,jax,jax.numpy as jnp
import escape.metal_atom as ma
jax.config.update('jax_enable_x64',True)
root=Path('/tmp/escape-sulfur-validation');rows=[]
for n in (15,30,72,87,232):
 with patch.object(ma,'files',lambda name:root):a=ma.load_metal_atom('S II',levels=n)
 delta=a.energy_wavenumber[:,None]-a.energy_wavenumber[None,:]
 occ=.025/jnp.expm1(ma.PLANCK*ma.C*jnp.maximum(delta,1)/(ma.KB*10000))
 down=a.spontaneous*(1+occ);up=(a.spontaneous*occ*a.weight[:,None]/a.weight[None,:]).T
 for t,ne in ((4500.,1e8),(6500.,1e12),(8000.,1e12)):
  collision=ne*ma.electron_collision_coefficients(a,t);population=ma.populations(down+up+collision,1.)
  heat=ma.kinetic_line_heating(population,collision,a.energy_wavenumber)
  row=dict(levels=n,temperature=t,electron=ne,net_heat_per_ion=float(heat),excited_fraction_above72=float(population[72:].sum()),minimum_population=float(population.min()),finite=bool(np.isfinite(population).all()),sum=float(population.sum()))
  rows.append(row);print(row,flush=True)
(root/'full_atom.json').write_text(json.dumps(dict(scope='Optically thin BB10000 W=.025, electron-only excitation; no atmosphere equivalence.',cases=rows),indent=2)+'\n')
