"""Source-backed S ionic coefficients and conditional excitation parity."""
from pathlib import Path
from unittest.mock import patch
import ast,hashlib,json,jax,jax.numpy as jnp,numpy as np
import escape.metal_atom as ma
import escape.metal_rates as mr
jax.config.update('jax_enable_x64',True)
root=Path('/tmp/escape-sulfur-validation')
source=Path('/tmp/escape-metal-prototype/validate.py');tree=ast.parse(source.read_text());exec(compile(ast.Module(body=[next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='parse')],type_ignores=[]),str(source),'exec'))
with patch.object(mr,'files',lambda name:root):data=mr.load_metal_rates();partitions=mr.load_metal_partitions()
report=dict(scope='Conditional local S II excitation/thermal and low-charge RR/DR/H/He CT parity at supplied Cloudy plasma/radiative rates; BB controls do not establish PHX atmosphere reduction.',ionic=[],atomic=[],truncation=[])
for p in sorted((root/'controls').glob('t*_s*/metal_atom_16_2_zone00001.txt')):
 if 'unmodified' in str(p):continue
 record=parse(p);n=len(record['population'])
 with patch.object(ma,'files',lambda name:root):atom=ma.load_metal_atom('S II',levels=n);colliders=ma.load_metal_colliders('S II',levels=n)
 t,ne=record['temperature'],record['electron'];effective=ne+1.7e-4*record['collider_densities_cm3']['H I']
 collision=effective*ma.electron_collision_coefficients(atom,t)
 names={'H':'H I','PROTON':'H II','HE':'He I','HE+':'He II'}
 for label,table in colliders.items():
  if label in names:collision+=record['collider_densities_cm3'][names[label]]*ma.tabulated_collision_coefficients(atom,table,t)
 solution=ma.populations(record['radiative']+collision,record['abundance']);heat=ma.kinetic_line_heating(solution,collision,atom.energy_wavenumber)
 l1=lambda actual,ref:float(np.sum(abs(np.asarray(actual)-ref))/max(np.sum(abs(ref)),1e-300))
 result=dict(control=p.parent.name,levels=n,temperature=t,electron=ne,abundance=record['abundance'],reference_cooling=record['cooling'],native_cooling=-float(heat),collision_relative_l1=l1(collision,record['collision']),population_relative_l1=l1(solution,record['population']),heat_relative_error=float(-heat/record['cooling']-1),a_relative_l1=l1(atom.spontaneous,record['a']),source_max=float(abs(record['source']).max()),sink_max=float(abs(record['sink']).max()),source_sha256=record['source_sha256']);report['atomic'].append(result);print('atomic',result,flush=True)
 if n==15:
  lines=[s.split() for s in p.read_text().splitlines() if s.startswith('CHARGE_RATE')]
  for row in lines[:3]:
   q=int(row[1])+1;ref=np.array([float(row[i]) for i in (4,5,7,8,9,10)])
   def rates(logt):
    temp=t*jnp.exp(logt)
    return jnp.array([mr.radiative_recombination(temp,16,q,data),mr.raw_dielectronic_recombination(temp,16,q,data)*mr.dielectronic_suppression(temp,ne,16,q),*mr.charge_exchange(temp,16,q,data)])
   actual=np.asarray(rates(0.));error=abs(actual-ref)/np.maximum(abs(ref),1e-40);derivative=np.asarray(jax.jacfwd(rates)(0.));finite=np.asarray((rates(1e-5)-rates(-1e-5))/2e-5)
   item=dict(control=p.parent.name,charge=q,actual=actual.tolist(),reference=ref.tolist(),relative_error=error.tolist(),passed=bool(np.allclose(actual,ref,rtol=3e-6,atol=1e-40)),derivative_pass=bool(np.allclose(derivative,finite,rtol=2e-5,atol=1e-30)));report['ionic'].append(item);print('ionic',item,flush=True)
for t in (4500,6500,8000):
 for density in (8,12):
  rows=[r for r in report['atomic'] if r['control'].startswith(f't{t}_n{density}_')];rows.sort(key=lambda x:x['levels'])
  report['truncation'].append(dict(temperature=t,log_n_h=density,requested_levels=[x['levels'] for x in rows],cooling_per_Splus=[x['reference_cooling']/x['abundance'] for x in rows],relative_15_to_30=(rows[1]['reference_cooling']/rows[1]['abundance'])/(rows[0]['reference_cooling']/rows[0]['abundance'])-1,relative_30_to_232=(rows[2]['reference_cooling']/rows[2]['abundance'])/(rows[1]['reference_cooling']/rows[1]['abundance'])-1))
report['ionic_passed']=all(r['passed'] and r['derivative_pass'] for r in report['ionic'])
report['atomic_passed']=all(r['a_relative_l1']<1e-6 and r['collision_relative_l1']<1e-6 and r['population_relative_l1']<1e-6 and abs(r['heat_relative_error'])<1e-4 for r in report['atomic'])
report['source_pins']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),root/'species2.cpp',Path(ma.__file__),Path(mr.__file__),root/'data/metal_rates.npz',root/'data/metal_atoms.npz']}
(root/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print('summary',report['ionic_passed'],report['atomic_passed'],report['truncation'],flush=True)
