from pathlib import Path
import hashlib,json,subprocess,time
root=Path('/tmp/escape-sulfur-validation');binary=root/'cloudy_diagnostic.exe';original=Path('/tmp/cloudy-reference-run/cloudy_unmodified.exe')
records=[]
for index,(temperature,density) in enumerate([(4500,8),(4500,12),(6500,8),(6500,12),(8000,8),(8000,12)]):
 for levels in (15,30,232):
  out=root/'controls'/f't{temperature}_n{density}_s{levels}';out.mkdir(exist_ok=False)
  text=f'''title Conditional S II atomic truncation and ionic coefficient control
blackbody 10000 K dilution -1.6020599913
hden {density}
constant temperature {temperature} K
abundances "default.abn"
species "S+" levels={levels}
stop zone 1
iterate 2
print last iteration
save physical conditions last ".conditions"
save heating last ".heating"
save cooling last ".cooling"
'''
  (out/'model.in').write_text(text);t=time.time()
  with (out/'console.txt').open('w') as stream:r=subprocess.run([str(binary),'-r','model'],cwd=out,stdout=stream,stderr=subprocess.STDOUT)
  item=dict(temperature=temperature,log_n_h=density,requested_levels=levels,elapsed=time.time()-t,returncode=r.returncode,output=str(out),input_sha256=hashlib.sha256((out/'model.in').read_bytes()).hexdigest());records.append(item);print(item,flush=True)
  (root/'control_runs.inprogress.json').write_text(json.dumps(records,indent=2)+'\n')
  if r.returncode:raise RuntimeError(item)
(root/'control_runs.inprogress.json').replace(root/'control_runs.json')
# Reporting-only output identity at a representative 15-level state.
reference=root/'controls/t6500_n12_s15';out=root/'controls/t6500_n12_s15_unmodified';out.mkdir(exist_ok=False);(out/'model.in').write_bytes((reference/'model.in').read_bytes())
with (out/'console.txt').open('w') as stream:r=subprocess.run([str(original),'-r','model'],cwd=out,stdout=stream,stderr=subprocess.STDOUT)
identity={name:(out/name).read_bytes()==(reference/name).read_bytes() for name in ('.conditions','.heating','.cooling')}
(root/'output_identity.json').write_text(json.dumps(dict(returncode=r.returncode,files=identity,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),unmodified_binary_sha256=hashlib.sha256(original.read_bytes()).hexdigest()),indent=2)+'\n')
print('identity',identity,flush=True)
