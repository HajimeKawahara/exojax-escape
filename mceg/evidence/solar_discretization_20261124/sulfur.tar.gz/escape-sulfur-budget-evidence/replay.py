"""Replay conditional source comparisons with an installed escape provider."""
from pathlib import Path
import json
import jax
import numpy as np
from matrix_parser import parse
from escape.metal_atom import (load_metal_atom,load_metal_colliders,
    electron_collision_coefficients,tabulated_collision_coefficients,
    populations,kinetic_line_heating)
from escape.metal_rates import (load_metal_rates,radiative_recombination,
    raw_dielectronic_recombination,dielectronic_suppression,charge_exchange)
jax.config.update('jax_enable_x64',True)
root=Path(__file__).parent;data=load_metal_rates();rows=[]
for path in sorted((root/'sulfur/controls').glob('*/metal_atom_16_2_zone00001.txt')):
 r=parse(path);atom=load_metal_atom('S II',levels=r['levels']);tables=load_metal_colliders('S II',levels=r['levels']);n=r['collider_densities_cm3'];t=r['temperature'];ne=r['electron']
 collision=(ne+1.7e-4*n['H I'])*electron_collision_coefficients(atom,t)
 for name,table in tables.items():
  collider={'H':'H I','PROTON':'H II','HE':'He I','HE+':'He II'}[name]
  collision+=n[collider]*tabulated_collision_coefficients(atom,table,t)
 population=populations(r['radiative']+collision,r['abundance'])
 heat=kinetic_line_heating(population,collision,atom.energy_wavenumber)
 relative=lambda value,ref:float(np.sum(abs(np.asarray(value)-ref))/max(np.sum(abs(ref)),1e-300))
 errors=dict(a=relative(atom.spontaneous,r['a']),collision=relative(collision,r['collision']),population=relative(population,r['population']),heat=abs(float(heat/-r['cooling']-1)))
 assert max(errors.values())<1e-6,(path,errors)
 rows.append(dict(control=path.parent.name,levels=r['levels'],errors=errors))
anchors=json.loads((root/'sulfur/independent_anchors.json').read_text())
for r in anchors['ionic_cases']:
 t,ne,q=r['temperature'],r['electron_cm3'],r['charge']
 actual=[radiative_recombination(t,16,q,data),raw_dielectronic_recombination(t,16,q,data)*dielectronic_suppression(t,ne,16,q),*charge_exchange(t,16,q,data)]
 np.testing.assert_allclose(actual,r['expected'],rtol=3e-12,atol=1e-40)
print(json.dumps(dict(passed=True,conditional_atomic_cases=rows,ionic_cases=len(anchors['ionic_cases']),scope='Supplied C23 radiation and plasma; no atmosphere, NUTS or PHX convergence claim.'),indent=2))
