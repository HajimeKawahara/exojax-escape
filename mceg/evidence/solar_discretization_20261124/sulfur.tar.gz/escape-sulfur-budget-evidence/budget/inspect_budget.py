from pathlib import Path
import json,re,hashlib
import numpy as np
root=Path('/tmp/escape-continuation-Fe716-union6k/iteration_000')

def read(name):
 rows=[]; labels=set()
 for raw in (root/name).read_text().splitlines():
  parts=raw.strip().split('\t')
  if not re.match(r'^[0-9]',parts[0]) or len(parts)<5:continue
  row=list(map(float,parts[:5]));terms={}
  assert (len(parts)-5)%2==0,(name,parts[-3:])
  for label,value in zip(parts[5::2],parts[6::2]):
   label=label.strip()
   if name=='model.cooling':label=re.sub(r'\s+[-+0-9.eE]+$','',label)
   label=' '.join(label.split());terms[label]=terms.get(label,0)+float(value)
  rows.append((row,terms));labels.update(terms)
 labels=sorted(labels)
 return np.array([x[0] for x in rows]),labels,np.array([[x[1].get(k,0) for k in labels] for x in rows])
for name in ['model.cooling','model.heating']:
 a,labels,f=read(name)
 print(name,a.shape,'fraction sum',f.sum(1).min(),f.sum(1).max(),'negative',f.min())
 for i in np.argsort(np.max(abs(f),axis=0))[::-1]:print(labels[i],float(np.max(f[:,i])),float(np.min(f[:,i])))
