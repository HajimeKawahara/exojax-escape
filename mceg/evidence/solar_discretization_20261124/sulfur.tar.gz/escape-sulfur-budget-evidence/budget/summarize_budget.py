"""Classify the saved prescribed-profile C23 thermal ledger; no model fitting."""
from pathlib import Path
import json,re,hashlib
import numpy as np
out=Path('/tmp/escape-solar-budget-audit')
exec(compile((out/'inspect_budget.py').read_text().split("for name in ['model.cooling'")[0],str(out/'inspect_budget.py'),'exec'))
geometry=np.loadtxt(root/'model.radius'); depth=geometry[:,2];dr=geometry[:,3]
radius=3*1.358348e10-depth; rp=radius/1.358348e10
h,hl,hf=read('model.heating');c,cl,cf=read('model.cooling')
assert len(geometry)==len(h)==len(c)==806
np.testing.assert_allclose(h[:,0],depth,rtol=1e-11,atol=1e-9)
np.testing.assert_allclose(c[:,0],depth,rtol=5e-6,atol=1e-5)
assert np.all(hf>=0) and np.all(cf>=0)
retained={'C','N','O','Mg','Al','Si','Ca','Mn','Fe'}
excitation={('C',1),('C',2),('N',1),('O',1),('Mg',2),('Al',2),('Si',2),('Ca',2),('Mn',2),('Fe',2),('Fe',3)}
def ion(label):
 m=re.fullmatch(r'([A-Z][a-z]?) (\d+)',label)
 return (m[1],int(m[2])) if m else None

def stats(frac,total):
 k=int(np.argmax(frac)); band=(rp>=1.1)&(rp<=2.5)
 return {'maximum_local_fraction':float(frac[k]),'maximum_radius_rp':float(rp[k]),'maximum_temperature_k':float(h[k,1]),'at_radius_1p1_1p3_1p8_2p5':np.interp([1.1,1.3,1.8,2.5],rp[::-1],frac[::-1]).tolist(),'column_integrated_fraction':float(np.sum(frac*total*dr)/np.sum(total*dr)),'spherical_integrated_fraction':float(np.sum(frac*total*dr*radius**2)/np.sum(total*dr*radius**2)),'band_1p1_to_2p5_column_integrated_fraction':float(np.sum((frac*total*dr)[band])/np.sum((total*dr)[band]))}

def classify(labels,f,total,kind):
 groups={
 'unretained_elements_explicit':lambda k:ion(k) is not None and ion(k)[0] not in retained|{'H','He'},
 'q_ge_3_explicit':lambda k:ion(k) is not None and ion(k)[1]>=4,
 'helium_explicit':lambda k:'He' in k,
 'H2_family_explicit':lambda k:k.startswith('H2'),
 'Hminus_explicit':lambda k:k.startswith('H-'),
 'Compton_explicit':lambda k:k=='Comp',
 }
 if kind=='cooling':groups['retained_elements_missing_excitation']=lambda k:ion(k) is not None and ion(k)[0] in retained and ion(k) not in excitation
 result={}
 for name,predicate in groups.items():
  indices=[i for i,k in enumerate(labels) if predicate(k)]
  result[name]={'labels':[labels[i] for i in indices],**stats(f[:,indices].sum(1),total)}
 result['unreported_residual']=stats(np.maximum(1-f.sum(1),0),total)
 return {'groups':result,'channels':{k:stats(f[:,i],total) for i,k in enumerate(labels)},'column_total_erg_cm2_s':float(np.sum(total*dr)),'spherical_total_erg_s':float(np.sum(total*dr*4*np.pi*radius**2))}
result={'reference_root':str(root),'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['model.in','model.radius','model.heating','model.cooling','model.out']},'scope':'One completed prescribed-temperature/density Fe716/H25 full-chemistry solar column, 806 adaptive zones. Not a thermal/wind solution, local-iteration-converged precision reference, model-reduction adequacy proof, or observable sensitivity bound.','definitions':{'local_fraction':'saved physical channel / corresponding total heating or cooling; dynamical terms excluded by C23 SaveHeat/CoolSave','column_integral':'sum(channel*Cloudy_zone_width) / sum(total*Cloudy_zone_width)','spherical_integral':'same with radius^2 from r=3Rp-Cloudy_depth; conditional spherical weighting of the plane-slab reference','unreported_residual':'1-sum(saved fractions); includes subthreshold channels and printed rounding, not a per-process measurement','saved_threshold_fraction':1e-4,'q_ge_3':'ion stage IV and above; explicit labels only, not hidden FF/recombination/DbLn contributions','helium':'explicit labels only; does not bound its electron, opacity, or molecular feedback'},'heating':classify(hl,hf,h[:,2],'heating'),'cooling':classify(cl,cf,h[:,3],'cooling')}
# Printed database pseudo-lines give conditional column-integrated, not local,
# species thermal budgets. Values have only three decimal places in log flux.
pseudo={}
for raw in (root/'model.out').read_text().splitlines():
 for m in re.finditer(r'(?:^| {2,})([A-Z][a-z]?\s+\d+[hc])\s+0\s+([-+\d.]+)\s+([-+\d.]+)',raw):
  label=' '.join(m[1].split());pseudo[label]={'log10_column_erg_cm2_s':float(m[2]),'relative_printed':float(m[3])}
result['printed_species_pseudo_lines']=pseudo
for what,suffix,total in [('heating','h',result['heating']['column_total_erg_cm2_s']),('cooling','c',result['cooling']['column_total_erg_cm2_s'])]:
 vals={k:10**v['log10_column_erg_cm2_s']/total for k,v in pseudo.items() if k.endswith(suffix) and k.split()[0] not in {'H','He'}}
 result[what]['printed_species_column_fractions']=vals
 result[what]['printed_unretained_species_column_fraction']=sum(v for k,v in vals.items() if k.split()[0] not in retained)
 if what=='heating':
  d=result['heating']['channels']['DbLn']['column_integrated_fraction']
  result[what]['unallocated_DbLn_column_fraction']=d-sum(vals.values())
result['limitations']=['DbLn heating is aggregated locally, so local omitted-species line heating cannot be bounded from these save files alone. Printed per-species pseudo-lines provide a column-integrated check only.','No explicit He or q>=3 label does not imply zero total contribution: these can enter aggregate continuum and charge channels.','S II cooling exceeds 5% locally; native S charge/excitation is absent and must be assessed before claiming reduction adequacy.']
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
for what in ['heating','cooling']:
 print(what)
 for group,v in result[what]['groups'].items():print(group,v['maximum_local_fraction'],v['maximum_radius_rp'],v['column_integrated_fraction'],v['spherical_integrated_fraction'])
 print('printed omitted',result[what]['printed_unretained_species_column_fraction'])
print('SII',result['cooling']['channels']['S 2'])
print('DbLn remainder',result['heating']['unallocated_DbLn_column_fraction'])
