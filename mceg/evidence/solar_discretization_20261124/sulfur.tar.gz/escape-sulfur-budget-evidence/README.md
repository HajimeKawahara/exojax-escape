# Sulfur inclusion and omitted-process budget

This bundle records why S II was added to the native solar candidate. It does not certify a converged solar atmosphere. The unchanged fixed-profile C23 reference has its own unresolved local/column convergence requirements.

- `budget/summary.json`: S II supplies up to 7.86% of local cooling, including 5.63% near 2.5 Rp. After including S, the remaining explicitly resolved omitted-element cooling reaches 3.56% locally; aggregate labels still prevent a complete omission bound. Deep layers dominate column integrals, so small integrated fractions cannot excuse an upper-layer omission.
- `sulfur/verification.json`: 18 local excitation matrices and 18 low-charge ionic coefficient cases. Radiative A values, native collisions, closed local SE and kinetic line heat are compared to actual reporting-only C23 output. Radiation and plasma conditions are supplied in this comparison.
- `sulfur/full_atom.json`: independent optically thin BB excitation controls. The 15/30-level reductions can change thermal exchange substantially. Native 72-to-232 changes are below 2e-6 in the listed cases, which does not establish PHX atmospheric truncation adequacy.
- `sulfur/maximum_levels_diagnostic.txt`: C23 uses 72 even when 232 levels are requested. `species.cpp:trim_levels()` removes trailing levels with no radiative downward transition. The package keeps all 232 energy levels as an optional alternative, but the normal model uses 72.
- `components.json` maps each conclusion to its receipt. `origins.json` and `manifest.json` identify sources and retained files.

The provider implementation is commit `542c932`; source-defined S trimming provenance is added in `07a1297`. The 43 passing tests comprise the 42-case atom/rate regression and one S shared-network integration test. An initial test used an incorrect returned-dictionary key; its failure is retained and is separate from the subsequent passing test.

## Replay

With the provider checkout and its JAX dependencies installed:

```sh
JAX_PLATFORMS=cpu OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python replay.py
```

This replays the 18 conditional atom comparisons and 18 ionic-rate comparisons using packaged data. It requires no Cloudy executable or stellar spectrum. Rebuilding the independent controls requires a licensed local Cloudy C23.01 source/data tree: `sulfur/species2.cpp` adds readouts only, and `sulfur/run_controls.py` records every BB input and the unmodified-output identity check. Those developer scripts preserve original local paths; adapt the root paths before rebuilding. The unchanged Cloudy and reporting-only binaries produced identical saved conditions/heating/cooling at the explicitly listed control.

The atmospheric budget source is the prescribed PHX full-solar Fe716/H25 column named in `budget/summary.json`; its stellar input is not redistributed. The numerical budget can be inspected from the retained heating/cooling/conditions tables. This bundle contains no SED/FITS, stellar-reference spectrum, executable, package atomic-data duplicate, compilation cache, or HLO artifact.
