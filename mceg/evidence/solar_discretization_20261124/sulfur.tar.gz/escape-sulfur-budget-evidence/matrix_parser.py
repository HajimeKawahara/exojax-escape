"""Parser of reporting-only C23 matrices; no solver implementation."""
import hashlib
import numpy as np
def parse(path):
    rows=[line.split() for line in path.read_text().splitlines()]
    head=list(map(float,rows[0][1:]))
    iteration, zone, radius, temperature, electron, abundance, count, cooling, constant=head
    count=int(count)
    result=dict(iteration=int(iteration),zone=int(zone),radius_rp=radius,temperature=temperature,
                electron=electron,abundance=abundance,levels=count,cooling=cooling,
                collision_constant=constant,path=str(path),
                source_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    level=np.array([list(map(float,row[1:])) for row in rows if row[0]=='LEVEL'])
    result.update(weight=level[:,1],energy=level[:,2],population=level[:,3],source=level[:,4],sink=level[:,5])
    matrices={name:np.zeros((count,count)) for name in ('radiative','collision','electron_coefficient','base_pump','a','loss','extra_radiative')}
    for row in rows:
        if row[0]=='ELEMENT':
            result['element'],result['element_total']=int(row[1]),float(row[2])
        if row[0]=='ION':
            result.setdefault('ions',{})[row[1]]=float(row[2])
        if row[0]=='COLLIDERS':
            result['collider_densities_cm3']=dict(zip(('electron','H I','H II','He I','He II','He III'),map(float,row[1:])))
        if row[0]=='CHARGE_RATE':
            result.setdefault('charge_rates',{})[row[1]]=dict(zip(
                ('RateIonizTot_s1','RateRecomTot_s1','RR_rate_coef_used_cm3_s','DR_Badnell_rate_coef_cm3_s',
                 'CX_recomb_rate_used','H_CharExcIonOf_cm3_s','H_CharExcRecTo_cm3_s',
                 'He_CharExcIonOf_cm3_s','He_CharExcRecTo_cm3_s'),map(float,row[2:])))
        if row[0]!='RATE':continue
        lo,hi=map(int,row[1:3]);esc,dest,up,down,clu,cul,qe,a,base,cool,nonthermal=map(float,row[3:])
        matrices['radiative'][lo,hi]=up
        matrices['radiative'][hi,lo]=esc+dest+down
        matrices['collision'][lo,hi]=clu
        matrices['collision'][hi,lo]=cul
        matrices['electron_coefficient'][hi,lo]=qe
        matrices['base_pump'][lo,hi]=base
        matrices['a'][hi,lo]=a
        matrices['loss'][hi,lo]=(esc+dest)/a if a>0 else 0
        matrices['extra_radiative'][lo,hi]=up-base
        matrices['extra_radiative'][hi,lo]=down-base*result['weight'][lo]/result['weight'][hi]
    result.update(matrices)
    return result
