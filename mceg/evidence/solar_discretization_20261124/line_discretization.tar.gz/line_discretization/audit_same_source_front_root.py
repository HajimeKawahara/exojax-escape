"""Scoped implicit-linearization check of a full Fe716 fixed-profile spectrum.

The host GMRES loop checks the implicit equations, not the production JAX
root primitive or thermal/wind inference. All stellar input is analytic BB.
"""
from pathlib import Path
import argparse, hashlib, json, signal, sys, threading, time
import jax
import jax.numpy as jnp
import numpy as np
from scipy.sparse.linalg import LinearOperator, gmres
from escape.solar import SolarCompositionModel
from escape.nlte_forward import HydrogenNLTEForwardModel
from escape.hydrogen_forward import PLANET_RADIUS_CM
from escape.hydrogen_rates import LIGHT_SPEED_CGS

parser=argparse.ArgumentParser()
parser.add_argument('stage',choices=['prepare','forward','reverse','plus','minus','compare'])
args=argparse.Namespace(stage='matched_front')
root=Path('/tmp/escape-solar-molecular-continuation')
out=root/'column_fe716_average_spectrum_derivative';out.mkdir(exist_ok=True)
start=time.time();phase='construct'
def heartbeat():
    while True:
        time.sleep(25)
        print(dict(heartbeat=True,phase=phase,elapsed=time.time()-start),flush=True)
threading.Thread(target=heartbeat,daemon=True).start()
def terminated(sig,frame):
    (out/(args.stage+'_interruption.json')).write_text(json.dumps(dict(signal=sig,phase=phase,elapsed=time.time()-start))+ '\n')
    print('Received signal',sig,'at phase',phase,flush=True);raise SystemExit(128+sig)
signal.signal(signal.SIGTERM,terminated)
jax.config.update('jax_enable_x64',True)
jax.config.update('jax_compilation_cache_dir','/tmp/escape-jax-cache')
edges=np.array([0.,5e5,1e6]);temperature=jnp.array([8000.,8200.]);density=jnp.array([1e12,9e11])
model=SolarCompositionModel(edges,nmax=15,iron_levels=716,quadrature_order=2,angle_order=2,line_optical_depth_scale=1.,line_sampling='front',line_quadrature_order=4)
incoming=model.hydrogen.boundary_blackbody(10000.,.025)
seedpath=root/'current_column_fe716_copy/solution.npz'
x=jnp.asarray(np.load(seedpath)['state']).ravel();shape=(model.cells,model.state_size)
def residual(value,theta):
    target,physical=model.evaluate(value.reshape(shape),density,temperature,incoming*jnp.exp(theta))
    return jnp.where(physical['valid'],(value.reshape(shape)-target).ravel(),jnp.nan)
function=jax.jit(residual)
product=jax.jit(lambda value,theta,v:jax.jvp(lambda a:residual(a,theta),(value,),(v,))[1])
observer=HydrogenNLTEForwardModel(nlayer=2,nlon=4,nlat=4,nnu=61,nmax=15,radius_edges_rp=1+edges/PLANET_RADIUS_CM)
frequency=jnp.asarray(observer.wavenumber_cm)*LIGHT_SPEED_CGS
def spectrum(value):
    physical=model.unpack(value.reshape(shape),density)
    chi,eta=model.continuum_coefficients_at(temperature,physical,frequency)
    return observer.spectrum_from_profiles(physical['bound_cm3'][::-1],temperature[::-1],jnp.zeros(2),continuum_extinction=chi[::-1],continuum_emission=eta[::-1]*LIGHT_SPEED_CGS)
observe=jax.jit(spectrum)
cotangent=jnp.exp(-((jnp.arange(61)-30)/8)**2);cotangent=cotangent/jnp.linalg.norm(cotangent)

def save_json(name,data):(out/name).write_text(json.dumps(data,indent=2)+'\n')
def checked_linear(operator,rhs,rtol=1e-9):
    trace=[]
    def callback(error):
        trace.append(float(error));print(dict(krylov=len(trace),relative=float(error),phase=phase),flush=True)
    answer,info=gmres(operator,rhs,restart=30,maxiter=5,rtol=rtol,atol=0.,callback=callback,callback_type='pr_norm')
    error=float(np.linalg.norm(operator@answer-rhs)/np.linalg.norm(rhs))
    if not np.isfinite(rhs).all() or np.linalg.norm(rhs)==0 or info!=0 or not np.isfinite(error) or error>5*rtol:raise RuntimeError((info,error))
    return answer,dict(relative_error=error,iterations=len(trace),info=int(info))

phase='same-source front residual'
norm=float(jnp.max(jnp.abs(function(x,0.))))
phase='same-source front observer'
spec=np.asarray(observe(x))
report=dict(source_revision='cd76343',source_manifest_sha256=hashlib.sha256((root/'source_cell_average/manifest.json').read_bytes()).hexdigest(),seed_sha256=hashlib.sha256(seedpath.read_bytes()).hexdigest(),residual=norm,converged=bool(np.isfinite(norm) and norm<1e-9),finite_observer=bool(np.isfinite(spec).all()),elapsed=time.time()-start,scope='Re-evaluate the earlier front-face root at the same source as the average control; the line_sampling option is the only configuration difference.')
save_json('matched_front.json',report)
assert report['converged'] and not report['finite_observer'],report
print(report,flush=True)
