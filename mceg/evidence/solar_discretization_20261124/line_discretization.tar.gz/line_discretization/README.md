# Finite-cell line discretization and a scoped spectrum derivative

The same source at `cd76343` and the same two-cell analytic blackbody setup
give a converged population root with either line-sampling option. The front
option produces net H-alpha gain in the outer cell, outside the existing
observer domain. The average option removes this inversion in this case and
gives a finite spectrum. The observer validity rule is unchanged.

The average root has maximum residual 5.5067e-13. Its implicit JVP agrees
with independently solved positive/negative log-field perturbations to
1.1941e-6 relative spectral error. The scalar VJP/JVP difference is 1.5822e-9.
The host GMRES solves use exact JAX products and check their true residuals.
This does not establish the production JAX root primitive, thermal/wind
derivatives, spatial convergence, or a solar-atmosphere inference domain.
The current ten-element model adds sulfur; this paired control deliberately
retains the earlier nine-element composition.

The earlier front-case derivative attempt is explicitly inapplicable: a NaN
primal observer was masked to a zero tangent. It provides no derivative
support. The repaired driver requires a finite primal before differentiating.

## Replay

Retrieve the provider at `cd76343` (all source hashes are independently checked
against Git) and put its `src` and the required ExoJAX installation on PYTHONPATH.
The original drivers preserve their exact recorded bytes and paths. Change
their `/tmp/escape-solar-molecular-continuation` working root to an empty local
directory, keeping these relative artifact paths. Run `solve_column_average.py`
with a new output directory, then run the derivative driver stages `prepare`,
`forward`, `reverse`, `plus`, `minus`, `compare`. The stored final root can be
used for the isolated derivative replay; that is not a cold-start solve.

The separate negative-Federman source harness records the original C23 zero
branch and the declared extension at exactly tau=-1. Its scope is not global
smoothness or maser physics. Cloudy's altered-source license is retained.
No stellar SED, stellar-reference array, executable or compiler artifact is
included; every illumination array in this control comes from an analytic BB.
