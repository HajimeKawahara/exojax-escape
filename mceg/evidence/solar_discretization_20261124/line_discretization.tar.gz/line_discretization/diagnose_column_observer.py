from pathlib import Path
import json
import jax
import jax.numpy as jnp
import numpy as np
from escape.solar import SolarCompositionModel
from escape.nlte_forward import HydrogenNLTEForwardModel,halpha_coefficients
from escape.hydrogen_forward import PLANET_RADIUS_CM
from escape.hydrogen_rates import LIGHT_SPEED_CGS
from escape.hydrogen_molecules import molecular_continuum_coefficients,hminus_equilibrium_factor
jax.config.update('jax_enable_x64',True)
jax.config.update('jax_compilation_cache_dir','/tmp/escape-jax-cache')
r=Path('/tmp/escape-solar-molecular-continuation/column_fe716_spectrum_derivative')
model=SolarCompositionModel([0.,5e5,1e6],nmax=15,iron_levels=716,quadrature_order=2,angle_order=2,line_optical_depth_scale=1.)
t=jnp.array([8000.,8200.]);density=jnp.array([1e12,9e11]);x=jnp.asarray(np.load(r/'prepared.npz')['state']).reshape(2,model.state_size)
p=model.unpack(x,density)
obs=HydrogenNLTEForwardModel(nlayer=2,nlon=4,nlat=4,nnu=61,nmax=15,radius_edges_rp=1+np.array([0.,5e5,1e6])/PLANET_RADIUS_CM)
f=jnp.asarray(obs.wavenumber_cm)*LIGHT_SPEED_CGS
chi,eta=model.continuum_coefficients_at(t,p,f)
a,e=halpha_coefficients(p['bound_cm3'],obs.line_center_cm,sum_branches=False)
profile=jax.vmap(obs._line_profiles)(t,jnp.zeros(2))
line=jnp.sum(a[:,:,None]*profile,axis=1);total=chi+line
np.savez_compressed(r/'observer_coefficients.npz',chi=np.asarray(chi),eta=np.asarray(eta),line=np.asarray(line),profile=np.asarray(profile),line_weights=np.asarray(a),line_emission=np.asarray(e))
report={k:np.asarray(p[k]).tolist() for k in ['electron_cm3','proton_cm3','molecule_cm3']}
report.update(bound_low=np.asarray(p['bound_cm3'][:,:6]).tolist(),continuum_min=np.asarray(chi.min(1)).tolist(),continuum_max=np.asarray(chi.max(1)).tolist(),emissivity_min=np.asarray(eta.min(1)).tolist(),emissivity_max=np.asarray(eta.max(1)).tolist(),line_weights=np.asarray(a).tolist(),total_extinction_min=np.asarray(total.min(1)).tolist(),total_extinction_max=np.asarray(total.max(1)).tolist(),line_profile_finite=bool(jnp.isfinite(profile).all()),geometry_finite=bool(jnp.isfinite(jnp.asarray(obs.geometry)).all()))
(r/'observer_diagnosis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
