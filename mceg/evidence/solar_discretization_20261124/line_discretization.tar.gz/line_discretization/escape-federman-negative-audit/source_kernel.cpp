#include <cmath>
#include <limits>
#include <cstdlib>
#include <cstdio>
#define STATIC
#define MAX2(a,b) ((a)>(b)?(a):(b))
#define TotalInsanity() abort()
using std::log;
const float SMALLFLOAT=std::numeric_limits<float>::min()*100.f;
STATIC double avg_shield(double s1, double s2, double dTau, double tau)
{
	enum options { AVG_OLD, AVG_DEPTH, AVG_NO, AVG_BACK, AVG_ARITH, 
						AVG_GEOM, AVG_COUNT };
	const enum options opt = AVG_DEPTH;
	if (opt == AVG_OLD)
	{
		return s1*log(1.+dTau)/dTau;
	}
	else if (opt == AVG_DEPTH)
	{
		// Average (1+tau)/(1+tau+dTau) over zone...
		/* Masers in last levels can give a negative value for dTauRel,
		 * in that case use SMALLFLOAT */
		double dTauRel = MAX2(dTau/(1.+tau),SMALLFLOAT);
		return s1*log(1.+dTauRel)/dTauRel;
	}
	else if (opt == AVG_NO)
	{
		return s1; // no shielding
	}
	else if (opt == AVG_BACK)
	{
		return s2; // implicit
	}
	else if (opt == AVG_ARITH)
	{
		return 0.5*(s1+s2); // Arithmetic average
	}
	else if (opt == AVG_GEOM)
	{
		return sqrt(s1*s2); // Geometric average
	}
	else if (opt == AVG_COUNT)
	{
		return (s1-s2)/dTau; // photon counting estimate [?]
	}
	TotalInsanity(); // invalid option
}

int main(){double ts[]={-29.,-2.,-1.0095126033145931,-1.000001,-1.,-.999999,-.5,0.,1.};double ds[]={.0011,.1,1.,1e8}; for(double t:ts)for(double d:ds)printf("%.17g %.17g %.17g\n",t,d,avg_shield(1.,1.,d,t));}
