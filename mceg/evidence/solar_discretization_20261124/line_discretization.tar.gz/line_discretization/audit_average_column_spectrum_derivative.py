"""Scoped implicit-linearization check of a full Fe716 fixed-profile spectrum.

The host GMRES loop checks the implicit equations, not the production JAX
root primitive or thermal/wind inference. All stellar input is analytic BB.
"""
from pathlib import Path
import argparse, hashlib, json, signal, sys, threading, time
import jax
import jax.numpy as jnp
import numpy as np
from scipy.sparse.linalg import LinearOperator, gmres
from escape.solar import SolarCompositionModel
from escape.nlte_forward import HydrogenNLTEForwardModel
from escape.hydrogen_forward import PLANET_RADIUS_CM
from escape.hydrogen_rates import LIGHT_SPEED_CGS

parser=argparse.ArgumentParser()
parser.add_argument('stage',choices=['prepare','forward','reverse','plus','minus','compare'])
args=parser.parse_args()
root=Path('/tmp/escape-solar-molecular-continuation')
out=root/'column_fe716_average_spectrum_derivative';out.mkdir(exist_ok=True)
start=time.time();phase='construct'
def heartbeat():
    while True:
        time.sleep(25)
        print(dict(heartbeat=True,phase=phase,elapsed=time.time()-start),flush=True)
threading.Thread(target=heartbeat,daemon=True).start()
def terminated(sig,frame):
    (out/(args.stage+'_interruption.json')).write_text(json.dumps(dict(signal=sig,phase=phase,elapsed=time.time()-start))+ '\n')
    print('Received signal',sig,'at phase',phase,flush=True);raise SystemExit(128+sig)
signal.signal(signal.SIGTERM,terminated)
jax.config.update('jax_enable_x64',True)
jax.config.update('jax_compilation_cache_dir','/tmp/escape-jax-cache')
edges=np.array([0.,5e5,1e6]);temperature=jnp.array([8000.,8200.]);density=jnp.array([1e12,9e11])
model=SolarCompositionModel(edges,nmax=15,iron_levels=716,quadrature_order=2,angle_order=2,line_optical_depth_scale=1.,line_sampling='average',line_quadrature_order=4)
incoming=model.hydrogen.boundary_blackbody(10000.,.025)
seedpath=root/'current_column_fe716_average/checkpoint.npz'
x=jnp.asarray(np.load(seedpath)['state']).ravel();shape=(model.cells,model.state_size)
def residual(value,theta):
    target,physical=model.evaluate(value.reshape(shape),density,temperature,incoming*jnp.exp(theta))
    return jnp.where(physical['valid'],(value.reshape(shape)-target).ravel(),jnp.nan)
function=jax.jit(residual)
product=jax.jit(lambda value,theta,v:jax.jvp(lambda a:residual(a,theta),(value,),(v,))[1])
observer=HydrogenNLTEForwardModel(nlayer=2,nlon=4,nlat=4,nnu=61,nmax=15,radius_edges_rp=1+edges/PLANET_RADIUS_CM)
frequency=jnp.asarray(observer.wavenumber_cm)*LIGHT_SPEED_CGS
def spectrum(value):
    physical=model.unpack(value.reshape(shape),density)
    chi,eta=model.continuum_coefficients_at(temperature,physical,frequency)
    return observer.spectrum_from_profiles(physical['bound_cm3'][::-1],temperature[::-1],jnp.zeros(2),continuum_extinction=chi[::-1],continuum_emission=eta[::-1]*LIGHT_SPEED_CGS)
observe=jax.jit(spectrum)
cotangent=jnp.exp(-((jnp.arange(61)-30)/8)**2);cotangent=cotangent/jnp.linalg.norm(cotangent)

def save_json(name,data):(out/name).write_text(json.dumps(data,indent=2)+'\n')
def checked_linear(operator,rhs,rtol=1e-9):
    trace=[]
    def callback(error):
        trace.append(float(error));print(dict(krylov=len(trace),relative=float(error),phase=phase),flush=True)
    answer,info=gmres(operator,rhs,restart=30,maxiter=5,rtol=rtol,atol=0.,callback=callback,callback_type='pr_norm')
    error=float(np.linalg.norm(operator@answer-rhs)/np.linalg.norm(rhs))
    if not np.isfinite(rhs).all() or np.linalg.norm(rhs)==0 or info!=0 or not np.isfinite(error) or error>5*rtol:raise RuntimeError((info,error))
    return answer,dict(relative_error=error,iterations=len(trace),info=int(info))

if args.stage=='prepare':
    phase='primal residual';f=np.asarray(function(x,0.));norm=float(abs(f).max())
    if not np.isfinite(norm) or norm>1e-9:raise RuntimeError(('seed is not a current-source root',norm))
    phase='finite primal observer'
    spec=np.asarray(observe(x))
    if not np.isfinite(spec).all():
        save_json('observer_failure.json',dict(finite=False,root_residual=norm,reason='Observer applicability must pass before differentiating.'))
        raise RuntimeError('Nonfinite primal spectrum; derivative control is inapplicable')
    phase='radiation derivative'
    rhs=np.asarray(jax.jit(lambda v:jax.jvp(lambda t:residual(v,t),(jnp.array(0.),),(jnp.array(1.),))[1])(x))
    np.savez_compressed(out/'prepared.npz',state=np.asarray(x),field_derivative=rhs,spectrum=spec,wavenumber_cm=np.asarray(observer.wavenumber_cm),cotangent=np.asarray(cotangent))
    save_json('configuration.json',dict(scope=__doc__,source_snapshot='source_cell_average/manifest.json',source_manifest_sha256=hashlib.sha256((root/'source_cell_average/manifest.json').read_bytes()).hexdigest(),seed_sha256=hashlib.sha256(seedpath.read_bytes()).hexdigest(),driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),root_residual=norm,cells=2,iron_levels=716,nmax=15,temperature_k=np.asarray(temperature).tolist(),n_h_cm3=np.asarray(density).tolist(),edges_cm=edges.tolist(),elapsed=time.time()-start))
elif args.stage=='forward':
    prepared=np.load(out/'prepared.npz');rhs=-prepared['field_derivative']
    phase='implicit JVP'
    operator=LinearOperator((x.size,x.size),dtype=float,matvec=lambda v:np.array(product(x,0.,v),copy=True))
    tangent,metrics=checked_linear(operator,rhs)
    phase='spectral tangent'
    derivative=np.asarray(jax.jit(lambda v:jax.jvp(spectrum,(x,),(v,))[1])(jnp.asarray(tangent)))
    if not np.isfinite(derivative).all() or np.max(abs(derivative))==0:raise RuntimeError('Nonfinite or uninformative spectral derivative')
    np.savez_compressed(out/'forward.npz',state_derivative=tangent,spectrum_derivative=derivative)
    save_json('forward.json',dict(**metrics,elapsed=time.time()-start))
elif args.stage=='reverse':
    phase='spectral gradient'
    gradient=np.asarray(jax.jit(jax.grad(lambda value:jnp.vdot(cotangent,spectrum(value))))(x))
    phase='implicit VJP'
    transpose=jax.jit(lambda v:jax.vjp(lambda a:residual(a,0.),x)[1](v)[0])
    operator=LinearOperator((x.size,x.size),dtype=float,matvec=lambda v:np.array(transpose(v),copy=True))
    adjoint,metrics=checked_linear(operator,gradient)
    field=np.load(out/'prepared.npz')['field_derivative']
    reverse=-float(np.vdot(adjoint,field))
    forward=float(np.vdot(np.asarray(cotangent),np.load(out/'forward.npz')['spectrum_derivative']))
    save_json('reverse.json',dict(**metrics,reverse=reverse,forward=forward,relative_difference=abs(reverse-forward)/max(abs(reverse),abs(forward),1e-300),elapsed=time.time()-start))
elif args.stage in ('plus','minus'):
    step=1e-3 if args.stage=='plus' else -1e-3
    value=np.array(x);path=out/(args.stage+'_state.npz')
    if path.exists():value=np.load(path)['state']
    phase='independent nearby root';history=[]
    for i in range(12):
        current=np.asarray(function(value,step));norm=float(abs(current).max())
        if norm<1e-11:break
        operator=LinearOperator((x.size,x.size),dtype=float,matvec=lambda v:np.array(product(value,step,v),copy=True))
        correction,metrics=checked_linear(operator,-current,rtol=1e-5)
        accepted=False
        for backtrack in range(12):
            candidate=value+2.**(-backtrack)*correction
            score=float(abs(function(candidate,step)).max())
            if np.isfinite(score) and score<norm:value=candidate;accepted=True;break
        history.append(dict(iteration=i,residual=score,accepted=accepted,backtrack=backtrack,**metrics));print(history[-1],flush=True)
        np.savez_compressed(path,state=value)
        if not accepted:raise RuntimeError('Nearby root did not progress')
        if time.time()-start>300:break
    norm=float(abs(function(value,step)).max())
    save_json(args.stage+'.json',dict(theta=step,residual=norm,history=history,converged=bool(norm<1e-11),elapsed=time.time()-start))
    if norm<1e-11:
        spec=np.asarray(observe(value))
        if not np.isfinite(spec).all():raise RuntimeError('Nearby root has an inapplicable observer')
        np.savez_compressed(out/(args.stage+'_spectrum.npz'),spectrum=spec)
else:
    plus=np.load(out/'plus_spectrum.npz')['spectrum'];minus=np.load(out/'minus_spectrum.npz')['spectrum']
    fd=(plus-minus)/.002;ad=np.load(out/'forward.npz')['spectrum_derivative']
    if not (np.isfinite(plus).all() and np.isfinite(minus).all() and np.isfinite(ad).all()):raise RuntimeError('Nonfinite observable')
    norm=float(np.max(abs(ad-fd))/max(np.max(abs(fd)),1e-300))
    save_json('comparison.json',dict(maximum_error_over_maximum_spectral_derivative=norm,maximum_derivative_per_logfield=float(np.max(abs(ad))),scope=__doc__))
print(dict(stage=args.stage,completed=True,elapsed=time.time()-start),flush=True)
